from typing import TYPE_CHECKING


# Attempt to import the optional module
try:
    from grpc.aio import Channel  # type: ignore[reportMissingModuleSource]
except ImportError:
    # If grpc.aio is not available, define a stub type for type checking.
    # This stub type will only be used by type checkers.
    if TYPE_CHECKING:

        class Channel:  # type: ignore[no-redef]
            """Stub class for type hinting when grpc.aio is not available."""

            async def close(self, grace: float | None = None) -> None:
                """Stub for Channel.close."""

    else:
        Channel = None  # At runtime, pd will be None if the import failed.
