import logging
import unittest

from a2a.server.request_handlers.response_helpers import (
    agent_card_to_dict,
    build_error_response,
    prepare_response_object,
)
from a2a.types import (
    InvalidParamsError,
    TaskNotFoundError,
)
from a2a.types.a2a_pb2 import (
    AgentCapabilities,
    AgentCard,
    AgentInterface,
    AgentSkill,
    Task,
    TaskState,
    TaskStatus,
)
from google.protobuf.json_format import MessageToDict


class TestResponseHelpers(unittest.TestCase):
    def test_agent_card_to_dict_without_extended_card(self) -> None:
        card = AgentCard(
            name='Test Agent',
            description='Test Description',
            version='1.0',
            capabilities=AgentCapabilities(extended_agent_card=False),
            supported_interfaces=[
                AgentInterface(
                    url='http://jsonrpc.v03.com',
                    protocol_binding='JSONRPC',
                    protocol_version='0.3',
                ),
            ],
        )
        result = agent_card_to_dict(card)
        self.assertNotIn('supportsAuthenticatedExtendedCard', result)
        self.assertEqual(result['name'], 'Test Agent')

    def test_agent_card_to_dict_with_extended_card(self) -> None:
        card = AgentCard(
            name='Test Agent',
            description='Test Description',
            version='1.0',
            capabilities=AgentCapabilities(extended_agent_card=True),
            supported_interfaces=[
                AgentInterface(
                    url='http://jsonrpc.v03.com',
                    protocol_binding='JSONRPC',
                    protocol_version='0.3',
                ),
            ],
        )
        result = agent_card_to_dict(card)
        self.assertIn('supportsAuthenticatedExtendedCard', result)
        self.assertTrue(result['supportsAuthenticatedExtendedCard'])
        self.assertEqual(result['name'], 'Test Agent')

    def test_agent_card_to_dict_all_transports_all_versions(self) -> None:
        card = AgentCard(
            name='Complex Agent',
            description='Agent with many interfaces',
            version='1.2.3',
            supported_interfaces=[
                AgentInterface(
                    url='http://jsonrpc.v10.com',
                    protocol_binding='JSONRPC',
                    protocol_version='1.0.0',
                ),
                AgentInterface(
                    url='http://jsonrpc.v03.com',
                    protocol_binding='JSONRPC',
                    protocol_version='0.3.0',
                ),
                AgentInterface(
                    url='http://grpc.v10.com',
                    protocol_binding='GRPC',
                    protocol_version='1.0.0',
                ),
                AgentInterface(
                    url='http://grpc.v03.com',
                    protocol_binding='GRPC',
                    protocol_version='0.3.0',
                ),
                AgentInterface(
                    url='http://httpjson.v10.com',
                    protocol_binding='HTTP+JSON',
                    protocol_version='1.0.0',
                ),
                AgentInterface(
                    url='http://httpjson.v03.com',
                    protocol_binding='HTTP+JSON',
                    protocol_version='0.3.0',
                ),
            ],
        )

        result = agent_card_to_dict(card)

        expected = {
            'name': 'Complex Agent',
            'description': 'Agent with many interfaces',
            'version': '1.2.3',
            'supportedInterfaces': [
                {
                    'url': 'http://jsonrpc.v10.com',
                    'protocolBinding': 'JSONRPC',
                    'protocolVersion': '1.0.0',
                },
                {
                    'url': 'http://jsonrpc.v03.com',
                    'protocolBinding': 'JSONRPC',
                    'protocolVersion': '0.3.0',
                },
                {
                    'url': 'http://grpc.v10.com',
                    'protocolBinding': 'GRPC',
                    'protocolVersion': '1.0.0',
                },
                {
                    'url': 'http://grpc.v03.com',
                    'protocolBinding': 'GRPC',
                    'protocolVersion': '0.3.0',
                },
                {
                    'url': 'http://httpjson.v10.com',
                    'protocolBinding': 'HTTP+JSON',
                    'protocolVersion': '1.0.0',
                },
                {
                    'url': 'http://httpjson.v03.com',
                    'protocolBinding': 'HTTP+JSON',
                    'protocolVersion': '0.3.0',
                },
            ],
            # Compatibility fields (v0.3)
            'url': 'http://jsonrpc.v03.com',
            'preferredTransport': 'JSONRPC',
            'protocolVersion': '0.3.0',
            'additionalInterfaces': [
                {'url': 'http://grpc.v03.com', 'transport': 'GRPC'},
                {'url': 'http://httpjson.v03.com', 'transport': 'HTTP+JSON'},
            ],
            'capabilities': {},
            'defaultInputModes': [],
            'defaultOutputModes': [],
            'skills': [],
        }

        self.assertEqual(result, expected)

    def test_agent_card_to_dict_only_1_0_interfaces(self) -> None:
        card = AgentCard(
            name='Modern Agent',
            description='Agent with only 1.0 interfaces',
            version='2.0.0',
            supported_interfaces=[
                AgentInterface(
                    url='http://jsonrpc.v10.com',
                    protocol_binding='JSONRPC',
                    protocol_version='1.0.0',
                ),
            ],
        )

        result = agent_card_to_dict(card)

        expected = {
            'name': 'Modern Agent',
            'description': 'Agent with only 1.0 interfaces',
            'version': '2.0.0',
            'supportedInterfaces': [
                {
                    'url': 'http://jsonrpc.v10.com',
                    'protocolBinding': 'JSONRPC',
                    'protocolVersion': '1.0.0',
                },
            ],
        }

        self.assertEqual(result, expected)

    def test_agent_card_to_dict_single_interface_no_version(self) -> None:
        card = AgentCard(
            name='Legacy Agent',
            description='Agent with no protocol version',
            version='1.0.0',
            supported_interfaces=[
                AgentInterface(
                    url='http://jsonrpc.legacy.com',
                    protocol_binding='JSONRPC',
                ),
            ],
        )

        result = agent_card_to_dict(card)

        expected = {
            'name': 'Legacy Agent',
            'description': 'Agent with no protocol version',
            'version': '1.0.0',
            'supportedInterfaces': [
                {
                    'url': 'http://jsonrpc.legacy.com',
                    'protocolBinding': 'JSONRPC',
                },
            ],
            # Compatibility fields (v0.3)
            'url': 'http://jsonrpc.legacy.com',
            'preferredTransport': 'JSONRPC',
            'protocolVersion': '0.3',
            'capabilities': {},
            'defaultInputModes': [],
            'defaultOutputModes': [],
            'skills': [],
        }

        self.assertEqual(result, expected)

    def test_build_error_response_with_a2a_error(self) -> None:
        request_id = 'req1'
        specific_error = TaskNotFoundError()
        response = build_error_response(request_id, specific_error)

        # Response is now a dict with JSON-RPC 2.0 structure
        self.assertIsInstance(response, dict)
        self.assertEqual(response.get('jsonrpc'), '2.0')
        self.assertEqual(response.get('id'), request_id)
        self.assertIn('error', response)
        self.assertEqual(response['error']['code'], -32001)
        self.assertEqual(response['error']['message'], specific_error.message)

    def test_build_error_response_with_jsonrpc_error(self) -> None:
        request_id = 123
        json_rpc_error = InvalidParamsError(message='Custom invalid params')
        response = build_error_response(request_id, json_rpc_error)

        self.assertIsInstance(response, dict)
        self.assertEqual(response.get('jsonrpc'), '2.0')
        self.assertEqual(response.get('id'), request_id)
        self.assertIn('error', response)
        self.assertEqual(response['error']['code'], -32602)
        self.assertEqual(response['error']['message'], json_rpc_error.message)

    def test_build_error_response_with_invalid_params_error(self) -> None:
        request_id = 'req_wrap'
        specific_jsonrpc_error = InvalidParamsError(message='Detail error')
        response = build_error_response(request_id, specific_jsonrpc_error)

        self.assertIsInstance(response, dict)
        self.assertEqual(response.get('jsonrpc'), '2.0')
        self.assertEqual(response.get('id'), request_id)
        self.assertIn('error', response)
        self.assertEqual(response['error']['code'], -32602)
        self.assertEqual(
            response['error']['message'], specific_jsonrpc_error.message
        )

    def test_build_error_response_data_is_typed_details_array(self) -> None:
        """error.data must be an array of typed-detail objects, with a
        leading google.rpc.ErrorInfo carrying the canonical reason."""
        error = TaskNotFoundError(data={'taskId': 'abc-123'})
        response = build_error_response('req-typed', error)

        data = response['error']['data']
        self.assertIsInstance(data, list)
        self.assertEqual(len(data), 1)
        self.assertEqual(
            data[0],
            {
                '@type': 'type.googleapis.com/google.rpc.ErrorInfo',
                'reason': 'TASK_NOT_FOUND',
                'domain': 'a2a-protocol.org',
                'metadata': {'taskId': 'abc-123'},
            },
        )

    def test_build_error_response_invalid_params_appends_bad_request(
        self,
    ) -> None:
        """InvalidParamsError carrying validation errors must append a
        BadRequest typed-detail entry alongside ErrorInfo."""
        error = InvalidParamsError(
            message='Validation failed',
            data={
                'errors': [
                    {
                        'field': 'message.parts',
                        'message': 'At least one required',
                    },
                    {'field': 'message.role', 'message': 'Unknown role'},
                ]
            },
        )
        response = build_error_response('req-bad', error)

        data = response['error']['data']
        self.assertEqual(len(data), 2)
        error_info, bad_request = data
        self.assertEqual(
            error_info['@type'],
            'type.googleapis.com/google.rpc.ErrorInfo',
        )
        self.assertEqual(error_info['reason'], 'INVALID_PARAMS')
        self.assertEqual(
            bad_request,
            {
                '@type': 'type.googleapis.com/google.rpc.BadRequest',
                'fieldViolations': [
                    {
                        'field': 'message.parts',
                        'description': 'At least one required',
                    },
                    {
                        'field': 'message.role',
                        'description': 'Unknown role',
                    },
                ],
            },
        )

    def test_build_error_response_no_data_yields_empty_metadata(self) -> None:
        """An A2AError with no data still produces a single
        ErrorInfo entry with an empty metadata dict (per AIP-193)."""
        error = TaskNotFoundError()
        response = build_error_response('req-empty', error)
        data = response['error']['data']
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]['metadata'], {})

    def test_build_error_response_with_request_id_string(self) -> None:
        request_id = 'string_id_test'
        error = TaskNotFoundError()
        response = build_error_response(request_id, error)

        self.assertIsInstance(response, dict)
        self.assertIn('error', response)
        self.assertEqual(response.get('id'), request_id)

    def test_build_error_response_with_request_id_int(self) -> None:
        request_id = 456
        error = TaskNotFoundError()
        response = build_error_response(request_id, error)

        self.assertIsInstance(response, dict)
        self.assertIn('error', response)
        self.assertEqual(response.get('id'), request_id)

    def test_build_error_response_with_request_id_none(self) -> None:
        request_id = None
        error = TaskNotFoundError()
        response = build_error_response(request_id, error)

        self.assertIsInstance(response, dict)
        self.assertIn('error', response)
        self.assertIsNone(response.get('id'))

    def _create_sample_task(
        self, task_id: str = 'task123', context_id: str = 'ctx456'
    ) -> Task:
        return Task(
            id=task_id,
            context_id=context_id,
            status=TaskStatus(state=TaskState.TASK_STATE_SUBMITTED),
            history=[],
        )

    def test_prepare_response_object_with_proto_message(self) -> None:
        request_id = 'req_success'
        task_result = self._create_sample_task()
        response = prepare_response_object(
            request_id=request_id,
            response=task_result,
            success_response_types=(Task,),
        )

        # Response is now a dict with JSON-RPC 2.0 structure
        self.assertIsInstance(response, dict)
        self.assertEqual(response.get('jsonrpc'), '2.0')
        self.assertEqual(response.get('id'), request_id)
        self.assertIn('result', response)
        # Result is the proto message converted to dict
        expected_result = MessageToDict(
            task_result, preserving_proto_field_name=False
        )
        self.assertEqual(response['result'], expected_result)

    def test_prepare_response_object_with_error(self) -> None:
        request_id = 'req_error'
        error = TaskNotFoundError()
        response = prepare_response_object(
            request_id=request_id,
            response=error,
            success_response_types=(Task,),
        )

        self.assertIsInstance(response, dict)
        self.assertEqual(response.get('jsonrpc'), '2.0')
        self.assertEqual(response.get('id'), request_id)
        self.assertIn('error', response)
        self.assertEqual(response['error']['code'], -32001)

    def test_prepare_response_object_with_invalid_response(self) -> None:
        request_id = 'req_invalid'
        invalid_response = object()
        response = prepare_response_object(
            request_id=request_id,
            response=invalid_response,  # type: ignore
            success_response_types=(Task,),
        )

        # Should return an InvalidAgentResponseError
        self.assertIsInstance(response, dict)
        self.assertIn('error', response)
        # Check that it's an InvalidAgentResponseError (code -32006)
        self.assertEqual(response['error']['code'], -32006)


if __name__ == '__main__':
    unittest.main()


class TestAgentCardToDictRequiredFields(unittest.TestCase):
    def test_warns_when_required_fields_are_missing(self) -> None:
        with self.assertLogs('a2a.utils.proto_utils', logging.WARNING) as logs:
            result = agent_card_to_dict(AgentCard(name='partial'))
        self.assertEqual(result['name'], 'partial')
        [message] = logs.output
        self.assertIn('agent_card passed to agent_card_to_dict:', message)
        self.assertIn('description', message)

    def test_complete_card_does_not_warn(self) -> None:
        card = AgentCard(
            name='complete_agent',
            description='An agent card with all required fields.',
            supported_interfaces=[
                AgentInterface(
                    url='http://localhost:8000',
                    protocol_binding='JSONRPC',
                    protocol_version='1.0',
                )
            ],
            version='1.0',
            capabilities=AgentCapabilities(),
            default_input_modes=['text/plain'],
            default_output_modes=['text/plain'],
            skills=[
                AgentSkill(
                    id='echo',
                    name='Echo',
                    description='Echoes the input.',
                    tags=['test'],
                )
            ],
        )
        with self.assertNoLogs('a2a.utils.proto_utils', logging.WARNING):
            agent_card_to_dict(card)
