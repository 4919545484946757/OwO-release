import asyncio
import concurrent.futures
import threading

from base64 import urlsafe_b64encode
from datetime import datetime, timedelta, timezone

import pytest

from a2a.auth.user import User
from a2a.server.context import ServerCallContext
from a2a.server.tasks import InMemoryTaskStore
from a2a.types.a2a_pb2 import ListTasksRequest, Task, TaskState, TaskStatus
from a2a.utils.constants import DEFAULT_LIST_TASKS_PAGE_SIZE
from a2a.utils.errors import InvalidParamsError
from a2a.utils.task import decode_list_tasks_cursor


class SampleUser(User):
    """A test implementation of the User interface."""

    def __init__(self, user_name: str):
        self._user_name = user_name

    @property
    def is_authenticated(self) -> bool:
        return True

    @property
    def user_name(self) -> str:
        return self._user_name


TEST_CONTEXT = ServerCallContext(user=SampleUser('test_user'))


def _decoded_cursor(page_token: str) -> tuple[datetime | None, str] | None:
    """The (timestamp, task ID) a page token resumes after; None on the last page."""
    if not page_token:
        return None
    cursor = decode_list_tasks_cursor(page_token)
    assert cursor is not None, 'expected a cursor token, not a legacy one'
    timestamp = (
        datetime(1970, 1, 1, tzinfo=timezone.utc)
        + timedelta(microseconds=cursor.timestamp_ns // 1_000)
        if cursor.timestamp_ns is not None
        else None
    )
    return (timestamp, cursor.task_id)


def create_minimal_task(
    task_id: str = 'task-abc', context_id: str = 'session-xyz'
) -> Task:
    """Create a minimal task for testing."""
    return Task(
        id=task_id,
        context_id=context_id,
        status=TaskStatus(state=TaskState.TASK_STATE_SUBMITTED),
    )


@pytest.mark.asyncio
async def test_in_memory_task_store_save_and_get() -> None:
    """Test saving and retrieving a task from the in-memory store."""
    store = InMemoryTaskStore()
    task = create_minimal_task()
    await store.save(task, TEST_CONTEXT)
    retrieved_task = await store.get('task-abc', TEST_CONTEXT)
    assert retrieved_task == task


@pytest.mark.asyncio
async def test_in_memory_task_store_get_nonexistent() -> None:
    """Test retrieving a nonexistent task."""
    store = InMemoryTaskStore()
    retrieved_task = await store.get('nonexistent', TEST_CONTEXT)
    assert retrieved_task is None


@pytest.mark.asyncio
@pytest.mark.parametrize(
    'params, expected_ids, total_count, next_cursor',
    [
        # No parameters, should return all tasks
        (
            ListTasksRequest(),
            ['task-2', 'task-1', 'task-0', 'task-4', 'task-3'],
            5,
            None,
        ),
        # Unknown context
        (
            ListTasksRequest(context_id='nonexistent'),
            [],
            0,
            None,
        ),
        # Pagination (first page)
        (
            ListTasksRequest(page_size=2),
            ['task-2', 'task-1'],
            5,
            (datetime(2025, 1, 1, tzinfo=timezone.utc), 'task-1'),
        ),
        # Pagination (same timestamp)
        (
            ListTasksRequest(
                page_size=2,
                page_token='dGFzay0x',  # base64 for 'task-1'
            ),
            ['task-1', 'task-0'],
            5,
            (datetime(2025, 1, 1, tzinfo=timezone.utc), 'task-0'),
        ),
        # Pagination (final page)
        (
            ListTasksRequest(
                page_size=2,
                page_token='dGFzay0z',  # base64 for 'task-3'
            ),
            ['task-3'],
            5,
            None,
        ),
        # Filtering by context_id
        (
            ListTasksRequest(context_id='context-1'),
            ['task-1', 'task-3'],
            2,
            None,
        ),
        # Filtering by status
        (
            ListTasksRequest(status=TaskState.TASK_STATE_WORKING),
            ['task-1', 'task-3'],
            2,
            None,
        ),
        # Combined filtering (context_id and status)
        (
            ListTasksRequest(
                context_id='context-0', status=TaskState.TASK_STATE_SUBMITTED
            ),
            ['task-2', 'task-0'],
            2,
            None,
        ),
        # Combined filtering and pagination
        (
            ListTasksRequest(
                context_id='context-0',
                page_size=1,
            ),
            ['task-2'],
            3,
            (datetime(2025, 1, 2, tzinfo=timezone.utc), 'task-2'),
        ),
    ],
)
async def test_list_tasks(
    params: ListTasksRequest,
    expected_ids: list[str],
    total_count: int,
    next_cursor: tuple[datetime, str] | None,
) -> None:
    """Test listing tasks with various filters and pagination."""
    store = InMemoryTaskStore()
    tasks_to_create = [
        Task(
            id='task-0',
            context_id='context-0',
            status=TaskStatus(
                state=TaskState.TASK_STATE_SUBMITTED,
                timestamp=datetime(2025, 1, 1, tzinfo=timezone.utc),
            ),
        ),
        Task(
            id='task-1',
            context_id='context-1',
            status=TaskStatus(
                state=TaskState.TASK_STATE_WORKING,
                timestamp=datetime(2025, 1, 1, tzinfo=timezone.utc),
            ),
        ),
        Task(
            id='task-2',
            context_id='context-0',
            status=TaskStatus(
                state=TaskState.TASK_STATE_SUBMITTED,
                timestamp=datetime(2025, 1, 2, tzinfo=timezone.utc),
            ),
        ),
        Task(
            id='task-3',
            context_id='context-1',
            status=TaskStatus(state=TaskState.TASK_STATE_WORKING),
        ),
        Task(
            id='task-4',
            context_id='context-0',
            status=TaskStatus(state=TaskState.TASK_STATE_COMPLETED),
        ),
    ]
    for task in tasks_to_create:
        await store.save(task, TEST_CONTEXT)

    page = await store.list(params, TEST_CONTEXT)

    retrieved_ids = [task.id for task in page.tasks]
    assert retrieved_ids == expected_ids
    assert page.total_size == total_count
    assert _decoded_cursor(page.next_page_token) == next_cursor
    assert page.page_size == (params.page_size or DEFAULT_LIST_TASKS_PAGE_SIZE)

    # Cleanup
    for task in tasks_to_create:
        await store.delete(task.id, TEST_CONTEXT)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    'params, expected_error_message',
    [
        (
            ListTasksRequest(
                page_size=2,
                page_token='invalid',
            ),
            'Token is not a valid base64-encoded cursor.',
        ),
        (
            ListTasksRequest(
                page_size=2,
                page_token='dGFzay0xMDA=',  # base64 for 'task-100'
            ),
            'Invalid page token: dGFzay0xMDA=',
        ),
    ],
)
async def test_list_tasks_fails(
    params: ListTasksRequest, expected_error_message: str
) -> None:
    """Test listing tasks with invalid parameters that should fail."""
    store = InMemoryTaskStore()
    tasks_to_create = [
        Task(
            id='task-0',
            context_id='context-0',
            status=TaskStatus(
                state=TaskState.TASK_STATE_SUBMITTED,
                timestamp=datetime(2025, 1, 1, tzinfo=timezone.utc),
            ),
        ),
        Task(
            id='task-1',
            context_id='context-1',
            status=TaskStatus(
                state=TaskState.TASK_STATE_WORKING,
                timestamp=datetime(2025, 1, 1, tzinfo=timezone.utc),
            ),
        ),
    ]
    for task in tasks_to_create:
        await store.save(task, TEST_CONTEXT)

    with pytest.raises(InvalidParamsError) as excinfo:
        await store.list(params, TEST_CONTEXT)

    assert expected_error_message in str(excinfo.value)

    # Cleanup
    for task in tasks_to_create:
        await store.delete(task.id, TEST_CONTEXT)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    'task_time, threshold, included',
    [
        ('00Z', '00.001Z', False),
        ('00.001Z', '00Z', True),
        ('00.123Z', '00.123001Z', False),
        ('00.123001Z', '00.123Z', True),
        ('00.123Z', '00.123000001Z', False),
        ('00.123000001Z', '00.123Z', True),
        ('00.123001Z', '00.123001001Z', False),
        ('00.123001001Z', '00.123001Z', True),
        ('00.123Z', '00.123Z', True),
        ('00.123000001Z', '00.123000001Z', True),
        ('00.999999999Z', '01Z', False),
        ('01Z', '00.999999999Z', True),
    ],
)
async def test_list_tasks_timestamp_filter_precision(
    task_time: str, threshold: str, included: bool
) -> None:
    """Compare timestamp values across JSON fractional-second precisions."""
    store = InMemoryTaskStore()
    task = create_minimal_task()
    task.status.timestamp.FromJsonString(f'2025-01-01T00:00:{task_time}')
    await store.save(task, TEST_CONTEXT)
    await store.save(create_minimal_task('no-timestamp'), TEST_CONTEXT)
    await store.save(Task(id='no-status'), TEST_CONTEXT)
    params = ListTasksRequest()
    params.status_timestamp_after.FromJsonString(
        f'2025-01-01T00:00:{threshold}'
    )

    page = await store.list(params, TEST_CONTEXT)

    assert [result.id for result in page.tasks] == (
        [task.id] if included else []
    )
    assert page.total_size == int(included)


@pytest.mark.asyncio
@pytest.mark.parametrize('page_size', [1, 3, 20])
async def test_list_tasks_timestamp_ordering_and_pagination(
    page_size: int,
) -> None:
    """Keep chronological order and ID tie-breaking across page boundaries."""
    store = InMemoryTaskStore()
    # Chronological order, including timestamps before and at the Unix epoch.
    timestamps = [
        '1969-12-31T23:59:59.999999999Z',
        '1970-01-01T00:00:00Z',
        '2025-01-01T00:00:00Z',
        '2025-01-01T00:00:00.123Z',
        '2025-01-01T00:00:00.123000001Z',
        '2025-01-01T00:00:00.123001Z',
        '2025-01-01T00:00:00.123001001Z',
        '2025-01-01T00:00:01Z',
        '2025-01-01T00:00:01Z',
    ]
    for index, timestamp in enumerate(timestamps):
        task = create_minimal_task(f'task-{index}')
        task.status.timestamp.FromJsonString(timestamp)
        await store.save(task, TEST_CONTEXT)
    await store.save(create_minimal_task('no-timestamp'), TEST_CONTEXT)
    await store.save(Task(id='no-status'), TEST_CONTEXT)
    expected_ids = [
        *(f'task-{index}' for index in reversed(range(len(timestamps)))),
        'no-timestamp',
        'no-status',
    ]
    params = ListTasksRequest(page_size=page_size)

    for start in range(0, len(expected_ids), page_size):
        page = await store.list(params, TEST_CONTEXT)
        assert [task.id for task in page.tasks] == expected_ids[
            start : start + page_size
        ]
        assert page.total_size == len(expected_ids)
        assert bool(page.next_page_token) == (
            start + page_size < len(expected_ids)
        )
        params.page_token = page.next_page_token


async def _store_with_five_tasks() -> InMemoryTaskStore:
    """t1..t5 with increasing timestamps, so they list as t5, t4, t3, t2, t1."""
    store = InMemoryTaskStore()
    for i in range(1, 6):
        task = create_minimal_task(f't{i}')
        task.status.timestamp.FromSeconds(1_700_000_000 + i)
        await store.save(task, TEST_CONTEXT)
    return store


@pytest.mark.asyncio
@pytest.mark.parametrize(
    'change, task_id, expected_second_page',
    [
        # The last task returned moves to the top: the listing continues.
        ('update', 't4', ['t3', 't2']),
        # The next task moves above the cursor: skipped this pass, no repeats.
        ('update', 't3', ['t2', 't1']),
        # Deleting either task does not invalidate the token.
        ('delete', 't4', ['t3', 't2']),
        ('delete', 't3', ['t2', 't1']),
    ],
)
async def test_list_tasks_page_token_survives_task_changes(
    change: str, task_id: str, expected_second_page: list[str]
) -> None:
    """Regression test for #1280: the token is a position, not a task lookup."""
    store = await _store_with_five_tasks()
    first = await store.list(ListTasksRequest(page_size=2), TEST_CONTEXT)
    assert [task.id for task in first.tasks] == ['t5', 't4']

    if change == 'update':
        task = create_minimal_task(task_id)
        task.status.timestamp.FromSeconds(1_800_000_000)
        await store.save(task, TEST_CONTEXT)
    else:
        await store.delete(task_id, TEST_CONTEXT)
    second = await store.list(
        ListTasksRequest(page_size=2, page_token=first.next_page_token),
        TEST_CONTEXT,
    )

    assert [task.id for task in second.tasks] == expected_second_page


@pytest.mark.asyncio
async def test_list_tasks_pages_through_tasks_without_timestamps() -> None:
    """Tasks without a timestamp sort last and are each returned once."""
    store = InMemoryTaskStore()
    timestamped = create_minimal_task('dated')
    timestamped.status.timestamp.FromSeconds(1_700_000_000)
    for task in (
        timestamped,
        create_minimal_task('undated-a'),
        create_minimal_task('undated-b'),
        Task(id='no-status'),
    ):
        await store.save(task, TEST_CONTEXT)

    seen: list[str] = []
    params = ListTasksRequest(page_size=1)
    while True:
        page = await store.list(params, TEST_CONTEXT)
        seen.extend(task.id for task in page.tasks)
        if not page.next_page_token:
            break
        params.page_token = page.next_page_token

    assert seen == ['dated', 'undated-b', 'undated-a', 'no-status']


@pytest.mark.asyncio
async def test_list_tasks_rejects_malformed_cursor_token() -> None:
    store = await _store_with_five_tasks()
    token = urlsafe_b64encode(b'{"ts":"soon","id":"t1"}').decode().rstrip('=')

    with pytest.raises(InvalidParamsError):
        await store.list(
            ListTasksRequest(page_size=2, page_token=token), TEST_CONTEXT
        )


@pytest.mark.asyncio
async def test_in_memory_task_store_delete() -> None:
    """Test deleting a task from the store."""
    store = InMemoryTaskStore()
    task = create_minimal_task()
    await store.save(task, TEST_CONTEXT)
    await store.delete('task-abc', TEST_CONTEXT)
    retrieved_task = await store.get('task-abc', TEST_CONTEXT)
    assert retrieved_task is None


@pytest.mark.asyncio
async def test_in_memory_task_store_delete_nonexistent() -> None:
    """Test deleting a nonexistent task."""
    store = InMemoryTaskStore()
    await store.delete('nonexistent', TEST_CONTEXT)


@pytest.mark.asyncio
async def test_owner_resource_scoping() -> None:
    """Test that operations are scoped to the correct owner."""
    store = InMemoryTaskStore()
    task = create_minimal_task()

    context_user1 = ServerCallContext(user=SampleUser(user_name='user1'))
    context_user2 = ServerCallContext(user=SampleUser(user_name='user2'))
    context_user3 = ServerCallContext(
        user=SampleUser(user_name='user3')
    )  # For testing non-existent user

    # Create tasks for different owners
    task1_user1 = Task()
    task1_user1.CopyFrom(task)
    task1_user1.id = 'u1-task1'

    task2_user1 = Task()
    task2_user1.CopyFrom(task)
    task2_user1.id = 'u1-task2'

    task1_user2 = Task()
    task1_user2.CopyFrom(task)
    task1_user2.id = 'u2-task1'

    await store.save(task1_user1, context_user1)
    await store.save(task2_user1, context_user1)
    await store.save(task1_user2, context_user2)

    # Test GET
    assert await store.get('u1-task1', context_user1) is not None
    assert await store.get('u1-task1', context_user2) is None
    assert await store.get('u2-task1', context_user1) is None
    assert await store.get('u2-task1', context_user2) is not None
    assert await store.get('u2-task1', context_user3) is None

    # Test LIST
    params = ListTasksRequest()
    page_user1 = await store.list(params, context_user1)
    assert len(page_user1.tasks) == 2
    assert {t.id for t in page_user1.tasks} == {'u1-task1', 'u1-task2'}
    assert page_user1.total_size == 2

    page_user2 = await store.list(params, context_user2)
    assert len(page_user2.tasks) == 1
    assert {t.id for t in page_user2.tasks} == {'u2-task1'}
    assert page_user2.total_size == 1

    page_user3 = await store.list(params, context_user3)
    assert len(page_user3.tasks) == 0
    assert page_user3.total_size == 0

    # Test DELETE
    await store.delete('u1-task1', context_user2)  # Should not delete
    assert await store.get('u1-task1', context_user1) is not None

    await store.delete('u1-task1', context_user1)  # Should delete
    assert await store.get('u1-task1', context_user1) is None

    # Cleanup remaining tasks
    await store.delete('u1-task2', context_user1)
    await store.delete('u2-task1', context_user2)


@pytest.mark.asyncio
@pytest.mark.parametrize('use_copying', [True, False])
async def test_inmemory_task_store_copying_behavior(use_copying: bool):
    """Verify that tasks are copied (or not) based on use_copying parameter."""
    store = InMemoryTaskStore(use_copying=use_copying)

    original_task = Task(
        id='test_task', status=TaskStatus(state=TaskState.TASK_STATE_WORKING)
    )
    await store.save(original_task, TEST_CONTEXT)

    # Retrieve it
    retrieved_task = await store.get('test_task', TEST_CONTEXT)
    assert retrieved_task is not None

    if use_copying:
        assert retrieved_task is not original_task
    else:
        assert retrieved_task is original_task

    # Modify retrieved task
    retrieved_task.status.state = TaskState.TASK_STATE_COMPLETED

    # Retrieve it again, it should NOT be modified in the store if use_copying=True
    retrieved_task_2 = await store.get('test_task', TEST_CONTEXT)
    assert retrieved_task_2 is not None

    if use_copying:
        assert retrieved_task_2.status.state == TaskState.TASK_STATE_WORKING
        assert retrieved_task_2 is not retrieved_task
    else:
        assert retrieved_task_2.status.state == TaskState.TASK_STATE_COMPLETED
        assert retrieved_task_2 is retrieved_task


def _lock_is_owned(lock: threading.RLock) -> bool:
    is_owned = getattr(lock, '_is_owned', None)
    return bool(is_owned()) if callable(is_owned) else False


def _save_task_in_thread(
    store: InMemoryTaskStore,
    task_id: str,
    context: ServerCallContext,
) -> None:
    asyncio.run(store.save(create_minimal_task(task_id=task_id), context))


def test_save_creates_owner_bucket_under_lock() -> None:
    """Creating the first owner bucket must happen while the RLock is held."""
    store = InMemoryTaskStore(use_copying=False)
    impl = store._impl
    lock_held: list[bool] = []

    class _LockHeldOwnerMap(dict[str, dict[str, Task]]):
        def setdefault(
            self,
            key: str,
            default: dict[str, Task] | None = None,
        ) -> dict[str, Task]:
            lock_held.append(_lock_is_owned(impl.lock))
            if default is None:
                default = {}
            return super().setdefault(key, default)

        def __setitem__(self, key: str, value: dict[str, Task]) -> None:
            lock_held.append(_lock_is_owned(impl.lock))
            super().__setitem__(key, value)

    impl.tasks = _LockHeldOwnerMap()
    asyncio.run(store.save(create_minimal_task(), TEST_CONTEXT))
    assert lock_held
    assert all(lock_held)


def test_concurrent_first_owner_saves_keep_both_tasks() -> None:
    """Concurrent first saves for a new owner must keep both tasks."""
    store = InMemoryTaskStore(use_copying=False)
    context = ServerCallContext(user=SampleUser('race-owner'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [
            pool.submit(_save_task_in_thread, store, 'task-a', context),
            pool.submit(_save_task_in_thread, store, 'task-b', context),
        ]
        for future in futures:
            future.result(timeout=10)

    page = asyncio.run(store.list(ListTasksRequest(), context))
    assert {task.id for task in page.tasks} == {'task-a', 'task-b'}
    assert asyncio.run(store.get('task-a', context)) is not None
    assert asyncio.run(store.get('task-b', context)) is not None
