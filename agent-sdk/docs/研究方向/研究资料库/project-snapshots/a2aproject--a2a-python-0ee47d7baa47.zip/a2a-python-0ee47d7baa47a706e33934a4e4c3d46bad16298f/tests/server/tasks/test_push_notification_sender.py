import asyncio
import unittest

from unittest.mock import AsyncMock, MagicMock, patch

import httpx

from a2a.server.tasks.base_push_notification_sender import (
    BasePushNotificationSender,
)
from a2a.types.a2a_pb2 import (
    AuthenticationInfo,
    StreamResponse,
    Task,
    TaskArtifactUpdateEvent,
    TaskPushNotificationConfig,
    TaskState,
    TaskStatus,
    TaskStatusUpdateEvent,
)
from a2a.utils.push_url_validator import validate_push_notification_url
from google.protobuf.json_format import MessageToDict


def _create_sample_task(
    task_id: str = 'task123',
    status_state: TaskState = TaskState.TASK_STATE_COMPLETED,
) -> Task:
    return Task(
        id=task_id,
        context_id='ctx456',
        status=TaskStatus(state=status_state),
    )


def _create_sample_push_config(
    url: str = 'http://example.com/callback',
    config_id: str = 'cfg1',
    token: str | None = None,
    authentication: AuthenticationInfo | None = None,
) -> TaskPushNotificationConfig:
    return TaskPushNotificationConfig(
        id=config_id, url=url, token=token, authentication=authentication
    )


class TestBasePushNotificationSender(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self.mock_httpx_client = AsyncMock(spec=httpx.AsyncClient)
        self.mock_config_store = AsyncMock()
        self.sender = BasePushNotificationSender(
            httpx_client=self.mock_httpx_client,
            config_store=self.mock_config_store,
        )

    def test_constructor_stores_client_and_config_store(self) -> None:
        self.assertEqual(self.sender._client, self.mock_httpx_client)
        self.assertEqual(self.sender._config_store, self.mock_config_store)

    async def test_send_notification_success(self) -> None:
        task_id = 'task_send_success'
        task_data = _create_sample_task(task_id=task_id)
        config = _create_sample_push_config(url='http://notify.me/here')
        self.mock_config_store.get_info_for_dispatch.return_value = [config]

        mock_response = AsyncMock(spec=httpx.Response)
        mock_response.status_code = 200
        self.mock_httpx_client.post.return_value = mock_response

        await self.sender.send_notification(task_id, task_data)

        self.mock_config_store.get_info_for_dispatch.assert_awaited_once_with(
            task_data.id
        )

        # assert httpx_client post method got invoked with right parameters
        self.mock_httpx_client.post.assert_awaited_once_with(
            config.url,
            json=MessageToDict(StreamResponse(task=task_data)),
            headers={},
        )
        mock_response.raise_for_status.assert_called_once()

    async def test_send_notification_with_token_success(self) -> None:
        task_id = 'task_send_success'
        task_data = _create_sample_task(task_id=task_id)
        config = _create_sample_push_config(
            url='http://notify.me/here', token='unique_token'
        )
        self.mock_config_store.get_info_for_dispatch.return_value = [config]

        mock_response = AsyncMock(spec=httpx.Response)
        mock_response.status_code = 200
        self.mock_httpx_client.post.return_value = mock_response

        await self.sender.send_notification(task_id, task_data)

        self.mock_config_store.get_info_for_dispatch.assert_awaited_once_with(
            task_data.id
        )

        # assert httpx_client post method got invoked with right parameters
        self.mock_httpx_client.post.assert_awaited_once_with(
            config.url,
            json=MessageToDict(StreamResponse(task=task_data)),
            headers={'X-A2A-Notification-Token': 'unique_token'},
        )
        mock_response.raise_for_status.assert_called_once()

    async def _post_headers_for(self, **config_kwargs) -> dict[str, str] | None:
        """Sends one notification and returns the headers it posted with."""
        task_data = _create_sample_task(task_id='task_auth')
        self.mock_config_store.get_info_for_dispatch.return_value = [
            _create_sample_push_config(**config_kwargs)
        ]
        self.mock_httpx_client.post.return_value = AsyncMock(
            spec=httpx.Response, status_code=200
        )

        await self.sender.send_notification(task_data.id, task_data)

        return self.mock_httpx_client.post.await_args.kwargs['headers']

    async def test_authentication_becomes_an_authorization_header(self) -> None:
        """Authentication becomes `Authorization: {scheme} {credentials}`."""
        headers = await self._post_headers_for(
            authentication=AuthenticationInfo(
                scheme='Bearer', credentials='test-token'
            )
        )

        assert headers == {'Authorization': 'Bearer test-token'}

    async def test_authentication_and_token_are_sent_together(self) -> None:
        headers = await self._post_headers_for(
            token='notification-token',
            authentication=AuthenticationInfo(
                scheme='Bearer', credentials='test-token'
            ),
        )

        assert headers == {
            'X-A2A-Notification-Token': 'notification-token',
            'Authorization': 'Bearer test-token',
        }

    async def test_authentication_without_credentials_sends_no_header(
        self,
    ) -> None:
        """A half-filled AuthenticationInfo yields no 'Bearer ' with nothing after it."""
        headers = await self._post_headers_for(
            authentication=AuthenticationInfo(scheme='Bearer')
        )

        assert headers == {}

    async def test_authentication_without_credentials_warns(self) -> None:
        """A scheme with no credentials is valid to send, so say why it was dropped."""
        with self.assertLogs(
            'a2a.server.tasks.base_push_notification_sender', level='WARNING'
        ) as logs:
            await self._post_headers_for(
                config_id='cfg-half-auth',
                authentication=AuthenticationInfo(scheme='Bearer'),
            )

        assert any(
            'cfg-half-auth' in line and 'no ' in line for line in logs.output
        )

    async def test_complete_authentication_does_not_warn(self) -> None:
        with self.assertNoLogs(
            'a2a.server.tasks.base_push_notification_sender', level='WARNING'
        ):
            await self._post_headers_for(
                authentication=AuthenticationInfo(
                    scheme='Bearer', credentials='test-token'
                )
            )

    async def test_no_authentication_sends_no_authorization_header(
        self,
    ) -> None:
        headers = await self._post_headers_for()

        assert headers == {}

    async def test_send_notification_no_config(self) -> None:
        task_id = 'task_send_no_config'
        task_data = _create_sample_task(task_id=task_id)
        self.mock_config_store.get_info_for_dispatch.return_value = []

        await self.sender.send_notification(task_id, task_data)

        self.mock_config_store.get_info_for_dispatch.assert_awaited_once_with(
            task_id
        )
        self.mock_httpx_client.post.assert_not_called()

    @patch('a2a.server.tasks.base_push_notification_sender.logger')
    async def test_send_notification_http_status_error(
        self, mock_logger: MagicMock
    ) -> None:
        task_id = 'task_send_http_err'
        task_data = _create_sample_task(task_id=task_id)
        config = _create_sample_push_config(url='http://notify.me/http_error')
        self.mock_config_store.get_info_for_dispatch.return_value = [config]

        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 404
        mock_response.text = 'Not Found'
        http_error = httpx.HTTPStatusError(
            'Not Found', request=MagicMock(), response=mock_response
        )
        self.mock_httpx_client.post.side_effect = http_error

        await self.sender.send_notification(task_id, task_data)

        self.mock_config_store.get_info_for_dispatch.assert_awaited_once_with(
            task_id
        )
        self.mock_httpx_client.post.assert_awaited_once_with(
            config.url,
            json=MessageToDict(StreamResponse(task=task_data)),
            headers={},
        )
        mock_logger.exception.assert_called_once()

    async def test_send_notification_multiple_configs(self) -> None:
        task_id = 'task_multiple_configs'
        task_data = _create_sample_task(task_id=task_id)
        config1 = _create_sample_push_config(
            url='http://notify.me/cfg1', config_id='cfg1'
        )
        config2 = _create_sample_push_config(
            url='http://notify.me/cfg2', config_id='cfg2'
        )
        self.mock_config_store.get_info_for_dispatch.return_value = [
            config1,
            config2,
        ]

        mock_response = AsyncMock(spec=httpx.Response)
        mock_response.status_code = 200
        self.mock_httpx_client.post.return_value = mock_response

        await self.sender.send_notification(task_id, task_data)

        self.mock_config_store.get_info_for_dispatch.assert_awaited_once_with(
            task_id
        )
        self.assertEqual(self.mock_httpx_client.post.call_count, 2)

        # Check calls for config1
        self.mock_httpx_client.post.assert_any_call(
            config1.url,
            json=MessageToDict(StreamResponse(task=task_data)),
            headers={},
        )
        # Check calls for config2
        self.mock_httpx_client.post.assert_any_call(
            config2.url,
            json=MessageToDict(StreamResponse(task=task_data)),
            headers={},
        )
        mock_response.raise_for_status.call_count = 2

    async def test_send_notification_status_update_event(self) -> None:
        task_id = 'task_status_update'
        event = TaskStatusUpdateEvent(
            task_id=task_id,
            status=TaskStatus(state=TaskState.TASK_STATE_WORKING),
        )
        config = _create_sample_push_config(url='http://notify.me/status')
        self.mock_config_store.get_info_for_dispatch.return_value = [config]

        mock_response = AsyncMock(spec=httpx.Response)
        mock_response.status_code = 200
        self.mock_httpx_client.post.return_value = mock_response

        await self.sender.send_notification(task_id, event)

        self.mock_config_store.get_info_for_dispatch.assert_awaited_once_with(
            task_id
        )
        self.mock_httpx_client.post.assert_awaited_once_with(
            config.url,
            json=MessageToDict(StreamResponse(status_update=event)),
            headers={},
        )

    async def test_send_notification_artifact_update_event(self) -> None:
        task_id = 'task_artifact_update'
        event = TaskArtifactUpdateEvent(
            task_id=task_id,
            append=True,
        )
        config = _create_sample_push_config(url='http://notify.me/artifact')
        self.mock_config_store.get_info_for_dispatch.return_value = [config]

        mock_response = AsyncMock(spec=httpx.Response)
        mock_response.status_code = 200
        self.mock_httpx_client.post.return_value = mock_response

        await self.sender.send_notification(task_id, event)

        self.mock_config_store.get_info_for_dispatch.assert_awaited_once_with(
            task_id
        )
        self.mock_httpx_client.post.assert_awaited_once_with(
            config.url,
            json=MessageToDict(StreamResponse(artifact_update=event)),
            headers={},
        )

    @patch('a2a.server.tasks.base_push_notification_sender.logger')
    async def test_send_notification_config_store_failure_is_swallowed(
        self, mock_logger: MagicMock
    ) -> None:
        """A config store read failure is logged and delivery is skipped
        instead of propagating into the task lifecycle (issue #1313)."""
        task_id = 'task_store_error'
        task_data = _create_sample_task(task_id=task_id)
        self.mock_config_store.get_info_for_dispatch.side_effect = RuntimeError(
            'transient DB error'
        )

        await self.sender.send_notification(task_id, task_data)

        self.mock_config_store.get_info_for_dispatch.assert_awaited_once_with(
            task_id
        )
        self.mock_httpx_client.post.assert_not_called()
        mock_logger.exception.assert_called_once()

    @patch('a2a.server.tasks.base_push_notification_sender.logger')
    async def test_push_url_validator_raising_rejects_url(
        self, mock_logger: MagicMock
    ) -> None:
        """A raising push_url_validator is treated as a rejected URL rather
        than propagating into the task lifecycle (issue #1313)."""
        sender = BasePushNotificationSender(
            httpx_client=self.mock_httpx_client,
            config_store=self.mock_config_store,
            push_url_validator=AsyncMock(side_effect=RuntimeError('boom')),
        )
        task_data = _create_sample_task(task_id='task_validator_error')
        config = _create_sample_push_config(url='http://notify.me/here')
        self.mock_config_store.get_info_for_dispatch.return_value = [config]

        await sender.send_notification(task_data.id, task_data)

        self.mock_httpx_client.post.assert_not_called()
        mock_logger.exception.assert_called_once()


def _gai_result(ip: str, port: int = 80):
    return [(2, 1, 6, '', (ip, port))]


class TestPushUrlValidation(unittest.IsolatedAsyncioTestCase):
    """SSRF hardening: when validate_push_notification_url is installed, client
    push URLs must not reach non-public destinations."""

    def setUp(self) -> None:
        self.mock_httpx_client = AsyncMock(spec=httpx.AsyncClient)
        self.mock_config_store = AsyncMock()
        self.sender = BasePushNotificationSender(
            httpx_client=self.mock_httpx_client,
            config_store=self.mock_config_store,
            push_url_validator=validate_push_notification_url,
        )

    async def _dispatch(self, url: str) -> None:
        task = _create_sample_task()
        config = _create_sample_push_config(url=url)
        self.mock_config_store.get_info_for_dispatch.return_value = [config]
        mock_response = AsyncMock(spec=httpx.Response)
        mock_response.status_code = 200
        self.mock_httpx_client.post.return_value = mock_response
        await self.sender.send_notification(task.id, task)

    def _patch_gai(self, *, return_value=None, side_effect=None):
        loop = asyncio.get_running_loop()
        mock_gai = AsyncMock(return_value=return_value, side_effect=side_effect)
        return patch.object(loop, 'getaddrinfo', mock_gai)

    async def test_metadata_endpoint_blocked(self) -> None:
        with self._patch_gai(return_value=_gai_result('169.254.169.254')):
            await self._dispatch('http://metadata.google.internal/latest')
        self.mock_httpx_client.post.assert_not_called()

    async def test_loopback_blocked(self) -> None:
        with self._patch_gai(return_value=_gai_result('127.0.0.1')):
            await self._dispatch('http://localhost:8080/admin')
        self.mock_httpx_client.post.assert_not_called()

    async def test_private_range_blocked(self) -> None:
        with self._patch_gai(return_value=_gai_result('10.0.0.5')):
            await self._dispatch('http://internal-service/endpoint')
        self.mock_httpx_client.post.assert_not_called()

    async def test_non_http_scheme_blocked(self) -> None:
        await self._dispatch('ftp://example.com/file')
        self.mock_httpx_client.post.assert_not_called()

    async def test_invalid_port_blocked(self) -> None:
        await self._dispatch('http://example.com:99999/hook')
        self.mock_httpx_client.post.assert_not_called()

    async def test_unresolvable_host_blocked_fail_closed(self) -> None:
        with self._patch_gai(side_effect=OSError('no DNS')):
            await self._dispatch('http://does-not-resolve.invalid/')
        self.mock_httpx_client.post.assert_not_called()

    async def test_public_host_allowed(self) -> None:
        with self._patch_gai(return_value=_gai_result('93.184.216.34')):
            await self._dispatch('http://notify.me/here')
        self.mock_httpx_client.post.assert_awaited_once()

    async def test_default_hook_none_skips_validation(self) -> None:
        sender = BasePushNotificationSender(
            httpx_client=self.mock_httpx_client,
            config_store=self.mock_config_store,
        )
        task = _create_sample_task()
        config = _create_sample_push_config(url='http://localhost:9000/hook')
        self.mock_config_store.get_info_for_dispatch.return_value = [config]
        mock_response = AsyncMock(spec=httpx.Response)
        mock_response.status_code = 200
        self.mock_httpx_client.post.return_value = mock_response
        await sender.send_notification(task.id, task)
        self.mock_httpx_client.post.assert_awaited_once()
