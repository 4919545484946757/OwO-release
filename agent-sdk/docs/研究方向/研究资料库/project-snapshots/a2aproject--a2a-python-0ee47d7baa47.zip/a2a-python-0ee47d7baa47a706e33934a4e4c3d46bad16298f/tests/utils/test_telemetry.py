import asyncio
import importlib
import sys

from collections.abc import Callable, Generator
from typing import Any, NoReturn
from unittest import mock

import pytest

from a2a.server.events.event_queue import QueueShutDown
from a2a.utils.telemetry import trace_class, trace_function


@pytest.fixture
def mock_span() -> mock.MagicMock:
    return mock.MagicMock()


@pytest.fixture
def mock_tracer(mock_span: mock.MagicMock) -> mock.MagicMock:
    tracer = mock.MagicMock()
    tracer.start_as_current_span.return_value.__enter__.return_value = mock_span
    tracer.start_as_current_span.return_value.__exit__.return_value = False
    return tracer


@pytest.fixture(autouse=True)
def patch_trace_get_tracer(
    mock_tracer: mock.MagicMock,
) -> Generator[None, Any, None]:
    with mock.patch('opentelemetry.trace.get_tracer', return_value=mock_tracer):
        yield


@pytest.fixture
def reload_telemetry_module(
    monkeypatch: pytest.MonkeyPatch,
) -> Generator[Callable[[str | None], Any], None, None]:
    """Fixture to handle telemetry module reloading with env var control."""

    def _reload(env_value: str | None = None) -> Any:
        if env_value is None:
            monkeypatch.delenv(
                'OTEL_INSTRUMENTATION_A2A_SDK_ENABLED', raising=False
            )
        else:
            monkeypatch.setenv(
                'OTEL_INSTRUMENTATION_A2A_SDK_ENABLED', env_value
            )

        sys.modules.pop('a2a.utils.telemetry', None)
        module = importlib.import_module('a2a.utils.telemetry')
        return module

    yield _reload

    # Cleanup to ensure other tests aren't affected by a "poisoned" sys.modules
    sys.modules.pop('a2a.utils.telemetry', None)


def test_trace_function_sync_success(mock_span: mock.MagicMock) -> None:
    @trace_function
    def foo(x, y):
        return x + y

    result = foo(2, 3)
    assert result == 5
    mock_span.set_status.assert_called()
    mock_span.set_status.assert_any_call(mock.ANY)
    mock_span.record_exception.assert_not_called()


def test_trace_function_sync_exception(mock_span: mock.MagicMock) -> None:
    @trace_function
    def bar() -> NoReturn:
        raise ValueError('fail')

    with pytest.raises(ValueError):
        bar()
    mock_span.record_exception.assert_called()
    mock_span.set_status.assert_any_call(mock.ANY, description='fail')


def test_trace_function_sync_attribute_extractor_called(
    mock_span: mock.MagicMock,
) -> None:
    called = {}

    def attr_extractor(span, args, kwargs, result, exception) -> None:
        called['called'] = True
        assert span is mock_span
        assert exception is None
        assert result == 42

    @trace_function(attribute_extractor=attr_extractor)
    def foo() -> int:
        return 42

    foo()
    assert called['called']


def test_trace_function_sync_attribute_extractor_error_logged(
    mock_span: mock.MagicMock,
) -> None:
    with mock.patch('a2a.utils.telemetry.logger') as logger:

        def attr_extractor(span, args, kwargs, result, exception) -> NoReturn:
            raise RuntimeError('attr fail')

        @trace_function(attribute_extractor=attr_extractor)
        def foo() -> int:
            return 1

        foo()
        logger.exception.assert_any_call(
            'attribute_extractor error in span %s',
            'test_telemetry.foo',
        )


@pytest.mark.asyncio
async def test_trace_function_async_success(mock_span: mock.MagicMock) -> None:
    @trace_function
    async def foo(x):
        await asyncio.sleep(0)
        return x * 2

    result = await foo(4)
    assert result == 8
    mock_span.set_status.assert_called()
    mock_span.record_exception.assert_not_called()


@pytest.mark.asyncio
async def test_trace_function_async_exception(
    mock_span: mock.MagicMock,
) -> None:
    @trace_function
    async def bar() -> NoReturn:
        await asyncio.sleep(0)
        raise RuntimeError('async fail')

    with pytest.raises(RuntimeError):
        await bar()
    mock_span.record_exception.assert_called()
    mock_span.set_status.assert_any_call(mock.ANY, description='async fail')


@pytest.mark.asyncio
async def test_trace_function_async_attribute_extractor_called(
    mock_span: mock.MagicMock,
) -> None:
    called = {}

    def attr_extractor(span, args, kwargs, result, exception) -> None:
        called['called'] = True
        assert exception is None
        assert result == 99

    @trace_function(attribute_extractor=attr_extractor)
    async def foo() -> int:
        return 99

    await foo()
    assert called['called']


def test_trace_function_with_args_and_attributes(
    mock_span: mock.MagicMock,
) -> None:
    @trace_function(span_name='custom.span', attributes={'foo': 'bar'})
    def foo() -> int:
        return 1

    foo()
    mock_span.set_attribute.assert_any_call('foo', 'bar')


def test_trace_class_exclude_list(mock_span: mock.MagicMock) -> None:
    @trace_class(exclude_list=['skip_me'])
    class MyClass:
        def a(self) -> str:
            return 'a'

        def skip_me(self) -> str:
            return 'skip'

        def __str__(self) -> str:
            return 'str'

    obj = MyClass()
    assert obj.a() == 'a'
    assert obj.skip_me() == 'skip'
    # Only 'a' is traced, not 'skip_me' or dunder
    assert hasattr(obj.a, '__wrapped__')
    assert not hasattr(obj.skip_me, '__wrapped__')


def test_trace_class_include_list(mock_span: mock.MagicMock) -> None:
    @trace_class(include_list=['only_this'])
    class MyClass:
        def only_this(self) -> str:
            return 'yes'

        def not_this(self) -> str:
            return 'no'

    obj = MyClass()
    assert obj.only_this() == 'yes'
    assert obj.not_this() == 'no'
    assert hasattr(obj.only_this, '__wrapped__')
    assert not hasattr(obj.not_this, '__wrapped__')


def test_trace_class_dunder_not_traced(mock_span: mock.MagicMock) -> None:
    @trace_class()
    class MyClass:
        def __init__(self) -> None:
            self.x = 1

        def foo(self) -> str:
            return 'foo'

    obj = MyClass()
    assert obj.foo() == 'foo'
    assert hasattr(obj.foo, '__wrapped__')
    assert hasattr(obj, 'x')


@pytest.mark.xdist_group(name='telemetry_isolation')
@pytest.mark.parametrize(
    'env_value,expected_tracing',
    [
        (None, True),  # Default: env var not set, tracing enabled
        ('true', True),  # Explicitly enabled
        ('True', True),  # Case insensitive
        ('false', False),  # Disabled
        ('', False),  # Empty string = false
    ],
)
def test_env_var_controls_instrumentation(
    reload_telemetry_module: Callable[[str | None], Any],
    env_value: str | None,
    expected_tracing: bool,
) -> None:
    """Test OTEL_INSTRUMENTATION_A2A_SDK_ENABLED controls span creation."""
    telemetry_module = reload_telemetry_module(env_value)

    is_noop = type(telemetry_module.trace).__name__ == '_NoOp'

    assert is_noop != expected_tracing


@pytest.mark.xdist_group(name='telemetry_isolation')
def test_env_var_disabled_logs_message(
    reload_telemetry_module: Callable[[str | None], Any],
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Test that disabling via env var logs appropriate debug message."""
    with caplog.at_level('DEBUG', logger='a2a.utils.telemetry'):
        reload_telemetry_module('false')

    assert (
        'A2A OTEL instrumentation disabled via environment variable'
        in caplog.text
    )
    assert 'OTEL_INSTRUMENTATION_A2A_SDK_ENABLED' in caplog.text


@pytest.mark.asyncio
@pytest.mark.parametrize('exc_cls', [asyncio.CancelledError, QueueShutDown])
async def test_trace_function_async_non_error_exception_does_not_mark_span_error(
    mock_span: mock.MagicMock,
    exc_cls: type[BaseException],
) -> None:
    """`trace_function` records non-error exceptions but never marks span ERROR.

    Covers `asyncio.CancelledError` and `QueueShutDown`.
    """

    @trace_function
    async def non_error_exception() -> NoReturn:
        await asyncio.sleep(0)
        raise exc_cls('operation ended with non-error exception')

    with pytest.raises(exc_cls):
        await non_error_exception()

    mock_span.record_exception.assert_called()
    # The wrapper only passes `description=` when calling
    # `set_status(StatusCode.ERROR, ...)`. Its absence on every call proves
    # the span was never marked as failed.
    for call in mock_span.set_status.call_args_list:
        assert 'description' not in call.kwargs


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ('exc_cls', 'is_error'), [(QueueShutDown, False), (ValueError, True)]
)
async def test_span_status_with_real_otel_sdk(
    exc_cls: type[Exception], is_error: bool
) -> None:
    """Check the status a real OTel SDK span ends with.

    The mocked-tracer tests only see the wrapper's own calls. By default,
    `start_as_current_span` also records any exception leaving its block and
    marks the span ERROR, which would turn a `QueueShutDown` into an error
    span and record every exception twice.
    """
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
        InMemorySpanExporter,
    )
    from opentelemetry.trace import StatusCode

    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))

    with mock.patch(
        'opentelemetry.trace.get_tracer', side_effect=provider.get_tracer
    ):

        @trace_function
        async def fail() -> NoReturn:
            await asyncio.sleep(0)
            raise exc_cls

        with pytest.raises(exc_cls):
            await fail()

    (span,) = exporter.get_finished_spans()
    assert (span.status.status_code is StatusCode.ERROR) is is_error
    assert [event.name for event in span.events] == ['exception']
