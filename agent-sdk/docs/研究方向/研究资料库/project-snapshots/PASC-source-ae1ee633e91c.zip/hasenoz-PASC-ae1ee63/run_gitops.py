#!/usr/bin/env python3
"""Single-instance runner for the GitOps multi-agent orchestrator.

One Docker container, N agents, shared git tree. Final patch is the team
diff (`git diff base..HEAD`). Mirrors run_isolated.py's CLI shape but runs
exactly one instance and exposes --n-agents / --agent-id for N-agent
experiments.
"""
from __future__ import annotations

from pathlib import Path

import typer

from pasc.gitops import GitOpsConfig, GitOpsOrchestrator
from pasc.gitops.orchestrator import DEFAULT_GITOPS_OUTPUT_DIR
from pasc.shared import DEFAULT_CONFIG_FILE


app = typer.Typer(rich_markup_mode="rich", add_completion=False)


@app.command()
def main(
    instance_spec: str = typer.Option(
        ..., "-i", "--instance", help="SWE-bench instance ID or numeric index."
    ),
    subset: str = typer.Option("_test", "--subset", help="Dataset subset or local path."),
    split: str = typer.Option("test", "--split", help="Dataset split."),
    output: Path = typer.Option(
        DEFAULT_GITOPS_OUTPUT_DIR, "-o", "--output", help="Base output directory."
    ),
    n_agents: int = typer.Option(
        2, "-n", "--n-agents", help="Number of agents sharing the container."
    ),
    agent_id: list[str] = typer.Option(
        [],
        "--agent-id",
        help=(
            "Explicit agent ID(s); repeatable. Overrides --n-agents when set. "
            "Default: agent_0..agent_{n-1}."
        ),
    ),
    model_name: str | None = typer.Option(None, "-m", "--model", help="Model name override."),
    model_class: str | None = typer.Option(None, "--model-class", help="Model class override."),
    environment_class: str | None = typer.Option(
        None, "--environment-class", help="Environment class override."
    ),
    seed_file: list[str] = typer.Option([], "--seed-file", help="Optional repeated seed hints."),
    config_spec: list[str] = typer.Option(
        [str(DEFAULT_CONFIG_FILE)],
        "-c",
        "--config",
        help="Config files or key-value overrides, merged in order.",
    ),
) -> None:
    if agent_id:
        ids = tuple(agent_id)
    else:
        if n_agents < 1:
            typer.echo("Error: --n-agents must be >= 1", err=True)
            raise typer.Exit(2)
        ids = tuple(f"agent_{i}" for i in range(n_agents))

    config = GitOpsConfig(
        instance_spec=instance_spec,
        subset=subset,
        split=split,
        output_dir=output,
        config_spec=config_spec,
        model_name=model_name,
        model_class=model_class,
        environment_class=environment_class,
        seed_files=seed_file,
        agent_ids=ids,
    )
    typer.echo(f"PASC GitOps single-instance run with agents={list(ids)}")
    result = GitOpsOrchestrator(config).run()
    typer.echo(str(result.run_dir))


if __name__ == "__main__":
    app()
