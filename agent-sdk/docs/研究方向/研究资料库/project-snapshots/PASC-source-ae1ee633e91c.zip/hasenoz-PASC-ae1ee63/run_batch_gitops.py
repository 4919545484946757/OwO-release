#!/usr/bin/env python3
"""Batch driver for the PASC GitOps multi-agent orchestrator.

`--workspace shared` (default): N agents commit to one shared git tree;
team patch = `git diff base..HEAD`.
`--workspace federated`: each agent owns a private clone; per-agent
patches are written and `final.patch` is the first non-empty in agent-id
order.

Writes `preds_list.json` (SWE-bench list format) and `preds.json` (dict
format) under the output directory; both use the headline patch as
`model_patch`.
"""
from __future__ import annotations

import json
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path

import typer

from pasc.gitops import GitOpsConfig, GitOpsOrchestrator
from pasc.shared import DEFAULT_CONFIG_FILE, PascRunResult


@dataclass
class InstanceOutcome:
    instance_id: str
    status: str  # "success" / "failed"
    run_dir: Path | None = None
    final_patch: str = ""
    # In shared mode every value equals final_patch; in federated mode each
    # agent's patch is distinct.
    per_agent_patches: dict[str, str] = field(default_factory=dict)
    error: str = ""
    duration_s: float = 0.0


def run_single_instance(
    instance_id: str,
    *,
    subset: str,
    split: str,
    output_dir: Path,
    config_spec: list[str],
    model_name: str | None,
    model_class: str | None,
    environment_class: str | None,
    seed_files: list[str],
    workspace: str,
    agent_ids: tuple[str, ...] = ("agent_0", "agent_1"),
) -> InstanceOutcome:
    start = time.monotonic()
    try:
        config = GitOpsConfig(
            instance_spec=instance_id,
            subset=subset,
            split=split,
            output_dir=output_dir,
            config_spec=config_spec,
            model_name=model_name,
            model_class=model_class,
            environment_class=environment_class,
            seed_files=seed_files,
            workspace=workspace,
            agent_ids=agent_ids,
        )
        result: PascRunResult = GitOpsOrchestrator(config).run()
        final_patch = (
            result.final_patch_path.read_text(encoding="utf-8")
            if result.final_patch_path.exists()
            else ""
        )
        per_agent_patches: dict[str, str] = {}
        patches_dir = result.run_dir / "patches"
        if patches_dir.is_dir():
            for diff_path in sorted(patches_dir.glob("*.diff")):
                per_agent_patches[diff_path.stem] = diff_path.read_text(encoding="utf-8")
        return InstanceOutcome(
            instance_id=instance_id,
            status="success",
            run_dir=result.run_dir,
            final_patch=final_patch,
            per_agent_patches=per_agent_patches,
            duration_s=time.monotonic() - start,
        )
    except Exception as exc:
        return InstanceOutcome(
            instance_id=instance_id,
            status="failed",
            error=f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}",
            duration_s=time.monotonic() - start,
        )


def collect_predictions(
    outcomes: list[InstanceOutcome], model_name: str | None
) -> list[dict[str, str]]:
    """Convert outcomes into SWE-bench list format using the headline patch."""
    predictions: list[dict[str, str]] = []
    for outcome in sorted(outcomes, key=lambda o: o.instance_id):
        if outcome.status != "success":
            continue
        entry: dict[str, str] = {
            "instance_id": outcome.instance_id,
            "patch": outcome.final_patch,
        }
        if model_name:
            entry["model_name_or_path"] = model_name
        predictions.append(entry)
    return predictions


def collect_per_agent_predictions(
    outcomes: list[InstanceOutcome], agent_id: str, model_name: str | None
) -> list[dict[str, str]]:
    """SWE-bench list format scoped to one specific agent's patches.

    Used in federated mode to emit one preds file per agent so each agent
    can be evaluated independently by SWE-bench Pro. ``model_name_or_path``
    is suffixed with ``__<agent_id>`` so multiple per-agent eval runs
    against the same harness don't collide on identifier.
    """
    predictions: list[dict[str, str]] = []
    for outcome in sorted(outcomes, key=lambda o: o.instance_id):
        if outcome.status != "success":
            continue
        entry: dict[str, str] = {
            "instance_id": outcome.instance_id,
            "patch": outcome.per_agent_patches.get(agent_id, ""),
        }
        if model_name:
            entry["model_name_or_path"] = f"{model_name}__{agent_id}"
        predictions.append(entry)
    return predictions


def discover_agent_ids(outcomes: list[InstanceOutcome]) -> list[str]:
    """Sorted union of agent_ids actually produced across successful outcomes.

    Reads from the on-disk ``patches/`` dir rather than the CLI ``agent_ids``
    so renamed-agent and partial-run scenarios still emit the right files.
    """
    seen: set[str] = set()
    for outcome in outcomes:
        seen.update(outcome.per_agent_patches.keys())
    return sorted(seen)


app = typer.Typer(rich_markup_mode="rich", add_completion=False)


@app.command()
def main(
    instance: list[str] = typer.Option([], "-i", "--instance", help="Instance ID(s)."),
    instances_file: Path | None = typer.Option(None, "--instances-file", help="One instance ID per line."),
    workers: int = typer.Option(2, "-w", "--workers", help="Parallel instances (each uses one container with N agents)."),
    n_agents: int = typer.Option(2, "-n", "--n-agents", help="Number of agents per instance (sharing one container)."),
    agent_id: list[str] = typer.Option([], "--agent-id", help="Explicit agent IDs; overrides --n-agents."),
    subset: str = typer.Option("_test", "--subset"),
    split: str = typer.Option("test", "--split"),
    output: Path = typer.Option(Path("runs/pasc_gitops"), "-o", "--output"),
    model_name: str | None = typer.Option(None, "-m", "--model"),
    model_class: str | None = typer.Option(None, "--model-class"),
    environment_class: str | None = typer.Option(None, "--environment-class"),
    seed_file: list[str] = typer.Option([], "--seed-file"),
    config_spec: list[str] = typer.Option([str(DEFAULT_CONFIG_FILE)], "-c", "--config"),
    workspace: str = typer.Option(
        "shared", "--workspace",
        help="Workspace strategy: 'shared' (one tree, all agents commit there) or "
             "'federated' (one private tree per agent).",
    ),
) -> None:
    if workspace not in ("shared", "federated"):
        typer.echo(f"Error: --workspace must be 'shared' or 'federated', got {workspace!r}", err=True)
        raise typer.Exit(2)

    instance_ids: list[str] = list(instance)
    if instances_file is not None:
        instance_ids.extend(
            line.strip()
            for line in instances_file.read_text().splitlines()
            if line.strip() and not line.strip().startswith("#")
        )
    if not instance_ids:
        typer.echo("Error: provide --instances-file <path> or -i <id>", err=True)
        raise typer.Exit(1)

    seen, deduped = set(), []
    for iid in instance_ids:
        if iid not in seen:
            seen.add(iid)
            deduped.append(iid)
    instance_ids = deduped

    if agent_id:
        agent_ids = tuple(agent_id)
    else:
        if n_agents < 1:
            typer.echo("Error: --n-agents must be >= 1", err=True)
            raise typer.Exit(2)
        agent_ids = tuple(f"agent_{i}" for i in range(n_agents))

    typer.echo("PASC GitOps Batch Run")
    typer.echo(f"  Workspace: {workspace}")
    typer.echo(f"  Instances: {len(instance_ids)}")
    typer.echo(f"  Workers:   {workers}")
    typer.echo(f"  Agents:    {len(agent_ids)} ({', '.join(agent_ids)})")
    typer.echo(f"  Output:    {output}")
    typer.echo(f"  Model:     {model_name or '(config default)'}")
    typer.echo("")

    shared_kwargs = dict(
        subset=subset,
        split=split,
        output_dir=output,
        config_spec=config_spec,
        model_name=model_name,
        model_class=model_class,
        environment_class=environment_class,
        seed_files=seed_file,
        workspace=workspace,
        agent_ids=agent_ids,
    )

    outcomes: list[InstanceOutcome] = []
    list_path = output / "preds_list.json"
    dict_path = output / "preds.json"
    output.mkdir(parents=True, exist_ok=True)

    def flush_preds() -> None:
        """Write current outcomes to preds_list.json + preds.json. In federated
        mode also emit one ``preds_<agent_id>.json`` + ``preds_list_<agent_id>.json``
        pair per agent so each agent's contribution can be evaluated separately
        by SWE-bench Pro. Idempotent; called after every completed instance and
        once more on shutdown so a Ctrl+C or final-instance crash never leaves
        the batch without preds."""
        preds_now = collect_predictions(outcomes, model_name=model_name)
        list_path.write_text(json.dumps(preds_now, indent=2), encoding="utf-8")
        dict_path.write_text(
            json.dumps({p["instance_id"]: p for p in preds_now}, indent=2),
            encoding="utf-8",
        )
        if workspace != "federated":
            return
        for aid in discover_agent_ids(outcomes):
            per_agent_preds = collect_per_agent_predictions(outcomes, aid, model_name)
            (output / f"preds_list_{aid}.json").write_text(
                json.dumps(per_agent_preds, indent=2), encoding="utf-8"
            )
            (output / f"preds_{aid}.json").write_text(
                json.dumps({p["instance_id"]: p for p in per_agent_preds}, indent=2),
                encoding="utf-8",
            )

    batch_start = time.monotonic()
    try:
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="pasc-gitops-batch") as pool:
            futures = {
                pool.submit(run_single_instance, iid, **shared_kwargs): iid for iid in instance_ids
            }
            for future in as_completed(futures):
                outcome = future.result()
                outcomes.append(outcome)
                patch_size = len(outcome.final_patch.encode("utf-8")) if outcome.final_patch else 0
                if outcome.status == "success":
                    typer.echo(
                        f"  OK   {outcome.instance_id} ({patch_size} bytes, {outcome.duration_s:.0f}s)"
                    )
                else:
                    typer.echo(
                        f"  FAIL {outcome.instance_id} ({outcome.duration_s:.0f}s): "
                        f"{outcome.error.splitlines()[0]}"
                    )
                # Persist after every instance — Ctrl+C / crash safe.
                flush_preds()
    finally:
        flush_preds()
        preds = collect_predictions(outcomes, model_name=model_name)
        ne_count = sum(1 for p in preds if p.get("patch", "").strip())
        typer.echo(f"\nBatch complete in {time.monotonic() - batch_start:.0f}s")
        typer.echo(
            f"Predictions written: {list_path}  ({len(preds)} entries, {ne_count} non-empty)"
        )
        typer.echo(f"                     {dict_path}")
        if workspace == "federated":
            for aid in discover_agent_ids(outcomes):
                per_agent = collect_per_agent_predictions(outcomes, aid, model_name)
                ne = sum(1 for p in per_agent if p.get("patch", "").strip())
                typer.echo(
                    f"  per-agent ({aid}): preds_list_{aid}.json + preds_{aid}.json"
                    f"  ({len(per_agent)} entries, {ne} non-empty)"
                )


if __name__ == "__main__":
    app()
