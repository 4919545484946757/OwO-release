# Third-Party Software Notice

This repository vendors source code from upstream open-source projects. The full license text of each is in this directory; the table below records provenance.

| Component | Path in this repo | Upstream source | Upstream license | Vendored at commit |
|---|---|---|---|---|
| `mini-swe-agent` | `mini-swe-agent/` | https://github.com/SWE-agent/mini-swe-agent | MIT (`mini-swe-agent.LICENSE`) | release `v2.2.6` (`minisweagent.__version__`), **modified — see below** |

Author and license metadata in `mini-swe-agent/` describe the upstream project, not this work.

## Modifications to the vendored tree

The vendored copy is **not** byte-identical to upstream `v2.2.6`. The MIT license
permits modification; this section records what was changed so the fork is
auditable. Differences below are against the upstream `v2.2.6` source
distribution, ignoring line-ending changes.

**Files added** (authored for this work, MIT, © the authors of this repository):

- `src/minisweagent/models/minimax_model.py`, `models/anthropic_sdk_model.py`
- `src/minisweagent/config/benchmarks/swebench_xml_gitops{,_silent,_federated,_npeer,_lean}.yaml`
- `src/minisweagent/config/benchmarks/swebench_xml_{dialogue,typed_envelope}.yaml`

**Upstream files modified** (16):

- `run/benchmarks/swebench.py` — SWE-Bench Pro support: `sweap-images` image
  resolution via `dockerhub_tag`, the `compose_pro_task()` task composer
  (problem statement + requirements + interface), and per-instance live
  trajectory saving.
- `config/benchmarks/swebench.yaml` — default model pinned to
  `MiniMax-M2.7-highspeed` (`model_class: minimax`), `cost_tracking:
  ignore_errors`; upstream's `drop_params` / `parallel_tool_calls` removed.
- `models/__init__.py` — registers the two added model classes.
- `__init__.py`, `models/{litellm,litellm_response,openrouter,openrouter_response,portkey,portkey_response,requesty}_model.py`,
  `models/test_models.py` — a `query_text()` method added to the model protocol
  and its implementations.
- `config/{default,mini,mini_textbased}.yaml`, `environments/extra/contree.py` —
  minor local adjustments.

The agent loop PASC extends (`agents/default.py`) is unmodified.
