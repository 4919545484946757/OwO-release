"""Custom Anthropic SDK model for MiniMax."""

import logging
import os
import time
from typing import Any

import anthropic
from pydantic import BaseModel

from minisweagent.models import GLOBAL_MODEL_STATS
from minisweagent.models.utils.actions_toolcall import (
    BASH_TOOL,
    format_toolcall_observation_messages,
    parse_toolcall_actions,
)
from minisweagent.models.utils.anthropic_utils import _reorder_anthropic_thinking_blocks
from minisweagent.models.utils.cache_control import set_cache_control
from minisweagent.models.utils.openai_multimodal import expand_multimodal_content
from minisweagent.models.utils.retry import retry

logger = logging.getLogger("anthropic_sdk_model")


def _content_blocks_to_text(blocks: list[Any]) -> str:
    parts = []
    for block in blocks:
        text = getattr(block, "text", "")
        if text:
            parts.append(text)
    return "\n".join(parts)


class AnthropicSDKModelConfig(BaseModel):
    model_name: str
    model_kwargs: dict[str, Any] = {}
    set_cache_control: str | None = None
    cost_tracking: str = "ignore_errors"
    observation_template: str = ""
    format_error_template: str = "{{ error }}"
    api_key: str | None = None
    base_url: str = "https://api.minimax.io/anthropic"
    multimodal_regex: str = ""


class AnthropicSDKModel:
    abort_exceptions = [KeyboardInterrupt]

    def __init__(self, **kwargs):
        self.config = AnthropicSDKModelConfig(**kwargs)
        # Get API key from config, env, or raise error
        api_key = self.config.api_key or os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY not set")
        self.client = anthropic.Anthropic(
            api_key=api_key,
            base_url=self.config.base_url,
        )

    def format_message(self, **kwargs) -> dict:
        return expand_multimodal_content(kwargs, pattern=self.config.multimodal_regex)

    def format_observation_messages(
        self, message: dict, outputs: list[dict], template_vars: dict | None = None
    ) -> list[dict]:
        """Format execution outputs into tool result messages."""
        actions = message.get("extra", {}).get("actions", [])
        return format_toolcall_observation_messages(
            actions=actions,
            outputs=outputs,
            observation_template=self.config.observation_template,
            template_vars=template_vars,
            multimodal_regex=self.config.multimodal_regex,
        )

    def get_template_vars(self, **kwargs) -> dict[str, Any]:
        return self.config.model_dump()

    def serialize(self) -> dict:
        return {
            "info": {
                "config": {
                    "model": self.config.model_dump(mode="json"),
                    "model_type": f"{self.__class__.__module__}.{self.__class__.__name__}",
                },
            }
        }

    def _query(self, messages: list[dict]) -> anthropic.types.Message:
        # Convert messages to Anthropic format
        anthropic_messages = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, str):
                anthropic_messages.append({
                    "role": role,
                    "content": content
                })
            else:
                # Handle multimodal content
                anthropic_messages.append({
                    "role": role,
                    "content": content
                })

        # Check if tools are supported (MiniMax might not support them)
        use_tools = self.config.model_kwargs.get("use_tools", True)

        # Skip tools for now - test without tools first
        response = self.client.messages.create(
            model=self.config.model_name,
            max_tokens=4096,
            messages=anthropic_messages,
        )
        return response

    def _prepare_messages_for_api(self, messages: list[dict]) -> list[dict]:
        prepared = [{k: v for k, v in msg.items() if k != "extra"} for msg in messages]
        prepared = _reorder_anthropic_thinking_blocks(prepared)
        return set_cache_control(prepared, mode=self.config.set_cache_control)

    def query(self, messages: list[dict], **kwargs) -> dict:
        for attempt in retry(logger=logger, abort_exceptions=self.abort_exceptions):
            with attempt:
                response = self._query(self._prepare_messages_for_api(messages))

        # Convert Anthropic response to litellm-like format
        content_blocks = []
        for block in response.content:
            if hasattr(block, 'text'):
                content_blocks.append({"type": "text", "text": block.text})
            elif hasattr(block, 'thinking'):
                content_blocks.append({"type": "thinking", "thinking": block.thinking})

        # Parse tool calls
        actions = parse_toolcall_actions(content_blocks)

        message = {
            "role": "assistant",
            "content": "\n".join([b.get("text", "") for b in content_blocks if b.get("type") == "text"]),
            "tool_calls": actions.get("tool_calls", []),
        }

        # Estimate cost (MiniMax doesn't provide this)
        input_tokens = response.usage.input_tokens if response.usage else 0
        output_tokens = response.usage.output_tokens if response.usage else 0

        message["extra"] = {
            "actions": actions,
            "response": {
                "model": response.model,
                "usage": {"input_tokens": input_tokens, "output_tokens": output_tokens},
            },
            "cost": 0.0,  # No cost tracking for MiniMax
            "timestamp": time.time(),
        }

        return message

    def query_text(self, messages: list[dict[str, Any]], **kwargs) -> str:
        for attempt in retry(logger=logger, abort_exceptions=self.abort_exceptions):
            with attempt:
                response = self._query(self._prepare_messages_for_api(messages))
        input_tokens = response.usage.input_tokens if response.usage else 0
        output_tokens = response.usage.output_tokens if response.usage else 0
        GLOBAL_MODEL_STATS.add(0.0)
        logger.debug(
            "anthropic_sdk query_text usage input_tokens=%s output_tokens=%s",
            input_tokens,
            output_tokens,
        )
        return _content_blocks_to_text(response.content)
