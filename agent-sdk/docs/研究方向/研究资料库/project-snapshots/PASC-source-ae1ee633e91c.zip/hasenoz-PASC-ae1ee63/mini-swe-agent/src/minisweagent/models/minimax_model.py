"""MiniMax model using Anthropic SDK."""

import json
import logging
import os
import time
from typing import Any

import anthropic
from pydantic import BaseModel

from minisweagent.models import GLOBAL_MODEL_STATS
from minisweagent.models.utils.actions_text import parse_regex_actions
from minisweagent.models.utils.actions_toolcall import (
    format_toolcall_observation_messages,
    parse_toolcall_actions,
)
from minisweagent.models.utils.anthropic_utils import _reorder_anthropic_thinking_blocks
from minisweagent.models.utils.cache_control import set_cache_control
from minisweagent.models.utils.openai_multimodal import expand_multimodal_content
from minisweagent.models.utils.retry import retry

logger = logging.getLogger("minimax_model")


def _raw_blocks_to_text(blocks: list[dict[str, Any]]) -> str:
    parts = []
    for block in blocks:
        if block.get("type") == "text" and block.get("text"):
            parts.append(str(block["text"]))
    return "\n".join(parts)


class MiniMaxModelConfig(BaseModel):
    model_name: str
    model_kwargs: dict[str, Any] = {}
    set_cache_control: str | None = None
    cost_tracking: str = "ignore_errors"
    format_error_template: str = "{{ error }}"
    observation_template: str = (
        "{% if output.exception_info %}<exception>{{output.exception_info}}</exception>\n{% endif %}"
        "<returncode>{{output.returncode}}</returncode>\n<output>\n{{output.output}}</output>"
    )
    multimodal_regex: str = ""
    action_regex: str = r"<mswea_bash_command>\s*(.*?)\s*</mswea_bash_command>"
    api_key: str | None = None
    base_url: str = "https://api.minimax.io/anthropic"


class MiniMaxModel:
    abort_exceptions = [KeyboardInterrupt]

    def __init__(self, **kwargs):
        self.config = MiniMaxModelConfig(**kwargs)
        # Strip the litellm-style "minimax/" routing prefix: the Anthropic SDK
        # client talks to the Minimax Anthropic-compatible endpoint directly, so
        # the API expects the bare model name (e.g. "MiniMax-M2.7-highspeed").
        # Passing "minimax/MiniMax-M2.7-highspeed" verbatim caused a silent
        # fallback to the default "MiniMax-M2.7" variant on the server side.
        if self.config.model_name.startswith("minimax/"):
            self.config.model_name = self.config.model_name.removeprefix("minimax/")
        api_key = self.config.api_key or os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY not set")
        self.client = anthropic.Anthropic(
            api_key=api_key,
            base_url=self.config.base_url,
        )

    def _query(self, messages: list[dict], **kwargs):
        # Messages are already prepared in _prepare_messages_for_api
        # Just pass them through directly - content can be string or array of blocks

        # Use tools with MiniMax-compatible format (input_schema, not function.parameters)
        tools = [{
            "name": "bash",
            "description": "Execute a bash command",
            "input_schema": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The bash command to execute",
                    }
                },
                "required": ["command"],
            }
        }]

        # drop_params is a litellm-only flag; the Anthropic SDK rejects unknown kwargs.
        extra = {k: v for k, v in self.config.model_kwargs.items() if k != "drop_params"}

        return self.client.messages.create(
            model=self.config.model_name,
            max_tokens=16384,
            messages=messages,
            tools=tools,
            **extra,
        )

    def _prepare_messages_for_api(self, messages: list[dict]) -> list[dict]:
        prepared = []
        i = 0
        while i < len(messages):
            msg = messages[i]
            role = msg.get("role")

            # Tool result messages → must be wrapped in a user role message as a content array
            if role == "tool" or msg.get("type") == "function_call_output":
                # Collect consecutive tool results and batch them into one user message
                tool_results = []
                while i < len(messages):
                    m = messages[i]
                    if m.get("role") == "tool" or m.get("type") == "function_call_output":
                        tid = m.get("tool_call_id") or m.get("call_id")
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": tid,
                            "content": m.get("content", ""),
                        })
                        i += 1
                    else:
                        break
                prepared.append({"role": "user", "content": tool_results})
                continue

            # Assistant and user messages: content is already in Anthropic block format
            # Just strip "extra" and "tool_calls" (they're redundant with content blocks)
            else:
                content = msg.get("content")
                # If content is a string, wrap it in a text block
                if isinstance(content, str):
                    content = [{"type": "text", "text": content}] if content else [{"type": "text", "text": ""}]
                prepared.append({
                    "role": role,
                    "content": content,
                })

            i += 1

        prepared = _reorder_anthropic_thinking_blocks(prepared)
        return set_cache_control(prepared, mode=self.config.set_cache_control)

    def query(self, messages: list[dict], **kwargs) -> dict:
        for attempt in retry(logger=logger, abort_exceptions=self.abort_exceptions):
            with attempt:
                response = self._query(self._prepare_messages_for_api(messages), **kwargs)

        # Store raw content blocks for faithful reconstruction in _prepare_messages_for_api
        raw_content_blocks = []
        tool_calls_for_parsing = []
        logger.debug(f"Response content blocks: {[type(b).__name__ + ':' + getattr(b, 'type', 'no_type') for b in response.content]}")

        for block in response.content:
            block_type = getattr(block, 'type', None)
            if block_type == 'text':
                raw_content_blocks.append({"type": "text", "text": block.text})
            elif block_type == 'tool_use':
                # Keep full Anthropic format - needed to reconstruct in _prepare_messages_for_api
                raw_content_blocks.append({
                    "type": "tool_use",
                    "id": block.id,
                    "name": block.name,
                    "input": block.input,
                })
                # Also create litellm-compatible object for parse_toolcall_actions
                arguments = json.dumps(block.input) if hasattr(block, 'input') else "{}"
                logger.debug(f"Tool use block: id={block.id}, name={block.name}")
                tool_call = type('ToolCall', (), {
                    'id': block.id,
                    'function': type('Function', (), {
                        'name': block.name,
                        'arguments': arguments
                    })()
                })()
                tool_calls_for_parsing.append(tool_call)
            elif block_type == 'thinking':
                raw_content_blocks.append({"type": "thinking", "thinking": block.thinking})
            else:
                logger.debug(f"Unknown block type: {block_type}")

        # Parse actions from tool calls (preferred) with fallback to text-based parsing.
        if tool_calls_for_parsing:
            actions = parse_toolcall_actions(tool_calls_for_parsing, format_error_template=self.config.format_error_template)
        else:
            text_content = "\n".join(
                block.get("text", "") for block in raw_content_blocks if block.get("type") == "text"
            )
            actions = parse_regex_actions(
                text_content,
                action_regex=self.config.action_regex,
                format_error_template=self.config.format_error_template,
            )

        # Store content as blocks, not flattened string
        message = {
            "role": "assistant",
            "content": raw_content_blocks,
            "tool_calls": actions,
        }

        # Estimate cost (MiniMax doesn't provide this)
        input_tokens = response.usage.input_tokens if response.usage else 0
        output_tokens = response.usage.output_tokens if response.usage else 0

        message["extra"] = {
            "actions": actions,
            "response": {
                "model": response.model,
                "usage": {"input_tokens": input_tokens, "output_tokens": output_tokens},
            },
            "cost": 0.0,
            "timestamp": time.time(),
        }

        return message

    def _query_text(self, messages: list[dict], **kwargs):
        extra = {k: v for k, v in self.config.model_kwargs.items() if k != "drop_params"}
        return self.client.messages.create(
            model=self.config.model_name,
            max_tokens=16384,
            messages=messages,
            **extra,
        )

    def query_text(self, messages: list[dict[str, Any]], **kwargs) -> str:
        for attempt in retry(logger=logger, abort_exceptions=self.abort_exceptions):
            with attempt:
                response = self._query_text(self._prepare_messages_for_api(messages), **kwargs)
        raw_content_blocks = []
        for block in response.content:
            if getattr(block, "type", None) == "text":
                raw_content_blocks.append({"type": "text", "text": block.text})
        GLOBAL_MODEL_STATS.add(0.0)
        return _raw_blocks_to_text(raw_content_blocks)

    def format_message(self, **kwargs) -> dict:
        return expand_multimodal_content(kwargs, pattern=self.config.multimodal_regex)

    def format_observation_messages(
        self, message: dict, outputs: list[dict], template_vars: dict | None = None
    ) -> list[dict]:
        """Format execution outputs into tool result messages."""
        actions = message.get("extra", {}).get("actions", [])
        return format_toolcall_observation_messages(
            actions=actions,
            outputs=outputs,
            observation_template=self.config.observation_template,
            template_vars=template_vars,
            multimodal_regex=self.config.multimodal_regex,
        )

    def get_template_vars(self, **kwargs) -> dict[str, Any]:
        return self.config.model_dump()

    def serialize(self) -> dict:
        return {
            "info": {
                "config": {
                    "model": self.config.model_dump(mode="json"),
                    "model_type": f"{self.__class__.__module__}.{self.__class__.__name__}",
                },
            }
        }
