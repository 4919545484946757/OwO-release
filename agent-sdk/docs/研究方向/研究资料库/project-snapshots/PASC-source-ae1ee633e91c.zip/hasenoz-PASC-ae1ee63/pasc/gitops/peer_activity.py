"""Build the <peer_activity> block injected into the next observation.

Three layers in priority order:

  L1 (commit feed)   — peer's git commits since the agent's last step
  L2 (status feed)   — peer's lifecycle events (SUBMITTED, STUCK, FAILED)
  L3 (output digest) — peer's most recent bash-output summary

Commit-source and patch-source operations are delegated to a Workspace,
which encapsulates shared- vs. federated-tree differences.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from pasc.gitops.workspace import Workspace


DEFAULT_PEER_AGENT_IDS: tuple[str, ...] = ("agent_0", "agent_1")


def peers_of(agent_id: str, all_agent_ids: tuple[str, ...]) -> list[str]:
    return [a for a in all_agent_ids if a != agent_id]


@dataclass
class PeerActivityBuilder:
    """Renders the <peer_activity> block for one agent's next step.

    Shared by all agents in a run; per-(viewer, peer) dedup state ensures a
    status or digest is surfaced exactly once to each viewer.
    """

    workspace: "Workspace"
    max_files_per_commit: int = 3
    max_commits: int = 12

    status_getter: Callable[[str], str] | None = None
    digest_getter: Callable[[str], str] | None = None
    # L3 one-shot: after a digest is surfaced, clear it. With N>2 we bypass
    # this in favor of per-(viewer, peer) dedup so the first viewer doesn't
    # clear before the others read.
    digest_clearer: Callable[[str], None] | None = None

    all_agent_ids: tuple[str, ...] = DEFAULT_PEER_AGENT_IDS

    _surfaced_status: dict[tuple[str, str], str] = field(default_factory=dict)
    _surfaced_digests: dict[tuple[str, str], str] = field(default_factory=dict)

    def build_for(self, agent_id: str) -> str:
        """Render the peer-activity block. Empty if nothing new to surface."""
        if agent_id not in self.all_agent_ids:
            return ""
        peer_ids = peers_of(agent_id, self.all_agent_ids)
        if not peer_ids:
            return ""

        layers: list[str] = [
            *self._render_l1(agent_id, peer_ids),
            *self._render_l2(agent_id, peer_ids),
            *self._render_l3(agent_id, peer_ids),
        ]
        if not layers:
            return ""
        return "<peer_activity>\n" + "\n".join(layers) + "\n</peer_activity>\n"

    def _render_l1(self, viewer: str, peer_ids: list[str]) -> list[str]:
        out: list[str] = []
        for peer_id in peer_ids:
            commits = self.workspace.consume_peer_commits(viewer, peer_id)
            if not commits:
                continue
            if len(commits) > self.max_commits:
                commits = commits[-self.max_commits :]
            out.append(self._render_commit_feed(peer_id, commits))
        return out

    def _render_commit_feed(self, peer_id: str, commits: list[tuple[str, str]]) -> str:
        peer_tree = self.workspace.peer_tree_path(peer_id)
        lines = [f"Since your last step, {peer_id} committed {len(commits)} change(s):"]
        for sha, subject in commits:
            stats = self.workspace.commit_file_stats(peer_id, sha)
            if stats:
                files_str = ", ".join(
                    f"{name} ({stat})" for name, stat in stats[: self.max_files_per_commit]
                )
                if len(stats) > self.max_files_per_commit:
                    files_str += f", +{len(stats) - self.max_files_per_commit} more"
            else:
                files_str = "(no file changes)"
            lines.append(f"  [{sha[:8]}] {subject}")
            lines.append(f"           {files_str}")
        lines.append(
            f"Run `git -C {peer_tree} show <sha>` "
            f"(or `git -C {peer_tree} diff <sha>~1 <sha>`) to inspect any commit."
        )
        return "\n".join(lines)

    def _render_l2(self, viewer: str, peer_ids: list[str]) -> list[str]:
        if self.status_getter is None:
            return []
        out: list[str] = []
        for peer_id in peer_ids:
            current_status = self.status_getter(peer_id) or ""
            if not current_status:
                continue
            if current_status == self._surfaced_status.get((viewer, peer_id), ""):
                continue
            rendered = self._render_status(peer_id, current_status)
            if rendered:
                out.append(rendered)
                self._surfaced_status[(viewer, peer_id)] = current_status
        return out

    @staticmethod
    def _render_status(peer_id: str, status: str) -> str:
        if status == "SUBMITTED":
            return (
                f"[Peer status: {peer_id} has SUBMITTED their work and stopped]\n"
                f"  → Their final tree state is what your team patch will diff against.\n"
                f"  → Decide: (a) verify the team patch with `pytest` or `git diff`, "
                f"(b) wrap up your current edit, or (c) submit if your contribution is ready."
            )
        if status == "STUCK":
            return (
                f"[Peer status: {peer_id} appears STUCK — repeated format errors / no progress]\n"
                f"  → They may not contribute further. Plan accordingly."
            )
        if status == "FAILED":
            return (
                f"[Peer status: {peer_id} terminated with an error]\n"
                f"  → Their thread is gone. You are now the only contributor."
            )
        return f"[Peer status: {peer_id} → {status}]"

    def _render_l3(self, viewer: str, peer_ids: list[str]) -> list[str]:
        if self.digest_getter is None:
            return []
        out: list[str] = []
        for peer_id in peer_ids:
            digest = self.digest_getter(peer_id) or ""
            if not digest:
                continue
            if digest == self._surfaced_digests.get((viewer, peer_id), ""):
                continue
            out.append(self._render_digest(peer_id, digest))
            self._surfaced_digests[(viewer, peer_id)] = digest
            # N=2 path: keep the in-memory digest slot clean via the clearer.
            if len(self.all_agent_ids) == 2 and self.digest_clearer is not None:
                try:
                    self.digest_clearer(peer_id)
                except Exception:
                    pass
        return out

    @staticmethod
    def _render_digest(peer_id: str, digest: str) -> str:
        return f"[Peer recent activity: {peer_id}]\n  {digest}"
