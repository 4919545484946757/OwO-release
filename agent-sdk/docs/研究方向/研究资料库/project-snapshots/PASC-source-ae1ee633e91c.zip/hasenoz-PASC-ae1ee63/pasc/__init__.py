from __future__ import annotations

from pasc.bootstrap import ensure_minisweagent_path

ensure_minisweagent_path()
