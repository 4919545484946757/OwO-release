"""Workspace strategy — how N agents share or partition the per-instance tree.

Two implementations:

  * SharedWorkspace      — all N agents commit to one git tree; peer
                           commits filtered by author. Team patch is one
                           `git diff base..HEAD`.
  * FederatedWorkspaces  — each agent owns a private clone of the base
                           tree. One patch per agent.

Both expose the same API so the orchestrator, GitOpsAgent, and
PeerActivityBuilder treat them interchangeably.
"""
from __future__ import annotations

import shlex
import threading
from abc import ABC, abstractmethod
from typing import Any

from pasc.gitops.commit_tracker import CommitRecord, CommitTracker
from pasc.gitops.git_ops import GitOps, docker_exec
from pasc.gitops.shared_environment import SharedDockerEnvironment


class Workspace(ABC):
    """How the per-instance file system is shared or partitioned."""

    @abstractmethod
    def step_lock(self, agent_id: str):
        """Context-manager lock wrapping the bash-exec + commit critical
        section. Shared mode: single workspace-wide lock (serializes
        `git add -A`/commit so peers cannot leak uncommitted writes).
        Federated mode: per-agent lock (trees are already isolated).
        """

    @abstractmethod
    def env_for(self, agent_id: str) -> SharedDockerEnvironment:
        """Container view this agent's bash commands run inside."""

    @abstractmethod
    def record_step(self, agent_id: str, step: int, thought: str) -> str | None:
        """Stage + commit pending changes in agent_id's tree. Returns new sha
        or None for an empty diff."""

    @abstractmethod
    def reset_index_for(self, agent_id: str) -> None:
        """Unstage pending changes in agent_id's tree. Working-tree mutations
        preserved. Best-effort: errors are swallowed and logged."""

    @abstractmethod
    def consume_peer_commits(self, viewer: str, peer: str) -> list[tuple[str, str]]:
        """New (sha, subject) commits by `peer` since `viewer` last checked,
        AND advance the per-pair bookmark atomically."""

    @abstractmethod
    def commit_file_stats(self, peer: str, sha: str) -> list[tuple[str, str]]:
        """[(filename, '+added/-removed')] for one of peer's commits."""

    @abstractmethod
    def peer_authored_files(self, viewer: str) -> set[str]:
        """Union of files committed by any peer (not viewer)."""

    @abstractmethod
    def history(self) -> list[CommitRecord]:
        """All commit records produced in this run, ordered by (step, agent_id)."""

    @abstractmethod
    def extract_patches(self) -> dict[str, str]:
        """{agent_id: diff_text}. Shared mode returns the same team patch
        for every key; federated returns distinct per-agent patches."""

    @abstractmethod
    def head_summary(self) -> dict[str, str]:
        """{agent_id: head_sha} for the merge report."""

    @abstractmethod
    def base_commit(self) -> str:
        """The starting commit captured before any agent ran."""

    @abstractmethod
    def peer_tree_path(self, peer: str) -> str:
        """Container path where peer's tree lives. Used to render
        `git -C <path> show <sha>` hints. Shared mode returns the same path
        for every peer."""

    @abstractmethod
    def task_prelude(self, agent_id: str) -> str:
        """Mode-specific text prepended to agent_id's task. Empty in shared
        mode; in federated mode a <workspace_note> describing the private
        tree path."""


class SharedWorkspace(Workspace):
    """All agents commit to one tree. Peer commits filtered by author."""

    def __init__(
        self,
        *,
        base_env: Any,
        container_id: str,
        executable: str,
        repo_path: str,
        base_commit: str,
        agent_ids: tuple[str, ...],
        logger: Any,
    ) -> None:
        self._env = SharedDockerEnvironment(base_env, container_id)
        self._git_ops = GitOps(
            container_id=container_id, repo_path=repo_path, executable=executable
        )
        self._tracker = CommitTracker(self._git_ops, base_commit, logger=logger)
        self._agent_ids = tuple(agent_ids)
        self._repo_path = repo_path
        self._base_commit = base_commit

        # Workspace-wide lock: closes the attribution-leak race when two
        # agents try to commit at the same time.
        self._step_lock = threading.Lock()

    def step_lock(self, agent_id: str):
        return self._step_lock

    def env_for(self, agent_id: str) -> SharedDockerEnvironment:
        return self._env

    def record_step(self, agent_id: str, step: int, thought: str) -> str | None:
        return self._tracker.record_step(agent_id=agent_id, step=step, thought=thought)

    def reset_index_for(self, agent_id: str) -> None:
        try:
            self._git_ops.reset_index()
        except Exception:
            pass

    def consume_peer_commits(self, viewer: str, peer: str) -> list[tuple[str, str]]:
        head = self._tracker.head()
        last_seen = self._tracker.last_seen(viewer, peer)
        if head == last_seen:
            return []
        commits = self._git_ops.log_between(last_seen, head, author=peer)
        self._tracker.advance_last_seen(viewer, peer, head)
        return commits

    def commit_file_stats(self, peer: str, sha: str) -> list[tuple[str, str]]:
        return self._git_ops.show_stat(sha)

    def peer_authored_files(self, viewer: str) -> set[str]:
        files: set[str] = set()
        for rec in self._tracker.history:
            if rec.agent_id == viewer:
                continue
            try:
                for fname, _stat in self._git_ops.show_stat(rec.sha):
                    files.add(fname)
            except Exception:
                pass
        return files

    def history(self) -> list[CommitRecord]:
        return list(self._tracker.history)

    def extract_patches(self) -> dict[str, str]:
        try:
            head = self._tracker.head()
            patch = self._git_ops.diff(self._base_commit, head)
        except Exception:
            patch = ""
        return {agent_id: patch for agent_id in self._agent_ids}

    def head_summary(self) -> dict[str, str]:
        head = self._tracker.head()
        return {agent_id: head for agent_id in self._agent_ids}

    def base_commit(self) -> str:
        return self._base_commit

    def peer_tree_path(self, peer: str) -> str:
        return self._repo_path

    def task_prelude(self, agent_id: str) -> str:
        return ""


class FederatedWorkspaces(Workspace):
    """Each agent owns a private clone of the base tree.

    Container layout::

        <repo_path>            ← base (read-only reference)
        <repo_path>_agent_0    ← agent_0's private clone
        <repo_path>_agent_1    ← agent_1's private clone
        ...

    Each tree has the full base history; new commits go on top, and
    `git diff base..HEAD` inside each tree gives that agent's contributions.
    """

    def __init__(
        self,
        *,
        base_env: Any,
        container_id: str,
        executable: str,
        repo_path: str,
        base_commit: str,
        agent_ids: tuple[str, ...],
        logger: Any,
    ) -> None:
        self._container_id = container_id
        self._executable = executable
        self._base_repo_path = repo_path
        self._base_commit = base_commit
        self._agent_ids = tuple(agent_ids)
        self._logger = logger

        self._tree_paths: dict[str, str] = {}
        self._git_ops: dict[str, GitOps] = {}
        self._envs: dict[str, SharedDockerEnvironment] = {}
        self._trackers: dict[str, CommitTracker] = {}

        # Per-agent locks. Trees are isolated, so contention is rare; keeping
        # the map uniform with SharedWorkspace simplifies the API.
        self._step_locks: dict[str, threading.Lock] = {
            aid: threading.Lock() for aid in agent_ids
        }

        self._setup(base_env)

    def step_lock(self, agent_id: str):
        return self._step_locks[agent_id]

    def _setup(self, base_env: Any) -> None:
        for agent_id in self._agent_ids:
            tree = f"{self._base_repo_path}_{agent_id}"
            self._tree_paths[agent_id] = tree

            self._clone_tree(tree, agent_id)

            git = GitOps(
                container_id=self._container_id,
                repo_path=tree,
                executable=self._executable,
            )
            git.disable_auto_gc()
            self._git_ops[agent_id] = git
            self._envs[agent_id] = SharedDockerEnvironment(
                base_env, self._container_id, cwd=tree
            )
            self._trackers[agent_id] = CommitTracker(git, self._base_commit, logger=self._logger)

    def _clone_tree(self, tree: str, agent_id: str) -> None:
        # --no-local disables file:// hardlinking; we want each tree fully
        # self-contained so cross-tree git ops don't share state.
        cmd = (
            f"git clone --no-hardlinks --no-local "
            f"{shlex.quote(self._base_repo_path)} {shlex.quote(tree)}"
        )
        rc, out = docker_exec(
            self._container_id, cmd, timeout=180, executable=self._executable
        )
        if rc != 0:
            raise RuntimeError(
                f"FederatedWorkspaces: clone for {agent_id} failed (rc={rc}): {out[:500]}"
            )
        self._logger.info(
            "event=federated_tree_cloned agent_id=%s path=%s", agent_id, tree
        )

    def env_for(self, agent_id: str) -> SharedDockerEnvironment:
        return self._envs[agent_id]

    def record_step(self, agent_id: str, step: int, thought: str) -> str | None:
        return self._trackers[agent_id].record_step(
            agent_id=agent_id, step=step, thought=thought
        )

    def reset_index_for(self, agent_id: str) -> None:
        try:
            self._git_ops[agent_id].reset_index()
        except Exception:
            pass

    def consume_peer_commits(self, viewer: str, peer: str) -> list[tuple[str, str]]:
        peer_git = self._git_ops[peer]
        peer_tracker = self._trackers[peer]
        head = peer_git.head_sha()
        last_seen = peer_tracker.last_seen(viewer, peer)
        if head == last_seen:
            return []
        # No --author filter: each tree only contains its owner's post-base
        # commits, and log_between skips the pre-base history.
        commits = peer_git.log_between(last_seen, head)
        peer_tracker.advance_last_seen(viewer, peer, head)
        return commits

    def commit_file_stats(self, peer: str, sha: str) -> list[tuple[str, str]]:
        return self._git_ops[peer].show_stat(sha)

    def peer_authored_files(self, viewer: str) -> set[str]:
        files: set[str] = set()
        for agent_id, tracker in self._trackers.items():
            if agent_id == viewer:
                continue
            git = self._git_ops[agent_id]
            for rec in tracker.history:
                try:
                    for fname, _stat in git.show_stat(rec.sha):
                        files.add(fname)
                except Exception:
                    pass
        return files

    def history(self) -> list[CommitRecord]:
        combined: list[CommitRecord] = []
        for tracker in self._trackers.values():
            combined.extend(tracker.history)
        combined.sort(key=lambda rec: (rec.step, rec.agent_id))
        return combined

    def extract_patches(self) -> dict[str, str]:
        patches: dict[str, str] = {}
        for agent_id in self._agent_ids:
            try:
                head = self._git_ops[agent_id].head_sha()
                patches[agent_id] = self._git_ops[agent_id].diff(self._base_commit, head)
            except Exception:
                patches[agent_id] = ""
        return patches

    def head_summary(self) -> dict[str, str]:
        return {
            agent_id: self._git_ops[agent_id].head_sha()
            for agent_id in self._agent_ids
        }

    def base_commit(self) -> str:
        return self._base_commit

    def peer_tree_path(self, peer: str) -> str:
        return self._tree_paths[peer]

    def task_prelude(self, agent_id: str) -> str:
        # The default system prompt was written for shared mode and refers to
        # /testbed (or /app). In federated mode each agent has a clone at a
        # different path; this note overrides the prompt to point at the
        # private tree so writes land where the commit hook can see them.
        tree = self._tree_paths[agent_id]
        base = self._base_repo_path
        peer_lines = [
            f"  {peer}: {self._tree_paths[peer]}"
            for peer in self._agent_ids
            if peer != agent_id
        ]
        peer_block = "\n".join(peer_lines) if peer_lines else "  (you are the only agent)"
        return (
            "<workspace_note>\n"
            f"Your private workspace tree is at {tree}. Bash commands run with "
            f"cwd={tree} by default. ALWAYS use either relative paths or paths "
            f"prefixed with {tree}/ when modifying files.\n"
            "\n"
            f"The original repository at {base} is the shared READ-ONLY base "
            f"reference. Reading from {base}/... is fine; writing there will "
            f"NOT land in your tree's git history and will be lost.\n"
            "\n"
            "Your peers' private trees (for inspection via `git -C <path> show <sha>`):\n"
            f"{peer_block}\n"
            "</workspace_note>\n\n"
        )


def build_workspace(
    mode: str,
    *,
    base_env: Any,
    container_id: str,
    executable: str,
    repo_path: str,
    base_commit: str,
    agent_ids: tuple[str, ...],
    logger: Any,
) -> Workspace:
    """Construct the requested workspace strategy. Raises ValueError on an
    unknown mode (no silent fallback).
    """
    kwargs = dict(
        base_env=base_env,
        container_id=container_id,
        executable=executable,
        repo_path=repo_path,
        base_commit=base_commit,
        agent_ids=tuple(agent_ids),
        logger=logger,
    )
    if mode == "shared":
        return SharedWorkspace(**kwargs)
    if mode == "federated":
        return FederatedWorkspaces(**kwargs)
    raise ValueError(
        f"Unknown workspace mode: {mode!r}. Expected one of: 'shared', 'federated'."
    )
