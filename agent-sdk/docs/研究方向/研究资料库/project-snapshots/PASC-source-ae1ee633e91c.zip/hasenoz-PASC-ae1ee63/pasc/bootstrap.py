from __future__ import annotations

import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
MINI_SWE_AGENT_SRC = REPO_ROOT / "mini-swe-agent" / "src"


def ensure_minisweagent_path() -> None:
    """Ensure the local mini-swe-agent source tree is importable."""
    src_path = str(MINI_SWE_AGENT_SRC)
    if src_path not in sys.path:
        sys.path.insert(0, src_path)
