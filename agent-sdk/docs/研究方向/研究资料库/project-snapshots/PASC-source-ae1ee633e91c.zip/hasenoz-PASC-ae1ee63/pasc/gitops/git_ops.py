"""Container-side git operations. All operations target a known repo_path
inside the container (typically /testbed or /app for SWE-Bench Pro images).
"""
from __future__ import annotations

import shlex
import subprocess
import time
from dataclasses import dataclass


CANDIDATE_REPO_PATHS: tuple[str, ...] = ("/testbed", "/app")


def docker_exec(container_id: str, command: str, *, timeout: int = 60, executable: str = "docker") -> tuple[int, str]:
    """Run a bash command in the container; return (rc, combined stdout/stderr)."""
    cmd = [executable, "exec", container_id, "bash", "-lc", command]
    result = subprocess.run(
        cmd,
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )
    return result.returncode, result.stdout or ""


def detect_repo_path(container_id: str, *, executable: str = "docker") -> str:
    """Absolute path of the git repo inside the container.

    Tries CANDIDATE_REPO_PATHS first, then `find / -maxdepth 4 -name .git`.
    """
    for candidate in CANDIDATE_REPO_PATHS:
        rc, _ = docker_exec(container_id, f"test -d {shlex.quote(candidate)}/.git", executable=executable)
        if rc == 0:
            return candidate

    rc, output = docker_exec(
        container_id,
        "find / -maxdepth 4 -name .git -type d 2>/dev/null | head -1",
        executable=executable,
    )
    candidate = output.strip()
    if rc == 0 and candidate.endswith("/.git"):
        return candidate[: -len("/.git")]
    raise RuntimeError(f"Could not detect git repo path in container {container_id}")


@dataclass(slots=True)
class GitOps:
    """Wrapper around `docker exec ... git ...` for one container/repo."""

    container_id: str
    repo_path: str
    executable: str = "docker"
    timeout: int = 60

    def run(self, args: str, *, timeout: int | None = None) -> tuple[int, str]:
        cmd = f"cd {shlex.quote(self.repo_path)} && git {args}"
        return docker_exec(self.container_id, cmd, timeout=timeout or self.timeout, executable=self.executable)

    def run_shell(self, shell_cmd: str, *, timeout: int | None = None) -> tuple[int, str]:
        cmd = f"cd {shlex.quote(self.repo_path)} && {shell_cmd}"
        return docker_exec(self.container_id, cmd, timeout=timeout or self.timeout, executable=self.executable)

    def head_sha(self) -> str:
        rc, out = self.run("rev-parse HEAD")
        if rc != 0:
            raise RuntimeError(f"git rev-parse HEAD failed: {out}")
        return out.strip()

    def commit_pending(self, *, agent_id: str, message: str) -> str | None:
        """Stage and commit any pending changes attributed to agent_id.

        Returns the new commit sha, or None if there was nothing to commit.
        """
        message_arg = shlex.quote(message)
        author_name = shlex.quote(agent_id)
        author_email = shlex.quote(f"{agent_id}@pasc.local")
        # `-c gc.auto=0 -c maintenance.auto=false`: git's default
        # gc.autoDetach=true would fork a background `git gc --auto` after
        # each commit, which can hold .git/index.lock past our return and
        # collide with the next agent's `git add`. Container is ephemeral,
        # so disabling housekeeping has no downstream effect.
        no_bg = "-c gc.auto=0 -c maintenance.auto=false"
        cmd = (
            f"git {no_bg} add -A && "
            f"( git {no_bg} diff --cached --quiet && exit 99 ; "
            f"git {no_bg} -c user.name={author_name} -c user.email={author_email} "
            f"commit --allow-empty-message -m {message_arg} )"
        )
        # Defense-in-depth: retry briefly on transient index.lock collisions.
        backoffs = (0.05, 0.20, 0.50)
        rc, out = self.run_shell(cmd)
        for delay in backoffs:
            if rc != 128 or "index.lock" not in out:
                break
            time.sleep(delay)
            rc, out = self.run_shell(cmd)
        if rc == 99:
            return None
        if rc != 0:
            raise RuntimeError(f"git commit failed (rc={rc}): {out}")
        return self.head_sha()

    def reset_index(self) -> tuple[int, str]:
        """Unstage everything in the index. Working-tree mutations preserved."""
        return self.run_shell("git -c gc.auto=0 -c maintenance.auto=false reset HEAD")

    def disable_auto_gc(self) -> None:
        """Persist gc.auto=0 / maintenance.auto=false in `.git/config`.

        Belt-and-suspenders with the inline `-c gc.auto=0` flags on each
        commit — ensures other code paths (agent bash, vendored tooling)
        also skip auto-gc. Must be called AFTER init_if_needed.
        """
        for setting in ("gc.auto 0", "maintenance.auto false"):
            self.run(f"config --local {setting}")

    def diff(self, base: str, head: str = "HEAD") -> str:
        rc, out = self.run(f"diff {shlex.quote(base)}..{shlex.quote(head)}", timeout=120)
        if rc != 0:
            raise RuntimeError(f"git diff {base}..{head} failed: {out}")
        return out

    def log_between(self, base: str, head: str = "HEAD", *, author: str | None = None) -> list[tuple[str, str]]:
        """Commits between base and head as (sha, subject), oldest first."""
        author_arg = f" --author={shlex.quote(author)}" if author else ""
        rc, out = self.run(f"log {shlex.quote(base)}..{shlex.quote(head)}{author_arg} --reverse --format=%H%x09%s")
        if rc != 0:
            raise RuntimeError(f"git log failed: {out}")
        commits: list[tuple[str, str]] = []
        for line in out.splitlines():
            if "\t" not in line:
                continue
            sha, subject = line.split("\t", 1)
            if sha.strip():
                commits.append((sha.strip(), subject.strip()))
        return commits

    def show_stat(self, sha: str) -> list[tuple[str, str]]:
        """[(filename, '+added/-removed')] for a commit's modified files."""
        rc, out = self.run(f"show --stat --format= {shlex.quote(sha)}")
        if rc != 0:
            return []
        files: list[tuple[str, str]] = []
        for line in out.splitlines():
            if "|" not in line:
                continue
            left, right = line.split("|", 1)
            name = left.strip()
            if not name or name.startswith(" "):
                continue
            stat = right.strip()
            files.append((name, stat))
        return files

    def init_if_needed(self) -> None:
        """Ensure the repo has a starting commit so we can diff from base."""
        rc, _ = self.run("rev-parse HEAD")
        if rc == 0:
            return
        rc, out = self.run("init")
        if rc != 0:
            raise RuntimeError(f"git init failed: {out}")
        no_bg = "-c gc.auto=0 -c maintenance.auto=false"
        cmd = (
            f"git {no_bg} add -A && "
            f"git {no_bg} -c user.name=pasc-base -c user.email=base@pasc.local "
            f"commit --allow-empty -m 'pasc base'"
        )
        rc, out = self.run_shell(cmd)
        if rc != 0:
            raise RuntimeError(f"pasc base commit failed: {out}")
