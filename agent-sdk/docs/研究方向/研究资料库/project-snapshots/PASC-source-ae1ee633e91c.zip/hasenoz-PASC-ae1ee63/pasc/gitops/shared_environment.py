"""Wrapper around mini-swe-agent's DockerEnvironment that lets multiple
agents target a single container. Composition over subclassing — the
upstream class owns its container; we only override the lifecycle hooks.
"""
from __future__ import annotations

from typing import Any


class SharedDockerEnvironment:
    """Composition wrapper. One container, one or more agents."""

    def __init__(
        self,
        base_env: Any,
        container_id: str,
        *,
        cwd: str | None = None,
    ):
        if getattr(base_env, "container_id", None) != container_id:
            raise ValueError(
                f"base_env.container_id={getattr(base_env, 'container_id', None)!r} "
                f"does not match shared container_id={container_id!r}"
            )
        self._base_env = base_env
        self._shared_container_id = container_id
        # Per-agent cwd override. None falls through to base_env's config
        # default. Explicit `cwd` arg to execute() still wins.
        self._cwd_override = cwd

    @property
    def container_id(self) -> str:
        return self._shared_container_id

    def execute(self, action: dict, cwd: str = "", *, timeout: int | None = None) -> dict[str, Any]:
        # Priority: explicit `cwd` arg > override > base_env default.
        effective_cwd = cwd or self._cwd_override or ""
        return self._base_env.execute(action, cwd=effective_cwd, timeout=timeout)

    def get_template_vars(self, **kwargs: Any) -> dict[str, Any]:
        vars_ = self._base_env.get_template_vars(**kwargs)
        if self._cwd_override is not None:
            vars_["cwd"] = self._cwd_override
        return vars_

    def serialize(self) -> dict:
        return self._base_env.serialize()

    def cleanup(self) -> None:
        """No-op; the orchestrator drives cleanup of the base env."""
        return None

    @property
    def config(self) -> Any:
        return self._base_env.config
