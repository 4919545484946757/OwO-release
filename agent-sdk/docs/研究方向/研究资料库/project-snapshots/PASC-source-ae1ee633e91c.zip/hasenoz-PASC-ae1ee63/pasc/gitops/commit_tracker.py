"""Thread-safe git commit hook + per-agent last-seen bookkeeping.

Two agents may finish steps concurrently; we serialize the git commit
operation with a mutex so attribution is clean. The bash subprocesses
themselves still run in parallel. The per-agent last-seen pointer is
also maintained here: each (viewer, peer) bookmark records the most
recent peer commit `viewer` has been shown, so each commit surfaces to
each viewer exactly once.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass

from pasc.gitops.git_ops import GitOps


@dataclass(slots=True)
class CommitRecord:
    sha: str
    agent_id: str
    step: int
    subject: str


class CommitTracker:
    """Shared GitOps + serialized commit + per-(viewer, peer) last-seen bookmarks."""

    def __init__(self, git_ops: GitOps, base_commit: str, *, logger: logging.Logger | None = None):
        self.git_ops = git_ops
        self.base_commit = base_commit
        self.logger = logger or logging.getLogger("pasc.gitops.commit_tracker")
        self._lock = threading.Lock()
        self._bookmark_lock = threading.Lock()
        self._bookmarks: dict[tuple[str, str], str] = {}
        self.history: list[CommitRecord] = []

    def record_step(self, *, agent_id: str, step: int, thought: str) -> str | None:
        """Stage + commit pending changes; return the new sha (or None)."""
        subject = self._compose_subject(agent_id=agent_id, step=step, thought=thought)
        with self._lock:
            sha = self.git_ops.commit_pending(agent_id=agent_id, message=subject)
            if sha is None:
                self.logger.debug("agent_id=%s step=%s event=no_changes_to_commit", agent_id, step)
                return None
            self.history.append(CommitRecord(sha=sha, agent_id=agent_id, step=step, subject=subject))
            self.logger.info("agent_id=%s step=%s event=commit sha=%s", agent_id, step, sha[:8])
            return sha

    def head(self) -> str:
        with self._lock:
            return self.git_ops.head_sha()

    def last_seen(self, viewer: str, peer: str) -> str:
        """Return the peer commit `viewer` was last shown (or base_commit)."""
        with self._bookmark_lock:
            return self._bookmarks.get((viewer, peer), self.base_commit)

    def advance_last_seen(self, viewer: str, peer: str, sha: str) -> None:
        """Move `viewer`'s last-seen pointer for `peer` to `sha`."""
        with self._bookmark_lock:
            self._bookmarks[(viewer, peer)] = sha

    @staticmethod
    def _compose_subject(*, agent_id: str, step: int, thought: str) -> str:
        text = " ".join((thought or "").split())
        if not text:
            text = "no thought"
        if len(text) > 140:
            text = text[:137] + "..."
        return f"{agent_id} step {step}: {text}"
