"""GitOps multi-agent orchestrator — one container, N agents."""
from __future__ import annotations

import copy
import json
import os
import threading
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from pasc.bootstrap import ensure_minisweagent_path

ensure_minisweagent_path()

from minisweagent.models import get_model
from minisweagent.run.benchmarks.swebench import compose_pro_task, get_sb_environment

from pasc.shared import (
    AgentPatchResult,
    CommonOrchestratorConfig,
    DEFAULT_AGENT_IDS,
    PascRunResult,
    build_run_logger,
    build_runtime_config,
    build_seeded_task,
    load_swebench_instance,
    resolve_seed_slots,
)
from pasc.gitops.agent import GitOpsAgent
from pasc.gitops.git_ops import GitOps, detect_repo_path
from pasc.gitops.output_digest import OutputDigestExtractor
from pasc.gitops.peer_activity import PeerActivityBuilder
from pasc.gitops.run_state import AgentStatus, RunState
from pasc.gitops.workspace import Workspace, build_workspace


DEFAULT_GITOPS_OUTPUT_DIR = Path("runs") / "pasc_gitops"


@dataclass(slots=True)
class GitOpsConfig(CommonOrchestratorConfig):
    """Config for the GitOps orchestrator."""

    output_dir: Path = DEFAULT_GITOPS_OUTPUT_DIR
    agent_ids: tuple[str, ...] = DEFAULT_AGENT_IDS


@dataclass(slots=True)
class RunContext:
    """Run-scoped state shared between orchestrator phases and workers."""

    instance: dict
    runtime_config: dict
    run_dir: Path
    base_task: str
    agent_ids: tuple[str, ...]
    seed_slots: list[str | None]
    container_id: str
    base_env: Any
    workspace: Workspace
    run_state: RunState
    peer_activity: PeerActivityBuilder
    digest_extractor: OutputDigestExtractor
    observation_role: str
    logger: Any
    results: dict[str, AgentPatchResult] = field(default_factory=dict)
    _results_lock: threading.Lock = field(default_factory=threading.Lock)

    def record_result(self, result: AgentPatchResult) -> None:
        with self._results_lock:
            self.results[result.agent_id] = result


class StatusNormalizer:
    """Maps mini-swe-agent exit-status strings to the peer-activity vocabulary."""

    _EXACT_MAP = {
        "Submitted": AgentStatus.SUBMITTED,
        "DONE": AgentStatus.SUBMITTED,
        "FAILED": AgentStatus.FAILED,
        "STUCK": AgentStatus.STUCK,
        "RUNNING": "",  # don't surface in-progress
    }

    def normalize(self, raw: str | None) -> str:
        if not raw:
            return ""
        return self._EXACT_MAP.get(raw, "")


class DigestPassModePolicy:
    """Resolves the pure-pass digest mode from PASC_DIGEST_PASS_MODE.

    Modes: qualify (default) / suppress / raw.
    """

    VAR = "PASC_DIGEST_PASS_MODE"

    @classmethod
    def resolve(cls, env: dict[str, str] | None = None) -> str:
        env = env if env is not None else os.environ
        return env.get(cls.VAR, "qualify")


class ObservationRolePolicy:
    """Message role for the bash observation: 'user' (default, text-bash) or
    'tool' (native-tool providers like DeepSeek-V4-Pro).
    """

    VAR = "PASC_GITOPS_OBSERVATION_ROLE"
    VALID = ("user", "tool")

    @classmethod
    def resolve(cls, env: dict[str, str] | None = None) -> str:
        env = env if env is not None else os.environ
        value = env.get(cls.VAR, "user")
        return value if value in cls.VALID else "user"


class GitOpsOrchestrator:
    """Drives one full multi-agent run end-to-end."""

    def __init__(
        self,
        config: GitOpsConfig,
        *,
        instance_loader: Callable[[str, str, str], dict] = load_swebench_instance,
        agent_factory: type[GitOpsAgent] = GitOpsAgent,
        status_normalizer: StatusNormalizer | None = None,
    ):
        self.config = config
        self._instance_loader = instance_loader
        self._agent_factory = agent_factory
        self._status_normalizer = status_normalizer or StatusNormalizer()

    def run(self) -> PascRunResult:
        ctx = self._prepare()
        try:
            self._run_agents(ctx)
            patches = self._extract_patches(ctx)
            headline_patch_path = self._write_patches(ctx, patches)
            self._write_merge_report(ctx, patches)
            self._persist_run_state(ctx)
            return PascRunResult(
                run_dir=ctx.run_dir,
                final_patch_path=headline_patch_path,
            )
        finally:
            self._cleanup(ctx)

    def _prepare(self) -> RunContext:
        instance = self._instance_loader(
            self.config.subset, self.config.split, self.config.instance_spec
        )
        runtime_config = build_runtime_config(self.config)
        run_dir = self._make_run_dir(instance["instance_id"])
        run_dir.mkdir(parents=True, exist_ok=True)

        logger = build_run_logger(run_dir / "orchestrator.log")
        logger.info(
            "event=orchestrator_start mode=gitops workspace=%s instance_id=%s",
            self.config.workspace, instance["instance_id"],
        )

        base_task = compose_pro_task(instance)
        agent_ids = tuple(self.config.agent_ids)
        if not agent_ids:
            raise ValueError("GitOpsConfig.agent_ids must be non-empty")
        seed_slots = resolve_seed_slots(base_task, self.config.seed_files, len(agent_ids))
        logger.info("event=agent_roster agents=%s", list(agent_ids))

        base_env, container_id = self._boot_container(runtime_config, instance, logger)
        executable, repo_path, base_commit = self._capture_base(
            base_env, container_id, runtime_config, logger
        )

        workspace = build_workspace(
            self.config.workspace,
            base_env=base_env,
            container_id=container_id,
            executable=executable,
            repo_path=repo_path,
            base_commit=base_commit,
            agent_ids=agent_ids,
            logger=logger,
        )
        logger.info(
            "event=workspace_ready mode=%s base_commit=%s repo_path=%s",
            self.config.workspace, base_commit, repo_path,
        )

        run_state = RunState.empty()
        peer_activity = self._build_peer_activity(workspace, run_state, agent_ids)
        digest_extractor = OutputDigestExtractor(pure_pass_mode=DigestPassModePolicy.resolve())

        return RunContext(
            instance=instance,
            runtime_config=runtime_config,
            run_dir=run_dir,
            base_task=base_task,
            agent_ids=agent_ids,
            seed_slots=seed_slots,
            container_id=container_id,
            base_env=base_env,
            workspace=workspace,
            run_state=run_state,
            peer_activity=peer_activity,
            digest_extractor=digest_extractor,
            observation_role=ObservationRolePolicy.resolve(),
            logger=logger,
        )

    def _boot_container(
        self, runtime_config: dict, instance: dict, logger: Any
    ) -> tuple[Any, str]:
        env = get_sb_environment(copy.deepcopy(runtime_config), instance)
        container_id = getattr(env, "container_id", None)
        if not container_id:
            raise RuntimeError(
                f"get_sb_environment returned an env without container_id: {env!r}"
            )
        logger.info("event=container_ready container_id=%s", container_id)
        return env, container_id

    def _capture_base(
        self, env: Any, container_id: str, runtime_config: dict, logger: Any
    ) -> tuple[str, str, str]:
        executable = (
            runtime_config.get("environment", {}).get("executable", "docker") or "docker"
        )
        repo_path = detect_repo_path(container_id, executable=executable)
        base_git = GitOps(
            container_id=container_id, repo_path=repo_path, executable=executable
        )
        base_git.init_if_needed()
        # See GitOps.commit_pending: disable git's background auto-gc to
        # prevent post-commit gc from holding .git/index.lock and colliding
        # with the next agent's `git add -A`.
        base_git.disable_auto_gc()
        base_commit = base_git.head_sha()
        logger.info(
            "event=base_commit_captured repo=%s sha=%s", repo_path, base_commit
        )
        return executable, repo_path, base_commit

    def _build_peer_activity(
        self,
        workspace: Workspace,
        run_state: RunState,
        agent_ids: tuple[str, ...],
    ) -> PeerActivityBuilder:
        normalizer = self._status_normalizer
        return PeerActivityBuilder(
            workspace=workspace,
            status_getter=lambda peer: normalizer.normalize(run_state.status.get(peer)),
            digest_getter=run_state.digests.get,
            digest_clearer=run_state.digests.clear,
            all_agent_ids=agent_ids,
        )

    def _run_agents(self, ctx: RunContext) -> None:
        threads = [
            threading.Thread(
                target=self._run_one_agent,
                args=(ctx, idx),
                name=f"pasc-gitops-{ctx.agent_ids[idx]}",
                daemon=False,
            )
            for idx in range(len(ctx.agent_ids))
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

    def _run_one_agent(self, ctx: RunContext, agent_index: int) -> None:
        agent_id = ctx.agent_ids[agent_index]
        seed_file = ctx.seed_slots[agent_index]
        agent_dir = ctx.run_dir / agent_id
        agent_dir.mkdir(parents=True, exist_ok=True)
        agent_logger = ctx.logger.getChild(agent_id)
        paths = _AgentArtifactPaths(
            trajectory=agent_dir / "trajectory.json",
            raw_patch=agent_dir / "raw.patch",
            result=agent_dir / "result.json",
        )

        info = _AgentRunInfo(
            agent_id=agent_id, seed_file=seed_file, container_id=ctx.container_id
        )
        agent: GitOpsAgent | None = None
        try:
            agent = self._build_agent(ctx, agent_id, paths.trajectory, agent_logger)
            task = build_seeded_task(ctx.base_task, seed_file)
            workspace_prelude = ctx.workspace.task_prelude(agent_id)
            if workspace_prelude:
                task = workspace_prelude + task
            run_info = agent.run(task, agent_id=agent_id)
            info.exit_status = str(run_info.get("exit_status", ""))
            info.submission = str(run_info.get("submission", "") or "")
            info.status = AgentStatus.DONE
            agent_logger.info(
                "event=agent_complete agent_id=%s exit=%s patch_bytes=%s",
                agent_id, info.exit_status, len(info.submission.encode("utf-8")),
            )
        except Exception as exc:
            info.exit_status = type(exc).__name__
            info.exception_str = str(exc)
            info.traceback_str = traceback.format_exc()
            agent_logger.exception("event=agent_failed agent_id=%s", agent_id)
        finally:
            self._save_agent_artifacts(ctx, agent, info, paths, agent_logger)

    def _build_agent(
        self,
        ctx: RunContext,
        agent_id: str,
        trajectory_path: Path,
        agent_logger: Any,
    ) -> GitOpsAgent:
        model = get_model(config=copy.deepcopy(ctx.runtime_config.get("model", {})))
        agent_config = copy.deepcopy(ctx.runtime_config.get("agent", {}))
        agent_config["output_path"] = trajectory_path

        def stuck_cb(aid: str) -> None:
            ctx.run_state.status.set(aid, AgentStatus.STUCK)

        def digest_cb(aid: str, digest: str) -> None:
            ctx.run_state.digests.set(aid, digest)

        # Adapter so GitOpsAgent keeps its CommitTracker-shaped dependency
        # while multi-tree dispatch happens inside the workspace.
        commit_hook = _CommitTrackerAdapter(workspace=ctx.workspace)

        return self._agent_factory(
            model,
            ctx.workspace.env_for(agent_id),
            agent_id=agent_id,
            runtime_logger=agent_logger,
            commit_tracker=commit_hook,
            peer_activity_builder=ctx.peer_activity,
            stuck_callback=stuck_cb,
            digest_callback=digest_cb,
            digest_extractor=ctx.digest_extractor,
            peer_authored_provider=lambda v=agent_id: ctx.workspace.peer_authored_files(v),
            observation_role=ctx.observation_role,
            step_lock=ctx.workspace.step_lock(agent_id),
            **agent_config,
        )

    def _save_agent_artifacts(
        self,
        ctx: RunContext,
        agent: GitOpsAgent | None,
        info: "_AgentRunInfo",
        paths: "_AgentArtifactPaths",
        agent_logger: Any,
    ) -> None:
        paths.raw_patch.write_text(info.submission, encoding="utf-8")

        serialized_extra = self._trajectory_extra(info, ctx)
        if agent is not None:
            try:
                agent.save(paths.trajectory, serialized_extra)
            except Exception:
                agent_logger.exception(
                    "event=trajectory_save_failed agent_id=%s", info.agent_id
                )
        elif not paths.trajectory.exists():
            placeholder = {
                "info": serialized_extra["info"],
                "instance_id": ctx.instance["instance_id"],
                "messages": [],
                "trajectory_format": "pasc-gitops-placeholder-1",
            }
            paths.trajectory.write_text(
                json.dumps(placeholder, indent=2), encoding="utf-8"
            )

        result = AgentPatchResult(
            agent_id=info.agent_id,
            seed_file=info.seed_file,
            exit_status=info.exit_status,
            status=info.status,
            submission=info.submission,
            trajectory_path=paths.trajectory,
            raw_patch_path=paths.raw_patch,
            container_id=info.container_id,
            exception_str=info.exception_str,
        )
        paths.result.write_text(
            json.dumps(result.to_json_dict(), indent=2), encoding="utf-8"
        )

        ctx.run_state.status.set(info.agent_id, info.status)
        ctx.run_state.patches.set(result)
        ctx.record_result(result)

    @staticmethod
    def _trajectory_extra(info: "_AgentRunInfo", ctx: RunContext) -> dict:
        return {
            "info": {
                "exit_status": info.exit_status,
                "submission": info.submission,
                "exception_str": info.exception_str,
                "traceback": info.traceback_str,
                "pasc": {
                    "agent_id": info.agent_id,
                    "seed_file": info.seed_file,
                    "status": info.status,
                    "container_id": info.container_id,
                    "mode": "gitops",
                    "workspace": ctx.workspace.__class__.__name__,
                },
            },
            "instance_id": ctx.instance["instance_id"],
        }

    def _extract_patches(self, ctx: RunContext) -> dict[str, str]:
        try:
            patches = ctx.workspace.extract_patches()
        except Exception:
            ctx.logger.exception("event=patch_extraction_failed")
            patches = {agent_id: "" for agent_id in ctx.agent_ids}
        total_bytes = sum(len(p.encode("utf-8")) for p in patches.values())
        ctx.logger.info(
            "event=patches_extracted count=%s total_bytes=%s",
            len(patches), total_bytes,
        )
        return patches

    def _write_patches(self, ctx: RunContext, patches: dict[str, str]) -> Path:
        """Per-agent patches + headline final.patch.

        Shared mode: all agent patches are identical → final.patch is that
        team patch. Federated mode: distinct per-agent patches; final.patch
        is the first non-empty in agent_id order.
        """
        patches_dir = ctx.run_dir / "patches"
        patches_dir.mkdir(exist_ok=True)
        for agent_id, patch in patches.items():
            (patches_dir / f"{agent_id}.diff").write_text(patch, encoding="utf-8")

        headline_agent_id, headline_patch = _pick_headline_patch(patches, ctx.agent_ids)
        headline_path = ctx.run_dir / "final.patch"
        headline_path.write_text(headline_patch, encoding="utf-8")
        ctx.logger.info(
            "event=final_patch_picked agent_id=%s bytes=%s",
            headline_agent_id, len(headline_patch.encode("utf-8")),
        )
        return headline_path

    def _write_merge_report(
        self, ctx: RunContext, patches: dict[str, str]
    ) -> Path:
        report_path = ctx.run_dir / "merge_report.json"
        headline_agent_id, _ = _pick_headline_patch(patches, ctx.agent_ids)
        report = {
            "instance_id": ctx.instance["instance_id"],
            "coordination_mode": "gitops",
            "workspace_mode": self.config.workspace,
            "merge_strategy": "team_patch_head_diff" if self.config.workspace == "shared" else "per_agent_diff",
            "base_commit": ctx.workspace.base_commit(),
            "head_commits": ctx.workspace.head_summary(),
            "headline_agent_id": headline_agent_id,
            "patches": {
                agent_id: {
                    "bytes": len(patch.encode("utf-8")),
                    "path": f"patches/{agent_id}.diff",
                }
                for agent_id, patch in patches.items()
            },
            "commit_history": [
                {"sha": rec.sha, "agent_id": rec.agent_id, "step": rec.step, "subject": rec.subject}
                for rec in ctx.workspace.history()
            ],
            "agent_results": {
                aid: result.to_json_dict()
                for aid, result in sorted(ctx.results.items())
            },
            "seed_slots": ctx.seed_slots,
        }
        report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        return report_path

    def _persist_run_state(self, ctx: RunContext) -> Path:
        path = ctx.run_dir / "run_state.json"
        ctx.run_state.persist(path)
        return path

    def _cleanup(self, ctx: RunContext) -> None:
        try:
            ctx.base_env.cleanup()
        except Exception:
            ctx.logger.exception("event=container_cleanup_failed")
        ctx.logger.info(
            "event=orchestrator_complete instance_id=%s", ctx.instance["instance_id"]
        )

    def _make_run_dir(self, instance_id: str) -> Path:
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        return self.config.output_dir / instance_id / f"pasc_gitops_{timestamp}_{time.time_ns()}"


def _pick_headline_patch(
    patches: dict[str, str], agent_order: tuple[str, ...]
) -> tuple[str, str]:
    """First non-empty patch in agent_order; falls back to the first agent's."""
    for agent_id in agent_order:
        if patches.get(agent_id, "").strip():
            return agent_id, patches[agent_id]
    first = agent_order[0]
    return first, patches.get(first, "")


@dataclass(slots=True)
class _AgentArtifactPaths:
    trajectory: Path
    raw_patch: Path
    result: Path


@dataclass(slots=True)
class _AgentRunInfo:
    agent_id: str
    seed_file: str | None
    container_id: str
    exit_status: str = ""
    submission: str = ""
    status: str = AgentStatus.FAILED
    exception_str: str = ""
    traceback_str: str = ""


class _CommitTrackerAdapter:
    """Routes GitOpsAgent's CommitTracker calls through the Workspace so
    GitOpsAgent stays unaware of shared- vs federated-tree dispatch.
    """

    def __init__(self, *, workspace: Workspace):
        self._workspace = workspace

    @property
    def history(self):
        return self._workspace.history()

    def record_step(self, *, agent_id: str, step: int, thought: str):
        return self._workspace.record_step(agent_id=agent_id, step=step, thought=thought)

    def reset_index_for(self, agent_id: str) -> None:
        self._workspace.reset_index_for(agent_id)
