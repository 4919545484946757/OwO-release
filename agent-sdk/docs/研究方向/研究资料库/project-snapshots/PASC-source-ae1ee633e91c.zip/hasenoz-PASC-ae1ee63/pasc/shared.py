"""Shared dataclasses and helpers for the PASC orchestrators."""
from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

from pasc.bootstrap import ensure_minisweagent_path

ensure_minisweagent_path()

from datasets import load_dataset

from minisweagent.config import builtin_config_dir, get_config_from_spec
from minisweagent.run.benchmarks.swebench import DATASET_MAPPING
from minisweagent.utils.serialize import UNSET, recursive_merge


DEFAULT_CONFIG_FILE = builtin_config_dir / "benchmarks" / "swebench.yaml"
DEFAULT_AGENT_IDS: tuple[str, ...] = ("agent_0", "agent_1")


@dataclass(slots=True)
class CommonOrchestratorConfig:
    """Fields shared by every PASC orchestrator."""

    instance_spec: str
    output_dir: Path
    subset: str = "_test"
    split: str = "test"
    config_spec: list[str] = field(default_factory=lambda: [str(DEFAULT_CONFIG_FILE)])
    model_name: str | None = None
    model_class: str | None = None
    environment_class: str | None = None
    seed_files: list[str] = field(default_factory=list)
    # "shared" = one tree, all agents commit there. "federated" = one private
    # tree per agent (clones of the base). See pasc.gitops.workspace.
    workspace: str = "shared"


@dataclass(slots=True)
class AgentPatchResult:
    """Terminal state of one agent within a run."""

    agent_id: str
    seed_file: str | None
    exit_status: str
    status: str
    submission: str
    trajectory_path: Path
    raw_patch_path: Path
    container_id: str | None
    exception_str: str = ""

    def to_json_dict(self) -> dict[str, object]:
        return {
            "agent_id": self.agent_id,
            "seed_file": self.seed_file,
            "exit_status": self.exit_status,
            "status": self.status,
            "submission": self.submission,
            "trajectory_path": str(self.trajectory_path),
            "raw_patch_path": str(self.raw_patch_path),
            "container_id": self.container_id,
            "exception_str": self.exception_str,
        }


@dataclass(slots=True)
class PascRunResult:
    """Top-level return value of an orchestrator's run()."""

    run_dir: Path
    final_patch_path: Path


_FL_BLOCK_RE = re.compile(r"<fl_analysis>\s*(.*?)\s*</fl_analysis>", re.DOTALL)


def extract_fl_seed_files(task: str) -> list[str]:
    """Pull `- path` bullets out of a <fl_analysis> block embedded in the task."""
    match = _FL_BLOCK_RE.search(task)
    if not match:
        return []
    files: list[str] = []
    for line in match.group(1).splitlines():
        stripped = line.strip()
        if stripped.startswith("- "):
            files.append(stripped[2:].strip())
    return files


def resolve_seed_slots(
    task: str,
    explicit_seed_files: list[str],
    agent_count: int = 2,
) -> list[str | None]:
    """One seed file (or None) per agent slot.

    Resolution order: explicit CLI files, then <fl_analysis> files in the task.
    Duplicates dropped; remaining slots padded with None.
    """
    candidates = explicit_seed_files if explicit_seed_files else extract_fl_seed_files(task)
    deduped: list[str] = []
    seen: set[str] = set()
    for candidate in candidates:
        stripped = candidate.strip()
        if stripped and stripped not in seen:
            deduped.append(stripped)
            seen.add(stripped)
    slots: list[str | None] = list(deduped[:agent_count])
    while len(slots) < agent_count:
        slots.append(None)
    return slots


def build_seeded_task(base_task: str, seed_file: str | None) -> str:
    """Prepend a <pasc_seed_hint> block when a seed file is provided."""
    if not seed_file:
        return base_task
    prelude = (
        "<pasc_seed_hint>\n"
        f"Start investigation from {seed_file}.\n"
        "This is a prioritization hint, not a restriction.\n"
        "</pasc_seed_hint>\n\n"
    )
    return f"{prelude}{base_task}"


def load_swebench_instance(subset: str, split: str, instance_spec: str) -> dict:
    """Resolve a SWE-Bench instance by name or numeric index."""
    dataset_path = DATASET_MAPPING.get(subset, subset)
    instances = {
        instance["instance_id"]: instance
        for instance in load_dataset(dataset_path, split=split)
    }
    resolved = instance_spec
    if instance_spec.isnumeric():
        resolved = sorted(instances)[int(instance_spec)]
    return instances[resolved]


def build_runtime_config(config: CommonOrchestratorConfig) -> dict:
    """Merge YAML config files + CLI overrides into a runtime config dict."""
    configs = [get_config_from_spec(spec) for spec in config.config_spec]
    configs.append(
        {
            "model": {
                "model_name": config.model_name or UNSET,
                "model_class": config.model_class or UNSET,
            },
            "environment": {
                "environment_class": config.environment_class or UNSET,
            },
        }
    )
    return recursive_merge(*configs) if configs else {}


def build_run_logger(log_path: Path) -> logging.Logger:
    # propagate=False so concurrent runs don't crosstalk via the root logger.
    logger = logging.getLogger(f"pasc.run.{time.time_ns()}")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    logger.handlers.clear()
    handler = logging.FileHandler(log_path)
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(threadName)s %(name)s %(levelname)s %(message)s")
    )
    logger.addHandler(handler)
    return logger
