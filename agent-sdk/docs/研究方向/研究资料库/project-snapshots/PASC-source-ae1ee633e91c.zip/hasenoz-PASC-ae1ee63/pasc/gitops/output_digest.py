"""L3 — extract a one-line digest from a (command, output, returncode) tuple.

Six patterns, first match wins:

  1. pytest summary line
  2. unittest "Ran N tests" + OK/FAILED
  3. traceback + final exception
  4. git apply / am error
  5. peer-authored python script run (catches reproducers that exit rc=0)
  6. generic rc != 0 fallback

Pattern 5 is checked BEFORE the generic rc!=0 fallback so a peer-script
that exits rc=0 still surfaces its output (otherwise "BUG NOT REPRODUCED"
prints would be invisible).
"""
from __future__ import annotations

import re
from dataclasses import dataclass


_PYTEST_SUMMARY_RE = re.compile(
    r"=+\s+([^=\n]+?)\s+in\s+([\d.]+)s\s*(?:\([^)]*\)\s*)?=+",
    re.MULTILINE,
)
_PYTEST_FAIL_LINE_RE = re.compile(r"^FAILED\s+(\S+::\S+)", re.MULTILINE)
_PYTEST_HAS_TEST_TOKEN_RE = re.compile(r"\b(passed|failed|error|skipped|xfailed|xpassed)\b")

_UNITTEST_RAN_RE = re.compile(r"^Ran\s+(\d+)\s+tests?\s+in\s+([\d.]+)s", re.MULTILINE)
_UNITTEST_RESULT_RE = re.compile(r"^(OK|FAILED)(?:\s*\((.*?)\))?\s*$", re.MULTILINE)

_TRACEBACK_RE = re.compile(r"Traceback \(most recent call last\):")
_TB_FRAME_RE = re.compile(r'File "([^"]+)", line (\d+)')
_TB_EXC_RE = re.compile(
    r"^([\w.]+(?:Error|Exception|Warning|Interrupt)):\s*(.*?)$",
    re.MULTILINE,
)

_GIT_APPLY_FAIL_RE = re.compile(r"error: patch failed:\s*(\S+)")
_GIT_APPLY_REJECT_RE = re.compile(r"error: patch does not apply")

_PYTHON_RUN_RE = re.compile(r"\bpython3?\s+([^\s|;&<>]+\.py)\b")


def _truncate(s: str, n: int = 200) -> str:
    s = (s or "").strip()
    if len(s) <= n:
        return s
    return s[: n - 3] + "..."


def _normalize_script_path(path: str) -> str:
    """Strip leading slashes and common testbed prefixes for matching."""
    p = path.lstrip("/").replace("\\", "/")
    for prefix in ("testbed/", "app/"):
        if p.startswith(prefix):
            p = p[len(prefix):]
    return p


_PURE_PASS_QUALIFIER = " (peer-selected, not gold)"
_VALID_PURE_PASS_MODES = ("qualify", "suppress", "raw")


@dataclass
class OutputDigestExtractor:
    """Stateless extractor.

    `pure_pass_mode` controls pytest/unittest summaries that contain only
    PASS/OK signals (no failure/error tokens):

    * "qualify" (default) — emit the digest with " (peer-selected, not gold)"
      after the test-runner name. Flags that this is the peer's own test
      selection, not the SWE-bench gold suite.
    * "suppress" — return None on pure-pass.
    * "raw" — emit as-is, no qualifier.

    Mixed digests (PASS + FAIL, tracebacks, git-apply errors, peer-script
    runs, generic rc!=0) are unaffected — the mode only gates pure-pass.
    """

    max_output_chars: int = 200
    pure_pass_mode: str = "qualify"

    def __post_init__(self) -> None:
        if self.pure_pass_mode not in _VALID_PURE_PASS_MODES:
            raise ValueError(
                f"pure_pass_mode must be one of {_VALID_PURE_PASS_MODES}, "
                f"got {self.pure_pass_mode!r}"
            )

    def extract(
        self,
        command: str,
        output: str,
        returncode: int | None,
        peer_authored_files: set[str] | None = None,
    ) -> str | None:
        """Return a one-line digest, or None if nothing interesting."""
        command = (command or "").strip()
        output = output or ""
        rc = returncode if returncode is not None else 0
        peer_files = peer_authored_files or set()

        digest = self._try_pytest(output)
        if digest:
            return digest

        digest = self._try_unittest(output)
        if digest:
            return digest

        digest = self._try_traceback(output)
        if digest:
            return digest

        digest = self._try_git_apply(command, output)
        if digest:
            return digest

        digest = self._try_peer_script(command, output, rc, peer_files)
        if digest:
            return digest

        if rc != 0:
            return self._try_generic_failure(command, output, rc)

        return None

    def _try_pytest(self, output: str) -> str | None:
        match = _PYTEST_SUMMARY_RE.search(output)
        if not match:
            return None
        summary, duration = match.group(1).strip(), match.group(2)
        # Guard: the summary text must actually contain test-result tokens
        # so we don't false-positive on "=== whatever in 1.2s ===".
        if not _PYTEST_HAS_TEST_TOKEN_RE.search(summary):
            return None
        summary_lower = summary.lower()
        is_pure_pass = "fail" not in summary_lower and "error" not in summary_lower
        if is_pure_pass and self.pure_pass_mode == "suppress":
            return None
        prefix = "pytest"
        if is_pure_pass and self.pure_pass_mode == "qualify":
            prefix += _PURE_PASS_QUALIFIER
        digest = f"{prefix}: {summary} ({duration}s)"
        fail = _PYTEST_FAIL_LINE_RE.search(output)
        if fail:
            digest += f" — fail: {fail.group(1)}"
        return digest

    def _try_unittest(self, output: str) -> str | None:
        ran = _UNITTEST_RAN_RE.search(output)
        if not ran:
            return None
        n_tests, duration = ran.group(1), ran.group(2)
        result = _UNITTEST_RESULT_RE.search(output)
        if not result:
            return f"unittest: {n_tests} ran ({duration}s)"
        verdict = result.group(1)
        details = (result.group(2) or "").strip()
        is_pure_pass = verdict == "OK"
        if is_pure_pass and self.pure_pass_mode == "suppress":
            return None
        prefix = "unittest"
        if is_pure_pass and self.pure_pass_mode == "qualify":
            prefix += _PURE_PASS_QUALIFIER
        if details:
            return f"{prefix}: {n_tests} ran, {verdict} ({details}) ({duration}s)"
        return f"{prefix}: {n_tests} ran, {verdict} ({duration}s)"

    def _try_traceback(self, output: str) -> str | None:
        if not _TRACEBACK_RE.search(output):
            return None
        excs = _TB_EXC_RE.findall(output)
        frames = _TB_FRAME_RE.findall(output)
        if not excs:
            return "Exception: (unparseable traceback)"
        exc_class, exc_msg = excs[-1]
        digest = f"Exception: {exc_class}"
        if exc_msg:
            digest += f": {_truncate(exc_msg, 100)}"
        if frames:
            file_path, line = frames[-1]
            short = file_path.replace("\\", "/").split("/")[-1]
            digest += f" (at {short}:{line})"
        return digest

    def _try_git_apply(self, command: str, output: str) -> str | None:
        if not (("git apply" in command) or ("git am" in command)):
            return None
        match = _GIT_APPLY_FAIL_RE.search(output)
        if match:
            return f"git apply: failed at {match.group(1)}"
        if _GIT_APPLY_REJECT_RE.search(output):
            return "git apply: patch does not apply"
        return None

    def _try_peer_script(
        self,
        command: str,
        output: str,
        rc: int,
        peer_files: set[str],
    ) -> str | None:
        if not peer_files:
            return None
        match = _PYTHON_RUN_RE.search(command)
        if not match:
            return None
        script_path = match.group(1)
        normalized = _normalize_script_path(script_path)
        is_peer_authored = False
        for pf in peer_files:
            pf_norm = _normalize_script_path(pf)
            if pf_norm == normalized or pf_norm.endswith("/" + normalized) or normalized.endswith("/" + pf_norm):
                is_peer_authored = True
                break
        if not is_peer_authored:
            return None
        out_summary = _truncate(output, self.max_output_chars)
        return f"peer ran {script_path}: rc={rc} — {out_summary or '(empty output)'}"

    def _try_generic_failure(self, command: str, output: str, rc: int) -> str | None:
        cmd_head = command.split()[0] if command else "?"
        out_summary = _truncate(output, self.max_output_chars)
        return f"{cmd_head} failed (rc={rc}): {out_summary or '(empty output)'}"
