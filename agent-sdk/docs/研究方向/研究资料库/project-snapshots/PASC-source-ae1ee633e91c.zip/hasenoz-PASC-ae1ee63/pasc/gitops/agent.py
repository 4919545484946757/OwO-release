"""GitOps-aware DefaultAgent subclass.

The agent is a thin shell. Logic lives in four composed helpers:
ThoughtExtractor, PeerActivityInjector, StuckDetector, DigestPublisher.
"""
from __future__ import annotations

import contextlib
import re
from collections import Counter, deque
from typing import Any, Callable, ContextManager, Iterable

from minisweagent.agents.default import DefaultAgent

from pasc.gitops.commit_tracker import CommitTracker
from pasc.gitops.output_digest import OutputDigestExtractor
from pasc.gitops.peer_activity import PeerActivityBuilder


_THOUGHT_BEFORE_BASH_RE = re.compile(r"^(.*?)<mswea_bash_command>", re.DOTALL)
_BASH_CMD_RE = re.compile(r"<mswea_bash_command>(.*?)</mswea_bash_command>", re.DOTALL)
_RC_RE = re.compile(r"<returncode>\s*(-?\d+)\s*</returncode>")
_OUTPUT_RE = re.compile(r"<output(?:_head|_tail)?>(.*?)</output(?:_head|_tail)?>", re.DOTALL)

_FORMAT_ERROR_PREFIX = "Format error:"
_TRUNCATED_BASH_SENTINEL = "<TRUNCATED_BASH_COMMAND>"


def _flatten_content(content: Any) -> str:
    """Render content (string or list of typed parts) as plain text."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(
            part.get("text", "")
            for part in content
            if isinstance(part, dict) and part.get("type") == "text"
        )
    return ""


def _last_assistant_index(messages: list[dict]) -> int | None:
    for i in range(len(messages) - 1, -1, -1):
        if messages[i].get("role") == "assistant":
            return i
    return None


class ThoughtExtractor:
    """Pull reasoning text from an assistant message.

    OpenAI-style providers put reasoning in plain `content`. Reasoning-style
    providers (DeepSeek-V4-Pro, DeepSeek-R1) leave `content` empty and put it
    under `extra.response.choices[0].message.reasoning_content`. We try both.
    """

    @staticmethod
    def extract(message_or_content: Any) -> str:
        if isinstance(message_or_content, dict) and "role" in message_or_content:
            content = message_or_content.get("content", "")
            extra = message_or_content.get("extra")
        else:
            content = message_or_content
            extra = None

        text = _flatten_content(content)
        if not text.strip() and extra is not None:
            text = ThoughtExtractor._reasoning_from_extra(extra)
        if not text:
            return ""

        match = _THOUGHT_BEFORE_BASH_RE.match(text)
        body = match.group(1) if match else text
        body = re.sub(r"^\s*THOUGHT\s*:\s*", "", body, flags=re.IGNORECASE)
        return body.strip()

    @staticmethod
    def _reasoning_from_extra(extra: Any) -> str:
        path: tuple = ("response", "choices", 0, "message", "reasoning_content")
        node: Any = extra
        for key in path:
            if isinstance(key, int):
                if not isinstance(node, list) or not node:
                    return ""
                node = node[0]
                continue
            if not isinstance(node, dict):
                return ""
            node = node.get(key)
        if isinstance(node, str) and node.strip():
            return node

        # Some providers mirror the field under provider_specific_fields.
        try:
            psf = extra["response"]["choices"][0]["message"]["provider_specific_fields"]
        except (KeyError, IndexError, TypeError):
            return ""
        rc = psf.get("reasoning_content") if isinstance(psf, dict) else None
        return rc if isinstance(rc, str) and rc.strip() else ""


class PeerActivityInjector:
    """Prepend the <peer_activity> block to the last observation before query.

    `observation_role="tool"` (native-tool providers) accepts both `user`
    and `tool` so format-error retries (always `user`) also get injections.
    """

    def __init__(
        self,
        builder: PeerActivityBuilder,
        *,
        observation_role: str = "user",
        logger: Any = None,
    ):
        self._builder = builder
        self._allowed_roles: tuple[str, ...] = (
            ("user", "tool") if observation_role == "tool" else ("user",)
        )
        self._logger = logger

    def inject(self, agent_id: str, messages: list[dict]) -> None:
        if not messages:
            return
        try:
            block = self._builder.build_for(agent_id)
        except Exception:
            self._log_exception(agent_id, "event=peer_activity_build_failed")
            return
        if not block:
            return

        target = messages[-1]
        if target.get("role") not in self._allowed_roles:
            return

        content = target.get("content", "")
        if isinstance(content, str):
            target["content"] = block + content
            event = "event=peer_activity_injected"
        elif isinstance(content, list):
            target["content"] = [{"type": "text", "text": block}, *content]
            event = "event=peer_activity_injected_list"
        else:
            return

        self._log_info(
            agent_id,
            f"{event} bytes={len(block.encode('utf-8'))} role={target.get('role')}",
        )

    def _log_info(self, agent_id: str, message: str) -> None:
        if self._logger is not None:
            self._logger.info("agent_id=%s %s", agent_id, message)

    def _log_exception(self, agent_id: str, event: str) -> None:
        if self._logger is not None:
            self._logger.exception("agent_id=%s %s", agent_id, event)


class StuckDetector:
    """Fires `stuck_callback` once when either signature trips:

      * format-error storm — N consecutive user messages starting with the
        "Format error:" template since the last assistant turn.
      * command repetition — same bash command appearing >= repeat_threshold
        times in the last repeat_window steps.
    """

    def __init__(
        self,
        callback: Callable[[str], None] | None,
        *,
        format_error_threshold: int = 5,
        repeat_window: int = 8,
        repeat_threshold: int = 4,
        logger: Any = None,
    ):
        self._callback = callback
        # Sane minimums so misconfiguration doesn't false-positive.
        self._format_error_threshold = max(2, format_error_threshold)
        self._repeat_window = max(4, repeat_window)
        self._repeat_threshold = max(3, repeat_threshold)
        self._logger = logger

        self._recent_commands: deque[str] = deque(maxlen=self._repeat_window)
        self._signaled = False

    def check_format_error_storm(self, agent_id: str, messages: list[dict]) -> None:
        if self._callback is None or self._signaled:
            return
        consecutive = self._count_trailing_format_errors(messages)
        if consecutive >= self._format_error_threshold:
            self._fire(
                agent_id,
                reason="format_error_retries",
                detail=f"consecutive_format_errors={consecutive}",
            )

    def check_command_repetition(self, agent_id: str, messages: list[dict]) -> None:
        if self._callback is None or self._signaled:
            return
        cmd = self._extract_last_command(messages)
        if cmd is None:
            return
        self._recent_commands.append(cmd)
        if len(self._recent_commands) < self._repeat_threshold:
            return
        most_common, count = Counter(self._recent_commands).most_common(1)[0]
        if count < self._repeat_threshold:
            return
        self._fire(
            agent_id,
            reason="cmd_repeat",
            detail=f"repeat={count} window={len(self._recent_commands)} cmd={most_common[:120]!r}",
        )

    @staticmethod
    def _count_trailing_format_errors(messages: list[dict]) -> int:
        count = 0
        for msg in reversed(messages):
            role = msg.get("role")
            if role == "assistant":
                break
            if role not in ("user", "tool"):
                continue
            if _flatten_content(msg.get("content", "")).lstrip().startswith(_FORMAT_ERROR_PREFIX):
                count += 1
        return count

    @staticmethod
    def _extract_last_command(messages: list[dict]) -> str | None:
        """Bash command from the most recent assistant message.

        Falls back to the truncation sentinel when an opening tag has no
        closing tag (output length exceeded mid-heredoc). For native-tool
        providers falls back to `tool_calls[*].function.arguments`.
        """
        idx = _last_assistant_index(messages)
        if idx is None:
            return None
        msg = messages[idx]
        text = _flatten_content(msg.get("content", ""))

        match = _BASH_CMD_RE.search(text)
        if match:
            return match.group(1).strip()
        if "<mswea_bash_command>" in text:
            return _TRUNCATED_BASH_SENTINEL

        for tc in msg.get("tool_calls") or []:
            if not isinstance(tc, dict):
                continue
            args = tc.get("function", {}).get("arguments")
            if isinstance(args, str) and args.strip():
                return args.strip()
        return None

    def _fire(self, agent_id: str, *, reason: str, detail: str) -> None:
        try:
            self._callback(agent_id)  # type: ignore[misc]
            self._signaled = True
            if self._logger is not None:
                self._logger.warning(
                    "agent_id=%s event=stuck_signaled reason=%s %s",
                    agent_id, reason, detail,
                )
        except Exception:
            if self._logger is not None:
                self._logger.exception(
                    "agent_id=%s event=stuck_callback_failed", agent_id
                )


class DigestPublisher:
    """Extract a one-line digest from this step's bash output, push to the
    digest board via `callback(agent_id, digest)`.

    Walks the trajectory tail rather than capturing execute_actions return
    values so we stay decoupled from mini-swe-agent's internal control flow.
    """

    def __init__(
        self,
        callback: Callable[[str, str], None] | None,
        extractor: OutputDigestExtractor | None,
        peer_authored_provider: Callable[[], Iterable[str]] | None = None,
        *,
        observation_role: str = "user",
        logger: Any = None,
    ):
        self._callback = callback
        self._extractor = extractor
        self._peer_authored_provider = peer_authored_provider
        self._allowed_obs_roles: tuple[str, ...] = (
            ("user", "tool") if observation_role == "tool" else (observation_role,)
        )
        self._logger = logger

    def publish(self, agent_id: str, messages: list[dict]) -> None:
        if self._callback is None or self._extractor is None:
            return
        command, output, rc = self._locate_command_and_observation(messages)
        if command is None:
            return

        peer_files = self._peer_authored_files()
        try:
            digest = self._extractor.extract(
                command, output, rc, peer_authored_files=peer_files
            )
        except Exception:
            self._log_exception(agent_id, "event=digest_extract_failed")
            return
        if not digest:
            return

        try:
            self._callback(agent_id, digest)  # type: ignore[misc]
            self._log_info(
                agent_id,
                f"event=digest_published bytes={len(digest.encode('utf-8'))} rc={rc}",
            )
        except Exception:
            self._log_exception(agent_id, "event=digest_callback_failed")

    def _locate_command_and_observation(
        self, messages: list[dict]
    ) -> tuple[str | None, str, int]:
        """(command, output_text, returncode) for the most recent completed
        step. Returns (None, "", 0) when no observation was appended (typical
        when this step ended in a format error).
        """
        assistant_idx = _last_assistant_index(messages)
        if assistant_idx is None:
            return None, "", 0

        obs_idx = None
        for j in range(assistant_idx + 1, len(messages)):
            role = messages[j].get("role")
            if role == "assistant":
                break
            if role in self._allowed_obs_roles:
                obs_idx = j
                break
        if obs_idx is None:
            return None, "", 0

        assistant_text = _flatten_content(messages[assistant_idx].get("content", ""))
        obs_text = _flatten_content(messages[obs_idx].get("content", ""))

        cmd_match = _BASH_CMD_RE.search(assistant_text)
        command = cmd_match.group(1).strip() if cmd_match else ""
        rc_match = _RC_RE.search(obs_text)
        rc = int(rc_match.group(1)) if rc_match else 0
        out_match = _OUTPUT_RE.search(obs_text)
        output = out_match.group(1) if out_match else obs_text
        return command, output, rc

    def _peer_authored_files(self) -> set[str]:
        if self._peer_authored_provider is None:
            return set()
        try:
            return set(self._peer_authored_provider() or ())
        except Exception:
            return set()

    def _log_info(self, agent_id: str, message: str) -> None:
        if self._logger is not None:
            self._logger.info("agent_id=%s %s", agent_id, message)

    def _log_exception(self, agent_id: str, event: str) -> None:
        if self._logger is not None:
            self._logger.exception("agent_id=%s %s", agent_id, event)


StuckCallback = Callable[[str], None]
DigestCallback = Callable[[str, str], None]
PeerAuthoredProvider = Callable[[], Iterable[str]]


class GitOpsAgent(DefaultAgent):
    """DefaultAgent with three hooks composed around step():

      pre-step : PeerActivityInjector
      post-step: commit hook → StuckDetector → DigestPublisher
    """

    def __init__(
        self,
        *args: Any,
        agent_id: str,
        runtime_logger: Any,
        commit_tracker: CommitTracker,
        peer_activity_builder: PeerActivityBuilder,
        inject_peer_activity: bool = True,
        stuck_callback: StuckCallback | None = None,
        stuck_format_error_threshold: int = 5,
        stuck_repeat_window: int = 8,
        stuck_repeat_threshold: int = 4,
        digest_callback: DigestCallback | None = None,
        digest_extractor: OutputDigestExtractor | None = None,
        peer_authored_provider: PeerAuthoredProvider | None = None,
        observation_role: str = "user",
        step_lock: ContextManager | None = None,
        **kwargs: Any,
    ):
        super().__init__(*args, **kwargs)
        self.agent_id = agent_id
        self.runtime_logger = runtime_logger
        self.commit_tracker = commit_tracker
        self._inject_peer_activity = inject_peer_activity
        # Workspace-level lock around bash-exec + commit. Shared mode: one
        # lock per workspace (serializes the critical section, closes the
        # attribution-leak race). Federated mode: per-agent lock (no
        # contention since trees are isolated).
        self._step_lock: Any = step_lock if step_lock is not None else contextlib.nullcontext()

        self._peer_activity = PeerActivityInjector(
            peer_activity_builder,
            observation_role=observation_role,
            logger=runtime_logger,
        )
        self._stuck = StuckDetector(
            stuck_callback,
            format_error_threshold=stuck_format_error_threshold,
            repeat_window=stuck_repeat_window,
            repeat_threshold=stuck_repeat_threshold,
            logger=runtime_logger,
        )
        self._digest = DigestPublisher(
            digest_callback,
            digest_extractor,
            peer_authored_provider,
            observation_role=observation_role,
            logger=runtime_logger,
        )

    def step(self) -> list[dict]:
        """Split DefaultAgent.step() into LLM-query (parallel) and
        bash-exec + commit (serialized under self._step_lock).

        While one agent holds the lock, the other cannot run bash → cannot
        have uncommitted writes in the working tree → cannot leak into this
        agent's `git add -A` commit. The LLM query (~95% of step latency)
        stays fully parallel.
        """
        step_number = self.n_calls + 1
        self._log_step("event=step_start", step_number)

        if self._inject_peer_activity:
            self._peer_activity.inject(self.agent_id, self.messages)

        message = self.query()

        result: list[dict] | None = None
        try:
            with self._step_lock:
                try:
                    result = self.execute_actions(message)
                finally:
                    self._commit_pending_changes(step_number)
        finally:
            self._stuck.check_format_error_storm(self.agent_id, self.messages)
            self._stuck.check_command_repetition(self.agent_id, self.messages)
            self._digest.publish(self.agent_id, self.messages)

        last_role = self.messages[-1]["role"] if self.messages else "none"
        self.runtime_logger.info(
            "agent_id=%s event=step_end step=%s cost=%.4f last_role=%s",
            self.agent_id, step_number, self.cost, last_role,
        )
        return result

    def _commit_pending_changes(self, step_number: int) -> None:
        """Stage + commit file mutations made by this step, attributed to
        this agent. The thought is used as the commit subject so peers get
        richer context than just the SHA.
        """
        thought = ""
        idx = _last_assistant_index(self.messages)
        if idx is not None:
            thought = ThoughtExtractor.extract(self.messages[idx])
        try:
            self.commit_tracker.record_step(
                agent_id=self.agent_id, step=step_number, thought=thought
            )
        except Exception:
            self.runtime_logger.exception(
                "agent_id=%s event=commit_hook_failed step=%s",
                self.agent_id, step_number,
            )
            # A failed record_step may have left `git add -A`'s work in the
            # index. If we don't clear it, the next agent's commit will sweep
            # it up and attribute it to the wrong author — the exact leak
            # the workspace lock is meant to prevent.
            reset = getattr(self.commit_tracker, "reset_index_for", None)
            if reset is not None:
                try:
                    reset(self.agent_id)
                    self.runtime_logger.info(
                        "agent_id=%s event=commit_hook_index_reset step=%s",
                        self.agent_id, step_number,
                    )
                except Exception:
                    self.runtime_logger.exception(
                        "agent_id=%s event=commit_hook_reset_failed step=%s",
                        self.agent_id, step_number,
                    )

    def _log_step(self, event: str, step_number: int) -> None:
        self.runtime_logger.info(
            "agent_id=%s %s step=%s container_id=%s",
            self.agent_id,
            event,
            step_number,
            getattr(self.env, "container_id", ""),
        )
