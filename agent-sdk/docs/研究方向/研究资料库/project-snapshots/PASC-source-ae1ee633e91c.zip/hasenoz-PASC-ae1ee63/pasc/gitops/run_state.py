"""Per-run shared state for the GitOps orchestrator.

Three thread-safe boards composed under one RunState:

  * AgentStatusBoard — lifecycle status per agent (read by the L2 feed)
  * DigestBoard      — most recent bash-output digest per agent (read by L3)
  * PatchRegistry    — each agent's terminal AgentPatchResult

Locking is per-board so callers can interleave operations without contending
on one global mutex.
"""
from __future__ import annotations

import json
import threading
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pasc.shared import AgentPatchResult


class AgentStatus:
    """Canonical status strings. Plain class (not Enum) so callers pass strings
    directly without importing the enum at every call site."""

    DONE = "DONE"
    FAILED = "FAILED"
    STUCK = "STUCK"
    SUBMITTED = "SUBMITTED"


class AgentStatusBoard:
    """Current lifecycle status of each agent."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._statuses: dict[str, str] = {}

    def set(self, agent_id: str, status: str) -> None:
        with self._lock:
            self._statuses[agent_id] = status

    def get(self, agent_id: str) -> str:
        with self._lock:
            return self._statuses.get(agent_id, "")

    def all(self) -> dict[str, str]:
        with self._lock:
            return dict(self._statuses)


class DigestBoard:
    """Most-recent output digest per agent. One-shot delivery — the source
    overwrites freely; each viewer should call clear() after rendering so the
    same digest isn't replayed.

    With N>2 agents the renderer dedups per-(viewer, peer) locally instead of
    calling clear() (one viewer clearing would deprive the others).
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._digests: dict[str, str] = {}

    def set(self, agent_id: str, digest: str) -> None:
        with self._lock:
            self._digests[agent_id] = digest

    def get(self, agent_id: str) -> str:
        with self._lock:
            return self._digests.get(agent_id, "")

    def clear(self, agent_id: str) -> None:
        with self._lock:
            self._digests.pop(agent_id, None)


class PatchRegistry:
    """Per-agent terminal AgentPatchResult records, keyed by agent_id."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._records: dict[str, "AgentPatchResult"] = {}

    def set(self, record: "AgentPatchResult") -> None:
        with self._lock:
            self._records[record.agent_id] = record

    def get(self, agent_id: str) -> "AgentPatchResult | None":
        with self._lock:
            return self._records.get(agent_id)

    def all(self) -> dict[str, "AgentPatchResult"]:
        with self._lock:
            return dict(self._records)


@dataclass(slots=True)
class RunState:
    """Composition root for the three boards."""

    status: AgentStatusBoard
    digests: DigestBoard
    patches: PatchRegistry

    @classmethod
    def empty(cls) -> "RunState":
        return cls(
            status=AgentStatusBoard(),
            digests=DigestBoard(),
            patches=PatchRegistry(),
        )

    def snapshot(self) -> dict:
        return {
            "agent_status": self.status.all(),
            "patches": {
                agent_id: _serialize_patch(record)
                for agent_id, record in self.patches.all().items()
            },
        }

    def persist(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.snapshot(), indent=2), encoding="utf-8")


def _serialize_patch(record: "AgentPatchResult") -> dict:
    # Path fields aren't JSON-serializable as-is; convert to str.
    data = asdict(record)
    for key, value in data.items():
        if isinstance(value, Path):
            data[key] = str(value)
    return data
