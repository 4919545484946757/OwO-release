"""
Paired (McNemar) and unpaired (Fisher) significance tests for the
destructive-thrash analysis.

The same set of instances is evaluated under both silent and pasc
(peer-aware) configurations per model. The correct test is McNemar's
exact test on the discordant pairs (b, c). Fisher's exact on the
marginals is reported for reference; it discards the pairing and is
therefore less powerful.

Pairings:
  - MiniMax  : silent_minimax_m27   vs pasc_minimax_m27
  - DeepSeek : silent_deepseek_v4pro vs pasc_deepseek_v4pro

Two signals tested per pair:
  - any_destructive_signal (full-rewrite | sed-reversal | shared-line | alternation)
  - has_sed_reversal (the strongest, most specific destructive signature)

Usage:
  python3 significance.py
  (reads silent_vs_pasc_thrash.json produced by analyze_silent_vs_pasc.py)
"""
from __future__ import annotations

import json
import math
from pathlib import Path

DATA_PATH = Path(__file__).parent / "silent_vs_pasc_thrash.json"

PAIRS = [
    ("MiniMax",  "silent_minimax_m27",   "pasc_minimax_m27"),
    ("DeepSeek", "silent_deepseek_v4pro", "pasc_deepseek_v4pro"),
]

SIGNALS = [
    ("any_destructive_signal", "ANY destructive signal"),
    ("has_sed_reversal",       "SED REVERSAL only"),
]


def _lc(n: int, k: int) -> float:
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)


def fisher_exact_two_sided(a: int, b: int, c: int, d: int) -> float:
    n = a + b + c + d
    if n == 0:
        return 1.0
    row1, row2, col1 = a + b, c + d, a + c

    def pmf(k: int) -> float:
        if k < max(0, col1 - row2) or k > min(col1, row1):
            return 0.0
        return math.exp(_lc(row1, k) + _lc(row2, col1 - k) - _lc(n, col1))

    p_obs = pmf(a)
    total = sum(
        pk for k in range(max(0, col1 - row2), min(col1, row1) + 1)
        if (pk := pmf(k)) <= p_obs + 1e-15
    )
    return min(total, 1.0)


def mcnemar_exact_two_sided(b: int, c: int) -> float:
    """Exact two-sided McNemar via binomial(b+c, 0.5)."""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    p = sum(math.exp(_lc(n, i)) * (0.5 ** n) for i in range(0, k + 1))
    p += sum(math.exp(_lc(n, i)) * (0.5 ** n) for i in range(n - k, n + 1))
    if k == n - k:
        p -= math.exp(_lc(n, k)) * (0.5 ** n)
    return min(p, 1.0)


def mcnemar_chi2_continuity(b: int, c: int) -> tuple[float, float]:
    """McNemar's chi-square with continuity correction. Recommended when
    b+c >= 25; we report it alongside the exact test for transparency."""
    n = b + c
    if n == 0:
        return 0.0, 1.0
    chi2 = (abs(b - c) - 1) ** 2 / n
    return chi2, math.erfc(math.sqrt(chi2 / 2.0))


def build_pair(rows_silent, rows_pasc, signal_field):
    by_iid_silent = {r["instance_id"]: r for r in rows_silent}
    by_iid_pasc = {r["instance_id"]: r for r in rows_pasc}
    common = set(by_iid_silent) & set(by_iid_pasc)
    a = b = c = d = 0
    for iid in common:
        s = bool(by_iid_silent[iid].get(signal_field))
        p = bool(by_iid_pasc[iid].get(signal_field))
        if s and p:
            a += 1
        elif s and not p:
            b += 1
        elif not s and p:
            c += 1
        else:
            d += 1
    return a, b, c, d, len(common)


def main() -> None:
    data = json.loads(DATA_PATH.read_text())
    per_config = data["per_config"]

    print("=" * 80)
    print("Paired McNemar vs Unpaired Fisher  —  silent vs PASC per model")
    print("=" * 80)

    for model_label, silent_key, pasc_key in PAIRS:
        rows_s = per_config[silent_key]
        rows_p = per_config[pasc_key]

        for signal_field, signal_label in SIGNALS:
            a, b, c, d, n = build_pair(rows_s, rows_p, signal_field)
            n_silent_pos = a + b
            n_pasc_pos = a + c

            mcn_p_exact = mcnemar_exact_two_sided(b, c)
            mcn_chi2, mcn_p_chi2 = mcnemar_chi2_continuity(b, c)
            fisher_p = fisher_exact_two_sided(
                n_silent_pos, n - n_silent_pos,
                n_pasc_pos, n - n_pasc_pos,
            )

            print()
            print(f"[{model_label}]  {signal_label}")
            print(f"  n paired = {n}")
            print(f"  silent positives: {n_silent_pos}/{n} ({100*n_silent_pos/n:.2f}%)")
            print(f"  pasc   positives: {n_pasc_pos}/{n} ({100*n_pasc_pos/n:.2f}%)")
            print(f"  paired 2x2:  a={a} (both)   b={b} (silent-only)   c={c} (pasc-only)   d={d} (neither)")
            print(f"  McNemar exact two-sided p = {mcn_p_exact:.4g}")
            if b + c >= 25:
                print(f"  McNemar chi^2 (cont. corr.)= {mcn_chi2:.3f}  p = {mcn_p_chi2:.4g}")
            print(f"  Fisher unpaired (marginals) p = {fisher_p:.4g}")
            if b > c:
                print(f"  direction: silent has MORE thrash than pasc (b={b} vs c={c})")
            elif c > b:
                print(f"  direction: pasc has MORE thrash than silent (c={c} vs b={b})")
            else:
                print(f"  direction: tied (b=c={b})")


if __name__ == "__main__":
    main()
