"""
N-agent ablation: destructive-thrash detector + per-N summary.

Runs the N-agent destructive-thrash detector across PASC runs at multiple
N values (typically N=2, 3, 5) and merges with the corresponding SWE-bench
Pro evaluation outcomes. Produces ``nagent_thrash.json`` consumed by
``advanced_stats.py``.

Re-running this script regenerates the JSON from raw run trees. The raw
runs are NOT shipped in this replication package; to rebuild them from
scratch:

  1. Run the N-agent ablation via ``run_batch_gitops.py`` with ``-n N``
     and ``-c swebench_xml_gitops_npeer`` (see top-level README).
  2. Set ``PASC_REPO_ROOT`` to a tree containing the resulting ``runs/``
     directories.
  3. Set ``PASC_SWE_BENCH_PRO_OS`` to the directory holding the
     ``eval_results_*`` directories produced by ``swe_bench_pro_eval.py``.
  4. Edit the ``CONFIGS`` dict below so each ``run_roots`` list points to
     YOUR run directories. The defaults below mirror the layout used to
     produce the shipped ``nagent_thrash.json``.

Output: ``nagent_thrash.json`` + console summary table.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from destructive_thrash_nagent import analyze_instance_nagent  # noqa: E402

REPO = Path(os.environ.get("PASC_REPO_ROOT", str(Path(__file__).resolve().parents[1])))
SBP = Path(os.environ.get("PASC_SWE_BENCH_PRO_OS", str(REPO / "SWE-bench_Pro-os")))

# One entry per N value tested in the ablation. Each entry combines all run
# trees that contributed instances at that N. Reviewers re-running this
# script should replace ``run_roots`` with paths to their own runs.
CONFIGS = {
    "pasc_n2": dict(
        eval_paths=[
            SBP / "eval_results_pasc_balanced50_n2/eval_results.json",
            SBP / "eval_results_pasc_extra25_n2/eval_results.json",
        ],
        run_roots=[
            REPO / "runs/balanced24_n2_mm",
            REPO / "runs/balanced26extra_n2_mm",
            REPO / "runs/extra25_n2_mm",
        ],
    ),
    "pasc_n3": dict(
        eval_paths=[
            SBP / "eval_results_pasc_balanced50_n3/eval_results.json",
            SBP / "eval_results_pasc_extra25_n3/eval_results.json",
        ],
        run_roots=[
            REPO / "runs/balanced24_n3_mm",
            REPO / "runs/balanced24_n3_mm_rerun",
            REPO / "runs/balanced26extra_n3_mm",
            REPO / "runs/extra25_n3_mm",
        ],
    ),
    "pasc_n5": dict(
        eval_paths=[
            SBP / "eval_results_pasc_balanced50_n5/eval_results.json",
            SBP / "eval_results_pasc_extra25_n5/eval_results.json",
        ],
        run_roots=[
            REPO / "runs/balanced50_n5_mm",
            REPO / "runs/extra25_n5_mm",
        ],
    ),
}


def latest_run(inst: Path) -> Path | None:
    cands = [d for d in inst.iterdir() if d.is_dir() and (d / "merge_report.json").exists()]
    if not cands:
        return None
    return max(cands, key=lambda d: d.stat().st_mtime)


def load_evals(eval_paths: list[Path]) -> dict[str, bool]:
    """Merge eval_results.json from one or more sources (later wins on overlap)."""
    out: dict[str, bool] = {}
    for p in eval_paths:
        if not p.is_file():
            continue
        out.update({k: bool(v) for k, v in json.loads(p.read_text()).items()})
    return out


def analyze_config(cfg: dict) -> list[dict]:
    evals = load_evals(cfg["eval_paths"])
    inst_to_run: dict[str, Path] = {}
    for root in cfg["run_roots"]:
        if not root.is_dir():
            continue
        for inst in root.iterdir():
            if not (inst.is_dir() and inst.name.startswith("instance_")):
                continue
            run = latest_run(inst)
            if run is None:
                continue
            prev = inst_to_run.get(inst.name)
            if prev is None or run.stat().st_mtime > prev.stat().st_mtime:
                inst_to_run[inst.name] = run

    rows = []
    for iid, run in sorted(inst_to_run.items()):
        if iid not in evals:
            continue
        try:
            r = analyze_instance_nagent(run)
        except Exception as e:
            r = {"skip": str(e), "instance_id": iid}
        if "skip" in r:
            continue
        r["resolved"] = bool(evals[iid])
        rows.append(r)
    return rows


def summarize(rows: list[dict], label: str) -> dict:
    n = len(rows)
    if n == 0:
        return {"label": label, "n": 0}
    n_resolved = sum(1 for r in rows if r["resolved"])
    n_destruct = sum(1 for r in rows if r["any_destructive_signal"])
    res_dest = sum(1 for r in rows if r["any_destructive_signal"] and r["resolved"])
    res_clean = sum(1 for r in rows if not r["any_destructive_signal"] and r["resolved"])
    by = lambda key: sum(1 for r in rows if r[key])  # noqa: E731
    return {
        "label": label, "n": n,
        "n_resolved": n_resolved,
        "pass_rate": n_resolved / n,
        "any_destructive_pct": n_destruct / n,
        "resolution_with_destructive": res_dest / max(1, n_destruct),
        "resolution_without_destructive": res_clean / max(1, n - n_destruct),
        "avg_contested_files": sum(r["n_contested_files"] for r in rows) / n,
        "avg_flagged_pairs": sum(r["n_flagged_pairs"] for r in rows) / n,
        "avg_severity": sum(r["instance_severity"] for r in rows) / n,
        "avg_no_thought_commits": sum(r["no_thought_commits"] for r in rows) / n,
        "avg_commits": sum(r["n_commits"] for r in rows) / n,
        "avg_patch_bytes": sum(r["team_patch_bytes"] for r in rows) / n,
        "full_rewrite": by("has_full_rewrite_collision"),
        "sed_reversal": by("has_sed_reversal"),
        "alternation": by("has_alternation"),
        "shared_lines": by("has_shared_lines"),
    }


def main() -> None:
    out: dict = {"per_config_rows": {}, "summary": []}
    print("Analyzing destructive-thrash signatures across N values...\n")
    print(f"{'Config':<10} {'n':>4} {'pass%':>6} {'destruc%':>9} "
          f"{'contest':>8} {'flagged':>8} {'severity':>9} "
          f"{'commits':>8} {'no-thought':>11} {'patch_kb':>9}")
    print("-" * 100)
    for name, cfg in CONFIGS.items():
        rows = analyze_config(cfg)
        out["per_config_rows"][name] = rows
        s = summarize(rows, name)
        out["summary"].append(s)
        if s["n"] == 0:
            print(f'{name:<10} (no data — check CONFIGS run_roots)')
            continue
        print(
            f'{s["label"]:<10} {s["n"]:>4} '
            f'{100 * s["pass_rate"]:>5.1f}% '
            f'{100 * s["any_destructive_pct"]:>8.1f}% '
            f'{s["avg_contested_files"]:>8.2f} '
            f'{s["avg_flagged_pairs"]:>8.2f} '
            f'{s["avg_severity"]:>9.1f} '
            f'{s["avg_commits"]:>8.1f} '
            f'{s["avg_no_thought_commits"]:>10.2f} '
            f'{s["avg_patch_bytes"] / 1024:>9.1f}'
        )

    print("\nBy signal type (count of instances with the signal, % of n):")
    print(f'{"Config":<10} {"full_rewrite":>15} {"sed_reversal":>15} {"alternation":>15} {"shared_lines":>15}')
    print("-" * 84)
    for s in out["summary"]:
        if s["n"] == 0:
            continue
        n = s["n"]
        print(
            f'{s["label"]:<10} '
            f'{s["full_rewrite"]:>4} ({100 * s["full_rewrite"] / n:>5.1f}%)  '
            f'{s["sed_reversal"]:>4} ({100 * s["sed_reversal"] / n:>5.1f}%)  '
            f'{s["alternation"]:>4} ({100 * s["alternation"] / n:>5.1f}%)  '
            f'{s["shared_lines"]:>4} ({100 * s["shared_lines"] / n:>5.1f}%)'
        )

    print("\nResolution rate split by destructive signal:")
    print(f'{"Config":<10} {"with_destruct":>18} {"clean":>10} {"diff_pp":>10}')
    print("-" * 52)
    for s in out["summary"]:
        if s["n"] == 0:
            continue
        wd = 100 * s["resolution_with_destructive"]
        cl = 100 * s["resolution_without_destructive"]
        print(f'{s["label"]:<10} {wd:>17.1f}%  {cl:>9.1f}%  {wd - cl:>+9.1f}')

    out_path = Path(__file__).parent / "nagent_thrash.json"
    out_path.write_text(json.dumps(out, indent=2, default=str))
    print(f"\nWrote {out_path}")


if __name__ == "__main__":
    main()
