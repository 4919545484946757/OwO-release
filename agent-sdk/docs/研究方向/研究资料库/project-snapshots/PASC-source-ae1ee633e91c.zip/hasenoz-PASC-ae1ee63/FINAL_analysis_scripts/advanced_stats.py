"""
Advanced statistical analyses on combined-73 (dead runs excluded) per-instance×N
table with binary outcomes (passed, thrash):

  1. Logistic regression: pass ~ N + thrash + N:thrash + repo, with instance
     fixed/random effect treatments (mixed-effect via BinomialBayesMixedGLM).
  2. TOST equivalence test for N=2 vs N=5 (paired binary), ±5 pp band.
  3. Cochran–Armitage trend test for destruct% across N=2,3,5.
  4. Mantel–Haenszel stratified test: thrash↔pass adjusted by instance.
  5. Power calculation for paired McNemar at observed discordance / effect.
"""
from __future__ import annotations
import json
from pathlib import Path
from math import comb, sqrt, erf

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.formula.api import logit
from statsmodels.genmod.bayes_mixed_glm import BinomialBayesMixedGLM
from scipy import stats

DEAD = {
    'instance_internetarchive__openlibrary-30bc73a1395fba2300087c7f307e54bb5372b60a-v76304ecdb3a5954fcf13feb710e8c40fcf24b73c',
    'instance_internetarchive__openlibrary-bb152d23c004f3d68986877143bb0f83531fe401-ve8c8d62a2b60610a3c4631f5f23ed866bada9818',
}

DATA = json.loads((Path(__file__).parent / 'nagent_thrash.json').read_text())
PER = DATA['per_config_rows']

def repo(k): return k.replace('instance_', '').split('__')[0]


def build_long():
    """Long-format DataFrame: one row per (instance, N) with thrash and pass."""
    recs = []
    for N in [2, 3, 5]:
        rows = PER[f'pasc_n{N}']
        for r in rows:
            iid = r.get('instance_id')
            if iid is None or iid in DEAD:
                continue
            recs.append(dict(
                instance=iid,
                repo=repo(iid),
                N=N,
                thrash=int(bool(r['any_destructive_signal'])),
                passed=int(bool(r['resolved'])),
                severity=r['instance_severity'],
                n_flagged=r['n_flagged_pairs'],
            ))
    df = pd.DataFrame(recs)
    return df


def section(title):
    print('\n' + '=' * 88)
    print(title)
    print('=' * 88)


# -----------------------------------------------------------------------------
# 1. Logistic regression: pass ~ N + thrash + N:thrash (+ repo + instance RE)
# -----------------------------------------------------------------------------
def logistic_models(df):
    section('1. Logistic regression — pass ~ N + thrash + N×thrash')
    # Treat N as continuous (centred) for interaction interpretability
    df = df.copy()
    df['N_c'] = df['N'] - df['N'].mean()
    df['thrash_c'] = df['thrash'] - df['thrash'].mean()
    df['N_x_thrash'] = df['N_c'] * df['thrash_c']

    # Model A: simple GLM with N + thrash + interaction + repo dummies
    Xcols = ['N_c', 'thrash_c', 'N_x_thrash']
    repo_dum = pd.get_dummies(df['repo'], prefix='repo', drop_first=True).astype(float)
    Xa = pd.concat([df[Xcols], repo_dum], axis=1).astype(float)
    Xa = sm.add_constant(Xa)
    y = df['passed'].astype(float)
    print('\nModel A: GLM logit, fixed effects (N centred, thrash centred, interaction, repo dummies)')
    try:
        m = sm.GLM(y, Xa, family=sm.families.Binomial()).fit()
        print(m.summary().tables[1])
        # Interaction coefficient
        coef = m.params.get('N_x_thrash', None)
        pval = m.pvalues.get('N_x_thrash', None)
        if coef is not None:
            print(f'\n  Interaction N×thrash:  β = {coef:+.4f}  p = {pval:.4f}'
                  f'  → interpretation: positive β means thrash is *more* harmful at higher N')
    except Exception as e:
        print(f'  GLM failed: {e}')

    # Model B: Bayesian mixed-effects with random intercepts for instance
    print('\nModel B: Bayesian mixed-effects (random intercept by instance + repo dummy fixed)')
    fmla = "passed ~ N_c + thrash_c + N_x_thrash + C(repo)"
    rfmla = {'instance': '0 + C(instance)'}
    try:
        m2 = BinomialBayesMixedGLM.from_formula(
            fmla, vc_formulas=rfmla, data=df,
        ).fit_vb()
        # Print fixed-effect posterior summaries
        print(f'  fe_posterior_mean: {dict(zip(m2.model.exog_names, np.round(m2.fe_mean, 4)))}')
        print(f'  fe_posterior_sd:   {dict(zip(m2.model.exog_names, np.round(m2.fe_sd, 4)))}')
        # 95% CI proxy via mean ± 1.96 SD
        for name, mu, sd in zip(m2.model.exog_names, m2.fe_mean, m2.fe_sd):
            lo, hi = mu - 1.96 * sd, mu + 1.96 * sd
            mark = '' if lo < 0 < hi else '  *'
            print(f'    {name:<25} β={mu:+.4f}  SD={sd:.4f}  95% CI [{lo:+.4f}, {hi:+.4f}]{mark}')
    except Exception as e:
        print(f'  Mixed-effects failed: {e}')


# -----------------------------------------------------------------------------
# 2. TOST equivalence test, paired binary, N=2 vs N=5, ±5pp band
# -----------------------------------------------------------------------------
def tost_paired_binary(df):
    section('2. TOST paired equivalence — N=2 vs N=5 on pass-rate, ±5 pp band')
    pivot = df.pivot(index='instance', columns='N', values='passed')
    pivot = pivot.dropna()
    n = len(pivot)
    p2 = pivot[2].mean()
    p5 = pivot[5].mean()
    diff = p5 - p2
    # Discordant pairs
    b = ((pivot[5] == 1) & (pivot[2] == 0)).sum()  # N=5 only
    c = ((pivot[2] == 1) & (pivot[5] == 0)).sum()  # N=2 only
    se_diff = np.sqrt((b + c - (b - c) ** 2 / n) / n ** 2)
    print(f'  n_pairs = {n}')
    print(f'  pass(N=2) = {p2:.3f}, pass(N=5) = {p5:.3f}, diff (N=5 − N=2) = {diff:+.3f}')
    print(f'  discordant: N=5-only={b}, N=2-only={c}')
    print(f'  SE(diff) = {se_diff:.4f}')

    # TOST: two one-sided tests at lower bound −0.05 and upper bound +0.05
    margin = 0.05
    z_lower = (diff - (-margin)) / se_diff  # H0: diff <= -margin; reject if z_lower large
    z_upper = ((+margin) - diff) / se_diff  # H0: diff >= +margin; reject if z_upper large
    p_lower = 1 - stats.norm.cdf(z_lower)
    p_upper = 1 - stats.norm.cdf(z_upper)
    p_tost = max(p_lower, p_upper)
    print(f'  Lower bound test (H0: diff ≤ −0.05): z = {z_lower:.3f},  p = {p_lower:.4f}')
    print(f'  Upper bound test (H0: diff ≥ +0.05): z = {z_upper:.3f},  p = {p_upper:.4f}')
    print(f'  TOST p (max of the two): p = {p_tost:.4f}')
    if p_tost < 0.05:
        print(f'  → REJECT both nulls: equivalence within ±{margin} demonstrated.')
    else:
        print(f'  → CANNOT reject; equivalence within ±{margin} NOT demonstrated at α=0.05.')

    # Newcombe-Yates 90% CI on difference (paired binomial)
    # Use simple symmetric Wald CI for paired difference
    z90 = 1.6449
    lo90 = diff - z90 * se_diff
    hi90 = diff + z90 * se_diff
    print(f'  90% CI on difference: [{lo90:+.3f}, {hi90:+.3f}]')
    if lo90 > -margin and hi90 < margin:
        print(f'  → 90% CI within ±{margin} band: equivalence supported.')
    else:
        print(f'  → 90% CI extends beyond ±{margin} band: equivalence NOT supported.')


# -----------------------------------------------------------------------------
# 3. Cochran–Armitage trend test for destruct% across N
# -----------------------------------------------------------------------------
def cochran_armitage(df):
    section('3. Cochran–Armitage trend test — destruct% across N=2, 3, 5')
    grouped = df.groupby('N').agg(n=('thrash', 'size'),
                                   x=('thrash', 'sum')).reset_index()
    print(grouped)
    n_i = grouped['n'].values
    x_i = grouped['x'].values
    s_i = np.array([2, 3, 5], dtype=float)
    N_total = n_i.sum()
    R = x_i.sum()
    s_bar = (n_i * s_i).sum() / N_total
    p_bar = R / N_total
    num = (x_i - n_i * p_bar) * (s_i - s_bar)
    T = num.sum()
    var_T = p_bar * (1 - p_bar) * (n_i * (s_i - s_bar) ** 2).sum()
    Z = T / np.sqrt(var_T)
    p_two = 2 * (1 - stats.norm.cdf(abs(Z)))
    print(f'  Cochran–Armitage Z = {Z:.3f},  two-sided p = {p_two:.4e}')
    print(f'  → Trend in destructive-thrash % across ordinal N: {"SIGNIFICANT" if p_two < 0.05 else "ns"}')


# -----------------------------------------------------------------------------
# 4. Mantel-Haenszel: thrash↔pass adjusted for instance
# -----------------------------------------------------------------------------
def mantel_haenszel(df):
    section('4. Mantel–Haenszel — thrash↔pass adjusted by instance')
    # Strata = instance. Each instance has rows across N.
    # Build per-instance 2×2 tables: thrash (yes/no) × pass (yes/no)
    strata = []
    for iid, sub in df.groupby('instance'):
        a = ((sub['thrash'] == 1) & (sub['passed'] == 1)).sum()
        b = ((sub['thrash'] == 1) & (sub['passed'] == 0)).sum()
        c = ((sub['thrash'] == 0) & (sub['passed'] == 1)).sum()
        d = ((sub['thrash'] == 0) & (sub['passed'] == 0)).sum()
        strata.append([[a, b], [c, d]])
    arr = np.array(strata)  # shape (K, 2, 2)
    # Tilt arr to (2,2,K) for sm
    table = arr.transpose(1, 2, 0)
    try:
        st = sm.stats.StratifiedTable(table.astype(float))
        OR = st.oddsratio_pooled
        ci = st.oddsratio_pooled_confint()
        chi2_stat, p_chi2 = st.test_null_odds().statistic, st.test_null_odds().pvalue
        homogen = st.test_equal_odds()
        print(f'  K (strata) = {len(arr)}')
        print(f'  MH common odds-ratio (pooled) = {OR:.3f}, 95% CI [{ci[0]:.3f}, {ci[1]:.3f}]')
        print(f'  Test of OR=1 (chi-square) = {chi2_stat:.3f},  p = {p_chi2:.4e}')
        print(f'  Test of homogeneity across strata: chi2 = {homogen.statistic:.3f},  p = {homogen.pvalue:.3f}')
        print(f'  → thrash↔pass association adjusted for instance: {"SIGNIFICANT (lower pass when thrash)" if OR<1 and p_chi2<0.05 else "ns or no clear direction"}')
    except Exception as e:
        print(f'  MH failed: {e}')


# -----------------------------------------------------------------------------
# 5. Power calculation for paired McNemar
# -----------------------------------------------------------------------------
def mcnemar_power(df):
    section('5. Power calculation — n required for paired McNemar at observed effect')
    # We have effect: thrash flagged runs have 9.1 pp lower pass-rate (pooled)
    # Compute per-instance paired comparison: thrash-flagged vs clean (binarised by N condition)
    # But this isn't strictly paired since each instance can have all-clean or all-thrash.

    # Simpler: derive McNemar power for the observed N=2 vs N=5 paired discordance
    pivot = df.pivot(index='instance', columns='N', values='passed').dropna()
    n = len(pivot)
    b = ((pivot[5] == 1) & (pivot[2] == 0)).sum()
    c = ((pivot[2] == 1) & (pivot[5] == 0)).sum()
    p_disc = (b + c) / n
    p5_only = b / max(1, b + c)
    p2_only = c / max(1, b + c)
    diff = (b - c) / n
    print(f'  observed paired discordance rate: {p_disc:.3f}  (b={b}, c={c}, total n={n})')
    print(f'  observed Δ = {diff:+.3f} ({100*diff:+.1f} pp)')

    # Use exact-binomial McNemar power approximation (Connor 1987 / Schork & Williams):
    # With observed discordance prob π_D and null Δ=0, we need to detect p1 = b/(b+c) ≠ 0.5.
    # Power = P(reject H0 | π_d, p1) over hypothetical sample.
    # Compute n required for 80% power at α=0.05 to detect a 0.5 → p1 shift.
    p1 = b / max(1, b + c)
    p1 = p1 if p1 != 0 and p1 != 1 else 0.6  # guard
    # Simple normal approximation:
    z_a = stats.norm.ppf(0.975)
    z_b = stats.norm.ppf(0.80)
    # Variance under H0: π_D / 4n; under H1: π_D * p1 * (1 - p1) / n
    # Sample size for paired McNemar:
    if p_disc > 0:
        n_req = ((z_a * 0.5 + z_b * np.sqrt(p1 * (1 - p1)))) ** 2 / (p_disc * (p1 - 0.5) ** 2 + 1e-12)
    else:
        n_req = float('inf')
    print(f'  Estimated n for 80% power at α=0.05 to detect observed effect: ≈ {n_req:.0f}')

    # MDE at current n=73, 80% power
    # Solve for required b/(b+c) given fixed n, π_D
    # Effect size = |2*p1 - 1| (deviation from 0.5)
    if p_disc > 0:
        delta_to_detect = (z_a * 0.5 + z_b * 0.5) / np.sqrt(n * p_disc)
        # convert to absolute pass-rate diff: delta = (b-c)/n; with π_D fixed, p1-0.5 = delta/(2*π_D)
        mde_pp = 100 * delta_to_detect * 2 * p_disc
        print(f'  At current n={n}, 80% power detects |Δ| ≥ {mde_pp:.1f} pp (paired pass-rate)')

    # Also report MDE for thrash↔pass at observed marginal rates
    print()
    print('  --- thrash↔pass effect (within-N) ---')
    # observed effect: pooled thrash 56.7%, clean 65.8% → diff 9.1 pp
    p_thrash = 0.567; p_clean = 0.658
    n_thrash = 67; n_clean = 152
    p_pool = (n_thrash * p_thrash + n_clean * p_clean) / (n_thrash + n_clean)
    se_pool = np.sqrt(p_pool * (1 - p_pool) * (1 / n_thrash + 1 / n_clean))
    z_obs = (p_clean - p_thrash) / se_pool
    print(f'  observed Δ = +{100*(p_clean - p_thrash):.1f} pp,  z = {z_obs:.2f},  p = {2*(1-stats.norm.cdf(abs(z_obs))):.3f}')
    # Required n per group for 80% power at α=0.05 to detect 9.1 pp diff
    p_avg = (p_thrash + p_clean) / 2
    diff_target = 0.091
    n_each = ((z_a + z_b) ** 2 * 2 * p_avg * (1 - p_avg)) / (diff_target ** 2)
    print(f'  Required n per group for 80% power detecting 9.1 pp diff (α=0.05): {n_each:.0f}')
    print(f'  → Current totals: thrash n={n_thrash}, clean n={n_clean}; under-powered.')


def main():
    df = build_long()
    print(f'Long-format dataset: {len(df)} rows ({df["instance"].nunique()} instances × {df["N"].nunique()} N levels)')
    print(f'Thrash positives: {df["thrash"].sum()}/{len(df)} = {100*df["thrash"].mean():.1f}%')
    print(f'Passed:           {df["passed"].sum()}/{len(df)} = {100*df["passed"].mean():.1f}%')

    logistic_models(df)
    tost_paired_binary(df)
    cochran_armitage(df)
    mantel_haenszel(df)
    mcnemar_power(df)


if __name__ == '__main__':
    main()
