# Destructive-Thrash Analysis — GitOps Multi-Agent Runs

Empirical analysis answering reviewer concerns about concurrent-edit
thrash in the GitOps coordination mode of PASC. The same SWE-bench Pro
Python instances are run under two configurations per model (silent =
no peer feed, pasc = full peer-activity feed); this analysis compares
them as a paired test.

## Files

| File | Purpose |
|------|---------|
| `destructive_thrash.py` | Per-instance detector for four destructive-edit signatures (full-rewrite collision, sed pattern reversal, shared-line targeting, alternating-edit sequence). Reads `merge_report.json` + `agent_*/trajectory.json`. |
| `destructive_thrash_nagent.py` | N-agent generalization of the detector. Same four signatures applied to every (i, j) pair of agents in an N-agent run. |
| `analyze_silent_vs_pasc.py` | Runs the detector across the four headline silent ↔ PASC configurations (per model) and merges with SWE-bench Pro evaluation outcomes. Produces `silent_vs_pasc_thrash.json`. |
| `analyze_nagent.py` | Runs the N-agent detector across N=2/3/5 PASC ablation runs and merges with SWE-bench Pro evaluation outcomes. Produces `nagent_thrash.json`. |
| `significance.py` | Paired (McNemar exact two-sided) and unpaired (Fisher exact) tests on silent-vs-pasc pairs per model and per signal type. Reads `silent_vs_pasc_thrash.json`. |
| `advanced_stats.py` | Logistic GLM (pass ~ N + thrash + interaction), TOST equivalence (N=2 vs N=5), Cochran-Armitage trend across N, Mantel-Haenszel stratified test, McNemar power calculation. Reads `nagent_thrash.json`. |

## Usage

`significance.py` and `advanced_stats.py` run out-of-the-box against the
shipped `silent_vs_pasc_thrash.json` and `nagent_thrash.json`:

```bash
python3 significance.py
python3 advanced_stats.py
```

`analyze_silent_vs_pasc.py` and `analyze_nagent.py` REGENERATE the
intermediate JSONs from raw `runs/<config>/instance_*/pasc_gitops_*`
trajectories. These traces are NOT included in this replication package
(they run to hundreds of MB per configuration); anyone who wants to rebuild
from scratch should run the entry-point scripts (`run_batch_gitops.py`, see
top-level README) and then point `PASC_REPO_ROOT` at the resulting tree,
optionally `PASC_SWE_BENCH_PRO_OS` at the directory holding the eval
outputs:

```bash
PASC_REPO_ROOT=/path/to/my/runs python3 analyze_silent_vs_pasc.py
PASC_REPO_ROOT=/path/to/my/runs python3 analyze_nagent.py
```

Both scripts ship a `CONFIGS` dict whose `run_roots` reflect the layout
used to produce the shipped JSONs. Reviewers re-running on a different
run tree should edit those paths to match their own.
