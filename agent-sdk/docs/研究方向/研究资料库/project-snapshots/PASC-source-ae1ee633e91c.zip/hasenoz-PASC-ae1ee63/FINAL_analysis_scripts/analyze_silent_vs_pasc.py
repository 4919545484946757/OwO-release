"""
Silent vs PASC paired analysis on the headline Python subset.

Runs the destructive-thrash detector on the four final configurations
(silent vs PASC, per model) and merges with SWE-bench Pro evaluation
outcomes. The same instances appear under both silent and PASC conditions
per model, so significance.py can run a paired McNemar test on the output.

Configurations:
  - silent_minimax_m27    ↔ pasc_minimax_m27     (MiniMax pair)
  - silent_deepseek_v4pro ↔ pasc_deepseek_v4pro  (DeepSeek pair)

Output:
  silent_vs_pasc_thrash.json — per-instance findings + summary, used by
                               significance.py for paired (McNemar) tests.

Re-running this script regenerates the JSON from raw run trees. The raw
runs are NOT shipped in this replication package; to rebuild them from
scratch:

  1. Run the silent + PASC configurations via ``run_batch_gitops.py`` with
     ``-c swebench_xml_gitops_silent`` and ``-c swebench_xml_gitops``
     (see top-level README).
  2. Set ``PASC_REPO_ROOT`` to a tree containing the resulting ``runs/``
     directories.
  3. Edit the ``CONFIGS`` dict below so each ``run_roots`` list points to
     YOUR run directories. The defaults below mirror the layout used to
     produce the shipped ``silent_vs_pasc_thrash.json``.

Usage:
  python3 analyze_silent_vs_pasc.py
"""
from __future__ import annotations

import json
import math
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from destructive_thrash import analyze_instance


REPO_ROOT = Path(
    os.environ.get("PASC_REPO_ROOT", str(Path(__file__).resolve().parents[1]))
)

CONFIGS = {
    "silent_minimax_m27": {
        "eval": REPO_ROOT / "FINAL_results/silent_minimax_m27/eval_results.json",
        "run_roots": [
            REPO_ROOT / "runs/gitops_silent_n216",
            REPO_ROOT / "runs/gitops_silent_n50",
        ],
    },
    "pasc_minimax_m27": {
        "eval": REPO_ROOT / "FINAL_results/pasc_minimax_m27/eval_results.json",
        "run_roots": [
            REPO_ROOT / "runs/gitops_l3_n216",
            REPO_ROOT / "runs/gitops_l3_n50",
        ],
    },
    "silent_deepseek_v4pro": {
        "eval": REPO_ROOT / "FINAL_results/silent_deepseek_v4pro/eval_results.json",
        "run_roots": [
            REPO_ROOT / "runs/gitops_silent_ds_v4_pro_python_remaining_201",
            REPO_ROOT / "runs/gitops_silent_ds_v3_50plusreg",
        ],
    },
    "pasc_deepseek_v4pro": {
        "eval": REPO_ROOT / "FINAL_results/pasc_deepseek_v4pro/eval_results.json",
        "run_roots": [
            REPO_ROOT / "runs/gitops_l3_ds_v4_pro_qualify_python_remaining_201",
            REPO_ROOT / "runs/gitops_l3_ds_v3_qualify_50plusreg",
        ],
    },
}


def chi2_p(a: int, b: int, c: int, d: int) -> tuple[float, float]:
    n = a + b + c + d
    if n == 0:
        return 0.0, 1.0
    row1, row2, col1, col2 = a + b, c + d, a + c, b + d
    expected = [row1 * col1 / n, row1 * col2 / n, row2 * col1 / n, row2 * col2 / n]
    if any(e == 0 for e in expected):
        return 0.0, 1.0
    chi2 = sum((o - e) ** 2 / e for o, e in zip([a, b, c, d], expected))
    p = math.erfc(math.sqrt(chi2 / 2.0))
    return chi2, p


def analyze_config(eval_path: Path, run_roots: list[Path]) -> list[dict]:
    evals = json.loads(eval_path.read_text())
    rows = []
    for root in run_roots:
        for d in sorted(root.glob("instance_*/pasc_gitops_*")):
            try:
                res = analyze_instance(d)
            except Exception:
                continue
            iid = res.get("instance_id")
            if iid is None or "skip" in res or iid not in evals:
                continue
            res["resolved"] = bool(evals[iid])
            rows.append(res)
    return rows


def summarize(rows: list[dict], label: str) -> dict:
    n = len(rows)
    if n == 0:
        return {"label": label, "n": 0}

    def group(pred):
        sub = [r for r in rows if pred(r)]
        rate = (sum(1 for r in sub if r["resolved"]) / len(sub)) if sub else 0.0
        return len(sub), rate

    n_any, rate_any = group(lambda r: r.get("any_destructive_signal"))
    n_no, rate_no = group(lambda r: not r.get("any_destructive_signal"))
    a = sum(1 for r in rows if r.get("any_destructive_signal") and r["resolved"])
    b = sum(1 for r in rows if r.get("any_destructive_signal") and not r["resolved"])
    c = sum(1 for r in rows if not r.get("any_destructive_signal") and r["resolved"])
    d = sum(1 for r in rows if not r.get("any_destructive_signal") and not r["resolved"])
    chi2, pval = chi2_p(a, b, c, d)

    n_resolved = sum(1 for r in rows if r["resolved"])
    return {
        "label": label,
        "n": n,
        "n_resolved": n_resolved,
        "base_resolution_rate": n_resolved / n,
        "any_destructive_count": n_any,
        "any_destructive_pct": (n_any / n) * 100,
        "any_destructive_resolution_rate": rate_any,
        "no_destructive_resolution_rate": rate_no,
        "diff_pp": (rate_any - rate_no) * 100,
        "chi2": chi2,
        "chi2_p": pval,
        "by_signal": {
            "full_rewrite_collision": dict(zip(("n", "rate"), group(lambda r: r.get("has_full_rewrite_collision")))),
            "sed_reversal":           dict(zip(("n", "rate"), group(lambda r: r.get("has_sed_reversal")))),
            "shared_lines":           dict(zip(("n", "rate"), group(lambda r: r.get("has_shared_lines")))),
            "alternation":            dict(zip(("n", "rate"), group(lambda r: r.get("has_alternation")))),
        },
    }


def main():
    out_path = Path(__file__).parent / "silent_vs_pasc_thrash.json"
    out_per_config: dict[str, list[dict]] = {}
    out_summary: list[dict] = []
    for name, cfg in CONFIGS.items():
        print(f"Processing {name}...", file=sys.stderr)
        rows = analyze_config(cfg["eval"], cfg["run_roots"])
        out_per_config[name] = rows
        out_summary.append(summarize(rows, name))

    print("\n" + "=" * 92)
    print("DESTRUCTIVE-THRASH SUMMARY — silent vs PASC, headline Python configurations")
    print("=" * 92)
    print(f"{'Config':<28} {'n':>4} {'base':>7} {'destrct':>8} {'wDest':>7} {'woDest':>7} {'diff_pp':>8} {'p':>7}")
    print("-" * 92)
    for s in out_summary:
        if s.get("n", 0) == 0:
            continue
        print(
            f"{s['label']:<28} {s['n']:>4} {s['base_resolution_rate']*100:>6.1f}% "
            f"{s['any_destructive_pct']:>7.1f}% "
            f"{s['any_destructive_resolution_rate']*100:>6.1f}% "
            f"{s['no_destructive_resolution_rate']*100:>6.1f}% "
            f"{s['diff_pp']:>+7.2f}  {s['chi2_p']:>5.3f}"
        )

    print("\n" + "=" * 92)
    print("BY SIGNAL TYPE  (n_with_signal, resolution_rate)")
    print("=" * 92)
    print(f"{'Config':<28} {'full_rewrite':>15} {'sed_reversal':>15} {'shared_lines':>15} {'alternation':>15}")
    print("-" * 92)
    for s in out_summary:
        if s.get("n", 0) == 0:
            continue
        bs = s["by_signal"]
        print(
            f"{s['label']:<28} "
            f"{bs['full_rewrite_collision']['n']:>4} ({bs['full_rewrite_collision']['rate']*100:>5.1f}%)  "
            f"{bs['sed_reversal']['n']:>4} ({bs['sed_reversal']['rate']*100:>5.1f}%)  "
            f"{bs['shared_lines']['n']:>4} ({bs['shared_lines']['rate']*100:>5.1f}%)  "
            f"{bs['alternation']['n']:>4} ({bs['alternation']['rate']*100:>5.1f}%)"
        )

    out_path.write_text(json.dumps({
        "summary": out_summary,
        "per_config": out_per_config,
    }, indent=2, default=str))
    print(f"\nWrote {out_path}")


if __name__ == "__main__":
    main()
