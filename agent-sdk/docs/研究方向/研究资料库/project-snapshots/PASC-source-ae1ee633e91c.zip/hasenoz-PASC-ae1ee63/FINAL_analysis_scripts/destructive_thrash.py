"""
Destructive-thrash detector for GitOps multi-agent runs.

For each instance, examines each "contested" source file (both agents issued
mutating commands on it) and looks for four destructive-edit signatures:

  1. FULL REWRITE COLLISION — both agents issued a full-file rewrite
     (`cat > F`, `tee F`, redirect-truncate). Whoever's commit lands later
     wipes the other's work.

  2. SED PATTERN REVERSAL — A's `sed -i 's/X/Y/' F` is followed (in wall-
     clock time) by B's `sed -i 's/Z/W/' F` whose search pattern Z contains
     A's replacement Y (or vice versa). B is editing the line A just wrote.

     False-positive guard: requires the overlapping substring to be at
     least MIN_REVERSAL_OVERLAP characters AND non-trivial. The threshold
     was tuned on a manual review of 8 candidate cases in silent_minimax_m27
     (7 true positives, 1 false positive: 'qtutils' coincidentally appearing
     in 'qtqtutils' from independent typo-fix commands). MIN=10 keeps all
     7 true positives and rejects the false positive.

  3. SHARED-LINE TARGETING — both agents' sed expressions targeting the
     same explicit line numbers (e.g. A: `sed -i '1085a...'`, B: `sed -i
     '1085s/.../...'`).

  4. ALTERNATING-EDIT SEQUENCE — chronological edit timeline shows
     A→B→A or B→A→B patterns on the same file.

Each contested file gets a severity score; the instance is flagged
`any_destructive_signal` if any of the four signatures fires.

Inputs:
  run_dir/
    merge_report.json
    agent_0/trajectory.json
    agent_1/trajectory.json

Output:
  dict with per-file findings + instance-level booleans.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

# ------------------------------------------------------------------ #
# Tunables                                                           #
# ------------------------------------------------------------------ #
MIN_REVERSAL_OVERLAP = 10  # chars; see false-positive note in module docstring


# ------------------------------------------------------------------ #
# Regex patterns                                                     #
# ------------------------------------------------------------------ #
_PATH_RE = re.compile(
    r"/(?:testbed|app)/[A-Za-z0-9_./-]+\."
    r"(?:py|c|cpp|js|ts|json|yaml|yml|toml|md|txt|cfg|ini|sh|rs|go|java|h|hpp|rb|php)"
)
_SOURCE_PATH_RE = re.compile(r"^/(?:testbed|app)/[A-Za-z0-9_-]+/")

_SED_SUBST_RE = re.compile(
    r"sed\s+-i(?:\s+-[a-zA-Z]+)?\s+['\"]?s([|/!@#])(.*?)\1(.*?)\1[gimspx]*['\"]?\s+(\S+)"
)
_SED_LINE_RE = re.compile(
    r"sed\s+-i(?:\s+-[a-zA-Z]+)?\s+['\"]?\s*(\d+)\s*(?:[asci]|s)"
)


def is_mutating(cmd: str) -> bool:
    """True if the bash command appears to mutate a file under the repo
    (/testbed/ or /app/). Conservative: false-negatives are acceptable;
    false-positives would inflate the destructive-thrash count."""
    if not cmd:
        return False
    return bool(
        re.search(r"\bsed\s+-i\b", cmd)
        or re.search(r"\bcat\s+>>?\s*/(?:testbed|app)/", cmd)
        or re.search(r"\becho\b.*>>?\s*/(?:testbed|app)/", cmd)
        or re.search(r"\btee\b.*\s/(?:testbed|app)/", cmd)
        or re.search(r"\b(?:mv|cp|rm)\b\s+(?:-\S+\s+)?\S+\s*\S*/(?:testbed|app)/", cmd)
        or re.search(
            r">>?\s*/(?:testbed|app)/\S+\."
            r"(?:py|c|cpp|js|ts|json|yaml|yml|toml|md|txt|cfg|ini|sh|rs|go|java|h|hpp|rb|php)\b",
            cmd,
        )
    )


def find_full_rewrite_targets(cmd: str) -> set[str]:
    """Return repo paths that this command appears to fully rewrite."""
    targets: set[str] = set()
    for m in re.finditer(r"cat\s+>\s*(/(?:testbed|app)/\S+)", cmd):
        targets.add(m.group(1).rstrip(";&|"))
    for m in re.finditer(r"cat\s+>\s*(/(?:testbed|app)/\S+)\s*<<", cmd):
        targets.add(m.group(1).rstrip(";&|"))
    for m in re.finditer(r"\btee\s+(/(?:testbed|app)/\S+)", cmd):
        targets.add(m.group(1).rstrip(";&|"))
    for m in re.finditer(r"(?:^|\s|;|&)\s*>\s*(/(?:testbed|app)/\S+\.[a-z]+)", cmd):
        targets.add(m.group(1).rstrip(";&|"))
    return targets


def extract_sed_substitutions(cmd: str) -> list[tuple[str, str, str]]:
    """Return list of (search_pattern, replacement, target_file)."""
    out: list[tuple[str, str, str]] = []
    for m in _SED_SUBST_RE.finditer(cmd):
        out.append((m.group(2), m.group(3), m.group(4)))
    return out


def extract_sed_line_targets(cmd: str) -> set[int]:
    return {int(m.group(1)) for m in _SED_LINE_RE.finditer(cmd)}


def extract_paths(cmd: str) -> set[str]:
    return set(_PATH_RE.findall(cmd))


def is_source_path(p: str) -> bool:
    return bool(_SOURCE_PATH_RE.match(p))


def _is_substantive_overlap(s_a: str, s_b: str) -> bool:
    """Return True if either string contains the other AND the contained
    portion is non-trivial (length >= MIN_REVERSAL_OVERLAP)."""
    if not s_a or not s_b:
        return False
    if s_a in s_b and len(s_a) >= MIN_REVERSAL_OVERLAP:
        return True
    if s_b in s_a and len(s_b) >= MIN_REVERSAL_OVERLAP:
        return True
    return False


# ------------------------------------------------------------------ #
# Per-instance analysis                                              #
# ------------------------------------------------------------------ #
def analyze_instance(run_dir: Path) -> dict:
    merge_p = run_dir / "merge_report.json"
    if not merge_p.exists():
        return {"skip": "no_merge_report"}
    report = json.loads(merge_p.read_text(encoding="utf-8"))
    commit_history = report.get("commit_history", [])
    committed_steps: set[tuple[str, int]] = {
        (c["agent_id"], int(c["step"])) for c in commit_history
    }

    # Collect mutating step records per agent
    edits: dict[str, list[dict]] = {"agent_0": [], "agent_1": []}
    for agent_id in ("agent_0", "agent_1"):
        traj_p = run_dir / agent_id / "trajectory.json"
        if not traj_p.exists():
            continue
        try:
            traj = json.loads(traj_p.read_text(encoding="utf-8"))
        except Exception:
            continue
        step_no = 0
        for m in traj.get("messages", []):
            if m.get("role") != "assistant":
                continue
            step_no += 1
            actions = m.get("extra", {}).get("actions") or []
            cmd = " || ".join(a.get("command", "") for a in actions)
            ts = m.get("extra", {}).get("timestamp")
            if not is_mutating(cmd):
                continue
            paths = {p for p in extract_paths(cmd) if is_source_path(p)}
            if not paths:
                continue
            edits[agent_id].append({
                "agent": agent_id, "step": step_no, "ts": ts, "cmd": cmd,
                "paths": paths,
                "full_rewrites": find_full_rewrite_targets(cmd) & paths,
                "sed_subs": [
                    (s, r, t) for s, r, t in extract_sed_substitutions(cmd)
                    if any(t in p or p in t for p in paths)
                ],
                "sed_lines": extract_sed_line_targets(cmd),
                "committed": (agent_id, step_no) in committed_steps,
            })

    paths_a = set().union(*(e["paths"] for e in edits["agent_0"])) if edits["agent_0"] else set()
    paths_b = set().union(*(e["paths"] for e in edits["agent_1"])) if edits["agent_1"] else set()
    contested = paths_a & paths_b

    file_findings: list[dict] = []
    for f in contested:
        evs_a = [e for e in edits["agent_0"] if f in e["paths"]]
        evs_b = [e for e in edits["agent_1"] if f in e["paths"]]
        all_evs = sorted(evs_a + evs_b, key=lambda e: (e.get("ts") or 0))

        # 1. Full rewrite collision
        fr_a = sum(1 for e in evs_a if f in e["full_rewrites"])
        fr_b = sum(1 for e in evs_b if f in e["full_rewrites"])
        full_rewrite_collision = fr_a > 0 and fr_b > 0

        # 2. Sed pattern reversal — strict: chronological order + substantive overlap
        sed_reversal_count = 0
        sed_pairs = []
        for ea in evs_a:
            for sa, ra, ta in ea["sed_subs"]:
                if not (f in ta or ta in f or ta.endswith(f.split("/")[-1])):
                    continue
                for eb in evs_b:
                    if (eb.get("ts") or 0) <= (ea.get("ts") or 0):
                        continue
                    matched = False
                    for sb, rb, tb in eb["sed_subs"]:
                        if not (f in tb or tb in f or tb.endswith(f.split("/")[-1])):
                            continue
                        if _is_substantive_overlap(ra, sb):
                            matched = True
                            sed_pairs.append({
                                "a_step": ea["step"], "b_step": eb["step"],
                                "a_replace": ra[:80], "b_search": sb[:80],
                            })
                            break
                    if matched:
                        sed_reversal_count += 1

        # 3. Alternating-edit sequence
        agents_seq = [e["agent"] for e in all_evs]
        alternations = sum(
            1 for i in range(len(agents_seq) - 2)
            if agents_seq[i] != agents_seq[i + 1] and agents_seq[i] == agents_seq[i + 2]
        )

        # 4. Shared explicit line numbers
        lines_a = set().union(*(e["sed_lines"] for e in evs_a)) if evs_a else set()
        lines_b = set().union(*(e["sed_lines"] for e in evs_b)) if evs_b else set()
        shared_lines = lines_a & lines_b

        uncommitted_a = sum(1 for e in evs_a if not e["committed"])
        uncommitted_b = sum(1 for e in evs_b if not e["committed"])

        severity = (
            (10 if full_rewrite_collision else 0)
            + sed_reversal_count * 4
            + alternations * 2
            + len(shared_lines) * 3
            + min(5, uncommitted_a + uncommitted_b)
        )
        file_findings.append({
            "file": f,
            "edits_a": len(evs_a), "edits_b": len(evs_b),
            "full_rewrite_collision": full_rewrite_collision,
            "fr_a": fr_a, "fr_b": fr_b,
            "sed_reversal_count": sed_reversal_count,
            "sed_pairs_sample": sed_pairs[:3],
            "alternations": alternations,
            "shared_line_count": len(shared_lines),
            "shared_lines": list(shared_lines)[:10],
            "uncommitted_a": uncommitted_a, "uncommitted_b": uncommitted_b,
            "severity": severity,
        })

    file_findings.sort(key=lambda x: x["severity"], reverse=True)
    has_full_rewrite = any(f["full_rewrite_collision"] for f in file_findings)
    has_sed_rev = any(f["sed_reversal_count"] > 0 for f in file_findings)
    has_alt = any(f["alternations"] > 0 for f in file_findings)
    has_shared = any(f["shared_line_count"] > 0 for f in file_findings)

    return {
        "instance_id": report.get("instance_id"),
        "n_contested_source_files": len(contested),
        "instance_severity": sum(f["severity"] for f in file_findings),
        "has_full_rewrite_collision": has_full_rewrite,
        "has_sed_reversal": has_sed_rev,
        "has_alternation": has_alt,
        "has_shared_lines": has_shared,
        "any_destructive_signal": has_full_rewrite or has_sed_rev or has_alt or has_shared,
        "file_findings": file_findings,
    }
