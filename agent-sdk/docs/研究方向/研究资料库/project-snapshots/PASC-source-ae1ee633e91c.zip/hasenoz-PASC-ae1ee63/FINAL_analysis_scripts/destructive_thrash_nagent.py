"""
N-agent generalization of destructive-thrash detector.

For runs with N>=2 agents (agent_0..agent_{N-1}), examines each (i, j) pair of
agents on each contested file (both committed mutating commands) and applies
the same four signatures as the 2-agent detector:

  1. FULL REWRITE COLLISION
  2. SED PATTERN REVERSAL (chronological + substantive overlap)
  3. SHARED-LINE TARGETING
  4. ALTERNATING-EDIT SEQUENCE (A->B->A on same file)

Instance-level booleans are OR over all C(N,2) pairs.
"""
from __future__ import annotations

import itertools
import json
import re
from pathlib import Path

# Re-use helpers from destructive_thrash.py
import sys
sys.path.insert(0, str(Path(__file__).parent))
from destructive_thrash import (  # noqa: E402
    is_mutating, find_full_rewrite_targets, extract_sed_substitutions,
    extract_sed_line_targets, extract_paths, is_source_path,
    _is_substantive_overlap,
)


def _collect_agent_edits(run_dir: Path, agent_id: str, committed_steps: set) -> list[dict]:
    traj_p = run_dir / agent_id / "trajectory.json"
    if not traj_p.exists():
        return []
    try:
        traj = json.loads(traj_p.read_text(encoding="utf-8"))
    except Exception:
        return []
    out = []
    step_no = 0
    for m in traj.get("messages", []):
        if m.get("role") != "assistant":
            continue
        step_no += 1
        actions = m.get("extra", {}).get("actions") or []
        cmd = " || ".join(a.get("command", "") for a in actions)
        ts = m.get("extra", {}).get("timestamp")
        if not is_mutating(cmd):
            continue
        paths = {p for p in extract_paths(cmd) if is_source_path(p)}
        if not paths:
            continue
        out.append({
            "agent": agent_id, "step": step_no, "ts": ts, "cmd": cmd, "paths": paths,
            "full_rewrites": find_full_rewrite_targets(cmd) & paths,
            "sed_subs": [(s, r, t) for s, r, t in extract_sed_substitutions(cmd)
                         if any(t in p or p in t for p in paths)],
            "sed_lines": extract_sed_line_targets(cmd),
            "committed": (agent_id, step_no) in committed_steps,
        })
    return out


def _pair_findings(evs_a: list[dict], evs_b: list[dict], f: str) -> dict:
    all_evs = sorted(evs_a + evs_b, key=lambda e: (e.get("ts") or 0))
    fr_a = sum(1 for e in evs_a if f in e["full_rewrites"])
    fr_b = sum(1 for e in evs_b if f in e["full_rewrites"])
    full_rewrite_collision = fr_a > 0 and fr_b > 0

    sed_reversal_count = 0
    for ea in evs_a:
        for sa, ra, ta in ea["sed_subs"]:
            if not (f in ta or ta in f or ta.endswith(f.split("/")[-1])):
                continue
            for eb in evs_b:
                if (eb.get("ts") or 0) <= (ea.get("ts") or 0):
                    continue
                for sb, rb, tb in eb["sed_subs"]:
                    if not (f in tb or tb in f or tb.endswith(f.split("/")[-1])):
                        continue
                    if _is_substantive_overlap(ra, sb):
                        sed_reversal_count += 1
                        break

    agents_seq = [e["agent"] for e in all_evs]
    alternations = sum(
        1 for i in range(len(agents_seq) - 2)
        if agents_seq[i] != agents_seq[i + 1] and agents_seq[i] == agents_seq[i + 2]
    )
    lines_a = set().union(*(e["sed_lines"] for e in evs_a)) if evs_a else set()
    lines_b = set().union(*(e["sed_lines"] for e in evs_b)) if evs_b else set()
    shared_lines = lines_a & lines_b
    return dict(
        full_rewrite_collision=full_rewrite_collision,
        fr_a=fr_a, fr_b=fr_b,
        sed_reversal_count=sed_reversal_count,
        alternations=alternations,
        shared_line_count=len(shared_lines),
    )


def analyze_instance_nagent(run_dir: Path) -> dict:
    merge_p = run_dir / "merge_report.json"
    if not merge_p.exists():
        return {"skip": "no_merge_report"}
    report = json.loads(merge_p.read_text(encoding="utf-8"))
    commit_history = report.get("commit_history", [])
    committed_steps = {(c.get("agent_id", ""), int(c.get("step", 0))) for c in commit_history}

    agent_dirs = sorted(d for d in run_dir.iterdir() if d.is_dir() and re.match(r"agent_\d+$", d.name))
    n_agents = len(agent_dirs)
    if n_agents < 2:
        return {"skip": "less_than_2_agents", "instance_id": report.get("instance_id")}

    edits = {ad.name: _collect_agent_edits(run_dir, ad.name, committed_steps) for ad in agent_dirs}
    paths_per_agent = {a: set().union(*(e["paths"] for e in evs)) if evs else set()
                       for a, evs in edits.items()}

    has_full_rewrite = has_sed_rev = has_alt = has_shared = False
    contested_files: set[str] = set()
    pair_count = 0
    flagged_pairs = 0
    severity_total = 0
    pair_findings: list[dict] = []
    for a, b in itertools.combinations(sorted(edits.keys()), 2):
        contested = paths_per_agent[a] & paths_per_agent[b]
        for f in contested:
            contested_files.add(f)
            pf = _pair_findings(
                [e for e in edits[a] if f in e["paths"]],
                [e for e in edits[b] if f in e["paths"]],
                f,
            )
            pair_count += 1
            sev = (
                (10 if pf["full_rewrite_collision"] else 0)
                + pf["sed_reversal_count"] * 4
                + pf["alternations"] * 2
                + pf["shared_line_count"] * 3
            )
            severity_total += sev
            if (pf["full_rewrite_collision"] or pf["sed_reversal_count"]
                    or pf["alternations"] or pf["shared_line_count"]):
                flagged_pairs += 1
            if pf["full_rewrite_collision"]:
                has_full_rewrite = True
            if pf["sed_reversal_count"] > 0:
                has_sed_rev = True
            if pf["alternations"] > 0:
                has_alt = True
            if pf["shared_line_count"] > 0:
                has_shared = True
            pair_findings.append(dict(file=f, pair=(a, b), **pf, severity=sev))

    pair_findings.sort(key=lambda x: x["severity"], reverse=True)
    return {
        "instance_id": report.get("instance_id"),
        "n_agents": n_agents,
        "n_contested_files": len(contested_files),
        "n_contested_pairs_examined": pair_count,
        "n_flagged_pairs": flagged_pairs,
        "instance_severity": severity_total,
        "has_full_rewrite_collision": has_full_rewrite,
        "has_sed_reversal": has_sed_rev,
        "has_alternation": has_alt,
        "has_shared_lines": has_shared,
        "any_destructive_signal": has_full_rewrite or has_sed_rev or has_alt or has_shared,
        "team_patch_bytes": report.get("team_patch_bytes", 0),
        "n_commits": len(commit_history),
        "no_thought_commits": sum(
            1 for c in commit_history if "no thought" in (c.get("subject", "") or "").lower()
        ),
        "top_pair_findings": pair_findings[:5],
    }
