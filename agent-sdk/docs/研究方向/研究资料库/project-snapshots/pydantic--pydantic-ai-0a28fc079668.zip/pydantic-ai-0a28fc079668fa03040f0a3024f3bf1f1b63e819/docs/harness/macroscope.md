---
title: Macroscope
description: "Run a local Macroscope code review from a Pydantic AI agent and get structured findings it can verify and fix with its own file and shell tools."
---

# Macroscope

`Macroscope` runs a local [Macroscope](https://docs.macroscope.com/cli) code
review from inside an agent: one tool runs the installed `macroscope` CLI in
the run's workspace, parses the streamed findings, and returns them as
structured data. The agent validates each finding and fixes the real ones with
the tools it already has -- this capability surfaces findings only.

[Source](https://github.com/pydantic/pydantic-ai/tree/main/src/pydantic_ai_harness/pydantic_ai_harness/macroscope/)

> While Pydantic AI Harness is on 0.x releases, the API may change between minor releases; when it does, deprecation warnings and release-note migration guidance tell you (or your agent) exactly how to upgrade. See the [version policy](index.md#version-policy).

## The problem

Macroscope reviews the current branch's diff and streams findings, but it ships
as editor plugins (Claude Code, Codex, Cursor, OpenCode). There is no way to
give a Pydantic AI agent the same review-and-fix loop from your own code.

## Usage

```python
from pydantic_ai import Agent
from pydantic_ai.capabilities import LocalWorkspace
from pydantic_ai_harness import Macroscope

agent = Agent(
    'anthropic:claude-sonnet-5',
    capabilities=[
        LocalWorkspace('.'),
        Macroscope(),
    ],
)

result = agent.run_sync('Run a Macroscope review and fix any real findings.')
print(result.output)
```

The review runs in the agent's [workspace](https://pydantic.dev/docs/ai/core-concepts/workspace/),
in its working directory, which should be the repository: your machine with
`LocalWorkspace`, or the sandbox when the run uses one. A run without a workspace fails at its
start. The `macroscope` CLI must be installed and authenticated in the
workspace first:

1. Install: `curl -sSL https://raw.githubusercontent.com/prassoai/macroscope-local/main/install.sh | bash`
2. Sign in and pick a Macroscope workspace by running `macroscope` once.

The capability cannot install or authenticate on your behalf. The model cannot
fix these setup problems either, so the tool raises `UserError` and the run
stops rather than spending tool retries on them. A missing binary reports the
install command, a binary that cannot be launched reports the OS error, and a
review that never starts (usually because you are not signed in) tells you to
run `macroscope` to finish setup. The exception is a review that fails to start
with a `base` the model passed: that is reported to the model as a retry so it
can drop or change the ref.

The tool invokes `macroscope codereview --raw` for machine-readable streaming
output, which needs a recent CLI build. The installer fetches the latest and the
CLI self-updates on use, so a fresh install satisfies this.

## The tool

| Tool | Purpose |
|---|---|
| `run_macroscope_review` | Run `macroscope codereview` on the current branch and return the review id, terminal status, and findings. Accepts an optional `base` git ref. |

Each finding is a `MacroscopeIssue` with `issue_id`, `sequence`, `path`,
`line`, `severity`, `category`, and `body`. The capability's default
instructions tell the agent to treat every finding as untrusted: read the
affected code to confirm an issue is real, skip false positives and
duplicates, and verify each fix.

## Options

Every field of `Macroscope` with its default:

```python
from pydantic_ai_harness import Macroscope

Macroscope(
    base=None,             # git ref to diff against -- None lets the CLI auto-detect
    command='macroscope',  # binary name or path
    timeout=600.0,         # max seconds to wait for a review
    guidance=None,         # None = default instructions, '' = none, str = custom
)
```

A per-call `base` argument takes precedence over the field. Reviews call a
remote service, so the timeout is generous by default; on timeout the
workspace stops the CLI and the timeout is reported to the model as a
retryable error. The tool is not offered when the workspace cannot run
commands (for example a read-only one).

## Scope and composition

This capability surfaces findings only. It does not edit files, create
worktrees, or commit -- validating and fixing findings is the agent's job,
using its other capabilities. Pair it with `FileSystem` or `Shell` to let the
agent read code and apply fixes, and consider running the agent in an isolated
worktree if you want fixes kept off your working tree.

## Agent spec

`Macroscope` works with Pydantic AI's [agent spec](../agent-spec.md),
so you can declare it in a config file instead of Python:

```yaml
# agent.yaml
model: anthropic:claude-sonnet-5
capabilities:
  - Macroscope:
      base: main
      timeout: 900
```

```python
from pydantic_ai import Agent
from pydantic_ai_harness import Macroscope

agent = Agent.from_file('agent.yaml', custom_capability_types=[Macroscope])
```

Pass `custom_capability_types` so the spec loader knows how to instantiate
`Macroscope`.

## Further reading

- [Macroscope CLI documentation](https://docs.macroscope.com/cli)
- [Pydantic AI capabilities](../capabilities/overview.md)
- [Toolsets](../toolsets.md)

## API reference

::: pydantic_ai_harness.macroscope.Macroscope

::: pydantic_ai_harness.macroscope.MacroscopeReview

::: pydantic_ai_harness.macroscope.MacroscopeIssue
