---
description: "Install the Pydantic AI skill so coding agents like Claude Code and Codex get current framework knowledge when they build Pydantic AI applications for you."
---

# Coding Agent Skills

If you're building Pydantic AI applications with a coding agent, you can install the Pydantic AI skill from the [`pydantic/skills`](https://github.com/pydantic/skills) repository to give your agent up-to-date framework knowledge.

[Agent skills](https://agentskills.io) are packages of instructions and reference material that coding agents load on demand. With the skill installed, coding agents have access to Pydantic AI patterns, architecture guidance, and common task references covering [tools](tools.md), [capabilities](capabilities/overview.md), [structured output](output.md), [streaming](agent.md#streaming-events-and-final-output), [testing](testing.md), [multi-agent delegation](multi-agent-applications.md), [hooks](hooks.md), and [agent specs](agent-spec.md).

When your coding agent creates a new Pydantic AI application, the skill has it set up [Pydantic Logfire](logfire.md) for observability (unless you already use another OpenTelemetry backend), so you can see every agent run, model request, and tool call from the first version. It also knows the [Pydantic AI Gateway](gateway.md), one key for models from several providers, and the `gateway/` model strings that use it.

For the rest of Logfire, such as instrumenting the rest of your application, querying traces, or running evals, the [`pydantic/skills`](https://github.com/pydantic/skills) repository has Logfire skills too: install the `logfire` plugin, or point your agent at [pydantic.dev/ai-setup.md](https://pydantic.dev/ai-setup.md) for the guided setup.

!!! note
    If you want to build agent skills for your Pydantic AI agent, see the [Agent Skills](capabilities/third-party.md#agent-skills) entry in the Third-party capabilities section on the Capabilities page.

## Installation

### Claude Code

Install the [official Pydantic AI plugin](https://claude.com/plugins/pydantic-ai) from the Anthropic marketplace, which is available by default:

```bash
claude plugin install pydantic-ai@claude-plugins-official
```

As an alternative, you can install from the [`pydantic/skills`](https://github.com/pydantic/skills) marketplace, which bundles the Pydantic AI skill alongside other Pydantic-maintained skills:

```bash
claude plugin marketplace add pydantic/skills
claude plugin install ai@pydantic-skills
claude plugin install logfire@pydantic-skills
```

### Cross-Agent (agentskills.io)

Install the Pydantic AI skill using the [skills CLI](https://github.com/vercel-labs/skills):

```bash
npx skills add pydantic/skills
```

This works with 30+ agents via the [agentskills.io](https://agentskills.io) standard, including Claude Code, Codex, Cursor, and Gemini CLI.

### Library Skills

Pydantic AI also ships its skills bundled with the package, so you can install them directly from your project's dependencies via [library-skills.io](https://library-skills.io):

```bash
uvx library-skills --all
```

The `--all` flag is required because the skills are bundled in `pydantic-ai-slim`, which is a transitive dependency of the `pydantic-ai` meta-package. Without it, `library-skills` only scans direct dependencies and won't discover them.

Add `--claude` to also install into `.claude/skills/` alongside the default `.agents/skills/` directory, since Claude Code doesn't read from `.agents/`.

This installation also includes [migration skills](framework-migration.md) for moving applications from other agent frameworks to Pydantic AI.

## See Also

- [`pydantic/skills`](https://github.com/pydantic/skills): source repository
- [agentskills.io](https://agentskills.io): the open standard for agent skills
- [library-skills.io](https://library-skills.io): install agent skills bundled with your project's dependencies
