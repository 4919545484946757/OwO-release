# `pydantic_ai.profiles`

::: pydantic_ai.profiles
    options:
      members:
        - ModelProfile
        - ModelProfileSpec
        - JsonSchemaTransformer
        - InlineDefsJsonSchemaTransformer
        - merge_profile
        - prompt_cache_outlook
        - PromptCacheOutlook
        - DEFAULT_PROFILE
        - DEFAULT_PROMPTED_OUTPUT_TEMPLATE
        - DEFAULT_THINKING_TAGS

::: pydantic_ai.profiles.openai

::: pydantic_ai.profiles.openai_codex

::: pydantic_ai.profiles.anthropic

::: pydantic_ai.profiles.google

::: pydantic_ai.profiles.meta

::: pydantic_ai.profiles.amazon

::: pydantic_ai.profiles.deepseek

::: pydantic_ai.profiles.grok

::: pydantic_ai.profiles.mistral

::: pydantic_ai.profiles.qwen

::: pydantic_ai.profiles.groq

::: pydantic_ai.profiles.zai

::: pydantic_ai.profiles.decision
