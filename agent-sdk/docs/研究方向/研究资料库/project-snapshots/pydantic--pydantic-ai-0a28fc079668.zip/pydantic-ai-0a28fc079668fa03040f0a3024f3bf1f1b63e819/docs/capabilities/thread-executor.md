---
description: "Run sync tools and callbacks on your own thread pool with the Pydantic AI UseThreadExecutor capability, so long-running servers do not accumulate threads."
---

# Thread Executor

The [`UseThreadExecutor`][pydantic_ai.capabilities.UseThreadExecutor] [capability](overview.md) provides a custom [`Executor`][concurrent.futures.Executor] for running sync tool functions and other sync callbacks in threads. This is useful in long-running servers (e.g. FastAPI) where the default ephemeral threads from [`anyio.to_thread.run_sync`][anyio.to_thread.run_sync] can accumulate under sustained load:

```python {test="skip"}
from concurrent.futures import ThreadPoolExecutor

from pydantic_ai import Agent
from pydantic_ai.capabilities import UseThreadExecutor

executor = ThreadPoolExecutor(max_workers=16, thread_name_prefix='agent-worker')
agent = Agent('openai:gpt-5.2', capabilities=[UseThreadExecutor(executor)])
```

It declares a default `id` of `'use_thread_executor'`, so two instances merge instead of raising a duplicate-id error — see [building custom capabilities](custom.md) for the merge rules.

See [Thread executor for long-running servers](../tools-advanced.md#thread-executor-for-long-running-servers) for more details.
