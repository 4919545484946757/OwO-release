# `pydantic_ai.providers`

::: pydantic_ai.providers.Provider

::: pydantic_ai.providers.infer_provider

::: pydantic_ai.providers.infer_provider_class

::: pydantic_ai.providers.gateway.gateway_provider

::: pydantic_ai.providers.anthropic.AnthropicProvider

::: pydantic_ai.providers.google

::: pydantic_ai.providers.google_cloud

::: pydantic_ai.providers.openai

::: pydantic_ai.providers.openai_codex
    options:
      inherited_members: true

::: pydantic_ai.providers.openai_decisions
    options:
      inherited_members: true

::: pydantic_ai.providers.xai

::: pydantic_ai.providers.deepseek

::: pydantic_ai.providers.bedrock

::: pydantic_ai.providers.bedrock_mantle

::: pydantic_ai.providers.groq

::: pydantic_ai.providers.azure

::: pydantic_ai.providers.cohere

::: pydantic_ai.providers.voyageai.VoyageAIProvider

::: pydantic_ai.providers.sentence_transformers.SentenceTransformersProvider

::: pydantic_ai.providers.cerebras.CerebrasProvider

::: pydantic_ai.providers.mistral.MistralProvider

::: pydantic_ai.providers.fireworks.FireworksProvider

::: pydantic_ai.providers.together.TogetherProvider

::: pydantic_ai.providers.heroku.HerokuProvider

::: pydantic_ai.providers.github.GitHubProvider

::: pydantic_ai.providers.github_copilot.GitHubCopilotProvider

::: pydantic_ai.providers.github_copilot.GitHubCopilotOAuthFlow

::: pydantic_ai.providers.github_copilot.GitHubCopilotDeviceAuthorization

::: pydantic_ai.providers.github_copilot.GitHubCopilotCredentials

::: pydantic_ai.providers.openrouter.OpenRouterProvider

::: pydantic_ai.providers.vercel.VercelProvider

::: pydantic_ai.providers.huggingface.HuggingFaceProvider

::: pydantic_ai.providers.moonshotai.MoonshotAIProvider

::: pydantic_ai.providers.ollama.OllamaProvider

::: pydantic_ai.providers.litellm.LiteLLMProvider

::: pydantic_ai.providers.vllm.VLLMProvider

::: pydantic_ai.providers.nebius.NebiusProvider

::: pydantic_ai.providers.ovhcloud.OVHcloudProvider

::: pydantic_ai.providers.crusoe.CrusoeProvider

::: pydantic_ai.providers.alibaba.AlibabaProvider

::: pydantic_ai.providers.sambanova.SambaNovaProvider

::: pydantic_ai.providers.snowflake.SnowflakeProvider

::: pydantic_ai.providers.typesafe.TypeSafeProvider

::: pydantic_ai.providers.system_one.SystemOneProvider

::: pydantic_ai.providers.zai.ZaiProvider
