---
title: Pylon
description: Connect a Pydantic AI agent to Pylon's hosted MCP server to work with support issues, accounts, and contacts.
---

# Pylon

`Pylon` connects an agent to [Pylon](https://www.usepylon.com)'s hosted MCP server so it can search, read, create, and update support issues, look up and update accounts, and look up contacts as the signed-in user.

[Source](https://github.com/pydantic/pydantic-ai/tree/main/src/pydantic_ai_harness/pydantic_ai_harness/pylon/)

> While Pydantic AI Harness is on 0.x releases, the API may change between minor releases; when it does, deprecation warnings and release-note migration guidance tell you (or your agent) exactly how to upgrade. See the [version policy](index.md#version-policy).

## Before you start

You need a Pylon Member or Admin seat with the `MCP Access` role; Viewer and Integration users cannot sign in. Pylon MCP takes an OAuth access token. Pylon REST API tokens do not work with it.

Pylon issues these tokens only through OAuth. Your application gets one by running the standard MCP authorization flow: the server names its authorization server and supports dynamic client registration, so any MCP OAuth client library can sign the user in. Store the token it returns and pass it as `auth` or `PYLON_ACCESS_TOKEN`.

## Installation

```bash
pip/uv-add "pydantic-ai-harness[pylon]" "pydantic-ai-slim[openai]"
```

The second package installs the OpenAI provider the example uses. For another model, install that provider's extra instead.

## Connect

```python
from pydantic_ai import Agent
from pydantic_ai_harness import Pylon

agent = Agent('openai:gpt-5.6-sol', capabilities=[Pylon()])
result = agent.run_sync('Summarize my open Pylon issues')
print(result.output)
```

Set `PYLON_ACCESS_TOKEN` to a Pylon access token, or pass `auth=` a token. On your own machine, `auth='oauth'` signs you in through the browser instead. To serve several users from one agent, pass a function instead (see [Per-user credentials](#per-user-credentials)). The agent sees the same issues, accounts, and contacts that user sees in the Pylon dashboard.

## Per-user credentials

`auth` decides which Pylon account each run uses:

| `auth` | Account used |
| --- | --- |
| Not set, `None`, or `''` | `PYLON_ACCESS_TOKEN`. If that is not set either, creating the agent raises an error. |
| An access token | That token, for every run. |
| `'oauth'` | The account you sign in to through the browser. This only works on your own machine. |
| A function | Called at the start of each run. The token it returns is used for that run. If it returns `None` or `''`, that run has no Pylon tools. A function never uses `PYLON_ACCESS_TOKEN`, and must not return `'oauth'`. |

A fixed token or `PYLON_ACCESS_TOKEN` suits a script or an agent on your own machine, where every run is the same account.

In an app where each user connects their own Pylon account, one agent serves all of them, so the token cannot be fixed when the agent is created. Pass a function that reads the current user's token from the run's deps:

```python
from dataclasses import dataclass

from pydantic_ai import Agent, RunContext
from pydantic_ai_harness import Pylon


@dataclass
class Deps:
    pylon_token: str | None


def pylon_token(ctx: RunContext[Deps]) -> str | None:
    return ctx.deps.pylon_token


agent = Agent('openai:gpt-5.6-sol', deps_type=Deps, capabilities=[Pylon(auth=pylon_token)])
```

Each run connects as its own user, so concurrent runs never share an account.

Your app gets each user's token, stores it, and refreshes it. For example, a "Connect Pylon" button that runs the OAuth flow from [Before you start](#before-you-start) and saves the token to their account. Before each run, load it (this can be async) and put it in the deps; the function only reads it.

With durable execution such as Temporal, read the token from the run's deps rather than from a global, since the function may run in another process. The capability's `id` defaults to `pylon`, so `defer_loading=True` works without one. To add more than one `Pylon` to an agent, give each a distinct `id` and wrap them in [PrefixTools](../capabilities/prefix-tools.md), since their tool names are the same; two that share an `id` but differ raise an error.

## Tool selection and approval

`read_only=True` gives the agent only the tools that Pylon's server labels as read-only, and leaves out all the others. If Pylon has not labeled its read tools, the agent gets no Pylon tools and emits an `MCPReadOnlyNoToolsWarning`. The token's permissions still decide what the agent can reach.

To filter tools or require approval in your application, wrap the toolset with the existing [toolset wrappers](../toolsets.md). For example, this asks for approval before every tool call, which suits tools that create or update issues and accounts:

```python
from pydantic_ai import Agent
from pydantic_ai.messages import DeferredToolRequests
from pydantic_ai_harness import Pylon

capability = Pylon()
agent = Agent(
    'openai:gpt-5.6-sol',
    toolsets=[capability.get_toolset().approval_required()],
    output_type=[str, DeferredToolRequests],
)
```

Handle the approval requests with the [deferred tools workflow](../deferred-tools.md). To cap the size of tool output, add [Tool Output Limits](tool-output-limits.md).

## Connection customization

Use `auth` in almost every case. Pass `client` only when you need control of the connection itself: your own FastMCP client or transport, for example one with a proxy or MCP handlers. The client then owns the URL and authentication, so passing `client` together with `auth` raises an error. `read_only` and `include_instructions` still apply. `include_instructions=False` stops the server's own instructions from reaching the agent.

A `client` is one connection shared by every run; see [Per-user credentials](#per-user-credentials) to connect each user separately.

## Telemetry

`Pylon` emits no spans of its own. Core's [instrumentation](../capabilities/instrumentation.md) already records each Pylon tool call as a tool span, and connecting makes no decision worth a span of its own.

## Define the agent in YAML or JSON

Loading a YAML file also needs the `spec` extra:

```bash
pip/uv-add "pydantic-ai-slim[spec]"
```

```yaml
# agent.yaml
model: openai:gpt-5.6-sol
capabilities:
  - Pylon: {}
```

```python
from pydantic_ai import Agent
from pydantic_ai_harness import Pylon

agent = Agent.from_file('agent.yaml', custom_capability_types=[Pylon])
```

Pass `custom_capability_types` so the loader can create `Pylon` from the file.

## API reference

::: pydantic_ai_harness.pylon.Pylon
