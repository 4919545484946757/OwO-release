---
description: "Where to get help with Pydantic AI, from getting started to advanced usage: ask the community in the Pydantic Slack or open an issue on GitHub."
---

# Getting Help

If you need help getting started with Pydantic AI or with advanced usage, the following sources may be useful.

## Slack

Join the `#pydantic-ai` channel in the [Pydantic Slack][slack] to ask questions, get help, and chat about Pydantic AI. There are also channels for Pydantic, Logfire, and FastUI.

If you're on a [Logfire][logfire] Pro plan, you can also get a dedicated private slack collab channel with us.

## :simple-github: GitHub Issues

The [Pydantic AI GitHub Issues][github-issues] are a great place to ask questions and give us feedback.

[slack]: https://logfire.pydantic.dev/docs/join-slack/
[github-issues]: https://github.com/pydantic/pydantic-ai/issues
[logfire]: https://pydantic.dev/logfire
