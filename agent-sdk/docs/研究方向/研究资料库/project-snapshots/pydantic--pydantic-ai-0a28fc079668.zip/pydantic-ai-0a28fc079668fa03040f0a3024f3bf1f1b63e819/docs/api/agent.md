# `pydantic_ai.agent`

::: pydantic_ai.agent
    options:
        members:
            - Agent
            - AbstractAgent
            - WrapperAgent
            - AgentRetries
            - AgentRealtime
            - AgentRun
            - AgentRunEvents
            - AgentRunResult
            - EndStrategy
            - RunOutputDataT
            - capture_run_messages
            - InstrumentationSettings
            - EventStreamHandler
            - AgentSpec
            - AgentModelSettings
            - AgentInstructions
            - UserPromptNode
            - ModelRequestNode
            - CallToolsNode
            - PydanticAIDeprecationWarning

::: pydantic_ai.CancellationToken
