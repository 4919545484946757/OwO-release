"""Claude's `Edit` tool -- replace a string in a workspace file.

The single-occurrence case is backed by pydantic-ai-harness's
`FileSystemToolset.edit_file`, which requires `old_string` to match exactly once
-- the same uniqueness rule Claude Code's own `Edit` enforces. `replace_all=True`
has no harness equivalent, so it keeps the prior in-place read/replace/write.
"""

from pydantic_ai import RunContext
from pydantic_ai.exceptions import ModelRetry

from ._backends import filesystem
from .shared import attach_context, resolve


async def edit_file(
    ctx: RunContext[object], file_path: str, old_string: str, new_string: str, replace_all: bool = False
) -> str:
    """Replace `old_string` with `new_string` in a workspace file.

    Replaces the single (unique) occurrence, or every occurrence when `replace_all`.
    """
    if replace_all:
        return await _replace_all(ctx, file_path, old_string, new_string)
    try:
        result = await filesystem().edit_file(file_path, old_string, new_string, workspace=ctx.workspace)
    except (ModelRetry, OSError) as exc:
        # The harness only converts a fixed set of errors to `ModelRetry`; a bare
        # `OSError` (e.g. `ENAMETOOLONG` while resolving the path) would otherwise
        # escape and abort the whole run, where the old tool returned an error.
        return f'error: {exc}'
    return attach_context(file_path) + result


async def _replace_all(ctx: RunContext[object], file_path: str, old_string: str, new_string: str) -> str:
    """Replace every occurrence of `old_string`.

    The harness `edit_file` rejects non-unique matches, so replace-all stays an
    in-place rewrite (as the tool did before it was harness-backed). Workspace
    containment is still enforced by preflighting the path through the filesystem
    capability's `file_info` -- the same check `Grep` uses -- so this branch
    can't escape the workspace root while the single-edit branch can't.
    """
    try:
        await filesystem().file_info(file_path, workspace=ctx.workspace)  # rejects a path that escapes the workspace
        p = resolve(file_path)
        text = p.read_text(encoding='utf-8')
        if old_string not in text:
            return 'error: `old_string` not found'
        p.write_text(text.replace(old_string, new_string, -1), encoding='utf-8')
    except ModelRetry as exc:
        return f'error: {exc}'
    except OSError as exc:
        return f'error: {exc}'
    return attach_context(file_path) + f'edited {p}'
