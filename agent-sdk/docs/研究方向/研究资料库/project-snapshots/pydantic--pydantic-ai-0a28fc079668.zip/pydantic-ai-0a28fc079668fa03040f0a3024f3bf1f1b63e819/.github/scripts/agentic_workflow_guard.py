"""Static policy checks for the `gh-aw` agentic workflows in `.github/workflows/`.

Every check here encodes a defect that actually reached `main` and burned model
budget before anyone noticed, documented in #6766:

- `dangling_needs` — `pydantic-ai-ui-security-review` gated `activation` on
  `needs.detect.outputs.touched` while `detect` was not one of its `needs`. The
  expression silently evaluated to empty, so the whole chain skipped for a month.
  A job skipped by `if:` reports *success*, so the required check stayed green
  while the security review never ran.
- `safe_output_job_max` — `record-attention-decision` relied on the default
  `max: 1`, so 9 of every 10 classifications were dropped into an `errors` array
  nobody read and the host script then failed the run.
- `prompt_paths` — the review prompt told the agent to read
  `/tmp/gh-aw/.review-context/`, outside the `Read` tool's root. Every run wasted
  ~15 tool calls rediscovering its own context via `bash cat`.
- `timeout_declared` — a sweep silently needs a wall-clock bound; `roundtrip-sweep`
  spent three weeks timing out one minute under its limit, filing nothing.
- `job_timeout_env` — the shim reads its wall-clock budget from
  `PYDANTIC_AI_JOB_TIMEOUT_MINUTES`, so every workflow must declare it and keep it
  equal to `timeout-minutes`. Absent, the shim assumed 30: `stale-issues-finder`
  asked for 60 and only ever used 28, and `attention-triage` asked for 20 and was
  killed before it could emit anything.
- `compiler_versions` — a partial `gh aw compile` leaves locks on mixed compiler
  versions, which is how source and lock drift apart unnoticed.
- `compiled_runner_contract` — every generated agent job must keep the command-line
  contract required by the Pydantic AI runner shim.
- `awf_binary_version` — `engine.command` makes gh-aw skip its own AWF install, so
  `shared/pre-steps.md` re-runs the installer with a hand-written version. #8041 moved
  gh-aw to a release bundling AWF v0.27.44 without touching that pin, and the v0.27.42
  binary rejected the v0.27.44 config (`config.apiProxy.providers is not supported`).
  The agent job died before the model started, on every workflow using the shim.
- `ai_credits_accounting` — `apiProxy.providers` is the API proxy's AI-credits pricing
  table, not a reporting field, and AWF caps a run at 10,000 credits with nothing in
  frontmatter able to lift it. Pricing `MiniMax-M3` there made one ordinary request cost
  tens of thousands, so every agent job 403'd on its first call.
- `compiler_version_compatibility` — the compiler version in every generated lock
  must not appear in gh-aw's live blocked-version policy.
- `lock_regenerated` — `.github/workflows/AGENTS.md` requires a recompiled
  `*.lock.yml` in the same change as its `*.md` source. GitHub Actions runs the
  lock, so an un-recompiled source is a silent no-op.

Run over the repo with `python .github/scripts/agentic_workflow_guard.py check`,
or as policy tests via `test_agentic_workflow_guard.py`.
"""

from __future__ import annotations

import argparse
import json
import posixpath
import re
import shlex
import subprocess
import sys
from collections.abc import Mapping, Sequence
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path
from typing import Any, TypeGuard, cast

import yaml

WORKFLOWS_DIR = Path('.github/workflows')
AGENTIC_GLOB = 'pydantic-ai-*.md'

# gh-aw stages the agent's workspace no-exec and roots its file tools at the
# checkout, so absolute paths under this prefix are unreadable by `Read`.
SANDBOX_PREFIX = '/tmp/gh-aw/'

# Paths the agent is told about but reads through `Bash`/`jq` rather than the file
# tools, which is fine — `Bash` is not rooted at the checkout. `/tmp/gh-aw/bin` is
# gh-aw's exec-able launcher path; the rest is the prefetched GitHub corpus that
# `shared/tool-hints.md` documents with `jq` invocations (#6509).
#
# These stay outside `$GITHUB_WORKSPACE` while PR review context was moved into it
# (#6766 F3), so an agent that reaches for `Read` here still hits the old failure.
# Worth revisiting if a sweep is seen burning turns on them.
# Every entry ends in `/`, including the one naming a single file, and the candidate
# path gets one appended before comparison. That makes the match land on a whole path
# component in both directions: without it `bin` also allows `bindings/`, and
# `open-issues.tsv` also allows `open-issues.tsv.bak`.
PROMPT_PATH_ALLOWLIST_PREFIXES = (
    '/tmp/gh-aw/bin/',
    '/tmp/gh-aw/agent/github-context/',
    '/tmp/gh-aw/agent/open-issues.tsv/',
    '/tmp/gh-aw/agent/issues/',
)

# A fenced block opens with three or more backticks or tildes, indented at most three
# spaces, optionally followed by an info string. `~~~` and the indent allowance are both
# CommonMark and both appear in the wild. The trailing group is the info string, which
# only an *opener* may carry — see `check_prompt_paths`.
FENCE_MARKER = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')

# Mirrors `pydantic_ai_gh_aw_shim.cli`, which this script deliberately does not import:
# the shim pulls in the whole agent runtime, and the guard must stay a lightweight
# stdlib+yaml script. `test_job_timeout_constants_match_the_shim` pins them together.
DEFAULT_JOB_TIMEOUT_MINS = 30
JOB_TIMEOUT_HEADROOM_MINS = 2

# Run to the end of the path token rather than to the end of a filename-ish character
# class. A class that stops early truncates `/tmp/gh-aw/bin:secret/x` to `/tmp/gh-aw/bin`,
# which then matches the allowlist and lets the real path through unflagged. Stopping at
# whitespace, backtick, quote and the markdown-link delimiters is enough to end the token
# wherever a prompt actually writes one.
SANDBOX_PATH = re.compile(rf'{re.escape(SANDBOX_PREFIX)}[^\s`\'"()\[\]<>]*')

# The version argument of the hand-written AWF install step. Both the script path and
# the version may be quoted, and the capture must not swallow those quotes: a pin that
# only differs from the compiled version by a pair of them is the same pin.
AWF_INSTALL_VERSION = re.compile(r'install_awf_binary\.sh"?\s+"?([^"\s]+)')

NEEDS_REFERENCE = re.compile(r'\bneeds\.([A-Za-z_][A-Za-z0-9_-]*)')
EXPRESSION_BLOCK = re.compile(r'\$\{\{(.*?)\}\}', re.DOTALL)


def _strip_boolean_wrappers(expression: str) -> str:
    """Strip parentheses that wrap the whole expression, not a subexpression."""
    expression = expression.strip()
    while expression.startswith('(') and expression.endswith(')'):
        depth = 0
        quote: str | None = None
        wraps_expression = True
        for index, character in enumerate(expression):
            if quote is not None:
                if character == quote:
                    quote = None
            elif character in ("'", '"'):
                quote = character
            elif character == '(':
                depth += 1
            elif character == ')':
                depth -= 1
                if depth == 0 and index != len(expression) - 1:
                    wraps_expression = False
                    break
        if not wraps_expression or depth != 0:
            break
        expression = expression[1:-1].strip()
    return expression


def _split_boolean_operator(expression: str, operator: str) -> list[str]:
    """Split at boolean operators outside quotes and parenthesized expressions."""
    terms: list[str] = []
    depth = 0
    quote: str | None = None
    start = 0
    index = 0
    while index < len(expression):
        character = expression[index]
        if quote is not None:
            if character == quote:
                quote = None
            index += 1
            continue
        if character in ("'", '"'):
            quote = character
            index += 1
            continue
        if character == '(':
            depth += 1
            index += 1
            continue
        if character == ')':
            depth -= 1
            index += 1
            continue
        if depth == 0 and expression.startswith(operator, index):
            terms.append(expression[start:index].strip())
            index += len(operator)
            start = index
            continue
        index += 1
    if not terms:
        return []
    terms.append(expression[start:].strip())
    return terms


def _boolean_branches(expression: str) -> list[list[str]]:
    """Return conjunction terms for each OR branch in a workflow condition."""
    expression = _strip_boolean_wrappers(expression)
    if expression.startswith('${{') and expression.endswith('}}'):
        expression = expression[3:-2].strip()
    disjunctions = _split_boolean_operator(expression, '||')
    if disjunctions:
        return [branch for term in disjunctions for branch in _boolean_branches(term)]
    conjunctions = _split_boolean_operator(expression, '&&')
    if not conjunctions:
        return [[expression]]
    branches: list[list[str]] = [[]]
    for term in conjunctions:
        term_branches = _boolean_branches(term)
        branches = [prefix + suffix for prefix in branches for suffix in term_branches]
    return branches


def _normalized_condition(expression: str) -> str:
    """Normalize whitespace for comparisons between boolean-expression terms."""
    return re.sub(r'\s+', '', expression)


def _condition_is_required(expression: str, condition: str) -> bool:
    """Check that `condition` is a conjunct in every OR branch."""
    expected = _normalized_condition(condition)
    branches = _boolean_branches(expression)
    return bool(branches) and all(expected in {_normalized_condition(term) for term in branch} for branch in branches)


@dataclass(frozen=True)
class Violation:
    """A single policy failure, rendered as one line of CI output."""

    path: str
    check: str
    message: str

    def __str__(self) -> str:
        return f'{self.path}: [{self.check}] {self.message}'


def _as_mapping(value: object) -> dict[str, Any]:
    """Coerce a parsed-YAML value to a string-keyed mapping.

    YAML 1.1 parses a bare `on:` key as the boolean `True`, so keys are stringified
    with that one special case mapped back.
    """
    if not isinstance(value, dict):
        return {}
    mapping = cast(dict[Any, Any], value)
    return {('on' if key is True else str(key)): item for key, item in mapping.items()}


def _as_strings(value: object) -> set[str]:
    """Coerce a parsed-YAML scalar-or-sequence to a set of strings."""
    if isinstance(value, str):
        return {value}
    if isinstance(value, list):
        return {str(item) for item in cast(list[Any], value)}
    return set()


def _is_object_sequence(value: object) -> TypeGuard[Sequence[object]]:
    """Narrow parsed YAML sequences without letting untyped items escape."""
    return isinstance(value, Sequence) and not isinstance(value, (str, bytes))


def parse_frontmatter(source: Path) -> dict[str, Any]:
    """Return the YAML frontmatter of a gh-aw workflow source, or `{}` if absent."""
    text = source.read_text(encoding='utf-8')
    match = re.match(r'^---\n(.*?)\n---\n', text, re.DOTALL)
    if match is None:
        return {}
    return _as_mapping(yaml.safe_load(match.group(1)))


def parse_prompt_body(source: Path) -> str:
    """Return the markdown body (the agent-facing prompt) of a gh-aw source."""
    text = source.read_text(encoding='utf-8')
    match = re.match(r'^---\n.*?\n---\n(.*)$', text, re.DOTALL)
    return match.group(1) if match else text


def _expressions_of(job: dict[str, Any]) -> list[tuple[str, str]]:
    """Return `(field, expression)` pairs whose `needs.*` refs must resolve.

    Every one of these silently evaluates to empty when it references a job that is not
    a dependency, rather than failing loudly. `if:` skips the job or step outright — and
    a job skipped by `if:` reports success. `outputs:`, `env:` and `with:` are worse in
    kind: nothing skips, the step just runs with an empty value, so a wrong action call
    or a wrong shell variable goes through looking healthy. gh-aw emits exactly that
    shape, e.g. `GH_AW_NEEDS_DETECT_OUTPUTS_TOUCHED: ${{ needs.detect.outputs.touched }}`.
    """
    expressions: list[tuple[str, str]] = []

    def add(field: str, value: Any) -> None:
        if isinstance(value, str):
            expressions.append((field, value))

    add('if', job.get('if'))
    for name, value in _as_mapping(job.get('outputs')).items():
        add(f'outputs.{name}', value)
    for name, value in _as_mapping(job.get('env')).items():
        add(f'env.{name}', value)
    for name, value in _as_mapping(job.get('with')).items():
        add(f'with.{name}', value)

    steps = job.get('steps')
    for index, raw_step in enumerate(cast(list[Any], steps) if isinstance(steps, list) else []):
        step = _as_mapping(raw_step)
        label = str(step.get('name') or step.get('uses') or f'#{index}')
        add(f'steps[{label}].if', step.get('if'))
        add(f'steps[{label}].run', step.get('run'))
        for name, value in _as_mapping(step.get('env')).items():
            add(f'steps[{label}].env.{name}', value)
        for name, value in _as_mapping(step.get('with')).items():
            add(f'steps[{label}].with.{name}', value)
    return expressions


def check_dangling_needs(lock: Path) -> list[Violation]:
    """Every `needs.<job>` reference must name a declared dependency of that job."""
    workflow = _as_mapping(yaml.safe_load(lock.read_text(encoding='utf-8')))

    violations: list[Violation] = []
    for job_name, raw_job in _as_mapping(workflow.get('jobs')).items():
        job = _as_mapping(raw_job)
        declared = _as_strings(job.get('needs'))
        for field, expression in _expressions_of(job):
            # `if:` is the one field GitHub evaluates as an expression without `${{ }}`.
            # Everywhere else a bare `needs.foo` is literal text — most often inside a
            # `run:` shell script — so only interpolated blocks count, or the check would
            # flag prose and jq programs that merely spell the word.
            if field == 'if' or field.endswith('.if'):
                scanned = expression
            else:
                scanned = ' '.join(EXPRESSION_BLOCK.findall(expression))
            for referenced in sorted(set(NEEDS_REFERENCE.findall(scanned))):
                if referenced not in declared:
                    violations.append(
                        Violation(
                            str(lock),
                            'dangling-needs',
                            f'job `{job_name}` references `needs.{referenced}` in `{field}:` but '
                            f'`{referenced}` is not in its `needs:` ({sorted(declared) or "none"}). '
                            'The expression evaluates to empty and the job silently skips — '
                            'and a job skipped by `if:` reports success.',
                        )
                    )
    return violations


def check_safe_output_job_max(source: Path) -> list[Violation]:
    """Custom `safe-outputs.jobs.*` entries must declare `max:` explicitly."""
    safe_outputs = _as_mapping(parse_frontmatter(source).get('safe-outputs'))
    return [
        Violation(
            str(source),
            'safe-output-job-max',
            f'safe-output job `{job_name}` does not declare `max:`. The default is 1, and extra '
            'items are dropped into an `errors` array that nothing reads — set it explicitly '
            'even when 1 is correct, so the bound is a decision rather than an accident.',
        )
        for job_name, job in _as_mapping(safe_outputs.get('jobs')).items()
        if 'max' not in _as_mapping(job)
    ]


def check_prompt_paths(source: Path) -> list[Violation]:
    """Prompts must not instruct the agent to read paths outside the workspace.

    Only prose is scanned. A path inside a fenced code block is being handed to a
    shell, and `Bash` can read anywhere — the F3 defect was prose telling the agent to
    `Read` a path its *file tools* reject. Flagging shell snippets too would condemn
    the documented `jq /tmp/gh-aw/agent/github-context/...` corpus reads, which work.
    """
    violations: list[Violation] = []
    fence: str | None = None
    for lineno, line in enumerate(parse_prompt_body(source).splitlines(), start=1):
        marker = FENCE_MARKER.match(line)
        if marker is not None:
            run, info = marker.group(1), marker.group(2)
            # CommonMark: a closer uses the same character, is at least as long as its
            # opener, and carries no info string. Getting any of those wrong leaves the
            # scanner out of step with the real block structure — and once it believes it
            # is inside a fence it skips every later line, turning a real violation into a
            # silent PASS. A ```bash line inside an open block is content, not a closer.
            if fence is None:
                fence = run
                continue
            if run[0] == fence[0] and len(run) >= len(fence) and not info.strip():
                fence = None
                continue
        if fence is not None:
            continue
        for match in SANDBOX_PATH.finditer(line):
            # Trailing sentence punctuation belongs to the prose, not the path. Stripped
            # after matching rather than excluded from the class, so that `:` and `.`
            # inside a path still keep the token whole.
            path = match.group(0).rstrip('.,;:!?')
            # Normalise for the comparison only, never for the message: the author needs
            # to see the path as they wrote it to find it again. `/tmp/gh-aw/bin/../` is
            # textually under an allowlisted directory but resolves outside it, which is
            # the very class of path this rejects. Compare with a trailing separator too,
            # so a directory entry matches the directory itself and everything under it
            # but not a sibling sharing its opening characters — bare `bin` would
            # otherwise allow `/tmp/gh-aw/bindings/`.
            if f'{posixpath.normpath(path)}/'.startswith(PROMPT_PATH_ALLOWLIST_PREFIXES):
                continue
            violations.append(
                Violation(
                    str(source),
                    'prompt-path-outside-workspace',
                    f"line {lineno}: prompt references `{path}`, which is outside the agent's file-tool "
                    'root — `Read` rejects it with "resolves outside the root directory" and the agent '
                    'burns turns rediscovering the file. Stage it under `$GITHUB_WORKSPACE` instead.',
                )
            )
    return violations


def check_timeout_declared(source: Path) -> list[Violation]:
    """Agentic workflows must bound their own wall clock."""
    if 'timeout-minutes' in parse_frontmatter(source):
        return []
    return [
        Violation(
            str(source),
            'timeout-declared',
            'no `timeout-minutes:` in frontmatter. Without an explicit bound an agent can spend a '
            'full run and be killed with nothing to show for it.',
        )
    ]


def check_job_timeout_env(source: Path) -> list[Violation]:
    """`PYDANTIC_AI_JOB_TIMEOUT_MINUTES`, when set, must equal a usable `timeout-minutes`.

    The shim derives the agent's own wall-clock budget from that env var, because
    gh-aw's `GH_AW_TIMEOUT_MINUTES` is set only on the failure-handler step and never
    reaches the agent container. If the two drift, the agent either stops early and
    wastes the time it was granted, or overruns and is killed with nothing emitted.
    """
    frontmatter = parse_frontmatter(source)
    timeout = frontmatter.get('timeout-minutes')
    if timeout is None:
        # `timeout-declared` already reports this, and every message below would quote
        # `None` as the value to copy into `env:`.
        return []
    if isinstance(timeout, int) and timeout <= JOB_TIMEOUT_HEADROOM_MINS:
        return [
            Violation(
                str(source),
                'job-timeout-too-short',
                f'`timeout-minutes: {timeout}` leaves the agent no budget. The shim reserves '
                f'{JOB_TIMEOUT_HEADROOM_MINS} minutes for container teardown and artifact upload, so it '
                f'falls back to {DEFAULT_JOB_TIMEOUT_MINS} minutes rather than granting a non-positive '
                'one — the agent then runs well past the point Actions kills the job, and emits nothing. '
                f'Give the job more than {JOB_TIMEOUT_HEADROOM_MINS} minutes.',
            )
        ]
    declared = _as_mapping(frontmatter.get('env')).get('PYDANTIC_AI_JOB_TIMEOUT_MINUTES')
    if declared is None:
        return [
            Violation(
                str(source),
                'job-timeout-env-missing',
                'no `PYDANTIC_AI_JOB_TIMEOUT_MINUTES` in `env:`. Without it the shim falls back to a '
                f'30-minute assumption, so a job with `timeout-minutes: {timeout}` either overruns and '
                'is killed with nothing emitted, or silently never uses the time it was granted. '
                f'Set it to `"{timeout}"`.',
            )
        ]
    if str(declared) == str(timeout):
        return []
    return [
        Violation(
            str(source),
            'job-timeout-env-mismatch',
            f'`PYDANTIC_AI_JOB_TIMEOUT_MINUTES` is `{declared}` but `timeout-minutes` is `{timeout}`. '
            "The shim derives the agent's budget from the env var, so a mismatch either wastes the "
            'granted time or gets the agent killed mid-run. Keep them equal.',
        )
    ]


def check_compiler_versions(locks: list[Path]) -> list[Violation]:
    """All locks must be compiled by the same gh-aw version."""
    versions: dict[str, list[str]] = {}
    for lock in locks:
        first_line = lock.read_text(encoding='utf-8').split('\n', 1)[0]
        _, _, payload = first_line.partition('gh-aw-metadata: ')
        if not payload:
            continue
        try:
            # `_as_mapping`, not `.get` directly: a payload that parses as valid JSON but
            # isn't an object (a bare string, `null`) would otherwise raise `AttributeError`
            # and take down the whole lint job instead of reporting a policy violation.
            version = str(_as_mapping(json.loads(payload)).get('compiler_version', 'unknown'))
        except json.JSONDecodeError:
            continue
        versions.setdefault(version, []).append(lock.name)

    if len(versions) <= 1:
        return []
    summary = '; '.join(f'{version}: {", ".join(sorted(names))}' for version, names in sorted(versions.items()))
    return [
        Violation(
            str(WORKFLOWS_DIR),
            'compiler-version-drift',
            f'locks were built by different gh-aw versions ({summary}). Run `gh aw compile` so every '
            'lock is regenerated together.',
        )
    ]


def check_compiled_runner_contract(lock: Path) -> list[Violation]:
    """The generated agent command must retain the interface our runner implements."""
    workflow = _as_mapping(yaml.safe_load(lock.read_text(encoding='utf-8')))
    agent = _as_mapping(_as_mapping(workflow.get('jobs')).get('agent'))
    steps = agent.get('steps')
    commands: list[list[str]] = []
    for raw_step in cast(list[Any], steps) if isinstance(steps, list) else []:
        run = _as_mapping(raw_step).get('run')
        if not isinstance(run, str) or 'pydantic-ai-runner-launch' not in run:
            continue
        with suppress(ValueError):
            outer_arguments = shlex.split(run)
            for index, argument in enumerate(outer_arguments[:-1]):
                if argument != '-c' or 'pydantic-ai-runner-launch' not in outer_arguments[index + 1]:
                    continue
                with suppress(ValueError):
                    inner_arguments = shlex.split(outer_arguments[index + 1])
                    for runner_index, inner_argument in enumerate(inner_arguments):
                        if inner_argument.endswith('/pydantic-ai-runner-launch'):
                            commands.append(inner_arguments[runner_index:])
    if len(commands) != 1:
        return [
            Violation(
                str(lock),
                'compiled-runner-contract',
                'the `agent` job must contain exactly one invocation of '
                '`pydantic-ai-runner-launch`. The custom runner is the compatibility '
                'boundary between gh-aw and Pydantic AI.',
            )
        ]

    command = commands[0]
    missing: list[str] = []
    if '--output-format' not in command or command.index('--output-format') == len(command) - 1:
        missing.append('`--output-format stream-json`')
    elif command[command.index('--output-format') + 1] != 'stream-json':
        missing.append('`--output-format stream-json`')
    if '--mcp-config' not in command or command.index('--mcp-config') == len(command) - 1:
        missing.append('`--mcp-config`')
    if '--allowed-tools' not in command or command.index('--allowed-tools') == len(command) - 1:
        missing.append('`mcp__safeoutputs` in `--allowed-tools`')
    elif 'mcp__safeoutputs' not in command[command.index('--allowed-tools') + 1].split(','):
        missing.append('`mcp__safeoutputs` in `--allowed-tools`')
    if not missing:
        return []
    return [
        Violation(
            str(lock),
            'compiled-runner-contract',
            f'the generated Pydantic AI runner invocation is missing {", ".join(missing)}. '
            'Recompiling changed the gh-aw interface that the custom runner implements.',
        )
    ]


def check_awf_binary_version(lock: Path) -> list[Violation]:
    """The hand-pinned AWF binary must be the one gh-aw compiled the lock against.

    `GH_AW_INFO_AWF_VERSION` is what gh-aw bundles and what it writes the firewall
    config against; the install step's argument is maintained by hand because
    `engine.command` makes gh-aw skip its own install. A gh-aw upgrade moves the
    first and leaves the second, and the older binary then refuses the newer config.

    A lock that pins a version but declares none also fails: the comparison has lost
    its reference, and passing there would disarm the check on a gh-aw rename.
    """
    workflow = _as_mapping(yaml.safe_load(lock.read_text(encoding='utf-8')))
    pinned: set[str] = set()
    bundled: set[str] = set()
    for raw_job in _as_mapping(workflow.get('jobs')).values():
        steps = _as_mapping(raw_job).get('steps')
        for raw_step in cast(list[Any], steps) if isinstance(steps, list) else []:
            step = _as_mapping(raw_step)
            run = step.get('run')
            # `finditer`, not `search`: one `run:` block can invoke the installer more than
            # once, and the last call is the binary the agent ends up with. Every invocation
            # has to match, so stopping at the first would let a stale later one through.
            if isinstance(run, str):
                pinned.update(match.group(1) for match in AWF_INSTALL_VERSION.finditer(run))
            version = _as_mapping(step.get('env')).get('GH_AW_INFO_AWF_VERSION')
            if isinstance(version, str):
                bundled.add(version)

    # No install step means this lock does not use the shim, so there is no hand-written
    # pin to drift.
    if not pinned:
        return []
    # A pin with nothing to compare it against is the check losing its reference, not a
    # pass. Returning empty here would let a gh-aw rename of `GH_AW_INFO_AWF_VERSION`
    # disarm this check silently, and the next skew would ship green exactly as #8041 did.
    if not bundled:
        return [
            Violation(
                str(lock),
                'awf-binary-version',
                f'the AWF install step pins {", ".join(sorted(pinned))} but the lock declares no '
                '`GH_AW_INFO_AWF_VERSION` to check it against. gh-aw stopped reporting the AWF '
                'version it bundles, so this check needs a new source before the pin can be trusted.',
            )
        ]
    unexpected = sorted(pinned - bundled)
    if not unexpected:
        return []
    return [
        Violation(
            str(lock),
            'awf-binary-version',
            f'the AWF install step pins {", ".join(unexpected)} but gh-aw compiled this lock against '
            f'{", ".join(sorted(bundled))}. Update the version in the `pre-steps` that re-run '
            '`install_awf_binary.sh` and recompile; an older binary rejects the newer firewall config.',
        )
    ]


def check_ai_credits_accounting(lock: Path) -> list[Violation]:
    """No lock may price a model into the API proxy's AI-credits table.

    `models.providers` in a source compiles to `apiProxy.providers`, which AWF reads as
    the pricing table for AI-credits accounting rather than as reporting metadata. A
    priced model gets charged, and AWF caps a run at 10,000 credits — a limit no
    frontmatter field lifts, since `max-ai-credits` only drops gh-aw's own budget. The
    weekly spend report reads token counts from each run's artifact, so nothing here
    needs the overlay.
    """
    # The AWF config is a single-line JSON string inside a `printf`, quoted bare in the
    # agent job and backslash-escaped where it is nested one level deeper. Match the two
    # keys on the same line so the informational `GH_AW_INFO_MODEL_COSTS` env var, which
    # carries the same overlay but configures nothing, is not mistaken for the config.
    if not any(
        'apiProxy' in line and ('"providers":' in line or '\\"providers\\":' in line)
        for line in lock.read_text(encoding='utf-8').splitlines()
    ):
        return []
    return [
        Violation(
            str(lock),
            'ai-credits-accounting',
            "the AWF config carries `apiProxy.providers`, which prices a model into the API proxy's "
            'AI-credits accounting. AWF then rejects the run at its 10,000-credit cap, which no '
            'frontmatter field can raise. Drop `models.providers` from the source and recompile.',
        )
    ]


def check_compiler_version_compatibility(locks: list[Path], compatibility: dict[str, Any]) -> list[Violation]:
    """Compiled gh-aw versions must not be revoked by the upstream runtime policy."""
    blocked_raw = compatibility.get('blockedVersions')
    blocked = _as_strings(blocked_raw)
    if not isinstance(blocked_raw, list):
        return [
            Violation(
                'gh-aw compatibility policy',
                'compiler-compatibility-policy-invalid',
                '`blockedVersions` is missing or is not a list; refusing to pass without '
                'the policy enforced by gh-aw activation jobs.',
            )
        ]
    violations: list[Violation] = []
    for lock in locks:
        first_line = lock.read_text(encoding='utf-8').split('\n', 1)[0]
        _, _, payload = first_line.partition('gh-aw-metadata: ')
        if not payload:
            continue
        try:
            version = _as_mapping(json.loads(payload)).get('compiler_version')
        except json.JSONDecodeError:
            continue
        if isinstance(version, str) and version in blocked:
            violations.append(
                Violation(
                    str(lock),
                    'compiler-version-blocked',
                    f'compiler version `{version}` is blocked by gh-aw and the activation job will fail. '
                    'Upgrade gh-aw and recompile every agentic workflow.',
                )
            )
    return violations


def check_lock_regenerated(changed: list[str], workflows_dir: Path = WORKFLOWS_DIR) -> list[Violation]:
    """A changed `.md` source (or shared import) must ship its recompiled lock.

    Actions runs the `.lock.yml`, never the `.md`, so a source edit without its
    recompiled lock is a silent no-op that leaves the two drifted apart.
    """
    changed_set = set(changed)
    violations: list[Violation] = []

    # Union of sources still on disk and sources named in the changeset: a deleted `.md`
    # is gone from the glob, so globbing alone would let its orphaned lock through and
    # Actions would keep running a workflow whose source no longer exists.
    changed_sources = {
        path for path in changed_set if Path(path).match(str(workflows_dir / AGENTIC_GLOB)) and '/shared/' not in path
    }
    sources = {str(path) for path in workflows_dir.glob(AGENTIC_GLOB)} | changed_sources

    for source_path in sorted(sources):
        source = Path(source_path)
        lock = source.with_suffix('.lock.yml')
        if source_path not in changed_set or str(lock) in changed_set:
            continue
        if source.exists():
            violations.append(
                Violation(
                    source_path,
                    'lock-not-regenerated',
                    f'source changed but `{lock.name}` did not. Run `gh aw compile` and commit the '
                    'regenerated lock in the same change.',
                )
            )
        else:
            violations.append(
                Violation(
                    source_path,
                    'lock-not-regenerated',
                    f'source was deleted but `{lock.name}` was left behind. Actions runs the lock, so '
                    'the workflow would keep running with no source. Delete the lock in the same change.',
                )
            )

    changed_shared = {path for path in changed_set if path.startswith(str(workflows_dir / 'shared'))}
    for shared in sorted(changed_shared):
        name = Path(shared).name
        for source in sorted(workflows_dir.glob(AGENTIC_GLOB)):
            lock = source.with_suffix('.lock.yml')
            imports = _as_strings(parse_frontmatter(source).get('imports'))
            if f'shared/{name}' in imports and str(lock) not in changed_set:
                violations.append(
                    Violation(
                        shared,
                        'lock-not-regenerated',
                        f'shared import changed but `{lock.name}`, which imports it, was not '
                        'regenerated. Run `gh aw compile` and commit every affected lock.',
                    )
                )
    return violations


def _is_zai_workflow(frontmatter: Mapping[str, object]) -> bool:
    imports = _as_strings(frontmatter.get('imports'))
    engine_env = _as_mapping(_as_mapping(frontmatter.get('engine')).get('env'))
    return 'shared/engine-zai.md' in imports or engine_env.get('ANTHROPIC_BASE_URL') == 'https://api.z.ai/api/anthropic'


def check_provider_engine_config(workflows_dir: Path = WORKFLOWS_DIR) -> list[Violation]:
    """Shared and workflow-local engines must use the shared provider configuration."""
    engine_path = workflows_dir / 'shared' / 'engine-zai.md'
    if not engine_path.is_file():
        return [Violation(str(engine_path), 'provider-engine-config', 'Shared Z.AI engine configuration is missing.')]

    engine_config = parse_frontmatter(engine_path)
    shared_engine = _as_mapping(engine_config.get('engine'))
    shared_env = _as_mapping(shared_engine.get('env'))
    endpoint = shared_env.get('ANTHROPIC_BASE_URL')
    credential = shared_env.get('ANTHROPIC_API_KEY')
    if not isinstance(endpoint, str) or not endpoint or not isinstance(credential, str) or not credential:
        return [
            Violation(
                str(engine_path),
                'provider-engine-config',
                'The shared agent engine must define a nonempty `ANTHROPIC_BASE_URL` and `ANTHROPIC_API_KEY`.',
            )
        ]

    shared_engines: tuple[tuple[str, object], ...] = (
        (
            'threat-detection',
            _as_mapping(_as_mapping(engine_config.get('safe-outputs')).get('threat-detection')).get('engine'),
        ),
    )
    violations: list[Violation] = []
    for engine_name, engine_value in shared_engines:
        engine_env = _as_mapping(_as_mapping(engine_value).get('env'))
        if engine_env.get('ANTHROPIC_BASE_URL') != endpoint or engine_env.get('ANTHROPIC_API_KEY') != credential:
            violations.append(
                Violation(
                    str(engine_path),
                    'provider-engine-config',
                    f'The shared {engine_name} engine must use the shared agent engine endpoint and credential.',
                )
            )

    source_paths = list(workflows_dir.glob(AGENTIC_GLOB))
    for source in (workflows_dir / 'shared' / 'provider-health.md', workflows_dir / 'agent-provider-health.yml'):
        if source.is_file():
            source_paths.append(source)
    for source in source_paths:
        frontmatter = parse_frontmatter(source) if source.suffix == '.md' else {}
        local_engines: tuple[object, ...] = (
            frontmatter.get('engine'),
            _as_mapping(_as_mapping(frontmatter.get('safe-outputs')).get('threat-detection')).get('engine'),
        )
        for local_engine in local_engines:
            local_env = _as_mapping(_as_mapping(local_engine).get('env'))
            if ('ANTHROPIC_BASE_URL' in local_env or 'ANTHROPIC_API_KEY' in local_env) and (
                local_env.get('ANTHROPIC_BASE_URL') != endpoint or local_env.get('ANTHROPIC_API_KEY') != credential
            ):
                violations.append(
                    Violation(
                        str(source),
                        'provider-engine-config',
                        'A workflow-local engine override must use the shared engine endpoint and credential.',
                    )
                )
    return violations


def check_provider_health_wiring(workflows_dir: Path = WORKFLOWS_DIR) -> list[Violation]:
    """Every Z.AI source must gate activation on its compiled provider-health job."""
    violations: list[Violation] = []
    for source in sorted(workflows_dir.glob(AGENTIC_GLOB)):
        frontmatter = parse_frontmatter(source)
        imports = _as_strings(frontmatter.get('imports'))
        if not _is_zai_workflow(frontmatter):
            continue
        if 'shared/provider-health.md' not in imports:
            violations.append(
                Violation(
                    str(source),
                    'provider-health-import',
                    'Z.AI workflow does not import `shared/provider-health.md`.',
                )
            )
        if 'needs.provider_health.outputs.ready' not in parse_prompt_body(source):
            violations.append(
                Violation(
                    str(source),
                    'provider-health-prompt',
                    'Workflow prompt body must reference `provider_health` so gh-aw hoists the gate before activation.',
                )
            )
        condition = str(frontmatter.get('if', ''))
        health_ready_condition = "needs.provider_health.outputs.ready == 'true'"
        if not _condition_is_required(condition, health_ready_condition):
            violations.append(
                Violation(
                    str(source),
                    'provider-health-gate',
                    'Z.AI workflow top-level `if:` must require `provider_health` readiness.',
                )
            )
        safe_outputs = _as_mapping(frontmatter.get('safe-outputs'))
        noop = _as_mapping(safe_outputs.get('noop'))
        if safe_outputs.get('report-failure-as-issue') is not False or noop.get('report-as-issue') is not False:
            violations.append(
                Violation(
                    str(source),
                    'provider-health-reporting',
                    'Z.AI workflows must disable gh-aw generic failure-as-issue reporting.',
                )
            )
        lock = source.with_suffix('.lock.yml')
        if not lock.is_file():
            violations.append(Violation(str(source), 'provider-health-lock', f'Compiled workflow `{lock}` is missing.'))
            continue
        workflow = _as_mapping(yaml.safe_load(lock.read_text(encoding='utf-8')))
        jobs = _as_mapping(workflow.get('jobs'))
        activation = _as_mapping(jobs.get('activation'))
        activation_needs = _as_strings(activation.get('needs'))
        activation_condition = str(activation.get('if', ''))
        if 'provider_health' not in activation_needs:
            violations.append(
                Violation(
                    str(lock),
                    'provider-health-activation-needs',
                    '`activation.needs` does not include `provider_health`; the health gate can resolve empty.',
                )
            )
        if not _condition_is_required(activation_condition, health_ready_condition):
            violations.append(
                Violation(
                    str(lock),
                    'provider-health-activation-if',
                    '`activation.if` does not require `provider_health` readiness before agent execution.',
                )
            )
        health_job = _as_mapping(jobs.get('provider_health'))
        if not health_job:
            violations.append(
                Violation(str(lock), 'provider-health-job', 'Compiled workflow has no `provider_health` job.')
            )
        elif 'activation' in _as_strings(health_job.get('needs')):
            violations.append(
                Violation(
                    str(lock),
                    'provider-health-job-order',
                    '`provider_health` depends on `activation` and therefore cannot gate inference.',
                )
            )
    return violations


def check_provider_health_identity(workflows_dir: Path = WORKFLOWS_DIR) -> list[Violation]:
    """The gate and shim must receive the same stable workflow task identity."""
    engine_path = workflows_dir / 'shared' / 'engine-zai.md'
    health_path = workflows_dir / 'shared' / 'provider-health.md'
    if not engine_path.is_file() or not health_path.is_file():
        return [
            Violation(
                str(engine_path), 'provider-health-identity', 'Shared workflow identity configuration is missing.'
            )
        ]
    engine = engine_path.read_text(encoding='utf-8')
    health = health_path.read_text(encoding='utf-8')
    assignment = re.compile(r'^\s*PYDANTIC_AI_TASK_KEY:\s*(.+?)\s*$', re.MULTILINE)
    engine_match = assignment.search(engine)
    health_match = assignment.search(health)
    attempt_assignment = re.compile(r'^\s*PYDANTIC_AI_RUN_ATTEMPT:\s*(.+?)\s*$', re.MULTILINE)
    engine_attempt_match = attempt_assignment.search(engine)
    health_attempt_match = attempt_assignment.search(health)
    workflow_assignment = 'GITHUB_WORKFLOW: ${{ github.workflow }}'
    event_assignment = 'PYDANTIC_AI_TRIGGER_EVENT: ${{ github.event_name }}'
    expected_attempt = '${{ github.run_attempt }}'
    if (
        engine_match is None
        or health_match is None
        or engine_match.group(1) != health_match.group(1)
        or engine_attempt_match is None
        or health_attempt_match is None
        or engine_attempt_match.group(1) != expected_attempt
        or health_attempt_match.group(1) != expected_attempt
        or workflow_assignment not in engine
        or event_assignment not in engine
    ):
        return [
            Violation(
                str(engine_path),
                'provider-health-identity',
                'The agent and provider-health job must forward identical workflow, event, and task identities plus the current run attempt.',
            )
        ]
    task_key = engine_match.group(1)
    manual_run_id = "(github.event_name == 'workflow_dispatch' && github.run_id)"
    if (
        manual_run_id not in task_key
        or 'github.run_id' in task_key.replace(manual_run_id, '')
        or 'github.run_attempt' in task_key
        or 'workflow_run.run_attempt' in task_key
    ):
        return [
            Violation(
                str(engine_path),
                'provider-health-task-stability',
                '`github.run_id` may distinguish manual dispatches but must not change the same workflow task across runs.',
            )
        ]
    expected_task_key = task_key
    for source in workflows_dir.glob(AGENTIC_GLOB):
        frontmatter = parse_frontmatter(source)
        imports = _as_strings(frontmatter.get('imports'))
        if not _is_zai_workflow(frontmatter) or 'shared/engine-zai.md' in imports:
            continue
        engine_env = _as_mapping(_as_mapping(frontmatter.get('engine')).get('env'))
        if (
            engine_env.get('GITHUB_WORKFLOW') != '${{ github.workflow }}'
            or engine_env.get('PYDANTIC_AI_TRIGGER_EVENT') != '${{ github.event_name }}'
            or engine_env.get('PYDANTIC_AI_RUN_ATTEMPT') != expected_attempt
            or engine_env.get('PYDANTIC_AI_TASK_KEY') != expected_task_key
        ):
            return [
                Violation(
                    str(source),
                    'provider-health-identity',
                    'A Z.AI workflow with a local engine config must forward the shared task identity exactly.',
                )
            ]
    return []


def check_provider_health_monitor(workflows_dir: Path = WORKFLOWS_DIR) -> list[Violation]:  # noqa: C901
    """The serialized monitor only accepts completions from the enumerated Z.AI workflows."""
    monitor_path = workflows_dir / 'agent-provider-health.yml'
    if not monitor_path.is_file():
        return [Violation(str(monitor_path), 'provider-health-monitor', 'Provider-health monitor is missing.')]
    monitor = _as_mapping(yaml.safe_load(monitor_path.read_text(encoding='utf-8')))
    triggers = _as_mapping(monitor.get('on'))
    workflow_run = _as_mapping(triggers.get('workflow_run'))
    monitor_names = _as_strings(workflow_run.get('workflows'))
    expected_names = {
        str(parse_frontmatter(source).get('name'))
        for source in workflows_dir.glob(AGENTIC_GLOB)
        if _is_zai_workflow(parse_frontmatter(source))
    }
    violations: list[Violation] = []
    if monitor_names != expected_names:
        missing = sorted(expected_names - monitor_names)
        unexpected = sorted(monitor_names - expected_names)
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-workflows',
                f'`workflow_run.workflows` must match all Z.AI workflows; missing={missing}, unexpected={unexpected}.',
            )
        )
    if 'workflow_dispatch' not in triggers or 'schedule' not in triggers:
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-triggers',
                'Monitor needs schedule and manual recovery triggers.',
            )
        )
    if str(monitor.get('name', '')) in monitor_names:
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-recursion',
                'Monitor must not trigger on its own completion.',
            )
        )
    jobs = _as_mapping(monitor.get('jobs'))
    monitor_job = _as_mapping(jobs.get('monitor'))
    if ' '.join(str(monitor_job.get('if', '')).split()) != (
        "github.repository == 'pydantic/pydantic-ai' && "
        "(github.event_name != 'workflow_run' || "
        "github.event.workflow_run.event != 'pull_request' || "
        'github.event.workflow_run.head_repository.full_name == github.repository)'
    ):
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-fork-gate',
                'Monitor must exclude fork `pull_request` completions while retaining trusted runs and recovery triggers.',
            )
        )
    concurrency = _as_mapping(monitor.get('concurrency'))
    if not concurrency.get('group') or concurrency.get('cancel-in-progress') is not False:
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-concurrency',
                'Monitor reconciliation must use one non-cancelling concurrency group.',
            )
        )
    if concurrency.get('queue') != 'max':
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-queue',
                'Monitor reconciliation must use FIFO `queue: max` and retain up to the platform limit of 100 pending runs.',
            )
        )
    steps_value: object = monitor_job.get('steps')
    steps: list[Mapping[str, object]] = []
    if _is_object_sequence(steps_value):
        for raw_step in steps_value:
            step = _as_mapping(raw_step)
            if step:
                steps.append(step)
    checkout_steps: list[Mapping[str, object]] = [
        step for step in steps if str(step.get('uses', '')).startswith('actions/checkout@')
    ]
    checkout: Mapping[str, object] = _as_mapping(checkout_steps[0].get('with')) if len(checkout_steps) == 1 else {}
    if (
        len(checkout_steps) != 1
        or checkout.get('repository') != '${{ github.repository }}'
        or checkout.get('ref') != '${{ github.event.repository.default_branch }}'
        or checkout.get('persist-credentials') is not False
        or checkout.get('sparse-checkout') != '.github/scripts/agent_provider_health.py'
    ):
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-trusted-checkout',
                'Monitor must check out only the controller script from the repository default branch, without persisted credentials.',
            )
        )
    artifact_steps: list[Mapping[str, object]] = [
        step for step in steps if str(step.get('uses', '')).startswith('actions/download-artifact@')
    ]
    if any(str(step.get('if', '')).strip() != "github.event_name == 'workflow_run'" for step in artifact_steps):
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-artifact-trigger',
                'Agent artifacts may only be downloaded for the allowlisted `workflow_run` event.',
            )
        )
    artifact_paths = re.compile(r'(?:^|[\s"\'=])(?:\./)?(?:agent|provider-health)/\S+')
    artifact_execution = False
    for step in steps:
        uses = str(step.get('uses', ''))
        run = str(step.get('run', '')).strip()
        if uses.startswith(('./agent/', './provider-health/')):
            artifact_execution = True
        if not artifact_paths.search(run):
            continue
        is_stub = run.splitlines() == ['mkdir -p agent', ': > agent/agent-stdio.log']
        is_controller = (
            run.startswith('python3 .github/scripts/agent_provider_health.py monitor')
            and '\n' not in run
            and not re.search(r';|&&|\|\|', run)
        )
        if not is_stub and not is_controller:
            artifact_execution = True
    if artifact_execution:
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-artifact-execution',
                'Downloaded agent artifacts must be parsed only as input to the trusted controller, never executed as code.',
            )
        )
    provider_keys: tuple[str, ...] = ('ZAI_API_KEY',)
    workflow_env: Mapping[str, object] = _as_mapping(monitor.get('env'))
    job_env: Mapping[str, object] = _as_mapping(monitor_job.get('env'))
    if job_env.get('PYDANTIC_AI_RUN_ATTEMPT') != '${{ github.run_attempt }}':
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-run-attempt',
                'Monitor job must pass its own positive run attempt to scheduled and manual reconciliation.',
            )
        )
    source_reconcile_steps = [
        step
        for step in steps
        if "github.event_name == 'workflow_run'" in str(step.get('if', ''))
        and str(step.get('run', '')).strip().startswith('python3 .github/scripts/agent_provider_health.py monitor')
    ]
    if (
        len(source_reconcile_steps) != 1
        or _as_mapping(source_reconcile_steps[0].get('env')).get('RUN_ATTEMPT')
        != '${{ github.event.workflow_run.run_attempt }}'
        or '--run-attempt "$RUN_ATTEMPT"' not in str(source_reconcile_steps[0].get('run', ''))
    ):
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-source-run-attempt',
                'Completed workflow reconciliation must pass the source workflow run attempt from the workflow_run event.',
            )
        )
    provider_key_events: dict[str, set[str]] = {key: set() for key in provider_keys}
    if any(key in workflow_env or key in job_env for key in provider_keys):
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-provider-event-scope',
                'Z.AI credentials must not be inherited by `workflow_run` steps.',
            )
        )
    for step in steps:
        step_env = _as_mapping(step.get('env'))
        event_condition = str(step.get('if', ''))
        for key in provider_keys:
            if key not in step_env:
                continue
            if event_condition.strip() == "github.event_name == 'schedule'":
                provider_key_events[key].add('schedule')
            elif event_condition.strip() == "github.event_name == 'workflow_dispatch'":
                provider_key_events[key].add('workflow_dispatch')
            else:
                provider_key_events[key].add('other')
    expected_recovery_events: set[str] = {'schedule', 'workflow_dispatch'}
    if any(provider_key_events[key] != expected_recovery_events for key in provider_keys):
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-provider-event-scope',
                'Z.AI credentials must be scoped exactly to scheduled or explicitly requested recovery, never `workflow_run`.',
            )
        )
    permissions = _as_mapping(monitor_job.get('permissions'))
    if permissions != {'actions': 'read', 'contents': 'read', 'issues': 'write'}:
        violations.append(
            Violation(
                str(monitor_path),
                'provider-health-monitor-permissions',
                'Monitor job permissions must be exactly `actions: read`, `contents: read`, and `issues: write`.',
            )
        )
    return violations


def check_assigned_alert_metadata_gate(workflows_dir: Path = WORKFLOWS_DIR) -> list[Violation]:
    """Operational metadata issues must not start the @claude issue-assignment agent."""
    source = workflows_dir / 'at-claude.yml'
    if not source.is_file():
        return [Violation(str(source), 'assigned-alert-metadata-gate', '@claude workflow is missing.')]
    workflow = _as_mapping(yaml.safe_load(source.read_text(encoding='utf-8')))
    jobs = _as_mapping(workflow.get('jobs'))
    job_condition = str(_as_mapping(jobs.get('get-pr-info')).get('if', ''))
    branches = _boolean_branches(job_condition)
    metadata_gate = _normalized_condition("!contains(github.event.issue.labels.*.name, 'pydanty:meta')")
    event_pattern = re.compile(r"github\.event_name\s*==\s*'([^']+)'")
    routes_are_gated = bool(branches)
    for event in ('issue_comment', 'issues'):
        relevant_branches: list[list[str]] = []
        for branch in branches:
            branch_events = {found for term in branch for found in event_pattern.findall(term)}
            if event in branch_events or not branch_events:
                relevant_branches.append(branch)
        if not relevant_branches or any(
            metadata_gate not in {_normalized_condition(term) for term in branch} for branch in relevant_branches
        ):
            routes_are_gated = False
            break
    if not routes_are_gated:
        return [
            Violation(
                str(source),
                'assigned-alert-metadata-gate',
                '`issues` and `issue_comment` route predicates must exclude `pydanty:meta` operational alerts.',
            )
        ]
    return []


def changed_files(base_ref: str) -> list[str]:
    """Return paths changed relative to `base_ref` (empty if git can't resolve it)."""
    try:
        completed = subprocess.run(
            ['git', 'diff', '--name-only', f'{base_ref}...HEAD'],
            capture_output=True,
            text=True,
            check=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return []
    return [line for line in completed.stdout.splitlines() if line]


def run_checks(
    workflows_dir: Path = WORKFLOWS_DIR,
    changed: list[str] | None = None,
    compatibility: dict[str, Any] | None = None,
) -> list[Violation]:
    """Run every static check; `changed` enables the lock-freshness check."""
    sources = sorted(workflows_dir.glob(AGENTIC_GLOB))
    locks = sorted(workflows_dir.glob('*.lock.yml'))
    # Resolve `shared/` under the caller's `workflows_dir`, not the module global, so a
    # custom root scans its own fragments rather than whatever sits under the cwd.
    # `rglob`, not `glob`: the F3 defect this scan exists to catch lived in
    # `shared/prompts/pydantic-ai-pr-review.md`. Those prompts are fetched at run time
    # rather than compiled in, so they change with no lock diff and are the least
    # reviewed files here — the last ones a path check should skip.
    shared_dir = workflows_dir / 'shared'
    shared = sorted(shared_dir.rglob('*.md')) if shared_dir.is_dir() else []

    violations: list[Violation] = []
    for lock in locks:
        violations += check_dangling_needs(lock)
        violations += check_compiled_runner_contract(lock)
        violations += check_awf_binary_version(lock)
        violations += check_ai_credits_accounting(lock)
    for source in sources:
        violations += check_safe_output_job_max(source)
        violations += check_timeout_declared(source)
        violations += check_job_timeout_env(source)
    for markdown in [*sources, *shared]:
        violations += check_prompt_paths(markdown)
    violations += check_compiler_versions(locks)
    violations += check_provider_engine_config(workflows_dir)
    violations += check_provider_health_wiring(workflows_dir)
    violations += check_provider_health_identity(workflows_dir)
    violations += check_provider_health_monitor(workflows_dir)
    violations += check_assigned_alert_metadata_gate(workflows_dir)
    if compatibility is not None:
        violations += check_compiler_version_compatibility(locks, compatibility)
    if changed:
        violations += check_lock_regenerated(changed, workflows_dir)
    return violations


def main(argv: list[str] | None = None) -> int:
    """Print every violation to stderr and return the process exit code."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['check'])
    parser.add_argument('--base-ref', default='', help='git ref to diff against for lock-freshness')
    parser.add_argument(
        '--changed-file-list',
        default='',
        help=(
            'file holding one changed path per line, for lock-freshness. Prefer this in CI, where the '
            'checkout is shallow and a `git diff` range cannot resolve: feed it `gh pr view --json files`.'
        ),
    )
    parser.add_argument(
        '--compatibility-file',
        type=Path,
        help='gh-aw compatibility policy downloaded from `.github/aw/compat.json` in github/gh-aw',
    )
    args = parser.parse_args(argv)

    if args.changed_file_list:
        # `splitlines`, not `split`: the producer writes one path per line, and a path
        # containing a space would otherwise become two paths that match nothing — the
        # real file's lock freshness then goes unchecked while the run still passes.
        text = Path(args.changed_file_list).read_text(encoding='utf-8')
        changed = [line for line in text.splitlines() if line.strip()]
    elif args.base_ref:
        changed = changed_files(args.base_ref)
    else:
        changed = None

    if args.compatibility_file is None:
        violations = run_checks(changed=changed)
    else:
        try:
            compatibility = _as_mapping(json.loads(args.compatibility_file.read_text(encoding='utf-8')))
        except (OSError, json.JSONDecodeError) as error:
            print(f'{args.compatibility_file}: [compiler-compatibility-policy-invalid] {error}', file=sys.stderr)
            return 1
        violations = run_checks(changed=changed, compatibility=compatibility)
    for violation in violations:
        print(violation, file=sys.stderr)
    if violations:
        print(f'\n{len(violations)} agentic-workflow policy violation(s).', file=sys.stderr)
        return 1
    print('Agentic workflow policy checks passed.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
