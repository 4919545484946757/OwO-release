//! Gemini stream faults through the runner: the recorded 404 on stream
//! setup, and scripted faults — a blocked prompt, a stream cut before its
//! terminal, an in-band error after content — served to the real
//! `streamGenerateContent` adapter. Every cell's hypothesis is that the fault
//! surfaces as its own kind, with nothing recorded, committed or executed
//! after it.

use bytes::Bytes;
use rig::error::ErrorKind;
use rig::providers::gemini::{GeminiConfig, completion::GEMINI_2_5_FLASH};
use rig::test_utils::SequencedStreamingHttpClient;
use rig_cassette::agent::AgentReplayExt;

use super::super::support::with_gemini_cassette;
use crate::stream_faults::{drain, recorded_stream_errors, scripted, sole_failed_completion};

/// A real `streamGenerateContent` content frame without a finish reason,
/// as `gemini-3.8-flash` streamed it on 2026-09-08 (captured in the
/// downstream rigcoder Gemini matrix; ids scrubbed by this engine). The
/// recordings in this tree stream whole answers in one terminal frame, so a
/// prefix-then-fault stream is assembled from this frame. Synthetic order,
/// real frames.
pub(super) const CONTENT_FRAME: &str = r#"{"candidates":[{"content":{"parts":[{"text":"pong"}],"role":"model"},"index":0}],"modelVersion":"gemini-3.8-flash","responseId":"id_REDACTED_1","usageMetadata":{"candidatesTokenCount":1,"promptTokenCount":795,"promptTokensDetails":[{"modality":"TEXT","tokenCount":795}],"serviceTier":"standard","thoughtsTokenCount":60,"totalTokenCount":856}}"#;
/// The text [`CONTENT_FRAME`] carries.
pub(super) const CONTENT_TEXT: &str = "pong";
/// The whole body Gemini answered a refused prompt with (`crate::stream_faults::GEMINI_BLOCKED_FRAME`).
pub(super) const BLOCKED_FRAME: &str = crate::stream_faults::GEMINI_BLOCKED_FRAME;
/// An error envelope in band under HTTP 200 (`crate::stream_faults::GEMINI_IN_BAND_ERROR`).
pub(super) const IN_BAND_ERROR_FRAME: &str = crate::stream_faults::GEMINI_IN_BAND_ERROR;
/// A key the scripted cells send: it must never reach a trace.
pub(super) const SCRIPTED_KEY: &str = "scripted-fault-key-7f3a9c";

/// Gemini's SSE framing of `frames`.
pub(super) fn gemini_sse(frames: &[&str]) -> Bytes {
    Bytes::from(
        frames
            .iter()
            .map(|frame| format!("data: {frame}\n\n"))
            .collect::<String>(),
    )
}

/// A client over a transport that answers one streaming request with
/// `chunks`, then EOF.
pub(super) fn scripted_client(chunks: Vec<Bytes>) -> (GeminiConfig, SequencedStreamingHttpClient) {
    (GeminiConfig::new(SCRIPTED_KEY), scripted(chunks))
}

/// A refused prompt is the provider's verdict, not a transport truncation:
/// the run fails as a non-retryable provider error naming the block reason,
/// and the record holds that error rather than "ended before its terminal".
#[tokio::test]
async fn blocked_prompt_is_a_provider_refusal_not_a_truncation() {
    let (client, http) = scripted_client(vec![gemini_sse(&[BLOCKED_FRAME])]);
    let recorder = rig_cassette::effect_log::EffectLogRecorder::keeping_stream_events();
    let agent = rig::AgentBuilder::new(client.connect(http.clone()).completion(GEMINI_2_5_FLASH))
        .record_to(recorder.clone())
        .build();
    let mut stream = agent.prompt("pong?").stream();
    let drained = drain(&mut stream).await;
    drop(stream);

    assert_eq!(drained.finals, 0, "{drained:?}");
    assert!(drained.text.is_empty(), "{drained:?}");
    assert_eq!(drained.errors.len(), 1, "{drained:?}");
    let report = &drained.errors[0];
    assert_eq!(report.kind, ErrorKind::ProviderResponse, "{report:?}");
    assert!(
        report.refusal,
        "the block is a refusal on the report: {report:?}"
    );
    assert_eq!(report.code.as_deref(), Some("SAFETY"), "{report:?}");
    assert!(!report.is_retryable(), "{report:?}");
    assert!(
        report.message.contains("block_reason=SAFETY"),
        "the block reason is named: {report:?}"
    );

    let log = agent.stamp(recorder.take());
    let recorded = sole_failed_completion(&log);
    assert_eq!(recorded.kind, ErrorKind::ProviderResponse, "{recorded:?}");
    assert!(recorded.refusal, "{recorded:?}");
    assert!(
        recorded.message.contains("block_reason=SAFETY"),
        "the record holds the refusal, not a truncation: {recorded:?}"
    );
}

/// The stream closes after content without a terminal record: the run
/// fails as a truncation, the text prefix was delivered, no final response
/// is assembled, and the record holds the truncation.
#[tokio::test]
async fn truncation_after_content_fails_the_run_and_keeps_the_prefix() {
    let (client, http) = scripted_client(vec![gemini_sse(&[CONTENT_FRAME])]);
    let recorder = rig_cassette::effect_log::EffectLogRecorder::keeping_stream_events();
    let agent = rig::AgentBuilder::new(client.connect(http.clone()).completion(GEMINI_2_5_FLASH))
        .record_to(recorder.clone())
        .build();
    let mut stream = agent.prompt("pong?").stream();
    let drained = drain(&mut stream).await;
    drop(stream);

    assert_eq!(drained.text, CONTENT_TEXT, "{drained:?}");
    assert_eq!(drained.finals, 0, "{drained:?}");
    assert_eq!(drained.terminals, 0, "{drained:?}");
    assert!(!drained.errors.is_empty(), "{drained:?}");
    for report in &drained.errors {
        assert_eq!(report.kind, ErrorKind::Response, "{report:?}");
        assert!(
            report
                .message
                .contains("ended before the provider ended it"),
            "a truncation, by name: {report:?}"
        );
    }

    let log = agent.stamp(recorder.take());
    let recorded = sole_failed_completion(&log);
    assert_eq!(recorded.kind, ErrorKind::Response, "{recorded:?}");
    assert_eq!(recorded.message, rig::serve::stream_truncated().message);
}

/// An error envelope after content: the run fails with the envelope's
/// classification (a 503, retryable, body preserved), the prefix was
/// delivered, and the error item sits after the content items.
#[tokio::test]
async fn in_band_error_after_content_fails_with_the_envelope() {
    let (client, http) = scripted_client(vec![gemini_sse(&[CONTENT_FRAME, IN_BAND_ERROR_FRAME])]);
    let recorder = rig_cassette::effect_log::EffectLogRecorder::keeping_stream_events();
    let agent = rig::AgentBuilder::new(client.connect(http.clone()).completion(GEMINI_2_5_FLASH))
        .record_to(recorder.clone())
        .build();
    let mut stream = agent.prompt("pong?").stream();
    let drained = drain(&mut stream).await;
    drop(stream);

    assert_eq!(drained.text, CONTENT_TEXT, "{drained:?}");
    assert_eq!(drained.finals, 0, "{drained:?}");
    assert_eq!(drained.terminals, 0, "{drained:?}");
    assert_eq!(drained.errors.len(), 1, "{drained:?}");
    let report = &drained.errors[0];
    assert_eq!(report.kind, ErrorKind::ProviderResponse, "{report:?}");
    assert_eq!(report.http_status, Some(503), "{report:?}");
    assert!(report.is_retryable(), "{report:?}");
    assert_eq!(
        report
            .provider_response_body()
            .map(|body| serde_json::from_str::<serde_json::Value>(body).expect("JSON")),
        Some(serde_json::from_str(IN_BAND_ERROR_FRAME).expect("JSON")),
        "the envelope is preserved: {report:?}"
    );

    let log = agent.stamp(recorder.take());
    let recorded = sole_failed_completion(&log);
    assert_eq!(recorded.kind, ErrorKind::ProviderResponse, "{recorded:?}");
    assert_eq!(recorded.http_status, Some(503), "{recorded:?}");
    let errors = recorded_stream_errors(&log);
    assert_eq!(errors.len(), 1, "{errors:?}");
    let delivered = log.records[0]
        .events
        .as_ref()
        .map_or(0, |events| events.len());
    assert!(delivered > 0, "content items precede the error");
    assert_eq!(
        errors[0].0, delivered,
        "the error item sits after the delivered content"
    );
}

/// The recording the two cells below derive from, once it exists: one
/// streamed prompt long enough for `gemini-3-flash-preview` to answer in
/// several `streamGenerateContent` frames, so a prefix can be cut from a
/// real Gemini stream instead of assembled from a downstream capture. The
/// prompt is the runner's own; the assertion is the ordinary smoke.
#[ignore = "needs a live recording: no committed Gemini REST stream carries more than one frame; record `stream_faults/multi_frame_stream` with GEMINI_API_KEY (one streamed prompt, gemini-3-flash-preview, a few hundred output tokens)"]
#[tokio::test]
async fn multi_frame_stream_recording() {
    with_gemini_cassette("stream_faults/multi_frame_stream", |client| async move {
        let agent = rig::AgentBuilder::new(
            client.completion(rig::providers::gemini::completion::GEMINI_3_FLASH_PREVIEW),
        )
        .preamble(crate::support::STREAMING_PREAMBLE)
        .build();
        let mut stream = agent
            .prompt(
                "Write four short paragraphs about the history of the Rust programming language.",
            )
            .stream();
        let drained = drain(&mut stream).await;
        assert_eq!(drained.finals, 1, "{drained:?}");
        assert!(!drained.text.is_empty(), "{drained:?}");
    })
    .await;
}

/// EOF before the terminal frame of a real multi-frame Gemini stream: the
/// same hypothesis as `truncation_after_content_fails_the_run_and_keeps_the_prefix`,
/// on frames Gemini itself streamed in sequence.
#[ignore = "derives from `stream_faults/multi_frame_stream`; see multi_frame_stream_recording"]
#[tokio::test]
async fn multi_frame_stream_cut_before_its_terminal_is_a_truncation() {
    let frames =
        crate::stream_faults::recorded_sse_frames("gemini", "stream_faults/multi_frame_stream", 0);
    let prefix =
        crate::stream_faults::frames_before(&frames, |frame| frame.contains("finishReason"));
    let expected: String = prefix
        .iter()
        .filter_map(|frame| {
            crate::stream_faults::frame_data(frame)["candidates"][0]["content"]["parts"][0]["text"]
                .as_str()
                .map(str::to_owned)
        })
        .collect();
    let (client, http) = scripted_client(vec![crate::stream_faults::sse_bytes(&prefix)]);
    let recorder = rig_cassette::effect_log::EffectLogRecorder::keeping_stream_events();
    let agent = rig::AgentBuilder::new(client.connect(http.clone()).completion(GEMINI_2_5_FLASH))
        .record_to(recorder.clone())
        .build();
    let mut stream = agent.prompt("pong?").stream();
    let drained = drain(&mut stream).await;
    drop(stream);

    assert_eq!(drained.text, expected, "{drained:?}");
    assert_eq!(drained.finals, 0, "{drained:?}");
    let log = agent.stamp(recorder.take());
    assert_eq!(
        sole_failed_completion(&log).message,
        rig::serve::stream_truncated().message
    );
}
