//! Matrix for raw provider response capture on the streaming path:
//! `CompletionResponse::raw` beside the normalized terminal fields.
//!
//! # The feature
//!
//! Capture is always on. The wire's reassembler rebuilds the `Message` a
//! unary reply would have been from the stream's frames, and the driver
//! records it as the terminal `CompletionResponse::raw`. So `raw` is the
//! **unary document**, not the frames: `message_start.message` with each
//! content block placed at its index, the deltas applied, and the closing
//! `message_delta` (`stop_reason`, `stop_sequence`, usage) folded over it.
//! The transport `request-id` header is stamped on the normalized terminal,
//! never on `raw`. `raw` is `Value::Null` only on a `CompletionResponse`
//! built by hand; `Value::Null` never means "not requested". Cells 1–3 pin
//! the document's shape, a terminal-only field, and normalized/raw agreement
//! on text streams; cells 4 and 5 repeat the round trip on an
//! extended-thinking stream and a forced tool-call stream, whose blocks the
//! document carries as their unary twins in `raw_capture_matrix.rs` do.
//!
//! # Matrix
//!
//! | # | Cell | Dimension | expected | Status |
//! |---|------|-----------|----------|--------|
//! | 1 | `terminal_raw_round_trips_into_provider_type` | plain text request | terminal `raw` populated; exactly the unary `Message` keys, the streamed text as its one `text` block, no frame keys | recorded |
//! | 2 | `raw_exposes_stop_sequence` | streamed twin of the `stop_sequences: ["alpha"]` request | `raw["stop_sequence"] == "alpha"`, `raw["stop_reason"] == "stop_sequence"` (verbatim spelling) | recorded |
//! | 3 | `normalized_terminal_matches_raw_renormalized` | plain text request | reading `raw` back into `StreamingCompletionResponse` reproduces `identity()`, `finish_reason`, `model`, `usage` | recorded |
//! | 4 | `terminal_raw_round_trips_for_thinking_stream` | streamed twin of the `thinking.enabled` request | terminal `raw` round-trips; `raw["content"][0]` is the `thinking` block with the streamed text and signature; `raw["usage"]["output_tokens_details"]["thinking_tokens"]` is the terminal `message_delta`'s, verbatim; normalized terminal folds it into `reasoning_tokens` and never spells `thinking`; the stream yielded the `thinking` block as `Reasoning` | recorded |
//! | 5 | `terminal_raw_round_trips_for_tool_use_stream` | streamed twin of the forced tool call | terminal `raw` round-trips; `raw["content"][0]` is the `tool_use` block with the assembled `input` object; `raw["stop_reason"] == "tool_use"` verbatim; normalized terminal `finish_reason == ToolCalls`; the stream yielded the `tool_use` block as a `ToolCall` whose provider id is the frame's | recorded |
//!
//! Every recorded cell re-derives its premise from its own SSE frames: the
//! stream opens with a `message_start` naming a `msg_…` id, closes with a
//! `message_delta` carrying `usage`, and the response carries a `request-id`
//! header. Cell 3 is not cell 1 restated: cell 1 proves `raw` is lossless
//! against the *provider* terminal type; cell 3 proves rig's own mapping of
//! that value agrees with the normalized terminal delivered beside it — the
//! single-stream form of the parity contract `raw_completion_parity_matrix.rs`
//! records across two exchanges. Cells 4 and 5 take the terminal round trip
//! off the text-only path, with the request shapes their blocking twins in
//! `raw_capture_matrix.rs` use (the `thinking.enabled` request from
//! `reasoning_usage_matrix.rs`; the `weather_tool` + `tool_choice` pattern
//! from `empty_stop_sequence_matrix.rs`). Each cell premise-asserts its
//! frames carry the block (`content_block_start` of `type: "thinking"` with
//! a `signature_delta`; `content_block_start` of `type: "tool_use"`), and
//! pins that `raw` carries the block rebuilt from them beside the usage
//! bucket and the verbatim `stop_reason`.

use rig::completion::CompletionResponse;
use rig::message::AssistantContent;
use rig_test_support::cassette_models::AnthropicModels;

use futures::StreamExt;
use rig::completion::{FinishReason, ToolDefinition};
use rig::message::ToolChoice;
use rig::providers::anthropic;
use rig::streaming::StreamEvent;
use serde_json::{Value, json};

use super::super::support::{
    assert_ids_match_recording, recorded_request_id_headers, with_anthropic_cassette,
};

use super::super::support::canonical_without_raw;
use crate::raw_capture::capture_terminal;
use crate::support::Observed;
use rig::completion::CompletionRequest;

const ANTHROPIC_PROVIDER: &str = "anthropic";
const PROMPT: &str = "Reply with exactly: raw stream capture probe";
/// From `empty_stop_sequence_matrix.rs`: one word, so the `alpha` sequence
/// matches and Anthropic names it on the terminal `message_delta`.
const IMMEDIATE_PROMPT: &str = "Reply with exactly this one word and nothing else: alpha";
/// From `reasoning_usage_matrix.rs`: costs a few thinking tokens without a
/// long answer.
const THINKING_PROMPT: &str = "What is 17 * 23? Reply with just the number.";
/// A question the forced tool answers, so the `tool_use` block's `input`
/// carries a real `city`.
const TOOL_PROMPT: &str = "What is the weather in Paris right now?";

const ROUND_TRIP_SCENARIO: &str =
    "raw_stream_capture_matrix/terminal_raw_round_trips_into_provider_type";
const STOP_SEQUENCE_SCENARIO: &str = "raw_stream_capture_matrix/raw_exposes_stop_sequence";
const RENORMALIZED_SCENARIO: &str =
    "raw_stream_capture_matrix/normalized_terminal_matches_raw_renormalized";
const THINKING_SCENARIO: &str =
    "raw_stream_capture_matrix/terminal_raw_round_trips_for_thinking_stream";
const TOOL_USE_SCENARIO: &str =
    "raw_stream_capture_matrix/terminal_raw_round_trips_for_tool_use_stream";

fn probe_request() -> rig::completion::CompletionRequest {
    CompletionRequest::new(PROMPT).max_tokens(32)
}

/// From `reasoning_usage_matrix.rs`: extended thinking on, minimum budget,
/// `max_tokens` above it as Anthropic requires.
fn thinking_request() -> rig::completion::CompletionRequest {
    CompletionRequest::new(THINKING_PROMPT)
        .max_tokens(2048)
        .additional_params(json!({ "thinking": { "type": "enabled", "budget_tokens": 1024 } }))
}

/// From `empty_stop_sequence_matrix.rs`.
fn weather_tool() -> ToolDefinition {
    ToolDefinition {
        name: rig_core::message::ToolName::new("get_weather").expect("tool name"),
        description: "Get the current weather for a city.".to_string(),
        parameters: json!({
            "type": "object",
            "properties": { "city": { "type": "string" } },
            "required": ["city"]
        }),
    }
}

/// `tool_choice: required` (Anthropic `any`) so the turn is a `tool_use`
/// terminal by construction, not by the model's mood.
fn tool_request() -> rig::completion::CompletionRequest {
    CompletionRequest::new(TOOL_PROMPT)
        .max_tokens(256)
        .tool(weather_tool())
        .tool_choice(ToolChoice::Required)
}

/// What a cell observed on the stream: every non-terminal item, and the
/// terminal record.
struct Streamed {
    items: Vec<rig::streaming::Item<StreamEvent>>,
    terminal: CompletionResponse,
}

async fn drain_stream(mut stream: rig::streaming::CompletionStream) -> Streamed {
    let mut items = Vec::new();
    while let Some(item) = stream.next().await {
        items.push(item.expect("stream item should succeed"));
    }
    Streamed {
        items,
        terminal: stream.finish().await.expect("the stream ends"),
    }
}

/// The body of cells 4 and 5: open the stream the cell's request describes on
/// the model the cell names, keeping the streamed items as well as the
/// terminal.
///
/// Cells 1–3 want only the terminal and use the shared
/// [`capture_terminal`]; these two assert on the non-terminal items too, so
/// the drain stays local.
async fn streamed_body(
    client: AnthropicModels,
    model_name: &str,
    request: rig::completion::CompletionRequest,
    sink: Observed<Streamed>,
) {
    let model = client.completion(model_name);
    let stream = model.stream(request).expect("stream should open");
    sink.put(drain_stream(stream).await);
}

/// Cells 4 and 5 share this: terminal `raw` is populated, and is
/// Anthropic's `Message`, with its usage and stop reason.
fn assert_raw_round_trips(raw: &Value) -> &Value {
    assert!(
        !raw.is_null(),
        "every terminal `stream()` yields carries `raw`"
    );
    assert!(
        raw["type"] == "message" && raw["usage"].is_object() && raw["stop_reason"].is_string(),
        "{raw}"
    );
    raw
}

/// Every string a JSON value contains — object keys and string leaves — so a
/// cell can prove a wire spelling (`"thinking"`, `"tool_use"`) is absent from
/// the normalized terminal *anywhere*, not just at one path.
fn collect_strings<'a>(value: &'a Value, out: &mut Vec<&'a str>) {
    match value {
        Value::String(text) => out.push(text.as_str()),
        Value::Array(items) => items.iter().for_each(|item| collect_strings(item, out)),
        Value::Object(fields) => {
            for (key, field) in fields {
                out.push(key.as_str());
                collect_strings(field, out);
            }
        }
        Value::Null | Value::Bool(_) | Value::Number(_) => {}
    }
}

fn contains_string(value: &Value, needle: &str) -> bool {
    let mut strings = Vec::new();
    collect_strings(value, &mut strings);
    strings.contains(&needle)
}

/// The premise every cell rests on, read from its own frames: `message_start`
/// names the id and model, the terminal `message_delta` names the stop reason
/// and carries the final usage, and the response carried a `request-id`.
struct RecordedStream {
    response_id: Option<String>,
    model: Option<String>,
    stop_reason: Option<String>,
    stop_sequence: Option<String>,
    output_tokens: u64,
    input_tokens: u64,
    request_id: Option<String>,
    frame_types: Vec<String>,
}

fn recorded_frames(scenario: &str) -> Vec<Value> {
    crate::cassettes::recorded_sse_json_frames(ANTHROPIC_PROVIDER, scenario)
}

fn recorded_stream(scenario: &str) -> RecordedStream {
    let frames = recorded_frames(scenario);
    let start = frames
        .iter()
        .find(|frame| frame["type"] == "message_start")
        .unwrap_or_else(|| panic!("{scenario}: premise — the stream opens with message_start"));
    let delta = frames
        .iter()
        .find(|frame| frame["type"] == "message_delta")
        .unwrap_or_else(|| panic!("{scenario}: premise — the stream closes with message_delta"));
    let request_ids = recorded_request_id_headers(scenario);
    assert_eq!(request_ids.len(), 1, "{scenario}: one recorded interaction");
    RecordedStream {
        response_id: start["message"]["id"].as_str().map(str::to_string),
        model: start["message"]["model"].as_str().map(str::to_string),
        stop_reason: delta["delta"]["stop_reason"].as_str().map(str::to_string),
        stop_sequence: delta["delta"]["stop_sequence"].as_str().map(str::to_string),
        output_tokens: delta["usage"]["output_tokens"]
            .as_u64()
            .unwrap_or_else(|| panic!("{scenario}: premise — terminal frame carries usage")),
        input_tokens: delta["usage"]["input_tokens"]
            .as_u64()
            .unwrap_or_else(|| panic!("{scenario}: premise — terminal frame carries usage")),
        request_id: request_ids[0].clone(),
        frame_types: frames
            .iter()
            .filter_map(|frame| frame["type"].as_str().map(str::to_string))
            .collect(),
    }
}

/// The normalized terminal reports what its own recording says.
fn assert_terminal_matches_fixture(
    scenario: &str,
    terminal: &CompletionResponse,
    recorded: &RecordedStream,
) {
    assert!(
        recorded
            .response_id
            .as_deref()
            .is_some_and(|id| id.starts_with("msg_")),
        "{scenario}: premise — message_start names a msg_ id"
    );
    assert!(
        recorded.request_id.is_some(),
        "{scenario}: premise — the response carries a request-id header"
    );
    assert_ids_match_recording(
        &[terminal.response_id().map(str::to_owned)],
        std::slice::from_ref(&recorded.response_id),
        scenario,
    );
    assert_ids_match_recording(
        std::slice::from_ref(&terminal.provider_request_id),
        std::slice::from_ref(&recorded.request_id),
        scenario,
    );
    assert_eq!(terminal.model(), recorded.model.as_deref());
    assert_eq!(terminal.usage.input_tokens, Some(recorded.input_tokens));
    assert_eq!(terminal.usage.output_tokens, Some(recorded.output_tokens));
    assert_eq!(terminal.provider(), ANTHROPIC_PROVIDER);
}

// ---------------------------------------------------------------------------
// 1: typed round trip, terminal-only shape
// ---------------------------------------------------------------------------

#[tokio::test]
async fn terminal_raw_round_trips_into_provider_type() {
    let sink = Observed::default();
    with_anthropic_cassette(
        "raw_stream_capture_matrix/terminal_raw_round_trips_into_provider_type",
        {
            let sink = sink.clone();
            move |client| async move {
                capture_terminal(
                    client.completion(anthropic::completion::CLAUDE_HAIKU_4_5),
                    probe_request(),
                    sink,
                )
                .await
                .expect("stream should open");
            }
        },
    )
    .await;
    let terminal = sink.take();
    let raw: &Value = &terminal.raw;
    assert!(
        !raw.is_null(),
        "every terminal `stream()` yields carries `raw`"
    );

    // The unary document. Pin the exact key set: the fields a unary
    // `Message` carries (no `provider_request_id`: the transport stamps
    // that onto the normalized record, not the provider's), and nothing
    // frame-shaped.
    let mut keys: Vec<&str> = raw
        .as_object()
        .expect("terminal raw is an object")
        .keys()
        .map(String::as_str)
        .collect();
    keys.sort_unstable();
    assert_eq!(
        keys,
        [
            "container",
            "content",
            "id",
            "model",
            "role",
            "stop_details",
            "stop_reason",
            "stop_sequence",
            "type",
            "usage"
        ],
        "the unary `Message`'s fields, and only those"
    );
    assert_eq!(raw["type"], "message");
    for frame_key in [
        "content_block_delta",
        "content_block_start",
        "delta",
        "index",
    ] {
        assert!(
            raw.get(frame_key).is_none(),
            "`raw` is the unary document, not the frames: found `{frame_key}`"
        );
    }
    let recorded_text: String = recorded_frames(ROUND_TRIP_SCENARIO)
        .iter()
        .filter(|frame| frame["delta"]["type"] == "text_delta")
        .filter_map(|frame| frame["delta"]["text"].as_str())
        .collect();
    assert_eq!(
        raw["content"],
        json!([{ "type": "text", "text": recorded_text }]),
        "the streamed text is the document's one text block"
    );

    // Wire-derived fields equal what the recorded frames say; the transport
    // id is the header the driver stamped.
    let recorded = recorded_stream(ROUND_TRIP_SCENARIO);
    assert!(
        recorded
            .frame_types
            .iter()
            .any(|kind| kind == "content_block_delta"),
        "premise: the recorded stream did carry frames `raw` must not contain"
    );
    assert_ids_match_recording(
        &[raw["id"].as_str().map(str::to_string)],
        std::slice::from_ref(&recorded.response_id),
        ROUND_TRIP_SCENARIO,
    );
    // The transport id is stamped on the normalized terminal, never on the
    // native record inside `raw`.
    assert!(raw.get("provider_request_id").is_none());
    assert_ids_match_recording(
        std::slice::from_ref(&terminal.provider_request_id),
        std::slice::from_ref(&recorded.request_id),
        ROUND_TRIP_SCENARIO,
    );
    assert_eq!(raw["model"].as_str(), recorded.model.as_deref());
    assert_eq!(raw["stop_reason"].as_str(), recorded.stop_reason.as_deref());
    assert_eq!(recorded.stop_reason.as_deref(), Some("end_turn"));
    assert_eq!(raw["usage"]["output_tokens"], json!(recorded.output_tokens));
    assert_eq!(raw["usage"]["input_tokens"], json!(recorded.input_tokens));

    // The normalized view beside it reports what the fixture recorded.
    assert_eq!(terminal.finish_reason(), Some(FinishReason::Stop));
    assert_terminal_matches_fixture(ROUND_TRIP_SCENARIO, &terminal, &recorded);
}

// ---------------------------------------------------------------------------
// 2: a terminal-only field, verbatim
// ---------------------------------------------------------------------------

#[tokio::test]
async fn raw_exposes_stop_sequence() {
    let sink = Observed::default();
    with_anthropic_cassette("raw_stream_capture_matrix/raw_exposes_stop_sequence", {
        let sink = sink.clone();
        move |client| async move {
            capture_terminal(
                client.completion(anthropic::completion::CLAUDE_HAIKU_4_5),
                CompletionRequest::new(IMMEDIATE_PROMPT)
                    .max_tokens(32)
                    .additional_params(json!({ "stop_sequences": ["alpha"] })),
                sink,
            )
            .await
            .expect("stream should open");
        }
    })
    .await;
    let terminal = sink.take();
    let raw: &Value = &terminal.raw;
    assert!(
        !raw.is_null(),
        "every terminal `stream()` yields carries `raw`"
    );

    // Premise from the frames: the terminal `message_delta` stopped on the
    // sequence and named it.
    let recorded = recorded_stream(STOP_SEQUENCE_SCENARIO);
    assert_eq!(
        recorded.stop_reason.as_deref(),
        Some("stop_sequence"),
        "premise: the recorded stream stopped on a sequence"
    );
    assert_eq!(
        recorded.stop_sequence.as_deref(),
        Some("alpha"),
        "premise: the recorded terminal names the sequence"
    );

    // Normalized: folded into `Stop`; the provider's spelling and the
    // sequence itself are only on `raw`.
    assert_eq!(terminal.finish_reason(), Some(FinishReason::Stop));
    let normalized = canonical_without_raw(terminal.clone());
    let normalized_keys: Vec<&str> = normalized
        .as_object()
        .expect("object")
        .keys()
        .map(String::as_str)
        .collect();
    assert!(
        !normalized_keys.contains(&"stop_sequence") && !normalized_keys.contains(&"stop_reason"),
        "the normalized terminal has neither `stop_sequence` nor a verbatim `stop_reason` \
         ({normalized_keys:?}) — `raw` is the only way to read them"
    );
    assert_eq!(raw["stop_reason"], "stop_sequence");
    assert_eq!(raw["stop_sequence"], "alpha");
    assert_terminal_matches_fixture(STOP_SEQUENCE_SCENARIO, &terminal, &recorded);
}

// ---------------------------------------------------------------------------
// 3: raw and the normalized terminal tell one story
// ---------------------------------------------------------------------------

/// The normalized terminal and `raw` describe the same stream: `raw`
/// carries every normalized field delivered beside it: identity, finish reason, model, usage. And each of
/// those is what the fixture recorded.
#[tokio::test]
async fn normalized_terminal_matches_raw_renormalized() {
    let sink = Observed::default();
    with_anthropic_cassette(
        "raw_stream_capture_matrix/normalized_terminal_matches_raw_renormalized",
        {
            let sink = sink.clone();
            move |client| async move {
                capture_terminal(
                    client.completion(anthropic::completion::CLAUDE_HAIKU_4_5),
                    probe_request(),
                    sink,
                )
                .await
                .expect("stream should open");
            }
        },
    )
    .await;
    let terminal = sink.take();
    let raw: &Value = &terminal.raw;
    assert!(
        !raw.is_null(),
        "every terminal `stream()` yields carries `raw`"
    );

    assert_eq!(
        raw["id"].as_str(),
        terminal.response_id(),
        "the message id is the record's"
    );
    assert_eq!(raw["model"].as_str(), terminal.model());
    assert_eq!(
        raw["usage"]["input_tokens"].as_u64(),
        terminal.usage.input_tokens
    );

    // …and none of that is vacuous: the normalized terminal is the fixture's.
    let recorded = recorded_stream(RENORMALIZED_SCENARIO);
    assert_eq!(recorded.stop_reason.as_deref(), Some("end_turn"));
    assert_eq!(terminal.finish_reason(), Some(FinishReason::Stop));
    assert_terminal_matches_fixture(RENORMALIZED_SCENARIO, &terminal, &recorded);
}

// ---------------------------------------------------------------------------
// 4: an extended-thinking stream — terminal round trip beside a thinking block
// ---------------------------------------------------------------------------

/// The streamed twin of `raw_capture_matrix::raw_exposes_thinking_block_and_signature`.
/// `raw` is the unary document, so it carries the thinking block rebuilt
/// from its deltas, text and signature, as the unary twin does, and the
/// usage bucket in the provider's spelling:
/// `usage.output_tokens_details.thinking_tokens`, verbatim from the
/// terminal `message_delta`. The normalized terminal folds it into
/// `reasoning_tokens` and never spells `thinking`.
#[tokio::test]
async fn terminal_raw_round_trips_for_thinking_stream() {
    let sink = Observed::default();
    with_anthropic_cassette(
        "raw_stream_capture_matrix/terminal_raw_round_trips_for_thinking_stream",
        {
            let sink = sink.clone();
            move |client| {
                streamed_body(
                    client,
                    anthropic::completion::CLAUDE_SONNET_4_6,
                    thinking_request(),
                    sink,
                )
            }
        },
    )
    .await;
    let Streamed { items, terminal } = sink.take();
    let raw: &Value = &terminal.raw;
    let typed = assert_raw_round_trips(raw);

    // Premise, from the frames: the stream opened a `thinking` content block,
    // signed it, and its terminal `message_delta` reports the thinking bucket.
    let frames = recorded_frames(THINKING_SCENARIO);
    assert!(
        frames.iter().any(|frame| {
            frame["type"] == "content_block_start" && frame["content_block"]["type"] == "thinking"
        }),
        "premise: the recorded stream opened a `thinking` content block"
    );
    let recorded_thinking_text = frames
        .iter()
        .filter(|frame| {
            frame["type"] == "content_block_delta" && frame["delta"]["type"] == "thinking_delta"
        })
        .filter_map(|frame| frame["delta"]["thinking"].as_str())
        .collect::<String>();
    assert!(
        !recorded_thinking_text.is_empty(),
        "premise: the recorded stream carried `thinking_delta` text"
    );
    let recorded_signature = frames
        .iter()
        .find(|frame| {
            frame["type"] == "content_block_delta" && frame["delta"]["type"] == "signature_delta"
        })
        .and_then(|frame| frame["delta"]["signature"].as_str())
        .map(str::to_string);
    assert!(
        recorded_signature
            .as_deref()
            .is_some_and(|sig| !sig.is_empty()),
        "premise: the recorded stream signed the thinking block (`signature_delta`)"
    );
    let recorded = recorded_stream(THINKING_SCENARIO);
    let recorded_thinking_tokens = frames
        .iter()
        .find(|frame| frame["type"] == "message_delta")
        .and_then(|frame| frame["usage"]["output_tokens_details"]["thinking_tokens"].as_u64())
        .expect(
            "premise: the terminal `message_delta` carries `output_tokens_details.thinking_tokens`",
        );
    assert!(
        recorded_thinking_tokens > 0,
        "premise: the recorded turn actually spent thinking tokens"
    );
    assert_eq!(recorded.stop_reason.as_deref(), Some("end_turn"), "premise");

    // `raw` carries the thinking block as the unary reply states it.
    assert_eq!(raw["content"][0]["type"], "thinking");
    assert_eq!(raw["content"][0]["thinking"], json!(recorded_thinking_text));
    assert_eq!(
        raw["content"][0]["signature"].as_str(),
        recorded_signature.as_deref()
    );

    // `raw` carries the provider's usage breakdown, verbatim.
    assert_eq!(
        raw["usage"]["output_tokens_details"]["thinking_tokens"],
        json!(recorded_thinking_tokens),
        "the terminal `raw` carries `thinking_tokens` as the wire spelled it"
    );
    assert_eq!(
        typed["usage"]["output_tokens_details"]["thinking_tokens"].as_u64(),
        Some(recorded_thinking_tokens)
    );
    assert_eq!(raw["stop_reason"], "end_turn");

    // The normalized terminal folds it into `reasoning_tokens` and never
    // spells `thinking` — only `raw` does.
    assert_eq!(terminal.finish_reason(), Some(FinishReason::Stop));
    assert_eq!(
        terminal.usage.reasoning_tokens,
        Some(recorded_thinking_tokens)
    );
    let normalized = canonical_without_raw(terminal.clone());
    assert!(
        !contains_string(&normalized, "thinking")
            && !contains_string(&normalized, "thinking_tokens")
            && !contains_string(&normalized, "output_tokens_details"),
        "the normalized terminal never spells `thinking` / `output_tokens_details`: {normalized}"
    );
    assert_terminal_matches_fixture(THINKING_SCENARIO, &terminal, &recorded);

    // And the block was delivered as normalized items too: the stream's
    // `Reasoning` text is the frames' `thinking_delta` text.
    let streamed_reasoning = items
        .iter()
        .filter_map(|item| match item {
            rig::streaming::Item::Event(StreamEvent::End {
                content: AssistantContent::Reasoning(reasoning),
                ..
            }) => Some(reasoning),
            _ => None,
        })
        .map(|reasoning| reasoning.text.as_str())
        .collect::<String>();
    assert_eq!(
        streamed_reasoning, recorded_thinking_text,
        "the stream delivered the thinking block as `Reasoning`"
    );
}

// ---------------------------------------------------------------------------
// 5: a forced tool-call stream — terminal round trip beside a tool_use block
// ---------------------------------------------------------------------------

/// The streamed twin of `raw_capture_matrix::raw_exposes_tool_use_block`. The
/// terminal `raw` round-trips, carries the `tool_use` block with its input
/// assembled from the streamed fragments, and names the stop reason as the
/// wire spelled it — `tool_use` — while the normalized terminal reports
/// `FinishReason::ToolCalls`; the block was also delivered as a `ToolCall`
/// item whose provider id is the frame's.
#[tokio::test]
async fn terminal_raw_round_trips_for_tool_use_stream() {
    let sink = Observed::default();
    with_anthropic_cassette(
        "raw_stream_capture_matrix/terminal_raw_round_trips_for_tool_use_stream",
        {
            let sink = sink.clone();
            move |client| {
                streamed_body(
                    client,
                    anthropic::completion::CLAUDE_HAIKU_4_5,
                    tool_request(),
                    sink,
                )
            }
        },
    )
    .await;
    let Streamed { items, terminal } = sink.take();
    let raw: &Value = &terminal.raw;
    let typed = assert_raw_round_trips(raw);

    // Premise, from the frames: the stream opened a `tool_use` block for the
    // forced tool and its terminal `message_delta` stopped on `tool_use`.
    let frames = recorded_frames(TOOL_USE_SCENARIO);
    let recorded_tool_use = frames
        .iter()
        .find(|frame| {
            frame["type"] == "content_block_start" && frame["content_block"]["type"] == "tool_use"
        })
        .map(|frame| &frame["content_block"])
        .expect("premise: the recorded stream opened a `tool_use` content block");
    assert_eq!(recorded_tool_use["name"], "get_weather", "premise");
    let recorded_tool_id = recorded_tool_use["id"].as_str().map(str::to_string);
    assert!(
        recorded_tool_id
            .as_deref()
            .is_some_and(|id| id.starts_with("toolu_")),
        "premise: the recorded `tool_use` block has a `toolu_…` id"
    );
    let recorded_input: Value = serde_json::from_str(
        &frames
            .iter()
            .filter(|frame| {
                frame["type"] == "content_block_delta"
                    && frame["delta"]["type"] == "input_json_delta"
            })
            .filter_map(|frame| frame["delta"]["partial_json"].as_str())
            .collect::<String>(),
    )
    .expect("premise: the recorded `input_json_delta` frames assemble into JSON");
    assert!(
        recorded_input["city"].is_string(),
        "premise: the recorded input names a `city`: {recorded_input}"
    );
    let recorded = recorded_stream(TOOL_USE_SCENARIO);
    assert_eq!(
        recorded.stop_reason.as_deref(),
        Some("tool_use"),
        "premise: the recorded stream stopped to call a tool"
    );

    // `raw` carries the call as the unary reply states it: the block the
    // stream opened, its `input` the assembled fragments.
    assert_eq!(raw["content"][0]["type"], "tool_use");
    assert_eq!(raw["content"][0]["name"], "get_weather");
    assert_eq!(raw["content"][0]["input"], recorded_input);
    assert_ids_match_recording(
        &[raw["content"][0]["id"].as_str().map(str::to_string)],
        std::slice::from_ref(&recorded_tool_id),
        TOOL_USE_SCENARIO,
    );

    // `raw` names the stop reason as the wire spelled it; the normalized
    // terminal maps it onto `ToolCalls` and never spells `tool_use`.
    assert_eq!(raw["stop_reason"], "tool_use");
    assert_eq!(typed["stop_reason"], "tool_use");
    assert_eq!(terminal.finish_reason(), Some(FinishReason::ToolCalls));
    let normalized = canonical_without_raw(terminal.clone());
    assert!(
        !contains_string(&normalized, "tool_use") && !contains_string(&normalized, "stop_reason"),
        "the normalized terminal has neither the spelling `tool_use` nor a verbatim \
         `stop_reason` — `raw` is the only way to read them: {normalized}"
    );
    assert_terminal_matches_fixture(TOOL_USE_SCENARIO, &terminal, &recorded);

    // And the block was delivered as a normalized item too: one `ToolCall`
    // for the forced tool, its arguments the assembled input, its provider
    // id the frame's `toolu_…`.
    let streamed_calls = items
        .iter()
        .filter_map(|item| match item {
            rig::streaming::Item::Event(StreamEvent::End {
                content: AssistantContent::ToolCall(tool_call),
                ..
            }) => Some(tool_call),
            _ => None,
        })
        .collect::<Vec<_>>();
    assert_eq!(
        streamed_calls.len(),
        1,
        "the stream delivered exactly one tool call: {streamed_calls:?}"
    );
    let call = streamed_calls[0];
    assert_eq!(call.function.name, "get_weather");
    assert_eq!(call.function.arguments_value(), recorded_input);
    assert_ids_match_recording(
        &[call
            .id
            .provider()
            .as_ref()
            .map(|provider| provider.as_str().to_owned())],
        std::slice::from_ref(&recorded_tool_id),
        TOOL_USE_SCENARIO,
    );
}
