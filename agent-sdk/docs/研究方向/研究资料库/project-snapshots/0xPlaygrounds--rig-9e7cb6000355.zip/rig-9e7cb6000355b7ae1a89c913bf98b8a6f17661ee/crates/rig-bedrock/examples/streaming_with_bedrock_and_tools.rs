use rig_agent::{agent::stream_to_stdout, prelude::*};
use rig_bedrock::client::BedrockRuntime;
use rig_bedrock::completion::AMAZON_NOVA_LITE;
mod common;

#[tokio::main]
async fn main() -> Result<(), anyhow::Error> {
    tracing_subscriber::fmt().init();
    // Create agent with a single context prompt and two tools
    let agent = AgentBuilder::new(BedrockRuntime::from_env().completion(AMAZON_NOVA_LITE))
        .preamble(
            "You are a calculator here to help the user perform arithmetic
            operations. Use the tools provided to answer the user's question.
            make your answer long, so we can test the streaming functionality,
            like 20 words",
        )
        .max_tokens(1024)
        .tool(common::Adder)
        .build();

    println!("Calculate 2 + 5");
    let mut stream = agent.prompt("Calculate 2 + 5").stream();
    let _ = stream_to_stdout(&mut stream).await?;
    Ok(())
}
