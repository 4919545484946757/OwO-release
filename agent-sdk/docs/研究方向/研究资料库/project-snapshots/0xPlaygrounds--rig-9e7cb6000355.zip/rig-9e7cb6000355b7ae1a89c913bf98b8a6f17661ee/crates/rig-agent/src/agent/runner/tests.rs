use std::sync::{Arc, Mutex};

use futures::StreamExt;
use serde_json::json;

use crate::{
    agent::{AgentBuilder, AgentHook, HookContext, OutcomeAction, OutcomeEvent},
    completion::Document,
    test_utils::{MockCompletionModel, MockStreamEvent, MockTurn},
    tool::{Tool, ToolContext, ToolErrorKind, ToolExecutionError},
};
use rig_core::message::ToolChoice;

struct MetadataFailingTool;

#[derive(serde::Serialize, serde::Deserialize)]
struct ResultMetadata(String);

impl rig_core::tool::ContextValue for ResultMetadata {
    const KEY: &'static str = "test.result_metadata";
}

impl Tool for MetadataFailingTool {
    const NAME: &'static str = "flaky_tool";
    type Error = rig::tool::ToolExecutionError;
    type Args = serde_json::Value;
    type Output = String;

    fn description(&self) -> String {
        "Fails after attaching result metadata".into()
    }

    fn parameters(&self) -> serde_json::Value {
        json!({"type": "object", "properties": {}})
    }

    async fn call(
        &self,
        context: &mut ToolContext,
        _args: Self::Args,
    ) -> Result<Self::Output, ToolExecutionError> {
        context.insert_result(ResultMetadata("shared-result-metadata".to_string()))?;
        Err(ToolExecutionError::timeout("raw timeout failure"))
    }
}

#[derive(Clone, Default)]
struct Results(Arc<Mutex<Vec<(ToolErrorKind, String, String)>>>);

impl AgentHook for Results {
    async fn on_outcome(&self, _ctx: &HookContext, event: OutcomeEvent<'_>) -> OutcomeAction {
        let Some(result) = event.tool_result() else {
            return OutcomeAction::proceed();
        };
        if let Some(error) = result.error() {
            self.0.lock().expect("results").push((
                error.kind(),
                result.output().render(),
                event
                    .tool_context()
                    .expect("tool outcome carries its context")
                    .result::<ResultMetadata>()
                    .expect("tool result metadata decodes")
                    .expect("tool result metadata")
                    .0,
            ));
        }
        OutcomeAction::rewrite_tool_result(&event, "rewritten for model")
    }
}

#[test]
fn agent_exposes_read_only_name_and_description() {
    let named = AgentBuilder::new(MockCompletionModel::text("done"))
        .name("researcher")
        .description("Finds evidence")
        .build();
    assert_eq!(named.name(), Some("researcher"));
    assert_eq!(named.description(), Some("Finds evidence"));

    let unnamed = AgentBuilder::new(MockCompletionModel::text("done")).build();
    assert_eq!(unnamed.name(), None);
    assert_eq!(unnamed.description(), None);
}

#[tokio::test]
async fn runner_applies_per_run_request_overrides() {
    let model = MockCompletionModel::text("done");
    AgentBuilder::new(model.clone())
        .preamble("baseline preamble")
        .context("baseline document")
        .temperature(0.1)
        .max_tokens(10)
        .additional_params(json!({"baseline": true}))
        .build()
        .prompt("go")
        .preamble("run preamble")
        .document(Document {
            id: "run-one".into(),
            text: "first run document".into(),
            additional_props: Default::default(),
        })
        .documents([Document {
            id: "run-two".into(),
            text: "second run document".into(),
            additional_props: Default::default(),
        }])
        .temperature(0.7)
        .max_tokens(42)
        .replace_additional_params(json!({"override": true}))
        .tool_choice(ToolChoice::None)
        .run()
        .await
        .expect("runner request should succeed");

    let requests = model.requests();
    let request = requests.first().expect("one request");
    assert!(request.chat_history.iter().any(
        |message| matches!(message, crate::completion::Message::System { content } if content == "run preamble")
    ));
    let documents = rig_core::test_utils::sent_documents(request);
    assert!(
        documents
            .iter()
            .any(|(_, text)| text == "baseline document")
    );
    assert!(documents.iter().any(|(id, _)| id == "run-one"));
    assert!(documents.iter().any(|(id, _)| id == "run-two"));
    assert_eq!(request.temperature, Some(0.7));
    assert_eq!(request.max_tokens, Some(42));
    assert_eq!(request.additional_params, Some(json!({"override": true})));
    assert_eq!(request.tool_choice, Some(ToolChoice::None));
}

#[tokio::test]
async fn runner_can_merge_additional_params_into_the_baseline() {
    let model = MockCompletionModel::text("done");
    AgentBuilder::new(model.clone())
        .additional_params(json!({"baseline": true, "winner": "baseline"}))
        .build()
        .prompt("go")
        .merge_additional_params(
            json!({"override": true, "winner": "runner"})
                .as_object()
                .expect("object")
                .clone(),
        )
        .run()
        .await
        .expect("runner request should succeed");

    assert_eq!(
        model
            .requests()
            .first()
            .expect("one request")
            .additional_params,
        Some(json!({"baseline": true, "override": true, "winner": "runner"}))
    );
}

#[tokio::test]
async fn the_agents_options_reach_the_request_and_a_runs_options_overlay_them() {
    use rig_core::completion::{CacheRetention, Effort, GenerationOptions, Reasoning};

    let model = MockCompletionModel::from_turns([MockTurn::text("one"), MockTurn::text("two")]);
    let agent = AgentBuilder::new(model.clone())
        .options(GenerationOptions::default().reasoning(Effort::High).seed(7))
        .build();
    agent
        .prompt("go")
        .run()
        .await
        .expect("the agent's request succeeds");
    agent
        .prompt("again")
        .options(
            GenerationOptions::default()
                .cache(CacheRetention::Long)
                .seed(9),
        )
        .run()
        .await
        .expect("the run's request succeeds");

    let requests = model.requests();
    let [first, second] = requests.as_slice() else {
        panic!("two requests: {requests:?}");
    };
    assert_eq!(
        first.options,
        GenerationOptions::default().reasoning(Effort::High).seed(7)
    );
    assert_eq!(
        second.options.reasoning,
        Some(Reasoning::Effort(Effort::High))
    );
    assert_eq!(second.options.cache, Some(CacheRetention::Long));
    assert_eq!(second.options.seed, Some(9));
}

/// A test-only provider extension: a shared section of free-form fields.
mod extension {
    use rig_core::completion::{ExtensionOptions, ProviderExtension, ReplyExtras};
    use rig_core::message::Api;
    use serde_json::{Map, Value};

    #[derive(Clone, Debug, serde::Serialize)]
    pub(super) struct Shared {
        #[serde(rename = "*")]
        pub(super) fields: Map<String, Value>,
    }

    /// Alpha's options; [`Beta`] stores the same type with `with::<Beta>`.
    impl ExtensionOptions for Shared {
        type Ext = Alpha;
    }

    pub(super) struct NoExtras;

    impl ReplyExtras for NoExtras {
        fn from_reply(_api: &Api, _raw: &Value) -> Result<Self, serde_json::Error> {
            Ok(Self)
        }
    }

    pub(super) struct Alpha;

    impl ProviderExtension for Alpha {
        const PROVIDER: &'static str = "alpha";
        type Options = Shared;
        type Extras = NoExtras;
    }

    pub(super) struct Beta;

    impl ProviderExtension for Beta {
        const PROVIDER: &'static str = "beta";
        type Options = Shared;
        type Extras = NoExtras;
    }

    pub(super) fn shared(fields: Value) -> Shared {
        Shared {
            fields: match fields {
                Value::Object(fields) => fields,
                _ => Map::new(),
            },
        }
    }
}

#[tokio::test]
async fn the_agents_provider_options_reach_the_request_and_a_run_replaces_an_entry() {
    use extension::{Alpha, Beta, shared};
    use rig_core::completion::ProviderOptions;

    let agent_options = ProviderOptions::new()
        .with::<Alpha>(&shared(json!({"top_k": 4})))
        .and_then(|options| options.with::<Beta>(&shared(json!({"min_p": 0.1}))))
        .expect("the agent's options serialize");
    let run_options = ProviderOptions::new()
        .with::<Alpha>(&shared(json!({"top_k": 8})))
        .expect("the run's options serialize");
    let model = MockCompletionModel::from_turns([MockTurn::text("one"), MockTurn::text("two")]);
    let agent = AgentBuilder::new(model.clone())
        .provider_options(agent_options.clone())
        .build();
    agent
        .prompt("go")
        .run()
        .await
        .expect("the agent's request succeeds");
    agent
        .prompt("again")
        .provider_options(run_options.clone())
        .run()
        .await
        .expect("the run's request succeeds");

    let requests = model.requests();
    let [first, second] = requests.as_slice() else {
        panic!("two requests: {requests:?}");
    };
    assert_eq!(first.provider_options, agent_options);
    assert_eq!(
        second.provider_options.get::<Alpha>(),
        run_options.get::<Alpha>()
    );
    assert_eq!(
        second.provider_options.get::<Beta>(),
        agent_options.get::<Beta>()
    );
}

#[tokio::test]
async fn provider_option_on_the_agent_and_the_run_equals_the_long_form() {
    use extension::{Alpha, Beta, shared};
    use rig_core::completion::ProviderOptions;

    let beta = ProviderOptions::new()
        .with::<Beta>(&shared(json!({"min_p": 0.1})))
        .expect("beta's options serialize");
    let requests = |short: bool| {
        let beta = beta.clone();
        async move {
            let model =
                MockCompletionModel::from_turns([MockTurn::text("one"), MockTurn::text("two")]);
            let builder = AgentBuilder::new(model.clone()).provider_options(beta.clone());
            let agent = match short {
                true => builder.provider_option(shared(json!({"top_k": 4}))),
                false => builder.provider_options(
                    beta.with::<Alpha>(&shared(json!({"top_k": 4})))
                        .expect("alpha's options serialize"),
                ),
            }
            .build();
            agent.prompt("go").run().await.expect("the agent's request");
            let run = agent.prompt("again");
            let run = match short {
                true => run.provider_option(shared(json!({"top_k": 8}))),
                false => run.provider_options(
                    ProviderOptions::new()
                        .with::<Alpha>(&shared(json!({"top_k": 8})))
                        .expect("the run's options serialize"),
                ),
            };
            run.run().await.expect("the run's request");
            model
                .requests()
                .into_iter()
                .map(|request| request.provider_options)
                .collect::<Vec<_>>()
        }
    };
    let short = requests(true).await;
    assert_eq!(short, requests(false).await);
    assert_eq!(short.len(), 2);
    assert!(short.iter().all(|options| options.contains::<Beta>()));
}

/// The provider options of the requests `model` received.
fn sent_provider_options(
    model: &MockCompletionModel,
) -> Vec<rig_core::completion::ProviderOptions> {
    model
        .requests()
        .into_iter()
        .map(|request| request.provider_options)
        .collect()
}

/// On the agent `provider_options` replaces every entry, dropping an
/// earlier `provider_option`; on a run it merges, keeping one.
#[tokio::test]
async fn provider_option_and_provider_options_apply_in_order() {
    use extension::{Beta, shared};
    use rig_core::completion::ProviderOptions;

    let beta = ProviderOptions::new()
        .with::<Beta>(&shared(json!({"min_p": 0.1})))
        .expect("beta's options serialize");
    let with_alpha = beta.clone().set(shared(json!({"top_k": 4})));

    let model = MockCompletionModel::from_turns([MockTurn::text("one"), MockTurn::text("two")]);
    let before = AgentBuilder::new(model.clone())
        .provider_option(shared(json!({"top_k": 4})))
        .provider_options(beta.clone())
        .build();
    before
        .prompt("go")
        .run()
        .await
        .expect("the agent's request");
    let after = AgentBuilder::new(model.clone())
        .provider_options(beta.clone())
        .provider_option(shared(json!({"top_k": 4})))
        .build();
    after.prompt("go").run().await.expect("the agent's request");
    assert_eq!(
        sent_provider_options(&model),
        [beta.clone(), with_alpha.clone()]
    );

    let model = MockCompletionModel::from_turns([MockTurn::text("one"), MockTurn::text("two")]);
    let agent = AgentBuilder::new(model.clone()).build();
    agent
        .prompt("go")
        .provider_option(shared(json!({"top_k": 4})))
        .provider_options(beta.clone())
        .run()
        .await
        .expect("the run's request");
    agent
        .prompt("go")
        .provider_options(beta.clone())
        .provider_option(shared(json!({"top_k": 4})))
        .run()
        .await
        .expect("the run's request");
    assert_eq!(
        sent_provider_options(&model),
        [with_alpha.clone(), with_alpha]
    );
}

/// A run's options that write no field hold no entry, so the agent's entry
/// for that provider stays, through the shortcut and the long form alike.
#[tokio::test]
async fn a_runs_empty_provider_option_keeps_the_agents_entry() {
    use extension::shared;
    use rig_core::completion::ProviderOptions;

    let model = MockCompletionModel::from_turns([MockTurn::text("one"), MockTurn::text("two")]);
    let agent_options = ProviderOptions::new().set(shared(json!({"top_k": 4})));
    let agent = AgentBuilder::new(model.clone())
        .provider_options(agent_options.clone())
        .build();
    agent
        .prompt("go")
        .provider_option(shared(json!({})))
        .run()
        .await
        .expect("the run's request");
    agent
        .prompt("go")
        .provider_options(ProviderOptions::new().set(shared(json!({}))))
        .run()
        .await
        .expect("the run's request");
    assert_eq!(
        sent_provider_options(&model),
        [agent_options.clone(), agent_options]
    );
}

/// The generation options of the last request `model` received, once `run`
/// has run.
async fn sent_options(
    model: &MockCompletionModel,
    run: crate::agent::AgentRunner,
) -> rig_core::completion::GenerationOptions {
    run.run().await.expect("the run's request succeeds");
    model
        .requests()
        .pop()
        .map(|request| request.options)
        .unwrap_or_default()
}

#[tokio::test]
async fn generation_option_shortcuts_on_the_agent_and_the_run_equal_their_long_forms() {
    use rig_core::completion::{
        CacheRetention, Effort, GenerationOptions, OnUnsupported, ServiceTier, Verbosity,
    };

    let long = GenerationOptions::new()
        .reasoning(Effort::Low)
        .cache(CacheRetention::Short)
        .service_tier(ServiceTier::Flex)
        .verbosity(Verbosity::Low)
        .parallel_tool_calls(false)
        .top_p(0.5)
        .seed(3)
        .stop(["x"])
        .on_unsupported(OnUnsupported::Ignore);
    let model = MockCompletionModel::text("done");
    let agent = AgentBuilder::new(model.clone())
        .reasoning(Effort::Low)
        .cache(CacheRetention::Short)
        .service_tier(ServiceTier::Flex)
        .verbosity(Verbosity::Low)
        .parallel_tool_calls(false)
        .top_p(0.5)
        .seed(3)
        .stop(["x"])
        .on_unsupported(OnUnsupported::Ignore)
        .build();
    assert_eq!(sent_options(&model, agent.prompt("go")).await, long);

    let run = GenerationOptions::new()
        .reasoning(Effort::High)
        .cache(CacheRetention::Long)
        .service_tier(ServiceTier::Priority)
        .verbosity(Verbosity::High)
        .parallel_tool_calls(true)
        .top_p(0.9)
        .seed(9)
        .stop(["y", "z"])
        .on_unsupported(OnUnsupported::Error);
    let model = MockCompletionModel::from_turns([MockTurn::text("one"), MockTurn::text("two")]);
    let agent = AgentBuilder::new(model.clone())
        .options(long.clone())
        .build();
    let short = agent
        .prompt("go")
        .reasoning(Effort::High)
        .cache(CacheRetention::Long)
        .service_tier(ServiceTier::Priority)
        .verbosity(Verbosity::High)
        .parallel_tool_calls(true)
        .top_p(0.9)
        .seed(9)
        .stop(["y", "z"])
        .on_unsupported(OnUnsupported::Error);
    let short = sent_options(&model, short).await;
    let long = sent_options(&model, agent.prompt("go").options(run.clone())).await;
    assert_eq!(short, long);
    assert_eq!(short, run);
}

/// A run's options restore `Error` over an agent's `Ignore`, through
/// `options` and through the shortcut alike.
#[tokio::test]
async fn a_run_restores_the_error_policy_over_an_agents_ignore() {
    use rig_core::completion::{GenerationOptions, OnUnsupported};

    let model = MockCompletionModel::from_turns([MockTurn::text("one"), MockTurn::text("two")]);
    let agent = AgentBuilder::new(model.clone())
        .seed(1)
        .on_unsupported(OnUnsupported::Ignore)
        .build();
    let error = GenerationOptions::new().on_unsupported(OnUnsupported::Error);
    let through_options = sent_options(&model, agent.prompt("go").options(error)).await;
    assert_eq!(through_options.unsupported_policy(), OnUnsupported::Error);
    assert_eq!(through_options.seed, Some(1));
    let through_shortcut = sent_options(
        &model,
        agent.prompt("go").on_unsupported(OnUnsupported::Error),
    )
    .await;
    assert_eq!(through_shortcut, through_options);
}

/// An empty stop list on a run means "not set", through the shortcut and
/// the long form alike: the agent's stop sequences stay.
#[tokio::test]
async fn a_runs_empty_stop_keeps_the_agents_stop_sequences() {
    use rig_core::completion::GenerationOptions;

    let model = MockCompletionModel::from_turns([MockTurn::text("one"), MockTurn::text("two")]);
    let agent = AgentBuilder::new(model.clone()).seed(1).stop(["x"]).build();
    let agents = GenerationOptions::new().seed(1).stop(["x"]);
    let short = sent_options(&model, agent.prompt("go").stop(Vec::<String>::new())).await;
    let long = sent_options(
        &model,
        agent
            .prompt("go")
            .options(GenerationOptions::new().stop(Vec::<String>::new())),
    )
    .await;
    assert_eq!(short, agents);
    assert_eq!(long, agents);
}

#[tokio::test]
async fn generation_option_calls_apply_in_order() {
    use rig_core::completion::{Effort, GenerationOptions};

    let shared = GenerationOptions::new().reasoning(Effort::High).seed(1);
    // On the agent `options` replaces every field.
    let model = MockCompletionModel::text("done");
    let agent = AgentBuilder::new(model.clone())
        .seed(7)
        .top_p(0.2)
        .options(shared.clone())
        .build();
    assert_eq!(sent_options(&model, agent.prompt("go")).await, shared);
    let model = MockCompletionModel::text("done");
    let agent = AgentBuilder::new(model.clone())
        .options(shared.clone())
        .seed(7)
        .build();
    assert_eq!(
        sent_options(&model, agent.prompt("go")).await,
        shared.clone().seed(7)
    );
    // On a run `options` overlays the fields it sets, over a shortcut
    // called before it; a shortcut called after sets its field on top.
    let model = MockCompletionModel::from_turns([MockTurn::text("one"), MockTurn::text("two")]);
    let agent = AgentBuilder::new(model.clone()).build();
    let before = agent
        .prompt("go")
        .seed(7)
        .top_p(0.2)
        .options(shared.clone());
    assert_eq!(
        sent_options(&model, before).await,
        shared.clone().top_p(0.2)
    );
    let after = agent.prompt("go").options(shared.clone()).seed(7);
    assert_eq!(sent_options(&model, after).await, shared.seed(7));
}

#[tokio::test]
async fn runner_can_clear_configured_request_defaults() {
    let model = MockCompletionModel::text("done");
    AgentBuilder::new(model.clone())
        .preamble("baseline")
        .temperature(0.1)
        .max_tokens(10)
        .additional_params(json!({"baseline": true}))
        .tool_choice(ToolChoice::Required)
        .build()
        .prompt("go")
        .without_preamble()
        .without_temperature()
        .without_max_tokens()
        .without_additional_params()
        .without_tool_choice()
        .run()
        .await
        .expect("runner request should succeed");

    let requests = model.requests();
    let request = requests.first().expect("one request");
    assert!(
        !request
            .chat_history
            .iter()
            .any(|message| matches!(message, crate::completion::Message::System { .. }))
    );
    assert_eq!(request.temperature, None);
    assert_eq!(request.max_tokens, None);
    assert_eq!(request.additional_params, None);
    assert_eq!(request.tool_choice, None);
}

#[tokio::test]
async fn blocking_and_streaming_preserve_raw_failure_while_rewriting_presentation() {
    let blocking = Results::default();
    let blocking_model = MockCompletionModel::from_turns([
        MockTurn::tool_call("tc1", "flaky_tool", json!({})),
        MockTurn::text("done"),
    ]);
    AgentBuilder::new(blocking_model.clone())
        .tool(MetadataFailingTool)
        .add_hook(blocking.clone())
        .build()
        .prompt("go")
        .max_turns(3)
        .run()
        .await
        .expect("blocking run");

    let streaming = Results::default();
    let streaming_model = MockCompletionModel::from_stream_turns([
        vec![
            MockStreamEvent::tool_call_name_delta("tc1", "flaky_tool"),
            MockStreamEvent::tool_call_arguments_delta("tc1", "{}"),
            MockStreamEvent::tool_call("tc1", "flaky_tool", json!({})),
            MockStreamEvent::final_response_with_total_tokens(0),
        ],
        vec![
            MockStreamEvent::text("done"),
            MockStreamEvent::final_response_with_total_tokens(0),
        ],
    ]);
    let mut stream = AgentBuilder::new(streaming_model.clone())
        .tool(MetadataFailingTool)
        .add_hook(streaming.clone())
        .build()
        .prompt("go")
        .max_turns(3)
        .stream();
    while let Some(item) = stream.next().await {
        item.expect("stream item");
    }

    assert_eq!(*blocking.0.lock().unwrap(), *streaming.0.lock().unwrap());
    assert_eq!(
        *blocking.0.lock().unwrap(),
        vec![(
            ToolErrorKind::Timeout,
            "raw timeout failure".into(),
            "shared-result-metadata".into()
        )]
    );

    let blocking_history = serde_json::to_value(
        &blocking_model
            .requests()
            .get(1)
            .expect("second blocking request")
            .chat_history,
    )
    .unwrap();
    let streaming_history = serde_json::to_value(
        &streaming_model
            .requests()
            .get(1)
            .expect("second streaming request")
            .chat_history,
    )
    .unwrap();
    assert_eq!(blocking_history, streaming_history);
    let history = blocking_history.to_string();
    assert!(history.contains("rewritten for model"));
    assert!(!history.contains("raw timeout failure"));
}

/// A runner's content-telemetry opt-in overrides the agent's, for that run
/// only.
#[test]
fn a_runner_overrides_content_telemetry_for_its_run() {
    let agent = AgentBuilder::new(MockCompletionModel::text("ok")).build();
    let runner = agent.prompt("go").record_content_telemetry(true);
    assert!(runner.config.record_telemetry_content);
    assert!(!agent.config.record_telemetry_content);
    assert!(
        !runner
            .record_content_telemetry(false)
            .config
            .record_telemetry_content
    );
}

/// A reply the Anthropic wire decodes, for a model connected over a
/// recording transport.
const ANTHROPIC_REPLY: &str = r#"{"id":"msg_1","type":"message","role":"assistant","model":"claude-haiku-4-5","content":[{"type":"text","text":"ok"}],"stop_reason":"end_turn","stop_sequence":null,"usage":{"input_tokens":1,"output_tokens":1}}"#;

/// `reference` connected through `catalog`, over a transport that records
/// what is sent and answers every call with [`ANTHROPIC_REPLY`].
fn connected(
    catalog: &rig_core::catalog::Catalog,
    reference: &str,
) -> (
    rig_core::DynModel<rig_core::operation::Completion>,
    rig_core::test_utils::RecordingHttpClient,
) {
    let http = rig_core::test_utils::RecordingHttpClient::new(ANTHROPIC_REPLY);
    let model = catalog
        .connect_with(
            reference,
            rig_core::providers::registry::ConnectOptions::new()
                .api_key("sk-test")
                .http(http.clone()),
        )
        .expect("connects");
    (model, http)
}

/// The JSON bodies `http` was sent.
fn sent_bodies(http: &rig_core::test_utils::RecordingHttpClient) -> Vec<serde_json::Value> {
    http.requests()
        .iter()
        .map(|request| serde_json::from_slice(&request.body).expect("a JSON body"))
        .collect()
}

/// Whether `error` is the model refusing `option` for `model` before
/// sending: the refusal crosses the bus as a request error naming both.
fn refused(error: &crate::completion::PromptError, option: &str, model: &str) -> bool {
    matches!(
        error,
        crate::completion::PromptError::Report(report)
            if report.kind == rig_core::error::ErrorKind::Request
                && report.message.contains(&format!(
                    "`{option}` is not supported by anthropic model `{model}`"
                ))
    )
}

/// An agent needs no copy of its model's spec: the model checks every call
/// against the spec it was connected with, when it encodes the call. A
/// refused option fails the run with nothing sent, unless the options
/// ignore what the model cannot take, and the same holds for a model a run
/// switches to, by value, by route or by a selection hook.
#[tokio::test]
async fn the_connected_model_checks_every_call_including_a_switched_one() {
    use rig_core::catalog::Catalog;
    use rig_core::completion::{Effort, OnUnsupported};

    let (haiku, haiku_http) = connected(Catalog::builtin(), "anthropic/claude-haiku-4-5");
    let (opus, opus_http) = connected(Catalog::builtin(), "anthropic/claude-opus-4-8");
    let agent = AgentBuilder::new(haiku.clone())
        .model_route("opus", opus.clone())
        .reasoning(Effort::High)
        .build();

    // Haiku 4.5, the agent's own model, takes no effort level.
    let error = agent.prompt("go").run().await.expect_err("refused");
    assert!(
        refused(&error, "reasoning", "claude-haiku-4-5"),
        "{error:?}"
    );
    let mut stream = agent.prompt("go").stream();
    let Some(Err(error)) = stream.next().await else {
        panic!("the stream fails");
    };
    assert!(
        refused(&error, "reasoning", "claude-haiku-4-5"),
        "{error:?}"
    );
    assert!(haiku_http.requests().is_empty(), "nothing was sent");

    agent
        .prompt("go")
        .on_unsupported(OnUnsupported::Ignore)
        .run()
        .await
        .expect("ignored, with a warning");
    let [ignored] = sent_bodies(&haiku_http).try_into().expect("one request");
    assert!(ignored.get("thinking").is_none(), "{ignored}");
    assert!(ignored.get("output_config").is_none(), "{ignored}");

    // Opus 4.8 takes `high`, whichever way the run switches to it.
    agent
        .prompt("go")
        .using_model("opus")
        .run()
        .await
        .expect("the route is Opus 4.8");
    let (by_value, by_value_http) = connected(Catalog::builtin(), "anthropic/claude-opus-4-8");
    agent
        .prompt("go")
        .using_model_value(by_value)
        .run()
        .await
        .expect("Opus 4.8 by value takes `high`");
    let (default, default_http) = connected(Catalog::builtin(), "anthropic/claude-opus-4-8");
    agent
        .clone()
        .with_model(default)
        .prompt("go")
        .run()
        .await
        .expect("Opus 4.8 as the agent's new default takes `high`");
    assert_eq!(default_http.requests().len(), 1);
    let hooked = AgentBuilder::new(haiku.clone())
        .model_route("opus", opus)
        .add_hook(SelectOpus)
        .reasoning(Effort::High)
        .build();
    hooked
        .prompt("go")
        .run()
        .await
        .expect("the hook selects Opus 4.8");
    assert_eq!(opus_http.requests().len(), 2);
    assert_eq!(by_value_http.requests().len(), 1);

    // A switch to a model that refuses the option fails that call.
    let (snapshot, snapshot_http) =
        connected(Catalog::builtin(), "anthropic/claude-haiku-4-5-20251001");
    let error = agent
        .prompt("go")
        .using_model_value(snapshot)
        .run()
        .await
        .expect_err("a Haiku 4.5 snapshot takes no effort level");
    assert!(
        refused(&error, "reasoning", "claude-haiku-4-5-20251001"),
        "{error:?}"
    );
    assert!(snapshot_http.requests().is_empty());
}

/// A selection hook that sends every call to the model labelled `opus`.
struct SelectOpus;

impl AgentHook for SelectOpus {
    fn on_model_select(
        &self,
        _ctx: &HookContext,
        _event: crate::agent::ModelSelection<'_>,
    ) -> crate::agent::ModelSelectionAction {
        crate::agent::ModelSelectionAction::select("opus")
    }
}

/// A model connected through the application's own catalog is checked
/// against that catalog's spec: an override that narrows what the model
/// takes reaches the agent with no extra wiring.
#[tokio::test]
async fn an_override_in_the_applications_catalog_reaches_the_agent() {
    use rig_core::catalog::Catalog;
    use rig_core::completion::{CacheRetention, OnUnsupported};

    let mut short_only = Catalog::builtin()
        .resolve("anthropic/claude-haiku-4-5")
        .expect("listed")
        .spec
        .clone();
    short_only.caching.retention = vec![CacheRetention::Short];
    let mut catalog = Catalog::builtin().clone();
    catalog.insert(short_only);
    let (model, http) = connected(&catalog, "anthropic/claude-haiku-4-5");
    let agent = AgentBuilder::new(model).build();

    let error = agent
        .prompt("go")
        .cache(CacheRetention::Long)
        .run()
        .await
        .expect_err("the override takes only short retention");
    assert!(refused(&error, "cache", "claude-haiku-4-5"), "{error:?}");
    assert!(http.requests().is_empty(), "nothing was sent");

    agent
        .prompt("go")
        .cache(CacheRetention::Short)
        .run()
        .await
        .expect("short retention is listed");
    agent
        .prompt("go")
        .cache(CacheRetention::Long)
        .on_unsupported(OnUnsupported::Ignore)
        .run()
        .await
        .expect("ignored, with a warning");
    let [short, ignored] = sent_bodies(&http).try_into().expect("two requests");
    assert_ne!(short, ignored, "the long retention was dropped, not sent");
    assert!(!ignored.to_string().contains("\"1h\""), "{ignored}");
}
