//! Agent configuration, request preparation, and prompting entry points.
//!
//! ```no_run
//! # async fn example(agent: rig_agent::Agent) -> Result<(), rig_agent::completion::PromptError> {
//! let response = agent.prompt("Explain ownership.").await?;
//! println!("{}", response.output());
//! # Ok(())
//! # }
//! ```

use super::hook::{HookStack, RequestPatch};
use super::run::{AgentRun, OutputMode};
use super::runner::AgentRunner;
use super::typed::TypedRun;
use crate::bus::{BusDriver, Dispatcher, ModelHandle};
use crate::{
    completion::{CompletionRequest, Document, Message, PromptError, ToolDefinition},
    run::response::PromptResponse,
    tool::{
        ToolCatalog,
        server::{ToolServerError, ToolServerHandle},
    },
};
use rig_core::completion::ModelRef;
use rig_core::effect::{HandlerDescriptor, HandlerKey, Key, family};
use rig_core::error::ProviderError;
use rig_core::id::ConversationId;

use super::drive::AgentBus;
use rig_core::{message::ToolChoice, wasm_compat::WasmCompatSend};
use std::sync::Arc;

use super::UNKNOWN_AGENT_NAME;

/// What a completion request was prepared with, including the executable Rig
/// tool names advertised to the provider for this turn.
pub(crate) struct PreparedCompletionRequest {
    /// The messages telemetry records for this attempt.
    pub(crate) telemetry_messages: Vec<Message>,
    /// The typed view the request is dispatched to.
    pub(crate) model: ModelHandle,
    /// Exact implementations behind this turn's provider definitions.
    pub(crate) tool_snapshot: Arc<ToolCatalog>,
    /// The definitions the request carries (executable tools plus, in Tool
    /// output mode, the synthetic output tool), for the run's `TurnTools`.
    pub(crate) advertised_tools: Vec<ToolDefinition>,
    /// The turn's tool policy, fed back to the run with the response.
    pub(crate) policy: crate::run::TurnPolicy,
    /// Effective structured output-token cap after runner overrides and request
    /// patches. Does not interpret caps passed through additional parameters.
    pub(crate) max_tokens: Option<u64>,
}

/// Retrieve tools and prepare a request from runner defaults and per-turn inputs.
/// Pins executable registrations and the selected model for this attempt.
/// Returns retrieval, preparation, and message-validation failures.
pub(crate) async fn build_prepared_completion_request(
    runner: &crate::agent::AgentRunner,
    ctx: &crate::agent::HookContext,
    model: &ModelHandle,
    prompt: Message,
    chat_history: &[Message],
    committed_output_tool: Option<&str>,
    request_patch: Option<&RequestPatch>,
) -> Result<(CompletionRequest, PreparedCompletionRequest), ProviderError> {
    let record_telemetry_content = runner.config.record_telemetry_content;
    let tool_server_handle = &runner.tool_server_handle;

    let retrieval_query = prompt.rag_text().or_else(|| {
        chat_history
            .iter()
            .rev()
            .find_map(rig_core::completion::Message::rag_text)
    });

    // Tool retrieval is a `Retrieve` dispatch at the boundary (observe-only
    // for hooks unless one opts in), recorded like every other effect.
    let mut dynamic_tool_ids = Vec::new();
    for (key, kind) in tool_server_handle.retrieval_effects(retrieval_query) {
        let ids = crate::agent::engine::dispatch_effect(runner, ctx, &key, kind)
            .await
            .and_then(|outcome| match outcome {
                rig_core::effect::Outcome::Documents(
                    rig_core::effect::RetrievedDocuments::Ids(ids),
                ) => Ok(ids.into_iter().map(|(_, id)| id).collect::<Vec<String>>()),
                other => Err(crate::agent::engine::wrong_outcome("retrieved ids", &other)),
            })
            .map_err(|report| {
                ProviderError::request(format!("Failed to get tool definitions: {report}"))
            })?;
        dynamic_tool_ids.extend(ids);
    }
    let mut tool_snapshot = tool_server_handle.snapshot_with_dynamic(&dynamic_tool_ids);

    let mut spec = runner.config.run_spec();
    spec.output_tool_description
        .clone_from(&runner.output_tool_description);
    spec.augment_output_preamble = runner.augment_output_preamble;
    let capabilities = model.capabilities();
    let committed_output_tool = if unforce_output_tool(runner, &capabilities, &mut spec) {
        None
    } else {
        committed_output_tool
    };

    let prepared = crate::run::prepare::prepare_request(
        &spec,
        &capabilities,
        chat_history,
        tool_snapshot.take_definitions(),
        committed_output_tool,
        request_patch,
    )?;

    // Narrow dispatch to the tools actually advertised this turn (a per-turn
    // `active_tools` allow-list), so the implementation behind every definition
    // the provider received is the one that runs.
    tool_snapshot.retain_names(prepared.policy.executable());

    let advertised_tools = prepared.tools.clone();
    let policy = prepared.policy.clone();
    let max_tokens = prepared.max_tokens;
    // The agent records the input itself, so the request the provider sees
    // carries the telemetry flag off: one span, no double recording.
    let request = prepared
        .apply(CompletionRequest::new(prompt))
        .accept_unknown_finish_reasons(runner.config.accept_unknown_finish_reasons);
    let telemetry_messages = if record_telemetry_content {
        request.messages_for_telemetry()
    } else {
        Vec::new()
    };
    let prepared = PreparedCompletionRequest {
        telemetry_messages,
        model: model.clone(),
        tool_snapshot: Arc::new(tool_snapshot),
        advertised_tools,
        policy,
        max_tokens,
    };
    Ok((request, prepared))
}

/// Rig's own structured-output flow (the extractor) forces its output tool.
/// For a model that rejects a forced tool choice, drop that force: use native
/// structured output where the wire composes it with tools, else keep the
/// output tool at `auto`, and say so in the preamble either way. A caller's
/// own forced choice outside that flow is left alone. Returns whether the
/// output tool was replaced by native output.
fn unforce_output_tool(
    runner: &crate::agent::AgentRunner,
    capabilities: &rig_core::completion::ProviderCapabilities,
    spec: &mut crate::run::spec::RunSpec,
) -> bool {
    let Some(name) = runner.output_tool_name.as_deref() else {
        return false;
    };
    let forced = matches!(
        spec.tool_choice,
        Some(ToolChoice::Required | ToolChoice::Specific { .. })
    );
    if !capabilities.rejects_forced_tool_choice || !forced || spec.output_schema.is_none() {
        return false;
    }
    spec.tool_choice = None;
    let native = capabilities.composes_native_output_with_tools;
    let line = if native {
        format!(
            "The `{name}` tool is not available for this model. Reply with only the JSON \
             object you would have passed to it."
        )
    } else {
        format!("Call the `{name}` tool with your answer instead of replying in text.")
    };
    spec.preamble = Some(match spec.preamble.take() {
        Some(preamble) => format!("{preamble}\n\n{line}"),
        None => line,
    });
    if native {
        spec.output_mode = OutputMode::Native;
    }
    native
}

/// Configured model, request settings, hooks, memory, and tool registry for runs.
/// Per-run overrides and dynamic retrieval determine each turn's effective request.
///
/// Default hooks attached with [`AgentBuilder::add_hook`](crate::agent::AgentBuilder::add_hook)
/// are used for every prompt request, plus any added on the request or runner.
///
/// # Example
/// ```no_run
/// use rig_agent::prelude::*;
/// use rig_core::{Model, providers::openai::{self, OpenAI}};
///
/// # async fn run() -> Result<(), Box<dyn std::error::Error>> {
/// let model = OpenAI::from_env()?.completion(openai::GPT_5_2);
///
/// let comedian_agent = AgentBuilder::new(model)
///     .preamble("You are a comedian here to entertain the user using humour and jokes.")
///     .temperature(0.9)
///     .build();
///
/// let response = comedian_agent.prompt("Entertain me!").await?;
/// # Ok(())
/// # }
/// ```
#[derive(Clone)]
pub struct Agent {
    pub(crate) config: AgentConfig,
    pub(crate) tool_server_handle: ToolServerHandle,
}

/// Configuration shared by the builder and built agent, separate from tool state.
#[derive(Clone)]
pub(crate) struct AgentConfig {
    /// Name of the agent used for logging and debugging
    pub(crate) name: Option<String>,
    /// Agent description. Primarily useful when using sub-agents as part of an agent workflow and converting agents to other formats.
    pub(crate) description: Option<String>,
    /// The bus every run dispatches through.
    pub(crate) bus: AgentBus,
    /// The key of the default model on the bus.
    pub(crate) model_key: Key<family::Completion>,
    /// System prompt
    pub(crate) preamble: Option<String>,
    /// Context documents always available to the agent
    pub(crate) static_context: Vec<Document>,
    /// Additional parameters to be passed to the model
    pub(crate) additional_params: Option<serde_json::Value>,
    /// Portable generation options every request carries.
    pub(crate) options: rig_core::completion::GenerationOptions,
    /// Typed per-provider options every request carries.
    pub(crate) provider_options: rig_core::completion::ProviderOptions,
    /// Whether to record sensitive request, response, and tool content on GenAI spans.
    ///
    /// Defaults to `false`. Enabling this can expose prompts, retrieved context,
    /// tool results, model responses, and other sensitive or high-cardinality data
    /// through OpenTelemetry span attributes, which can increase observability
    /// backend storage and query costs.
    pub(crate) record_telemetry_content: bool,
    /// Whether a finish reason outside the normalized vocabulary ends a turn
    /// as a normal stop.
    pub(crate) accept_unknown_finish_reasons: bool,
    /// Maximum number of tokens for the completion
    pub(crate) max_tokens: Option<u64>,
    /// Temperature of the model
    pub(crate) temperature: Option<f64>,
    /// Whether or not the underlying LLM should be forced to use a tool before providing a response.
    pub(crate) tool_choice: Option<ToolChoice>,
    /// Total model-call budget, including the initial call and every retry or
    /// continuation. Defaults to `1` (the initial call only).
    pub(crate) max_turns: usize,
    /// Default hook stack applied to every prompt request and runner created
    /// from this agent. Empty by default.
    pub(crate) hooks: HookStack,
    /// Optional JSON Schema for structured output. When set, providers that support
    /// native structured outputs will constrain the model's response to match this schema.
    pub(crate) output_schema: Option<schemars::Schema>,
    /// How the schema is conveyed: output tool, native constraint, or prompt.
    pub(crate) output_mode: OutputMode,
    /// Optional conversation memory backend that loads/saves history per conversation id.
    pub(crate) memory_key: Option<Key<family::Memory>>,
    /// The models registered as routes at build (`model_route`), part of
    /// the required row: a program that can select them needs them served.
    pub(crate) route_keys: Vec<Key<family::Completion>>,
    /// The dynamic-context indexes registered at build
    /// (`dynamic_context`), part of the required row: every model call
    /// queries them.
    pub(crate) context_keys: Vec<Key<family::Retrieve>>,
    /// Optional conversation id used when none is set per-request.
    pub(crate) conversation_id: Option<ConversationId>,
    /// The anonymous model this value selected ([`Agent::set_model`],
    /// [`AgentRunner::using_model_value`]); its registration lives as long
    /// as the values sharing it.
    pub(crate) anonymous_model: Option<std::sync::Arc<super::drive::AnonymousModel>>,
}

impl AgentConfig {
    /// The unconfigured starting point for a builder over `model`.
    pub(crate) fn new(bus: AgentBus, model_key: Key<family::Completion>) -> Self {
        Self {
            name: None,
            description: None,
            bus,
            model_key,
            preamble: None,
            static_context: vec![],
            additional_params: None,
            options: rig_core::completion::GenerationOptions::default(),
            provider_options: rig_core::completion::ProviderOptions::default(),
            record_telemetry_content: false,
            accept_unknown_finish_reasons: false,
            max_tokens: None,
            temperature: None,
            tool_choice: None,
            max_turns: 1,
            hooks: HookStack::new(),
            route_keys: Vec::new(),
            context_keys: Vec::new(),
            output_schema: None,
            output_mode: OutputMode::default(),
            memory_key: None,
            conversation_id: None,
            anonymous_model: None,
        }
    }

    /// Bind the default model's typed view.
    pub(crate) fn model_handle(&self) -> Result<ModelHandle, rig_core::error::ErrorReport> {
        self.bus.dispatcher().bind(&self.model_key)
    }

    /// The default model's label as registered now (the key's tail when
    /// nothing serves it).
    pub(crate) fn model_label(&self) -> ModelRef {
        match self
            .bus
            .dispatcher()
            .descriptor(self.model_key.raw())
            .map(|descriptor| descriptor.family)
        {
            Some(rig_core::effect::FamilyDescriptor::Completion { model, .. }) => model,
            Some(rig_core::effect::FamilyDescriptor::Tool { .. })
            | Some(rig_core::effect::FamilyDescriptor::Embed { .. })
            | Some(rig_core::effect::FamilyDescriptor::Memory {})
            | Some(rig_core::effect::FamilyDescriptor::Retrieve {})
            | Some(rig_core::effect::FamilyDescriptor::Rerank { .. })
            | Some(rig_core::effect::FamilyDescriptor::Custom { .. })
            | None => ModelRef::new(
                self.bus
                    .model_label(self.model_key.raw())
                    .unwrap_or(self.model_key.as_str()),
            ),
        }
    }

    /// Bind the model registered under `label`.
    pub(crate) fn model_by_ref(
        &self,
        label: &ModelRef,
    ) -> Result<ModelHandle, rig_core::error::ErrorReport> {
        self.bus
            .dispatcher()
            .bind(&self.bus.model_key(label.as_str()))
    }

    /// Bind the memory handle, when memory is configured.
    pub(crate) fn memory_handle(
        &self,
    ) -> Option<Result<crate::bus::MemoryHandle, rig_core::error::ErrorReport>> {
        self.memory_key
            .as_ref()
            .map(|key| self.bus.dispatcher().bind(key))
    }
}

impl AgentConfig {
    /// The protocol-facing half of this configuration as plain data: what a
    /// driver needs to shape requests and budget a run, without the model,
    /// hooks, memory or identity this config also carries.
    pub(crate) fn run_spec(&self) -> crate::run::spec::RunSpec {
        crate::run::spec::RunSpec {
            preamble: self.preamble.clone(),
            static_context: self.static_context.clone(),
            additional_params: self.additional_params.clone(),
            options: self.options.clone(),
            provider_options: self.provider_options.clone(),
            max_tokens: self.max_tokens,
            temperature: self.temperature,
            tool_choice: self.tool_choice.clone(),
            max_turns: Some(self.max_turns),
            max_invalid_tool_call_retries: 0,
            max_consecutive_malformed_tool_calls: None,
            output_schema: self
                .output_schema
                .as_ref()
                .map(|schema| schema.as_value().clone()),
            output_mode: self.output_mode.clone(),
            output_tool_name: None,
            output_tool_description: None,
            augment_output_preamble: true,
            unhandled_invalid_tool_call: crate::run::spec::UnhandledInvalidToolCall::Fail,
            accept_unknown_finish_reasons: self.accept_unknown_finish_reasons,
        }
    }
}

impl Agent {
    /// Return serializable request settings and run policy, excluding live models,
    /// tools, hooks, and memory.
    pub fn run_spec(&self) -> crate::run::spec::RunSpec {
        self.config.run_spec()
    }
}

impl Agent {
    /// The tool server this agent dispatches tool calls through. Cloning the
    /// handle lets external tool sources (an MCP client handler, for example)
    /// register and refresh tools the agent will see on its next turn.
    pub fn tool_server_handle(&self) -> &crate::tool::server::ToolServerHandle {
        &self.tool_server_handle
    }

    /// Returns the configured agent name.
    pub fn name(&self) -> Option<&str> {
        self.config.name.as_deref()
    }

    /// Returns the configured agent description.
    pub fn description(&self) -> Option<&str> {
        self.config.description.as_deref()
    }

    pub(crate) fn name_or_default(&self) -> &str {
        self.name().unwrap_or(UNKNOWN_AGENT_NAME)
    }

    /// The key of this agent's default model on its bus (a completion key;
    /// `.raw()` for the wire string).
    pub fn model_key(&self) -> &Key<family::Completion> {
        &self.config.model_key
    }

    /// The descriptor of this agent's default model, as registered now.
    pub fn model_descriptor(&self) -> Option<HandlerDescriptor> {
        self.config
            .bus
            .dispatcher()
            .descriptor(self.config.model_key.raw())
    }

    /// The label of this agent's default model, as registered now.
    pub fn model_label(&self) -> Option<ModelRef> {
        self.model_descriptor()
            .and_then(|descriptor| match descriptor.family {
                rig_core::effect::FamilyDescriptor::Completion { model, .. } => Some(model),
                rig_core::effect::FamilyDescriptor::Tool { .. }
                | rig_core::effect::FamilyDescriptor::Embed { .. }
                | rig_core::effect::FamilyDescriptor::Memory {}
                | rig_core::effect::FamilyDescriptor::Retrieve {}
                | rig_core::effect::FamilyDescriptor::Rerank { .. }
                | rig_core::effect::FamilyDescriptor::Custom { .. } => None,
            })
    }

    /// Register `model` on this agent's bus under `label` and return the
    /// label a run selects it by.
    pub fn register_model(
        &self,
        label: impl Into<ModelRef>,
        model: impl Into<rig_core::DynModel<rig_core::operation::Completion>>,
    ) -> ModelRef {
        let label = label.into();
        self.config.bus.register_model(&label, model);
        label
    }

    /// Make the model registered under `label` this agent value's default.
    /// Value semantics: clones of the agent keep their own default.
    pub fn set_model_label(&mut self, label: impl Into<ModelRef>) {
        self.config.model_key = self.config.bus.model_key(label.into().as_str());
        self.config.anonymous_model = None;
    }

    /// Register `model` under a generated label and make it this agent
    /// value's default. The registration is scoped to the values that
    /// select it (this agent, its clones, the runners it produces): it
    /// leaves the bus when the last of them drops or selects another model.
    pub fn set_model(
        &mut self,
        model: impl Into<rig_core::DynModel<rig_core::operation::Completion>>,
    ) {
        let anonymous = self.config.bus.register_anonymous_model(model);
        self.config.model_key = anonymous.key().clone();
        self.config.anonymous_model = Some(anonymous);
    }

    /// The owner segment of the keys this agent minted
    /// (`<owner>/model:<label>`, `<owner>/memory`, ...): the label given to
    /// [`AgentBuilder::owner`](crate::agent::AgentBuilder::owner), else
    /// `agent#<n>`.
    pub fn owner(&self) -> &str {
        self.config.bus.owner()
    }

    /// [`Agent::set_model_label`] by value.
    pub fn with_model_label(mut self, label: impl Into<ModelRef>) -> Self {
        self.set_model_label(label);
        self
    }

    /// [`Agent::set_model`] by value.
    pub fn with_model(
        mut self,
        model: impl Into<rig_core::DynModel<rig_core::operation::Completion>>,
    ) -> Self {
        self.set_model(model);
        self
    }

    /// The effect row this program can dispatch to: its model, every tool
    /// the registry serves, its memory backend and its retrieval indexes,
    /// each with the family it needs, from the registry rather than what a
    /// run happened to dispatch.
    pub fn required_row(&self) -> rig_core::effect::EffectRow {
        use rig_core::effect::EffectFamily;
        let mut row = rig_core::effect::EffectRow::new();
        row.insert(
            self.config.model_key.raw().clone(),
            EffectFamily::Completion,
        );
        for route in &self.config.route_keys {
            row.insert(route.raw().clone(), EffectFamily::Completion);
        }
        if let Some(memory) = &self.config.memory_key {
            row.insert(memory.raw().clone(), EffectFamily::Memory);
        }
        for (_, tool) in self.tool_server_handle.toolset().iter() {
            row.insert(tool.key().raw().clone(), EffectFamily::Tool);
        }
        for key in self.tool_server_handle.retrieval_keys() {
            row.insert(key, EffectFamily::Retrieve);
        }
        for context in &self.config.context_keys {
            row.insert(context.raw().clone(), EffectFamily::Retrieve);
        }
        row
    }

    /// What decides on this agent's behalf: its hook stack's names, then
    /// every layer on the bus's handlers (the handler table's order,
    /// outermost in). The log's `hooks`; a replay under another stack of
    /// either is refused.
    pub fn program_names(&self) -> Vec<String> {
        let mut names = self.config.hooks.names();
        for descriptor in self.config.bus.dispatcher().descriptors() {
            names.extend(descriptor.layers);
        }
        names
    }

    /// The policy this agent's own bus runs under; `None` over a host's bus.
    pub fn bus_config(&self) -> Option<rig_core::serve::ServingPolicy> {
        self.config.bus.config()
    }

    /// The descriptor currently registered under `key`, without access to dispatch.
    pub fn handler_descriptor(&self, key: &HandlerKey) -> Option<HandlerDescriptor> {
        self.config.bus.dispatcher().descriptor(key)
    }

    /// Whether this agent owns and drives its own bus driver.
    pub fn owns_bus(&self) -> bool {
        self.config.bus.owns_driver()
    }

    /// Take the agent apart: the dispatcher and the driver leave together,
    /// so whoever gets the dispatcher also gets the duty to drive. Fails
    /// when the agent was built over a host's bus or when another clone of
    /// it still shares the driver.
    pub fn into_parts(self) -> Result<AgentParts, Agent> {
        let Agent {
            mut config,
            tool_server_handle,
        } = self;
        let detached = config.bus.detached();
        let bus = std::mem::replace(&mut config.bus, detached);
        let registrar = bus.registrar().clone();
        match bus.try_into_parts() {
            Ok((dispatcher, driver)) => Ok(AgentParts {
                dispatcher,
                registrar,
                driver,
                agent: Agent {
                    config,
                    tool_server_handle,
                },
            }),
            Err(bus) => {
                config.bus = bus;
                Err(Agent {
                    config,
                    tool_server_handle,
                })
            }
        }
    }

    /// Resolve the provider-facing tool definitions available for a prompt.
    ///
    /// This read-only view does not expose tool dispatch. Agent execution and
    /// tool lifecycle hooks remain owned by [`Self::prompt`].
    pub async fn tool_definitions(
        &self,
        prompt: Option<String>,
    ) -> Result<Vec<ToolDefinition>, ToolServerError> {
        self.tool_server_handle.tool_defs(prompt).await
    }
}

impl Agent {
    /// Start a run from `prompt`. The returned [`AgentRunner`] is the run:
    /// configure it (history, turn budget, tool context, hooks, …), then pick
    /// how to drive it. Nothing happens until it is driven.
    ///
    /// - `.await` (or [`run`](AgentRunner::run)) folds the whole loop to a
    ///   [`PromptResponse`], whose `output` is the accepted assistant text.
    /// - [`stream`](AgentRunner::stream) yields every provider delta, tool
    ///   event and the final response as a stream.
    /// - [`run_channel`](AgentRunner::run_channel) splits the run into a
    ///   future and an event feed for a host with its own executor or tick.
    ///
    /// The medium is chosen by the terminal call alone: an awaited runner asks
    /// the provider for a complete response, a streamed one for a stream.
    /// Hooks, tools, memory and the resulting history are the same in each.
    ///
    /// ```rust,no_run
    /// # use rig_agent::Agent;
    /// # use futures::StreamExt;
    /// # async fn example(agent: Agent) -> Result<(), Box<dyn std::error::Error>> {
    /// let response = agent.prompt("What is 2 + 2?").max_turns(3).await?;
    /// println!("{}", response.output());
    ///
    /// let mut stream = agent.prompt("And 3 + 3?").stream();
    /// while let Some(item) = stream.next().await {
    ///     let item = item?;
    ///     // text deltas, tool calls and results, then `FinalResponse`
    /// }
    /// # Ok(())
    /// # }
    /// ```
    pub fn prompt(&self, prompt: impl Into<Message>) -> AgentRunner {
        AgentRunner::from_agent(self, prompt)
    }

    /// Continue a persisted run instead of starting one from a prompt.
    ///
    /// The state a driver serialized between steps (see [`AgentRun`]) is
    /// resumed under this agent's hooks, tools, and bus, executing pending tool
    /// calls or requesting the next model turn.
    /// The run is authoritative for what it persisted: its prompt, its
    /// history, its turn budget, its invalid-tool-call retry budget and its
    /// unhandled-invalid-tool-call policy, so
    /// [`history`](AgentRunner::history), [`max_turns`](AgentRunner::max_turns)
    /// and [`unhandled_invalid_tool_call`](AgentRunner::unhandled_invalid_tool_call)
    /// on the returned runner have no effect. Everything else still comes
    /// from the agent and the runner: the request shape (preamble, documents,
    /// sampling parameters, additional params, tool choice, output mode),
    /// [`add_hook`](AgentRunner::add_hook),
    /// [`tool_context`](AgentRunner::tool_context),
    /// [`tool_concurrency`](AgentRunner::tool_concurrency), the model
    /// selection and telemetry settings (inbound tool context is driver
    /// state, never part of the persisted run). Invalid-call hooks see, and a
    /// `Skip` is gated by, the tool choice each turn was sent with. One
    /// run-side value still shows through: the output tool the run pinned
    /// stays pinned even though the schema and mode advertising it are the
    /// runner's.
    /// Conversation memory is neither
    /// loaded nor appended: the history is already in the run, and the driver
    /// that persisted it owns memory persistence and appends the finished run's
    /// `messages` itself, since a suspended run never reached the `Done`
    /// append, so the response's `memory_append` is `None`. Unanswered tool
    /// calls re-execute on resume: a tool that ran before the suspension but
    /// whose result was not fed to the run runs again (at least once), while
    /// answered calls keep their results. Drive it like any runner: `.await`,
    /// [`stream`](AgentRunner::stream) or
    /// [`run_channel`](AgentRunner::run_channel). The run must have been
    /// suspended by the same rig version.
    ///
    /// ```rust,no_run
    /// # use rig_agent::{Agent, AgentRun};
    /// # async fn example(agent: Agent, saved: &str) -> Result<(), Box<dyn std::error::Error>> {
    /// let run: AgentRun = serde_json::from_str(saved)?;
    /// let response = agent.resume(run).tool_concurrency(4).await?;
    /// # Ok(())
    /// # }
    /// ```
    pub fn resume(&self, run: AgentRun) -> AgentRunner {
        AgentRunner::resuming(self, run)
    }

    /// Run `prompt` against caller-owned history with the agent's defaults,
    /// then append the messages the run committed to `chat_history`. This is
    /// [`prompt`](Self::prompt) with [`history`](AgentRunner::history) plus
    /// the write-back; the runner form is the one to configure or stream.
    /// The returned [`PromptResponse`] keeps its `messages`.
    ///
    /// The caller's history is the run's input history, so conversation
    /// memory is bypassed (no load, no append) and the caller owns
    /// persistence. A run that fails appends nothing: the error carries the
    /// history the run had, the caller's vector is unchanged.
    #[tracing::instrument(skip(self, prompt, chat_history), fields(agent_name = self.name_or_default()))]
    pub async fn chat(
        &self,
        prompt: impl Into<Message> + WasmCompatSend,
        chat_history: &mut Vec<Message>,
    ) -> Result<PromptResponse, PromptError> {
        let response = AgentRunner::from_agent(self, prompt)
            .history(chat_history.clone())
            .await?;
        chat_history.extend(response.messages.iter().cloned());
        Ok(response)
    }

    /// Run `prompt` and deserialize the accepted structured response as `T`.
    ///
    /// The JSON schema for `T` is generated and sent to the provider as the
    /// run's structured-output schema. Providers that support native structured
    /// outputs constrain the model's response to match it.
    ///
    /// ```no_run
    /// # async fn example(agent: rig_agent::Agent) -> Result<(), Box<dyn std::error::Error>> {
    /// #[derive(Debug, serde::Deserialize, schemars::JsonSchema)]
    /// struct WeatherForecast { city: String, temperature_f: f64 }
    /// let forecast = agent
    ///     .prompt_typed::<WeatherForecast>("What's the weather in NYC?")
    ///     .max_turns(3)
    ///     .await?
    ///     .output;
    /// # Ok(())
    /// # }
    /// ```
    pub fn prompt_typed<T>(&self, prompt: impl Into<Message>) -> TypedRun<T>
    where
        T: JsonSchema + DeserializeOwned + WasmCompatSend,
    {
        TypedRun::native(self, prompt)
    }
}

use schemars::JsonSchema;
use serde::de::DeserializeOwned;

#[cfg(test)]
mod request_identity_tests;

/// An agent taken apart by [`Agent::into_parts`]: the same agent, now over
/// the bus as a host would hold it, plus the dispatcher and the driver.
pub struct AgentParts {
    /// The bus's client half.
    pub dispatcher: Dispatcher,
    /// The bus's registration handle: register on the bus once the driver
    /// is spawned.
    pub registrar: crate::bus::Registrar,
    /// The bus's serving half: spawn it or drive it, or the agent hangs.
    pub driver: BusDriver,
    /// The agent, now over the bus rather than owning it.
    pub agent: Agent,
}
