//! Groq live coverage for batch multi-extract pipelines.
use rig_test_support::cassette_models::OpenAiModels;
use std::future::IntoFuture;

use anyhow::Result;
use futures::stream::{StreamExt, TryStreamExt};
use rig::providers::openai::wire::GROQ;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::support::assert_nonempty_response;

use super::{MULTI_EXTRACT_NAMES_MODEL, MULTI_EXTRACT_SENTIMENT_MODEL, MULTI_EXTRACT_TOPICS_MODEL};

#[derive(Debug, Deserialize, JsonSchema, Serialize)]
struct Names {
    names: Vec<String>,
}

#[derive(Debug, Deserialize, JsonSchema, Serialize)]
struct Topics {
    topics: Vec<String>,
}

#[derive(Debug, Deserialize, JsonSchema, Serialize)]
struct Sentiment {
    sentiment: f64,
    confidence: f64,
}

#[tokio::test]
#[ignore = "requires GROQ_API_KEY"]
async fn batch_multi_extract_chain() -> Result<()> {
    let groq = OpenAiModels::from_env_for(&GROQ).expect("GROQ_API_KEY should be set");
    let names_extractor =
        rig::extractor::ExtractorBuilder::<Names>::new(groq.completion(MULTI_EXTRACT_NAMES_MODEL))
            .append_preamble("Extract names from the given text.")
            .retries(2)
            .build();
    let topics_extractor = rig::extractor::ExtractorBuilder::<Topics>::new(
        groq.completion(MULTI_EXTRACT_TOPICS_MODEL),
    )
    .append_preamble("Extract topics from the given text.")
    .retries(2)
    .build();
    let sentiment_extractor = rig::extractor::ExtractorBuilder::<Sentiment>::new(
        groq.completion(MULTI_EXTRACT_SENTIMENT_MODEL),
    )
    .append_preamble("Extract sentiment and confidence from the given text.")
    .retries(2)
    .build();

    let inputs = vec![
        "Ada Lovelace discussed analytical engines and early programming.",
        "I love my dog, but I hate rainy weather.",
        "I'm going to the store to buy milk and bread.",
    ];
    let responses: Vec<String> = futures::stream::iter(inputs)
        .map(|text| {
            let names_extractor = &names_extractor;
            let topics_extractor = &topics_extractor;
            let sentiment_extractor = &sentiment_extractor;
            async move {
                let (names, topics, sentiment) = futures::try_join!(
                    names_extractor.extract(text).into_future(),
                    topics_extractor.extract(text).into_future(),
                    sentiment_extractor.extract(text).into_future(),
                )?;
                anyhow::Ok(format!(
                    "Extracted names: {}\nExtracted topics: {}\nExtracted sentiment: {} ({})",
                    names.output.names.join(", "),
                    topics.output.topics.join(", "),
                    sentiment.output.sentiment,
                    sentiment.output.confidence,
                ))
            }
        })
        .buffered(4)
        .try_collect()
        .await?;

    anyhow::ensure!(
        responses.len() == 3,
        "expected three responses, got {}",
        responses.len()
    );
    for response in responses {
        assert_nonempty_response(&response);
    }

    Ok(())
}
