//! Explicit conversation renderers and generated-output parsers.

use std::collections::{HashMap, HashSet};

use rig_core::completion::{AssistantContent, CompletionRequest, ToolDefinition};
use rig_core::message::{
    CallId, Message, Reasoning, ToolCall, ToolChoice, ToolFunction, ToolName, ToolResultContent,
    UserContent,
};
use serde::Deserialize;

use crate::{
    BEGIN_OF_TEXT, CandleError, ConversationProtocol, END_HEADER, END_OF_TURN, IM_END, IM_START,
    SMOLLM2_DEFAULT_SYSTEM_PROMPT, START_HEADER,
};

const TOOL_CALL_START: &str = "<tool_call>";
const TOOL_CALL_END: &str = "</tool_call>";
const TOOL_RESPONSE_START: &str = "<tool_response>";
const TOOL_RESPONSE_END: &str = "</tool_response>";
const THINK_START: &str = "<think>";
const THINK_END: &str = "</think>";

const QWEN_TOOLS_PREAMBLE: &str = "# Tools\n\nYou may call one or more functions to assist with the user query.\n\nYou are provided with function signatures within <tools></tools> XML tags:\n<tools>";
const QWEN_TOOLS_SUFFIX: &str = "\n</tools>\n\nFor each function call, return a json object with function name and arguments within <tool_call></tool_call> XML tags:\n<tool_call>\n{\"name\": <function-name>, \"arguments\": <args-json-object>}\n</tool_call>";
const QWEN_REQUIRED_INSTRUCTION: &str =
    "\n\nYou must call at least one of the functions provided above before answering.";

#[derive(Debug)]
pub(crate) struct ParsedAssistant {
    pub(crate) items: Vec<AssistantContent>,
    pub(crate) visible_text: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct QwenToolCallEnvelope {
    #[serde(default)]
    id: Option<String>,
    name: String,
    arguments: serde_json::Value,
}

#[derive(Debug)]
enum RenderedMessage {
    Normal { role: &'static str, content: String },
    ToolResults(Vec<String>),
}

pub(crate) fn render_prompt(
    request: &CompletionRequest,
    protocol: ConversationProtocol,
) -> Result<String, CandleError> {
    validate_common_request(request)?;
    validate_protocol_inputs(request, protocol)?;
    match protocol {
        ConversationProtocol::Llama3 => render_plain_chat(request, ConversationProtocol::Llama3),
        ConversationProtocol::SmolLm2 => render_plain_chat(request, ConversationProtocol::SmolLm2),
        ConversationProtocol::Qwen3 => render_qwen3(request),
    }
}

fn reserved_markers(protocol: ConversationProtocol) -> &'static [&'static str] {
    match protocol {
        ConversationProtocol::Llama3 => &[BEGIN_OF_TEXT, START_HEADER, END_HEADER, END_OF_TURN],
        ConversationProtocol::SmolLm2 => &[IM_START, IM_END],
        ConversationProtocol::Qwen3 => &[
            IM_START,
            IM_END,
            "<tools>",
            "</tools>",
            TOOL_CALL_START,
            TOOL_CALL_END,
            TOOL_RESPONSE_START,
            TOOL_RESPONSE_END,
            THINK_START,
            THINK_END,
        ],
    }
}

fn validate_protocol_text(
    value: &str,
    field: &'static str,
    protocol: ConversationProtocol,
) -> Result<(), CandleError> {
    if let Some(marker) = reserved_markers(protocol)
        .iter()
        .find(|marker| value.contains(**marker))
    {
        return Err(CandleError::ReservedProtocolMarker { field, marker });
    }
    Ok(())
}

fn validate_protocol_inputs(
    request: &CompletionRequest,
    protocol: ConversationProtocol,
) -> Result<(), CandleError> {
    for tool in &request.tools {
        validate_protocol_text(&tool.description, "tool description", protocol)?;
        validate_protocol_text(
            &serde_json::to_string(&tool.parameters).map_err(|error| {
                CandleError::InvalidToolDefinition {
                    tool: tool.name.to_string(),
                    reason: format!("parameters cannot be serialized: {error}"),
                }
            })?,
            "tool schema",
            protocol,
        )?;
    }
    for message in request.chat_history.iter() {
        match message {
            Message::System { content } => {
                validate_protocol_text(content, "system message", protocol)?;
            }
            Message::Assistant(turn) => {
                for item in turn.content.iter() {
                    match item {
                        AssistantContent::Text(text) => {
                            validate_protocol_text(&text.text, "assistant text", protocol)?;
                        }
                        AssistantContent::Reasoning(reasoning) => validate_protocol_text(
                            &reasoning.text,
                            "assistant reasoning",
                            protocol,
                        )?,
                        AssistantContent::ToolCall(call) => {
                            validate_protocol_text(
                                &call.function.name,
                                "historical tool name",
                                protocol,
                            )?;
                            validate_protocol_text(
                                &serde_json::to_string(&call.function.arguments).map_err(
                                    |error| {
                                        CandleError::MalformedToolCall(format!(
                                            "historical arguments cannot be serialized: {error}"
                                        ))
                                    },
                                )?,
                                "historical tool arguments",
                                protocol,
                            )?;
                        }
                        _ => {}
                    }
                }
            }
            Message::User { content } => {
                for item in content.iter() {
                    match item {
                        UserContent::Text(text) => {
                            validate_protocol_text(&text.text, "user text", protocol)?;
                        }
                        UserContent::ToolResult(result) => {
                            for item in result.content.iter() {
                                match item {
                                    ToolResultContent::Text(text) => {
                                        validate_protocol_text(
                                            &text.text,
                                            "tool result",
                                            protocol,
                                        )?;
                                    }
                                    ToolResultContent::Json { value } => validate_protocol_text(
                                        &serde_json::to_string(value).map_err(|_| {
                                            CandleError::UnsupportedPromptContent(
                                                "unserializable JSON tool result",
                                            )
                                        })?,
                                        "JSON tool result",
                                        protocol,
                                    )?,
                                    ToolResultContent::Image(_) => {}
                                }
                            }
                        }
                        UserContent::Image(_)
                        | UserContent::Audio(_)
                        | UserContent::Video(_)
                        | UserContent::Document(_) => {}
                    }
                }
            }
        }
    }
    Ok(())
}

pub(crate) fn parse_assistant(
    raw: &str,
    request: &CompletionRequest,
    protocol: ConversationProtocol,
) -> Result<ParsedAssistant, CandleError> {
    match protocol {
        ConversationProtocol::Llama3 | ConversationProtocol::SmolLm2 => Ok(ParsedAssistant {
            items: vec![AssistantContent::text(raw)],
            visible_text: raw.to_string(),
        }),
        ConversationProtocol::Qwen3 => parse_qwen3_assistant(raw, request),
    }
}

fn validate_common_request(request: &CompletionRequest) -> Result<(), CandleError> {
    if request.output_schema.is_some() {
        return Err(CandleError::UnsupportedFeature(
            "direct output_schema requires constrained decoding; use Rig's tool output mode"
                .to_string(),
        ));
    }
    Ok(())
}

fn selected_tools(
    request: &CompletionRequest,
) -> Result<(Vec<&ToolDefinition>, bool), CandleError> {
    for tool in &request.tools {
        validate_tool_definition(tool)?;
    }

    let choice = request.tool_choice.as_ref().unwrap_or(&ToolChoice::Auto);
    match choice {
        ToolChoice::Auto => Ok((request.tools.iter().collect(), false)),
        ToolChoice::None => Ok((Vec::new(), false)),
        ToolChoice::Required => {
            if request.tools.is_empty() {
                return Err(CandleError::ToolChoiceViolation(
                    "required tool choice was requested without any tools".to_string(),
                ));
            }
            Ok((request.tools.iter().collect(), true))
        }
        ToolChoice::Specific { function_names } => {
            if function_names.is_empty() {
                return Err(CandleError::ToolChoiceViolation(
                    "specific tool choice must contain at least one function name".to_string(),
                ));
            }
            let mut requested = HashSet::new();
            for name in function_names {
                if !requested.insert(name.as_str()) {
                    return Err(CandleError::ToolChoiceViolation(format!(
                        "specific tool choice contains duplicate function `{name}`"
                    )));
                }
                if !request.tools.iter().any(|tool| tool.name == *name) {
                    return Err(CandleError::ToolChoiceViolation(format!(
                        "specific tool `{name}` is not present in the request"
                    )));
                }
            }
            Ok((
                request
                    .tools
                    .iter()
                    .filter(|tool| requested.contains(tool.name.as_str()))
                    .collect(),
                true,
            ))
        }
    }
}

fn validate_tool_definition(tool: &ToolDefinition) -> Result<(), CandleError> {
    let valid_name = tool.name.len() <= 64
        && tool
            .name
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'-'));
    if !valid_name {
        return Err(CandleError::InvalidToolDefinition {
            tool: tool.name.to_string(),
            reason: "name must contain 1-64 ASCII letters, digits, underscores, or hyphens"
                .to_string(),
        });
    }
    let parameters =
        tool.parameters
            .as_object()
            .ok_or_else(|| CandleError::InvalidToolDefinition {
                tool: tool.name.to_string(),
                reason: "parameters must be a JSON Schema object".to_string(),
            })?;
    if parameters
        .get("type")
        .and_then(serde_json::Value::as_str)
        .is_some_and(|kind| kind != "object")
    {
        return Err(CandleError::InvalidToolDefinition {
            tool: tool.name.to_string(),
            reason: "the root parameter schema type must be `object` when present".to_string(),
        });
    }
    serde_json::to_string(&tool.parameters).map_err(|error| {
        CandleError::InvalidToolDefinition {
            tool: tool.name.to_string(),
            reason: format!("parameters cannot be serialized: {error}"),
        }
    })?;
    Ok(())
}

fn render_plain_chat(
    request: &CompletionRequest,
    family: ConversationProtocol,
) -> Result<String, CandleError> {
    if !request.tools.is_empty() {
        return Err(CandleError::UnsupportedFeature(
            "tools require the Qwen3 conversation protocol".to_string(),
        ));
    }
    if request.tool_choice.is_some() {
        return Err(CandleError::UnsupportedFeature(
            "tool_choice requires the Qwen3 conversation protocol".to_string(),
        ));
    }
    let messages = &request.chat_history;
    type Pieces = &'static [&'static str];
    let (turn_start, role_suffix, turn_end, mut rendered): (&str, Pieces, Pieces, String) =
        match family {
            ConversationProtocol::Llama3 => (
                START_HEADER,
                &[END_HEADER, "\n\n"],
                &[END_OF_TURN],
                String::from(BEGIN_OF_TEXT),
            ),
            ConversationProtocol::SmolLm2 => (
                IM_START,
                &["\n"],
                &[IM_END, "\n"],
                if matches!(messages.first(), Some(Message::System { .. })) {
                    String::new()
                } else {
                    format!("{IM_START}system\n{SMOLLM2_DEFAULT_SYSTEM_PROMPT}{IM_END}\n")
                },
            ),
            ConversationProtocol::Qwen3 => {
                return Err(CandleError::UnsupportedModelFamily(
                    "Qwen3 requires its dedicated conversation renderer".to_string(),
                ));
            }
        };
    for message in messages {
        let (role, content) = render_plain_message(message)?;
        for piece in [&[turn_start, role][..], role_suffix, &[&content], turn_end].concat() {
            rendered.push_str(piece);
        }
    }
    rendered.extend([&[turn_start, "assistant"][..], role_suffix].concat());
    Ok(rendered)
}

fn unsupported_user_content(item: &UserContent) -> CandleError {
    CandleError::UnsupportedPromptContent(match item {
        UserContent::Text(_) => "text content",
        UserContent::ToolResult(_) => "tool results",
        UserContent::Image(_) => "image content",
        UserContent::Audio(_) => "audio content",
        UserContent::Video(_) => "video content",
        UserContent::Document(_) => "message document content",
    })
}

fn render_plain_message(message: &Message) -> Result<(&'static str, String), CandleError> {
    match message {
        Message::System { content } => Ok(("system", content.clone())),
        Message::User { content } => {
            let mut parts = Vec::new();
            for item in content.iter() {
                match item {
                    UserContent::Text(text) => parts.push(text.text.clone()),
                    unsupported => return Err(unsupported_user_content(unsupported)),
                }
            }
            Ok(("user", parts.join("\n")))
        }
        Message::Assistant(turn) => {
            let mut parts = Vec::new();
            for item in turn.content.iter() {
                match item {
                    AssistantContent::Text(text) => parts.push(text.text.clone()),
                    AssistantContent::ToolCall(_) => {
                        return Err(CandleError::UnsupportedPromptContent("tool calls"));
                    }
                    AssistantContent::Reasoning(_) => {
                        return Err(CandleError::UnsupportedPromptContent(
                            "structured reasoning",
                        ));
                    }
                    AssistantContent::Image(_) => {
                        return Err(CandleError::UnsupportedPromptContent("image content"));
                    }
                    AssistantContent::Opaque(_) => {
                        return Err(CandleError::UnsupportedPromptContent("provider items"));
                    }
                    _ => {
                        return Err(CandleError::UnsupportedPromptContent("assistant content"));
                    }
                }
            }
            Ok(("assistant", parts.join("\n")))
        }
    }
}

fn render_qwen3(request: &CompletionRequest) -> Result<String, CandleError> {
    let (tools, require_call) = selected_tools(request)?;
    let messages = &request.chat_history;
    let mut rendered = String::new();
    let mut first_message = 0;

    if !tools.is_empty() {
        rendered.push_str(IM_START);
        rendered.push_str("system\n");
        if let Some(Message::System { content }) = messages.first() {
            rendered.push_str(content);
            rendered.push_str("\n\n");
            first_message = 1;
        }
        rendered.push_str(QWEN_TOOLS_PREAMBLE);
        for tool in &tools {
            rendered.push('\n');
            let definition = serde_json::json!({
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": tool.parameters,
                }
            });
            rendered.push_str(&serde_json::to_string(&definition).map_err(|error| {
                CandleError::InvalidToolDefinition {
                    tool: tool.name.to_string(),
                    reason: format!("definition cannot be serialized: {error}"),
                }
            })?);
        }
        rendered.push_str(QWEN_TOOLS_SUFFIX);
        if require_call {
            rendered.push_str(QWEN_REQUIRED_INSTRUCTION);
        }
        rendered.push_str(IM_END);
        rendered.push('\n');
    } else if let Some(Message::System { content }) = messages.first() {
        rendered.push_str(IM_START);
        rendered.push_str("system\n");
        rendered.push_str(content);
        rendered.push_str(IM_END);
        rendered.push('\n');
        first_message = 1;
    }

    let mut aliases = HashMap::<String, CallId>::new();
    let mut unresolved = HashSet::<CallId>::new();
    let mut answered = HashSet::<CallId>::new();
    let mut rendered_messages = Vec::new();
    for message in messages.iter().skip(first_message) {
        rendered_messages.extend(render_qwen_message(
            message,
            &mut aliases,
            &mut unresolved,
            &mut answered,
        )?);
    }
    if let Some(call_id) = unresolved.iter().next() {
        return Err(CandleError::MalformedToolCall(format!(
            "historical tool call `{call_id}` has no correlated tool result"
        )));
    }

    let mut index = 0;
    while let Some(message) = rendered_messages.get(index) {
        match message {
            RenderedMessage::Normal { role, content } => {
                rendered.push_str(IM_START);
                rendered.push_str(role);
                rendered.push('\n');
                rendered.push_str(content);
                rendered.push_str(IM_END);
                rendered.push('\n');
                index += 1;
            }
            RenderedMessage::ToolResults(_) => {
                rendered.push_str(IM_START);
                rendered.push_str("user");
                while let Some(message) = rendered_messages.get(index) {
                    let RenderedMessage::ToolResults(results) = message else {
                        break;
                    };
                    for result in results {
                        rendered.push('\n');
                        rendered.push_str(TOOL_RESPONSE_START);
                        rendered.push('\n');
                        rendered.push_str(result);
                        rendered.push('\n');
                        rendered.push_str(TOOL_RESPONSE_END);
                    }
                    index += 1;
                }
                rendered.push_str(IM_END);
                rendered.push('\n');
            }
        }
    }

    rendered.push_str(IM_START);
    rendered.push_str("assistant\n");
    // This template prefix requests no-thinking mode; the parser still accepts
    // a leading reasoning block if the model emits one.
    rendered.push_str("<think>\n\n</think>\n\n");
    Ok(rendered)
}

fn render_qwen_message(
    message: &Message,
    aliases: &mut HashMap<String, CallId>,
    unresolved: &mut HashSet<CallId>,
    answered: &mut HashSet<CallId>,
) -> Result<Vec<RenderedMessage>, CandleError> {
    match message {
        Message::System { content } => Ok(vec![RenderedMessage::Normal {
            role: "system",
            content: content.clone(),
        }]),
        Message::Assistant(turn) => {
            let mut rendered = String::new();
            let mut call_count = 0usize;
            for item in turn.content.iter() {
                match item {
                    AssistantContent::Text(text) => rendered.push_str(&text.text),
                    AssistantContent::Reasoning(_) => {
                        // Official Qwen guidance omits historical thinking. The
                        // final answer and tool calls remain in history.
                    }
                    AssistantContent::ToolCall(call) => {
                        let call_key = call.id.clone();
                        if !unresolved.insert(call_key.clone()) {
                            return Err(CandleError::MalformedToolCall(format!(
                                "duplicate historical tool-call ID `{}`",
                                call.id
                            )));
                        }
                        if let Some(provider) = call.id.provider() {
                            let call_id = provider.as_str();
                            if aliases
                                .get(call_id)
                                .is_some_and(|existing| existing != &call_key)
                            {
                                return Err(CandleError::MalformedToolCall(format!(
                                    "duplicate historical tool call correlation ID `{call_id}`"
                                )));
                            }
                            aliases.insert(call_id.to_owned(), call_key.clone());
                        }
                        if call_count > 0 || !rendered.is_empty() {
                            rendered.push('\n');
                        }
                        let envelope = serde_json::json!({
                            "name": call.function.name,
                            "arguments": call.function.arguments,
                        });
                        rendered.push_str(TOOL_CALL_START);
                        rendered.push('\n');
                        rendered.push_str(&serde_json::to_string(&envelope).map_err(|error| {
                            CandleError::MalformedToolCall(format!(
                                "historical tool call cannot be serialized: {error}"
                            ))
                        })?);
                        rendered.push('\n');
                        rendered.push_str(TOOL_CALL_END);
                        call_count += 1;
                    }
                    AssistantContent::Image(_) => {
                        return Err(CandleError::UnsupportedPromptContent(
                            "assistant image content",
                        ));
                    }
                    AssistantContent::Opaque(_) => {
                        return Err(CandleError::UnsupportedPromptContent("provider items"));
                    }
                    _ => {
                        return Err(CandleError::UnsupportedPromptContent("assistant content"));
                    }
                }
            }
            Ok(vec![RenderedMessage::Normal {
                role: "assistant",
                content: rendered,
            }])
        }
        Message::User { content } => {
            // A user message the adapter merged holds results and then text:
            // the results render as one tool-response turn and the text as
            // the user turn after it, in their order.
            let mut segments: Vec<RenderedMessage> = Vec::new();
            for item in content.iter() {
                match item {
                    UserContent::Text(value) => match segments.last_mut() {
                        Some(RenderedMessage::Normal { content, .. }) => {
                            content.push('\n');
                            content.push_str(&value.text);
                        }
                        _ => segments.push(RenderedMessage::Normal {
                            role: "user",
                            content: value.text.clone(),
                        }),
                    },
                    UserContent::ToolResult(result) => {
                        let canonical_by_id = unresolved.get(&result.call);
                        // A recycled provider handle must not redirect a stale
                        // local result to a different outstanding occurrence.
                        // Direct local matches still permit completed-turn reuse.
                        if canonical_by_id.is_none() && answered.contains(&result.call) {
                            return Err(CandleError::UnmatchedToolResult {
                                result_id: result.call.to_string(),
                            });
                        }
                        let canonical_by_call_id = result
                            .call
                            .provider()
                            .and_then(|provider| aliases.get(provider.as_str()));
                        if let (Some(by_id), Some(by_call_id)) =
                            (canonical_by_id, canonical_by_call_id)
                            && by_id != by_call_id
                        {
                            return Err(CandleError::UnmatchedToolResult {
                                result_id: result.call.to_string(),
                            });
                        }
                        let canonical = canonical_by_id
                            .or(canonical_by_call_id)
                            .cloned()
                            .ok_or_else(|| CandleError::UnmatchedToolResult {
                                result_id: result.call.to_string(),
                            })?;
                        if !unresolved.remove(&canonical) {
                            return Err(CandleError::UnmatchedToolResult {
                                result_id: result.call.to_string(),
                            });
                        }
                        // Provider aliases name only outstanding occurrences.
                        // A later completed turn may legitimately reuse its IDs.
                        aliases.retain(|_, id| id != &canonical);
                        answered.insert(canonical);
                        answered.insert(result.call.clone());
                        let mut items = Vec::new();
                        for item in result.content.iter() {
                            match item {
                                ToolResultContent::Text(value) => items.push(value.text.clone()),
                                ToolResultContent::Json { value } => {
                                    items.push(serde_json::to_string(value).map_err(|error| {
                                        CandleError::UnsupportedPromptContent(if error.is_io() {
                                            "unserializable JSON tool result"
                                        } else {
                                            "invalid JSON tool result"
                                        })
                                    })?);
                                }
                                ToolResultContent::Image(_) => {
                                    return Err(CandleError::UnsupportedPromptContent(
                                        "image tool results",
                                    ));
                                }
                            }
                        }
                        let result = items.join("\n");
                        match segments.last_mut() {
                            Some(RenderedMessage::ToolResults(results)) => results.push(result),
                            _ => segments.push(RenderedMessage::ToolResults(vec![result])),
                        }
                    }
                    unsupported => return Err(unsupported_user_content(unsupported)),
                }
            }
            if segments.is_empty() {
                segments.push(RenderedMessage::Normal {
                    role: "user",
                    content: String::new(),
                });
            }
            Ok(segments)
        }
    }
}

fn parse_qwen3_assistant(
    raw: &str,
    request: &CompletionRequest,
) -> Result<ParsedAssistant, CandleError> {
    let (_, require_call) = selected_tools(request)?;
    let mut remaining = raw.trim();
    let mut items = Vec::new();

    if remaining.starts_with(THINK_START) {
        let end = remaining.find(THINK_END).ok_or_else(|| {
            CandleError::MalformedToolCall("unterminated `<think>` reasoning block".to_string())
        })?;
        let reasoning = remaining[THINK_START.len()..end].trim();
        if !reasoning.is_empty() {
            items.push(AssistantContent::Reasoning(Reasoning::new(reasoning)));
        }
        remaining = remaining[end + THINK_END.len()..].trim_start();
    } else if remaining.contains(THINK_END) {
        return Err(CandleError::MalformedToolCall(
            "encountered `</think>` without a leading `<think>` block".to_string(),
        ));
    }
    if remaining.contains("<tool-call") || remaining.contains("</tool-call") {
        return Err(CandleError::MalformedToolCall(
            "encountered unsupported `<tool-call>` delimiter; expected `<tool_call>`".to_string(),
        ));
    }
    if remaining.contains(THINK_START) || remaining.contains(THINK_END) {
        return Err(CandleError::MalformedToolCall(
            "reasoning blocks are only valid once at the beginning of a Qwen3 turn".to_string(),
        ));
    }

    let mut seen_ids = HashSet::new();
    let mut tool_calls = 0usize;
    while let Some(start) = remaining.find(TOOL_CALL_START) {
        if remaining[..start].contains(TOOL_CALL_END) {
            return Err(CandleError::MalformedToolCall(
                "encountered `</tool_call>` before `<tool_call>`".to_string(),
            ));
        }
        validate_qwen_visible_segment(&remaining[..start])?;
        push_text(&mut items, &remaining[..start]);
        let body_start = start + TOOL_CALL_START.len();
        let after_start = &remaining[body_start..];
        let end = after_start.find(TOOL_CALL_END).ok_or_else(|| {
            CandleError::MalformedToolCall("unterminated `<tool_call>` block".to_string())
        })?;
        let body = after_start[..end].trim();
        if body.contains(TOOL_CALL_START) {
            return Err(CandleError::MalformedToolCall(
                "nested `<tool_call>` blocks are invalid".to_string(),
            ));
        }
        let envelope: QwenToolCallEnvelope = serde_json::from_str(body).map_err(|error| {
            CandleError::MalformedToolCall(format!("invalid JSON envelope: {error}"))
        })?;
        if envelope.name.is_empty() {
            return Err(CandleError::MalformedToolCall(
                "tool name must not be empty".to_string(),
            ));
        }
        if !envelope.arguments.is_object() {
            return Err(CandleError::MalformedToolCall(
                "tool arguments must be a JSON object".to_string(),
            ));
        }
        if let Some(id) = &envelope.id
            && (id.is_empty() || !seen_ids.insert(id.clone()))
        {
            return Err(CandleError::MalformedToolCall(format!(
                "duplicate or empty tool-call ID `{id}`"
            )));
        }
        let name = ToolName::new(envelope.name)
            .map_err(|error| CandleError::MalformedToolCall(error.to_string()))?;
        // Rig issues an id for an id-less envelope.
        items.push(AssistantContent::ToolCall(ToolCall::from_wire(
            envelope.id.unwrap_or_default(),
            ToolFunction::new(name, envelope.arguments),
        )));
        tool_calls += 1;
        remaining = after_start[end + TOOL_CALL_END.len()..].trim_start();
    }
    if remaining.contains(TOOL_CALL_END) {
        return Err(CandleError::MalformedToolCall(
            "encountered `</tool_call>` without `<tool_call>`".to_string(),
        ));
    }
    validate_qwen_visible_segment(remaining)?;
    push_text(&mut items, remaining);

    if require_call && tool_calls == 0 {
        return Err(CandleError::ToolChoiceViolation(
            "the model returned no tool call for a required/specific choice".to_string(),
        ));
    }
    // Preserve empty turns without inventing model output.
    let visible_text = canonicalize_visible_text(&mut items);
    Ok(ParsedAssistant {
        items,
        visible_text,
    })
}

/// Normalizes text split by control envelopes once, then stores that exact
/// representation in both the parsed items and final response. Streaming can
/// therefore emit the items verbatim without reconstructing separators.
fn canonicalize_visible_text(items: &mut [AssistantContent]) -> String {
    let mut visible_text = String::new();
    let mut has_visible_text = false;
    for item in items {
        let AssistantContent::Text(text) = item else {
            continue;
        };
        if has_visible_text {
            text.text.insert(0, ' ');
        }
        visible_text.push_str(&text.text);
        has_visible_text = true;
    }
    visible_text
}

fn validate_qwen_visible_segment(text: &str) -> Result<(), CandleError> {
    for marker in [
        IM_START,
        IM_END,
        "<tools>",
        "</tools>",
        TOOL_RESPONSE_START,
        TOOL_RESPONSE_END,
    ] {
        if text.contains(marker) {
            return Err(CandleError::MalformedToolCall(format!(
                "generated visible text contains reserved protocol marker `{marker}`"
            )));
        }
    }
    Ok(())
}

fn push_text(items: &mut Vec<AssistantContent>, text: &str) {
    let text = text.trim();
    if !text.is_empty() {
        items.push(AssistantContent::text(text));
    }
}

#[cfg(test)]
#[allow(clippy::expect_used, clippy::indexing_slicing, clippy::panic)]
mod tests;
