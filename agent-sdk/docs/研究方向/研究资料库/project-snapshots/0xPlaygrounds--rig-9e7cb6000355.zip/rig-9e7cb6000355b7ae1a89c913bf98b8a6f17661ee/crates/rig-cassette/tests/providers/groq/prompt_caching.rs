//! Groq prompt-caching cassette suite.
//!
//! **Groq's prompt cache is real but intermittent** — the same signature as
//! Mistral, and it took the strengthened `assert_no_meaningful_prefix_cache` to
//! notice.
//!
//! An earlier revision of this suite concluded Groq did not cache at all. It
//! was reading only the first two turns of one probe; the streaming probe's
//! *first* turn reads 1,792 of 1,795 prompt tokens — 99.8% — against a prefix an
//! earlier scenario had warmed, and then turns 2 and 3 read zero. Repeated
//! recordings put the hit on different turns, with `assert_prefix_stable`
//! proving on every run that rig's own bytes never moved. Routing without cache
//! affinity is the plausible cause; either way it is not something rig controls.
//!
//! For the record: the blocking fixture was re-recorded as part of this
//! reclassification. Its previous recording read zero on all three turns and
//! would have kept passing the "no cache" assertion, which is exactly how the
//! wrong classification survived. Re-recording until a turn hits is what
//! `assert_cache_read_is_surfaced` explicitly asks for — the fixture has to
//! contain a hit for it to prove rig maps the field at all.
//!
//! So these cells assert the narrower thing that is true and deterministic:
//! when Groq reports a cache read, rig surfaces it at full magnitude, on the
//! blocking and streaming paths alike. That is a claim about rig's usage mapping
//! rather than about Groq's hit rate. Groq speaks the OpenAI chat shape, so the
//! value arrives in `prompt_tokens_details.cached_tokens`.
//!
//! **Rate-limit caveat:** this account's Groq tier allows 8,000 tokens per
//! minute, and three turns of the default ~4,600-token probe exceed that before
//! turn 2 can be sent. The probe is capped at ~1,800 tokens per turn, which
//! clears the 1,024-token floor a prompt cache would plausibly need. Recording
//! these fixtures needs roughly a minute between attempts.
//!
//! # No agent-loop cell, and why
//!
//! Most providers in the matrix have an `agent_loop` cell driving a real
//! multi-turn agent run with a tool round-trip — the only cell that can catch
//! rig's *driver* disturbing the prefix between iterations. This provider has
//! none, deliberately: its model answers the probe's prompt from its own knowledge and never calls the tool. A run that
//! makes one model call records one request, which leaves `assert_prefix_stable`
//! no pair to compare and the cell proving nothing. A cell that cannot fail is
//! worse than an acknowledged gap.
//!
//! The loop-level guarantee is still covered for this provider by the
//! corpus-wide scan in `tests/cassette_cache_prefix.rs`, which compares every
//! recorded multi-turn conversation in its existing suites.
//!
//! # Recording
//!
//! ```text
//! RIG_PROVIDER_TEST_MODE=record cargo test -p rig --test groq --all-features \
//!     prompt_caching:: -- --exact --test-threads=1
//! ```

use crate::cache_conformance::{
    CacheProbe, CacheSupport, assert_cache_read_is_surfaced, assert_prefix_stable, run_cache_probe,
    run_cache_probe_streaming,
};

use super::support::with_groq_prompt_caching_cassette;

/// A model Groq actually serves today; the cassette was recorded against it.
const CACHE_MODEL: &str = rig::providers::groq::GPT_OSS_20B;

const GROQ_CACHE_SUPPORT: CacheSupport = CacheSupport {
    provider: "groq",
    explicit_breakpoints: false,
    reports_writes: false,
    min_cacheable_tokens: 1024,
    cache_key_field: None,
    hit_ratio_floor: 0.80,
};

/// Groq's free tier allows 8,000 tokens per minute, and three turns of the
/// default ~4,600-token probe blows through that before turn 2 is even sent
/// (`rate_limit_exceeded`, "Limit 8000, Used 4633, Requested 4691"). Sixty
/// repetitions puts each turn near 1,600 tokens, so all three fit in one
/// minute's budget while still clearing the 1,024-token floor a prompt cache
/// would need.
const GROQ_PADDING_REPETITIONS: usize = 60;

/// Room for a reasoning model to finish thinking and answer in text, so
/// each turn's reply goes back and the next request extends it.
const ANSWERING_MAX_TOKENS: u64 = 1024;

fn probe() -> CacheProbe {
    CacheProbe::new("groq prompt caching")
        .with_padding(GROQ_PADDING_REPETITIONS, "groq prompt caching")
}

#[tokio::test]
async fn blocking_probe_surfaces_the_cache_read_groq_reports() {
    const SCENARIO: &str = "prompt_caching/blocking_probe";

    with_groq_prompt_caching_cassette("prompt_caching/blocking_probe", |client| async move {
        let model = client.completion(CACHE_MODEL);
        let probe = CacheProbe {
            max_tokens: ANSWERING_MAX_TOKENS,
            ..probe()
        };
        let observation = run_cache_probe(model, &probe).await;
        assert_cache_read_is_surfaced(&observation, &GROQ_CACHE_SUPPORT, "blocking probe");
    })
    .await;

    assert_prefix_stable("groq", SCENARIO);
}

#[tokio::test]
#[ignore = "stale cassette: its request predates item-shaped history, and Groq's cache never warmed in any re-record attempt"]
async fn streaming_probe_surfaces_the_cache_read_groq_reports() {
    const SCENARIO: &str = "prompt_caching/streaming_probe";

    with_groq_prompt_caching_cassette("prompt_caching/streaming_probe", |client| async move {
        let model = client.completion(CACHE_MODEL);
        let observation = run_cache_probe_streaming(model, &probe()).await;
        assert_cache_read_is_surfaced(&observation, &GROQ_CACHE_SUPPORT, "streaming probe");
    })
    .await;

    assert_prefix_stable("groq", SCENARIO);
}
