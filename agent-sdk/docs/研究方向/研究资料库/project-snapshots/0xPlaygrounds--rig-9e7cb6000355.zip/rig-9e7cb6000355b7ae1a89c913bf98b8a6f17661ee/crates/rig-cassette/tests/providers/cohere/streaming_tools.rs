//! Cohere streaming tools smoke test.

use rig::providers::cohere::{self};
use rig_test_support::cassette_models::CohereModels;

use crate::support::{
    Adder, STREAMING_TOOLS_PREAMBLE, STREAMING_TOOLS_PROMPT, Subtract,
    assert_mentions_expected_number, collect_stream_final_response,
};

#[tokio::test]
#[ignore = "requires COHERE_API_KEY"]
async fn streaming_tools_smoke() {
    let cohere = CohereModels::from_env().expect("config should build from env");
    let agent = rig::AgentBuilder::new(cohere.completion(cohere::COMMAND_A_03_2025))
        .preamble(STREAMING_TOOLS_PREAMBLE)
        .tool(Adder)
        .tool(Subtract)
        .build();

    let mut stream = agent.prompt(STREAMING_TOOLS_PROMPT).stream();
    let response = collect_stream_final_response(&mut stream)
        .await
        .expect("streaming tool prompt should succeed");

    assert_mentions_expected_number(&response, -3);
}
