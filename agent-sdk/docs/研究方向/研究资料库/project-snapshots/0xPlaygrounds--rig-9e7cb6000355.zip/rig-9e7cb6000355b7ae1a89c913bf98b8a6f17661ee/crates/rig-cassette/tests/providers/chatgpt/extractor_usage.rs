//! Integration tests for ChatGPT extractor usage tracking.

use anyhow::{Result, anyhow};
use rig::TypedPromptResponse;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::chatgpt::{LIVE_MODEL, live_client};

#[derive(Debug, Deserialize, Serialize, JsonSchema, PartialEq)]
struct Person {
    name: Option<String>,
    age: Option<u8>,
    profession: Option<String>,
}

#[derive(Debug, Deserialize, Serialize, JsonSchema, PartialEq)]
struct Address {
    street: Option<String>,
    city: Option<String>,
    state: Option<String>,
    zip_code: Option<String>,
}

fn assert_compatible_professions(left: Option<&str>, right: Option<&str>) -> Result<()> {
    let left = left
        .ok_or_else(|| anyhow!("profession should be present"))?
        .trim()
        .to_ascii_lowercase();
    let right = right
        .ok_or_else(|| anyhow!("profession should be present"))?
        .trim()
        .to_ascii_lowercase();

    anyhow::ensure!(
        left == right || left.contains(&right) || right.contains(&left),
        "expected compatible professions, got {left:?} and {right:?}"
    );
    Ok(())
}

#[tokio::test]
#[ignore = "requires ChatGPT credentials or existing OAuth cache"]
async fn extract_backward_compatibility() -> Result<()> {
    let extractor =
        rig::extractor::ExtractorBuilder::<Person>::new(live_client().await.completion(LIVE_MODEL))
            .build();

    let person = extractor
        .extract("John Doe is a 30 year old software engineer.")
        .await?
        .output;

    anyhow::ensure!(person.name.as_deref() == Some("John Doe"));
    anyhow::ensure!(person.age == Some(30));
    anyhow::ensure!(person.profession.as_deref() == Some("software engineer"));

    Ok(())
}

#[tokio::test]
#[ignore = "requires ChatGPT credentials or existing OAuth cache"]
async fn extract_with_usage_returns_data_and_usage() -> Result<()> {
    let extractor =
        rig::extractor::ExtractorBuilder::<Person>::new(live_client().await.completion(LIVE_MODEL))
            .build();

    let response: TypedPromptResponse<Person> = extractor
        .extract("Jane Smith is a 45 year old data scientist.")
        .await?;

    anyhow::ensure!(response.output.name.as_deref() == Some("Jane Smith"));
    anyhow::ensure!(response.output.age == Some(45));
    anyhow::ensure!(response.output.profession.as_deref() == Some("data scientist"));
    anyhow::ensure!(response.usage.input_tokens.is_some_and(|n| n > 0));
    anyhow::ensure!(response.usage.output_tokens.is_some_and(|n| n > 0));
    anyhow::ensure!(response.usage.total_tokens.is_some_and(|n| n > 0));

    Ok(())
}

#[tokio::test]
#[ignore = "requires ChatGPT credentials or existing OAuth cache"]
async fn extract_with_chat_history_with_usage_works() -> Result<()> {
    use rig::message::Message;

    let extractor = rig::extractor::ExtractorBuilder::<Address>::new(
        live_client().await.completion(LIVE_MODEL),
    )
    .build();

    let chat_history = vec![Message::user(
        "I'm looking at a property that might be interesting.",
    )];

    let response: TypedPromptResponse<Address> = extractor
        .extract("The address is 123 Main St in Springfield, IL 62701.")
        .history(chat_history)
        .await?;

    anyhow::ensure!(response.output.street.as_deref() == Some("123 Main St"));
    anyhow::ensure!(response.output.city.as_deref() == Some("Springfield"));
    anyhow::ensure!(response.output.state.as_deref() == Some("IL"));
    anyhow::ensure!(response.output.zip_code.as_deref() == Some("62701"));
    anyhow::ensure!(response.usage.input_tokens.is_some_and(|n| n > 0));
    anyhow::ensure!(response.usage.total_tokens.is_some_and(|n| n > 0));

    Ok(())
}

#[tokio::test]
#[ignore = "requires ChatGPT credentials or existing OAuth cache"]
async fn extract_and_extract_with_usage_return_same_data() -> Result<()> {
    let extractor =
        rig::extractor::ExtractorBuilder::<Person>::new(live_client().await.completion(LIVE_MODEL))
            .build();

    let text = "Bob Johnson is a 55 year old retired teacher.";

    let person = extractor.extract(text).await?.output;
    let response = extractor.extract(text).await?;

    anyhow::ensure!(person.name.as_deref() == Some("Bob Johnson"));
    anyhow::ensure!(response.output.name.as_deref() == Some("Bob Johnson"));
    anyhow::ensure!(person.age == Some(55));
    anyhow::ensure!(response.output.age == Some(55));
    assert_compatible_professions(
        person.profession.as_deref(),
        response.output.profession.as_deref(),
    )?;
    anyhow::ensure!(
        response.usage.total_tokens.is_some_and(|n| n > 0),
        "usage should be populated"
    );

    Ok(())
}

#[tokio::test]
#[ignore = "requires ChatGPT credentials or existing OAuth cache"]
async fn usage_tracking_works_for_different_schemas() -> Result<()> {
    let client = live_client().await;

    let person_extractor =
        rig::extractor::ExtractorBuilder::<Person>::new(client.completion(LIVE_MODEL)).build();
    let person_response = person_extractor
        .extract("Alice is a 25 year old developer.")
        .await?;
    anyhow::ensure!(person_response.usage.total_tokens.is_some_and(|n| n > 0));

    let address_extractor =
        rig::extractor::ExtractorBuilder::<Address>::new(client.completion(LIVE_MODEL)).build();
    let address_response = address_extractor
        .extract("456 Oak Avenue, Cambridge, MA 02139")
        .await?;
    anyhow::ensure!(address_response.usage.total_tokens.is_some_and(|n| n > 0));

    Ok(())
}
