//! AWS Bedrock agent completion replay smoke test.

use rig::agent::AgentBuilder;
use rig::bedrock;

use super::super::support::with_bedrock_cassette;
use crate::support::{
    Adder, BASIC_PREAMBLE, BASIC_PROMPT, STREAMING_TOOLS_PREAMBLE, STREAMING_TOOLS_PROMPT,
    Subtract, assert_mentions_expected_number, assert_nonempty_response,
};

#[tokio::test]
async fn completion_smoke() {
    with_bedrock_cassette("agent/completion_smoke", |client| async move {
        let agent = client
            .agent(bedrock::completion::AMAZON_NOVA_LITE)
            .preamble(BASIC_PREAMBLE)
            .build();

        let response = agent
            .prompt(BASIC_PROMPT)
            .await
            .expect("completion should succeed")
            .output();

        assert_nonempty_response(&response);
    })
    .await;
}

#[tokio::test]
async fn tool_roundtrip_smoke() {
    with_bedrock_cassette("agent/tool_roundtrip_smoke", |client| async move {
        let agent = client
            .agent(bedrock::completion::AMAZON_NOVA_LITE)
            .preamble(STREAMING_TOOLS_PREAMBLE)
            .max_tokens(1024)
            .tool(Adder)
            .tool(Subtract)
            .default_max_turns(2)
            .build();

        let response = agent
            .prompt(STREAMING_TOOLS_PROMPT)
            .await
            .expect("tool prompt should succeed")
            .output();

        assert_mentions_expected_number(&response, -3);
    })
    .await;
}

#[tokio::test]
async fn prompt_caching_completion_smoke() {
    with_bedrock_cassette(
        "agent/prompt_caching_completion_smoke",
        |client| async move {
            let model = client.completion(bedrock::completion::AMAZON_NOVA_LITE);
            let agent = AgentBuilder::new(model)
                .cache(rig::completion::CacheRetention::Short)
                .preamble(BASIC_PREAMBLE)
                .build();

            let response = agent
                .prompt(BASIC_PROMPT)
                .await
                .expect("prompt-caching completion should succeed")
                .output();

            assert_nonempty_response(&response);
        },
    )
    .await;
}
