//! Copilot agent completion smoke test.

use crate::copilot::{LIVE_MODEL, live_client, with_copilot_cassette};
use crate::support::{BASIC_PREAMBLE, BASIC_PROMPT, assert_nonempty_response};

#[tokio::test]
async fn completion_smoke() {
    with_copilot_cassette("agent/completion_smoke", |client| async move {
        let agent = rig::AgentBuilder::new(client.completion(LIVE_MODEL))
            .preamble(BASIC_PREAMBLE)
            .build();

        let response = agent
            .prompt(BASIC_PROMPT)
            .await
            .expect("completion should succeed");

        assert_nonempty_response(&response.output());
    })
    .await;
}

/// Command to run
/// cargo test -p rig --test copilot all_models_completion_smoke -- --ignored --nocapture
#[tokio::test]
#[ignore = "requires Copilot credentials or existing OAuth cache"]
async fn all_models_completion_smoke() {
    let client = live_client().await;

    let models = client
        .list_models()
        .await
        .expect("listing Copilot models should succeed");

    println!(
        "Found {} models; testing completion on each...",
        models.len()
    );

    assert!(
        !models.is_empty(),
        "expected Copilot to return at least one model"
    );

    let mut succeeded = Vec::new();
    let mut failed = Vec::new();

    for model in models.iter() {
        println!("Testing {:#?}...", model.id);
        let agent = rig::AgentBuilder::new(client.completion(model.id.as_str()))
            .preamble(BASIC_PREAMBLE)
            .build();

        match agent.prompt(BASIC_PROMPT).await {
            Ok(response) if !response.output().is_empty() => succeeded.push(model.id.clone()),
            Ok(_) => failed.push(format!("{}: empty response", model.id)),
            Err(e) => failed.push(format!("{}: {e}", model.id)),
        }
    }

    println!("\n=== Completion results ({} models) ===", models.len());
    println!("Succeeded ({}):", succeeded.len());
    for id in &succeeded {
        println!("  + {id}");
    }
    println!("Failed ({}):", failed.len());
    for entry in &failed {
        println!("  - {entry}");
    }
}
