//! Common imports for Rig's classic runtime.
//!
//! ```
//! use rig_agent::prelude::*;
//! use rig_core::operation::Completion;
//!
//! fn assistant(model: impl Into<DynModel<Completion>>) -> Agent {
//!     AgentBuilder::new(model).build()
//! }
//! ```

pub use crate::agent::{
    Agent, AgentBuilder, AgentHook, HookContext, ModelHandle, ModelRef, ModelSelection,
    ModelSelectionAction, MultiTurnStreamItem, RunEvents, StreamingResult,
};
pub use crate::completion::{Message, PromptError, StructuredOutputError};
pub use crate::tool::{Tool, ToolSet};
pub use rig_core::driver::{DynModel, Model};
pub use rig_core::error::ProviderError;

pub use rig_core::Embed;
pub use rig_core::embeddings::EmbeddingsBuilder;
pub use rig_core::vector_store::VectorStoreIndex;
pub use rig_core::vector_store::in_memory_store::InMemoryVectorStore;
pub use rig_core::vector_store::request::VectorSearchRequest;
