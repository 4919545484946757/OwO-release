//! Follow-up live census after the first DeepSeek bug-hunt sweep.
//!
//! These cells target documented Chat Completions fields absent from the
//! existing cassette assertions. They pin both the request premise and the
//! provider's raw response shape. A census cell that exposes a Rig defect is
//! moved into a dedicated per-bug exhaustive matrix before merge.

use rig::providers::deepseek;
use serde_json::{Value, json};

use super::support::{
    collect_raw_stream_outcome, recorded_request, recorded_response, recorded_stream_chunks,
    with_deepseek_followup_hunt_cassette_result,
};
use rig::completion::{CompletionRequest, GenerationOptions, Reasoning};

const MODEL: &str = deepseek::DEEPSEEK_V4_FLASH;

/// Thinking off, stopping at `ZEBRA`.
fn non_thinking_stop() -> GenerationOptions {
    GenerationOptions::default()
        .reasoning(Reasoning::Off)
        .stop(["ZEBRA"])
}

fn first_blocking_choice(scenario: &str) -> Value {
    recorded_response(scenario)["choices"]
        .as_array()
        .and_then(|choices| choices.first())
        .cloned()
        .unwrap_or_else(|| panic!("{scenario} should record a completion choice"))
}

fn stream_choices(scenario: &str) -> Vec<Value> {
    recorded_stream_chunks(scenario)
        .into_iter()
        .flat_map(|chunk| chunk["choices"].as_array().cloned().unwrap_or_default())
        .collect()
}

#[tokio::test]
async fn blocking_stop_sequence_reaches_the_wire_and_stops_generation() {
    const SCENARIO: &str =
        "followup_hunt_matrix/blocking_stop_sequence_reaches_the_wire_and_stops_generation";
    with_deepseek_followup_hunt_cassette_result(
        "followup_hunt_matrix/blocking_stop_sequence_reaches_the_wire_and_stops_generation",
        |client| async move {
            let model = client.completion(MODEL);
            let request = CompletionRequest::new(
                "Write exactly `alpha ZEBRA omega` with no punctuation or explanation.",
            )
            .options(non_thinking_stop())
            .max_tokens(24);
            let response = model.call(request).await?;
            assert_eq!(
                response.finish_reason(),
                Some(rig::completion::FinishReason::Stop)
            );
            Ok::<(), rig::error::ProviderError>(())
        },
    )
    .await
    .expect("blocking stop-sequence census should replay");

    assert_eq!(recorded_request(SCENARIO)["stop"], json!(["ZEBRA"]));
    let choice = first_blocking_choice(SCENARIO);
    assert_eq!(choice["finish_reason"], "stop");
    assert!(
        !choice["message"]["content"]
            .as_str()
            .unwrap_or_default()
            .contains("ZEBRA"),
        "the stop sequence itself must not be returned"
    );
}

#[tokio::test]
async fn streaming_stop_sequence_reaches_the_wire_and_stops_generation() {
    const SCENARIO: &str =
        "followup_hunt_matrix/streaming_stop_sequence_reaches_the_wire_and_stops_generation";
    with_deepseek_followup_hunt_cassette_result(
        "followup_hunt_matrix/streaming_stop_sequence_reaches_the_wire_and_stops_generation",
        |client| async move {
            let model = client.completion(MODEL);
            let request = CompletionRequest::new(
                "Write exactly `alpha ZEBRA omega` with no punctuation or explanation.",
            )
            .options(non_thinking_stop())
            .max_tokens(24);
            let outcome = collect_raw_stream_outcome(model.stream(request)?).await;
            assert!(
                outcome.errors.is_empty(),
                "stream errors: {:?}",
                outcome.errors
            );
            assert_eq!(
                outcome.finish_reason(),
                Some(rig::completion::FinishReason::Stop)
            );
            assert!(!outcome.text.contains("ZEBRA"));
            Ok::<(), rig::error::ProviderError>(())
        },
    )
    .await
    .expect("streaming stop-sequence census should replay");

    assert_eq!(recorded_request(SCENARIO)["stop"], json!(["ZEBRA"]));
    assert!(
        stream_choices(SCENARIO)
            .iter()
            .any(|choice| choice["finish_reason"] == "stop")
    );
}

#[tokio::test]
async fn low_reasoning_effort_produces_a_reasoning_turn() {
    const SCENARIO: &str = "followup_hunt_matrix/low_reasoning_effort_produces_a_reasoning_turn";
    with_deepseek_followup_hunt_cassette_result(
        "followup_hunt_matrix/low_reasoning_effort_produces_a_reasoning_turn",
        |client| async move {
            let model = client.completion(MODEL);
            let request = CompletionRequest::new("What is 17 + 25? Answer with only the number.")
                .additional_params(json!({ "reasoning_effort": "low" }))
                .max_tokens(64);
            let response = model.call(request).await?;
            assert!(
                response
                    .choice
                    .iter()
                    .any(|part| matches!(part, rig::message::AssistantContent::Reasoning(_))),
                "reasoning_effort should enable a reasoning turn"
            );
            Ok::<(), rig::error::ProviderError>(())
        },
    )
    .await
    .expect("reasoning-effort census should replay");

    assert_eq!(recorded_request(SCENARIO)["reasoning_effort"], "low");
    assert!(
        first_blocking_choice(SCENARIO)["message"]["reasoning_content"]
            .as_str()
            .is_some_and(|reasoning| !reasoning.is_empty()),
        "the recorded premise must contain reasoning_content"
    );
}
