//! Feature matrix for raw provider response capture on the Gemini
//! Interactions API (`POST /v1beta/interactions`) unary seam.
//!
//! # The feature
//!
//! Raw capture is always on: the driver puts the provider's reply body,
//! parsed as JSON, onto [`rig::completion::CompletionResponse::raw`] — here
//! the API's own interaction document, verbatim. There is no opt-in and
//! nothing about it reaches the wire; `raw` is required at construction, so
//! there is no response without the document that produced it and no way
//! for capture to be "not requested".
//!
//! # Matrix
//!
//! `expected` is what the caller observes on the normalized response. Every
//! recorded cell re-derives its premise from its own fixture bytes after the
//! wrapper returns: the recorded interaction must have completed and carry the
//! lifecycle fields the cells read.
//!
//! | # | Cell | Dimension | expected | Status |
//! |---|------|-----------|----------|--------|
//! | 1 | `raw_roundtrips_interaction` | document access | `raw` reads back as the interaction document, and its provider-native fields agree with the normalized response | recorded |
//! | 2 | `raw_exposes_lifecycle_fields` | un-normalized fields | `object` / `status` spelling / `steps` == fixture, absent from the normalized response | recorded |
//!
//! Every cell is recorded: `GEMINI_API_KEY` was available and the seam under
//! test is the plain non-streaming interactions route.
//!
//! Cell 1 also carries the "one story" contract: the normalized response was
//! folded by one decoder out of these very bytes, so the identity, finish
//! reason, model and usage read off `raw` are the ones the response reports —
//! `raw` and the normalized response can never disagree about the turn they
//! describe.
//!
//! The un-normalized fields of choice are the interaction's lifecycle
//! envelope: `object` (`"interaction"`), the wire spelling of `status`
//! (`"completed"`, which normalizes to rig's `Stop`), and the `steps` log —
//! the interaction `id` is normalized into `response_id` *and* scrubbed into
//! the fixture, so it cannot prove anything against the recorded bytes.

use rig::completion::FinishReason;
use rig::providers::gemini::extension::{GeminiExt, InteractionStatus};
use serde_json::Value;
use std::sync::{Arc, Mutex};

use super::super::support::with_gemini_interactions_cassette;
use crate::support::{json_contains_key, normalized_without_raw};
use rig::completion::CompletionRequest;

const PROVIDER: &str = "gemini";

/// The model the neighbouring interactions cassettes record against; the
/// Interactions API is served for the Gemini 3 family.
const MODEL: &str = "gemini-3-flash-preview";

const PROMPT: &str = "Reply with exactly this one word and nothing else: captured";

fn request() -> rig::completion::CompletionRequest {
    CompletionRequest::new(PROMPT).temperature(0.0)
}

/// The premise every cell rests on: the recorded body is a completed
/// interaction carrying the lifecycle envelope cell 2 reads.
fn assert_recorded_completed_interaction(scenario: &str) -> Value {
    let body = crate::cassettes::recorded_json_response(PROVIDER, scenario);
    assert_eq!(
        body.get("object"),
        Some(&Value::String("interaction".to_string())),
        "{scenario}: the recorded body should be an interaction object"
    );
    assert_eq!(
        body.get("status"),
        Some(&Value::String("completed".to_string())),
        "{scenario}: the recorded interaction should have completed"
    );
    assert!(
        body.get("steps")
            .and_then(Value::as_array)
            .is_some_and(|steps| !steps.is_empty()),
        "{scenario}: the recorded interaction should carry its steps log"
    );
    body
}

// ---------------------------------------------------------------------------
// 1: the document is recoverable, and tells the same story
// ---------------------------------------------------------------------------

#[tokio::test]
async fn raw_roundtrips_interaction() {
    const SCENARIO: &str = "interactions_raw_capture_matrix/raw_roundtrips_interaction";
    with_gemini_interactions_cassette(
        "interactions_raw_capture_matrix/raw_roundtrips_interaction",
        |client| async move {
            let model = client.interactions(MODEL);
            let response = model
                .call(request())
                .await
                .expect("completion should succeed");

            let raw = &response.raw;

            let document = raw
                .as_object()
                .expect("raw must be the Interactions API's interaction document");

            // One decoder folded the normalized response out of these very
            // bytes, so every field it kept must be the one the document
            // carries — `raw` is additive, never a divergent second view.
            assert_eq!(
                document.get("model").and_then(Value::as_str),
                response.model()
            );
            assert_eq!(
                document.get("id").and_then(Value::as_str),
                response.response_id()
            );
            assert_eq!(
                raw.pointer("/usage/total_input_tokens")
                    .and_then(Value::as_u64),
                response.usage.input_tokens
            );
            assert_eq!(
                raw.pointer("/usage/total_tokens").and_then(Value::as_u64),
                response.usage.total_tokens
            );
            assert_eq!(
                document.get("status").and_then(Value::as_str),
                Some("completed"),
                "the document keeps the API's own lifecycle spelling"
            );
            assert_eq!(
                response.finish_reason(),
                Some(FinishReason::Stop),
                "and `completed` reaches the caller as rig's Stop"
            );
        },
    )
    .await;

    assert_recorded_completed_interaction(SCENARIO);
}

// ---------------------------------------------------------------------------
// 2: un-normalized lifecycle fields are readable and match the wire
// ---------------------------------------------------------------------------

#[tokio::test]
async fn raw_exposes_lifecycle_fields() {
    const SCENARIO: &str = "interactions_raw_capture_matrix/raw_exposes_lifecycle_fields";
    let observed: Arc<Mutex<Option<Value>>> = Arc::new(Mutex::new(None));
    let sink = Arc::clone(&observed);
    with_gemini_interactions_cassette(
        "interactions_raw_capture_matrix/raw_exposes_lifecycle_fields",
        |client| async move {
            let model = client.interactions(MODEL);
            let response = model
                .call(request())
                .await
                .expect("completion should succeed");

            let raw = &response.raw;
            *sink.lock().expect("observation lock") = Some(raw.clone());

            // The normalized response provably lacks these: `object` and `steps`
            // have no normalized home, and `status` reaches it only as rig's
            // finish-reason vocabulary.
            let normalized = normalized_without_raw(response.clone());
            assert!(!json_contains_key(&normalized, "object"));
            assert!(!json_contains_key(&normalized, "steps"));
            assert!(!json_contains_key(&normalized, "status"));
            assert_eq!(response.finish_reason(), Some(FinishReason::Stop));

            // The typed extras read the same recorded interaction.
            let extras = response
                .extras::<GeminiExt>()
                .expect("an Interactions reply has Gemini extras")
                .expect("the recorded interaction holds the extras' shape");
            assert_eq!(
                extras.id.as_deref(),
                Some("v1_Chd6YTZ5YXAtVElLYkFxdHNQN28yMnVBaxIXemE2eWFwLVRJS2JBcXRzUDdvMjJ1QWs")
            );
            assert_eq!(extras.status, Some(InteractionStatus::Completed));
            assert_eq!(extras.service_tier.as_deref(), Some("standard"));
            // The recorder's scrubbed timestamps.
            assert_eq!(extras.created.as_deref(), Some("1970-01-01T00:00:00Z"));
            assert_eq!(extras.updated.as_deref(), Some("1970-01-01T00:00:00Z"));
            let input = extras.input_tokens_by_modality.unwrap_or_default();
            assert_eq!(
                input
                    .iter()
                    .map(|count| (count.modality.as_deref(), count.tokens))
                    .collect::<Vec<_>>(),
                [(Some("text"), Some(12))]
            );
            assert_eq!(
                extras.model_version, None,
                "a GenerateContent field on an Interactions reply"
            );
        },
    )
    .await;

    let raw = observed
        .lock()
        .expect("observation lock")
        .take()
        .expect("the test body observed a raw payload");
    let body = assert_recorded_completed_interaction(SCENARIO);
    assert_eq!(raw.get("object"), body.get("object"));
    assert_eq!(
        raw.get("status"),
        body.get("status"),
        "raw keeps the API's own status spelling"
    );
    assert_eq!(
        raw.get("steps").and_then(Value::as_array).map(Vec::len),
        body.get("steps").and_then(Value::as_array).map(Vec::len),
        "raw carries the interaction's steps log, one entry per recorded step"
    );
    assert_eq!(
        raw.pointer("/usage/total_tokens"),
        body.pointer("/usage/total_tokens"),
        "raw carries the wire's total token count untouched"
    );
}
