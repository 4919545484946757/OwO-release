//! Wire-conformance suite for candle's in-process typed-event wire.
//!
//! Events-first (`WireInput::Event`): fixture frames are already-typed
//! generation events replayed by a scripted transport through the
//! [`Generation`] wire — the shared driver, grammar, and terminal
//! normalization — with no model load. This family never produces `Unknown` and has no frame-level decode,
//! so the malformed/unknown scenarios self-report as skipped.

#![allow(clippy::expect_used)]

use rig_candle::{
    CandleCompletionResponse, CandleFrame, ConversationProtocol,
    FinishReason as CandleFinishReason, Generation, GenerationEvent,
};
use rig_core::completion::{CompletionRequest, FinishReason};
use rig_core::driver::{Exchange, Model, Opened, Opening, Transport};
use rig_core::error::ProviderError;
use rig_core::message::{CallId, ToolCall, ToolFunction, ToolName};
use rig_core::test_utils::streaming_conformance::{
    ProviderWireFixture, WireDriver, event_frame, fixtures::drain,
};

type CandleEvent = GenerationEvent;

/// Replays scripted generation events as the local generator sends them.
#[derive(Clone)]
struct Scripted(std::sync::Arc<std::sync::Mutex<Vec<Result<CandleEvent, ProviderError>>>>);

impl Transport<Generation> for Scripted {
    fn send(
        &self,
        _request: rig_candle::CandleRequest,
        _exchange: Exchange,
    ) -> Opening<CandleFrame> {
        let events = match self.0.lock() {
            Ok(mut events) => std::mem::take(&mut *events),
            Err(_) => {
                return Opening::failed(ProviderError::Provider("script lock poisoned".to_owned()));
            }
        };
        Opening::ready(Opened::new(futures::stream::iter(
            events
                .into_iter()
                .map(|event| event.map(CandleFrame::Event)),
        )))
    }
}

fn driver() -> WireDriver {
    WireDriver::new("candle", |chunks| {
        Box::pin(async move {
            let events: Vec<Result<CandleEvent, ProviderError>> = chunks
                .into_iter()
                .map(|chunk| match chunk {
                    Ok(frame) => frame
                        .downcast_event::<CandleEvent>()
                        .cloned()
                        .ok_or_else(|| {
                            ProviderError::Provider(
                                "candle conformance frames must be generation events".to_string(),
                            )
                        }),
                    Err(error) => Err(ProviderError::Http(error.into())),
                })
                .collect();
            let generation = Generation {
                model: "qwen3-scripted".to_owned(),
                protocol: ConversationProtocol::Qwen3,
                facts: Default::default(),
            };
            let stream = Model::new(
                generation,
                Scripted(std::sync::Arc::new(std::sync::Mutex::new(events))),
            )
            .stream(CompletionRequest::new("hello"))?;
            Ok(drain(stream).await)
        })
    })
}

fn terminal_response() -> CandleCompletionResponse {
    CandleCompletionResponse {
        text: "hi".to_string(),
        prompt_tokens: 10,
        generated_tokens: 5,
        requested_max_tokens: 256,
        effective_max_tokens: 256,
        finish_reason: CandleFinishReason::Eos,
        prefill_duration_ms: 1,
        time_to_first_token_ms: Some(1),
        generation_duration_ms: 2,
        tokens_per_second: None,
    }
}

fn fixture() -> ProviderWireFixture {
    ProviderWireFixture {
        driver: driver(),
        text_frames: vec![event_frame::<CandleEvent>(GenerationEvent::Text(
            "hi".to_string(),
        ))],
        expected_texts: vec!["hi"],
        tool_call_frames: vec![event_frame::<CandleEvent>(GenerationEvent::ToolCall(
            ToolCall::new(
                CallId::from_wire("call_1"),
                ToolFunction::new(
                    ToolName::new("get_weather").expect("a tool name"),
                    serde_json::json!({"city": "Tokyo"}),
                ),
            ),
        ))],
        expected_tool_name: "get_weather",
        // Local generation delivers tool calls whole after the buffered turn
        // is parsed; arguments never stream.
        partial_tool_call_frames: None,
        terminal_frames: vec![event_frame::<CandleEvent>(GenerationEvent::Final(
            terminal_response(),
        ))],
        // prompt 10 + generated 5.
        expected_usage_total: 15,
        expected_finish_reason: Some(FinishReason::Stop),
        // Local usage is always computed from token counts; there is no
        // usage-less genuine terminal to spell.
        zero_usage_terminal_frames: None,
        bare_terminal_frames: None,
        // No decode exists between the generator and the driver, so no
        // frame-level malformed input can be spelled; generation failures are
        // transport errors on the channel.
        malformed_frame: None,
        // This family never produces `Unknown`: the producer sends
        // already-typed grammar events, so every frame is `Modeled`.
        unknown_event_frame: None,
        defective_known_frame: None,
        delta_less_prelude_frame: None,
        refusal: None,
        interleaved_reasoning: None,
    }
}

rig_core::streaming_conformance_suite! {
    provider: "candle",
    fixture: fixture(),
    // Typed local wire: no malformed/unknown/defective shapes exist,
    // so the derived set is genuinely empty.
    manifest: [],
}

/// Compile-linked manifest of the wire families this binary covers.
///
/// This suite lives outside the `rig` facade's `core` test binary, so the
/// workspace registry cannot link it: it lists `candle` in
/// `OUT_OF_BINARY_FAMILIES` and relies on the "Test out-of-facade streaming
/// conformance and structural guards" CI step to execute this binary. The test
/// below keeps the family name honest at the definition site, which is the
/// direction the registry loses for out-of-binary suites (#2258 F3).
const SUITE_FAMILIES: &[&str] = &[WIRE_FAMILY];

#[test]
fn suite_families_are_registered_wire_families() {
    for family in SUITE_FAMILIES {
        assert!(
            rig_core::test_utils::streaming_conformance::WIRE_FAMILIES.contains(family),
            "suite names wire family {family:?}, absent from WIRE_FAMILIES"
        );
    }
}
