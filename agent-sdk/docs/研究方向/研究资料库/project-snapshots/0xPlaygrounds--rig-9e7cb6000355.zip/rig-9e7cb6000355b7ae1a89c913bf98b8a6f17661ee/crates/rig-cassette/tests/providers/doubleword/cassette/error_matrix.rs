//! Provider-error matrix for Doubleword chat completions.
//!
//! Three stable failure classes—unknown model, invalid credentials and an
//! out-of-range sampling parameter—are crossed with blocking and streaming
//! transports. Every cell requires a 4xx status, a preserved provider body,
//! and a recorded JSON error envelope, preventing a generic transport string
//! from replacing the actionable upstream diagnostic.
//!
//! | failure | blocking | streaming | envelope |
//! |---|---|---|---|
//! | invalid key | 403 | 403 | nested `error` |
//! | unknown model | 404 | 404 | nested `error` |
//! | `temperature: 100` | 400 | 400 | nested `error` |
//!
//! The out-of-range cells first recorded a flat top-level `message` / `type`
//! / `code` envelope; Doubleword now answers them with the nested envelope
//! too, so every failure class shares one shape.
//!
//! Streaming status failures open a rig stream successfully and surface the
//! preserved `ProviderError` as its first in-band item. The matrix treats
//! that as the streaming contract and proves the body/status match blocking.

use futures::StreamExt;
use rig::error::ErrorReport;
use rig::error::ProviderError;
use rig::providers::doubleword;
use rig_test_support::cassette_models::OpenAiModels;
use serde_json::json;

use super::super::support::{
    recorded_chat_calls, with_doubleword_bogus_key_cassette, with_doubleword_cassette,
};
use rig::completion::CompletionRequest;

const PROMPT: &str = "Reply with error-probe.";

fn assert_nested_error_envelope(json: &serde_json::Value) {
    let has_nested_error = json.get("error").is_some_and(serde_json::Value::is_object);
    let has_flat_fields = ["message", "type", "code"]
        .iter()
        .all(|field| json.get(*field).is_some());
    assert!(
        has_nested_error && !has_flat_fields,
        "expected nested error envelope, got: {json}"
    );
}

fn assert_preserved_client_error(error: &ProviderError, expected_status: u16) {
    assert_preserved_client_error_report(&ErrorReport::from(error), expected_status);
}

/// The streaming twin: an in-band stream failure is an `ErrorReport`, which
/// carries the same preserved provider response as the `ProviderError`.
fn assert_preserved_client_error_report(report: &ErrorReport, expected_status: u16) {
    let status = report
        .provider_response_status()
        .expect("provider status should be preserved");
    assert_eq!(status.as_u16(), expected_status, "error: {report}");
    let body = report
        .provider_response_body()
        .expect("provider response body should be preserved");
    assert!(!body.trim().is_empty());
    let json: serde_json::Value =
        serde_json::from_str(body).expect("Doubleword error body should be JSON");
    assert_nested_error_envelope(&json);
}

fn assert_recorded_error(
    scenario: &str,
    expected_status: u16,
    request_field: Option<(&str, serde_json::Value)>,
) {
    let calls = recorded_chat_calls(scenario);
    assert_eq!(calls.len(), 1);
    let call = &calls[0];
    assert_eq!(call.status, expected_status);
    if let Some((field, expected)) = request_field {
        assert_eq!(call.request[field], expected);
    }
    let body = call
        .response_json
        .as_ref()
        .expect("recorded JSON error body");
    assert_nested_error_envelope(body);
    assert!(call.stream_chunks.is_empty());
}

fn assert_recorded_transport_parity(blocking_scenario: &str, streaming_scenario: &str) {
    let blocking_calls = recorded_chat_calls(blocking_scenario);
    let streaming_calls = recorded_chat_calls(streaming_scenario);
    assert_eq!(blocking_calls.len(), 1);
    assert_eq!(streaming_calls.len(), 1);
    assert_eq!(blocking_calls[0].status, streaming_calls[0].status);
    assert_eq!(
        blocking_calls[0].response_json,
        streaming_calls[0].response_json
    );
}

async fn invalid_key_blocking_body(client: OpenAiModels) {
    let model = client.completion(doubleword::QWEN3_5_9B);
    let error = model
        .call(CompletionRequest::new(PROMPT).max_tokens(8))
        .await
        .expect_err("invalid credentials should be rejected");
    assert_preserved_client_error(&error, 403);
}

async fn invalid_temperature_blocking_body(client: OpenAiModels) {
    let model = client.completion(doubleword::QWEN3_5_9B);
    let error = model
        .call(
            CompletionRequest::new(PROMPT)
                .additional_params(json!({ "temperature": 100 }))
                .max_tokens(8),
        )
        .await
        .expect_err("an out-of-range temperature should be rejected");
    assert_preserved_client_error(&error, 400);
}

async fn invalid_temperature_streaming_body(client: OpenAiModels) {
    let model = client.completion(doubleword::QWEN3_5_9B);
    let result = model.stream(
        CompletionRequest::new(PROMPT)
            .additional_params(json!({ "temperature": 100 }))
            .max_tokens(8),
    );
    let mut stream = result.expect("streaming HTTP failures are delivered in-band");
    let error = loop {
        match stream.next().await {
            Some(Err(error)) => break error,
            Some(Ok(_)) => continue,
            None => panic!("invalid-temperature stream ended without its provider error"),
        }
    };
    assert_preserved_client_error_report(&rig::ErrorReport::from(&error), 400);
}

#[tokio::test]
async fn invalid_key_blocking() {
    const SCENARIO: &str = "error_matrix/invalid_key_blocking";
    with_doubleword_bogus_key_cassette(
        "error_matrix/invalid_key_blocking",
        invalid_key_blocking_body,
    )
    .await;
    assert_recorded_error(
        SCENARIO,
        403,
        Some(("model", json!(doubleword::QWEN3_5_9B))),
    );
}

#[tokio::test]
async fn invalid_temperature_blocking() {
    const SCENARIO: &str = "error_matrix/invalid_temperature_blocking";
    with_doubleword_cassette(
        "error_matrix/invalid_temperature_blocking",
        invalid_temperature_blocking_body,
    )
    .await;
    assert_recorded_error(SCENARIO, 400, Some(("temperature", json!(100))));
}

#[tokio::test]
async fn invalid_temperature_streaming() {
    const SCENARIO: &str = "error_matrix/invalid_temperature_streaming";
    with_doubleword_cassette(
        "error_matrix/invalid_temperature_streaming",
        invalid_temperature_streaming_body,
    )
    .await;
    assert_recorded_error(SCENARIO, 400, Some(("temperature", json!(100))));
    assert_recorded_transport_parity(
        "error_matrix/invalid_temperature_blocking",
        "error_matrix/invalid_temperature_streaming",
    );
}
