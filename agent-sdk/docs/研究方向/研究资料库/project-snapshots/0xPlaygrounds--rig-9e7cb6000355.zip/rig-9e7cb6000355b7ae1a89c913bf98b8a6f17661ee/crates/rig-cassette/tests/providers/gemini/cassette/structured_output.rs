//! Gemini structured output smoke test.

use rig::agent::OutputMode;
use rig::providers::gemini::{self, GeminiConfig};
use rig::test_utils::{MockHttpResponse, SequencedHttpClient};
use rig_agent::test_utils::decode_structured_output;

use crate::support::{
    STRUCTURED_OUTPUT_PROMPT, SmokeStructuredOutput, assert_smoke_structured_output,
    smoke_structured_output_value,
};

fn text_response(text: &str, response_id: &str) -> String {
    serde_json::json!({
        "candidates": [{
            "content": {
                "parts": [{"text": text}],
                "role": "model"
            },
            "finishReason": "STOP",
            "index": 0
        }],
        "modelVersion": gemini::completion::GEMINI_2_5_FLASH,
        "responseId": response_id,
        "usageMetadata": {
            "promptTokenCount": 1,
            "candidatesTokenCount": 1,
            "totalTokenCount": 2
        }
    })
    .to_string()
}

fn output_tool_response(name: &str) -> String {
    serde_json::json!({
        "candidates": [{
            "content": {
                "parts": [{
                    "functionCall": {
                        "args": smoke_structured_output_value(),
                        "name": name
                    }
                }],
                "role": "model"
            },
            "finishReason": "STOP",
            "index": 0
        }],
        "modelVersion": gemini::completion::GEMINI_2_5_FLASH,
        "responseId": "gemini-runtime-recovery-final",
        "usageMetadata": {
            "promptTokenCount": 1,
            "candidatesTokenCount": 1,
            "totalTokenCount": 2
        }
    })
    .to_string()
}

#[tokio::test]
async fn classic_invalid_output_recovers_through_gemini_generate_content() {
    let http = SequencedHttpClient::new([
        MockHttpResponse::success(text_response("not valid JSON", "gemini-runtime-invalid")),
        MockHttpResponse::success(output_tool_response("final_result")),
    ]);
    let client = GeminiConfig::new("test-key");
    let agent = rig::AgentBuilder::new(
        client
            .connect(http.clone())
            .completion(gemini::completion::GEMINI_2_5_FLASH),
    )
    .output_schema::<SmokeStructuredOutput>()
    .output_mode(OutputMode::Tool)
    .default_max_turns(2)
    .build();

    let response = agent
        .prompt(STRUCTURED_OUTPUT_PROMPT)
        .await
        .expect("classic Gemini output recovery should succeed");
    let structured: SmokeStructuredOutput =
        decode_structured_output("gemini_classic_recovery", &response.output())
            .expect("recovered output-tool arguments should deserialize");
    assert_smoke_structured_output(&structured);

    let requests = http.requests();
    assert_eq!(requests.len(), 2);
    assert_eq!(http.remaining_responses(), 0);
    let first: serde_json::Value =
        serde_json::from_slice(&requests[0].body).expect("request should be JSON");
    let second: serde_json::Value =
        serde_json::from_slice(&requests[1].body).expect("request should be JSON");
    assert_eq!(
        first["tools"][0]["functionDeclarations"][0]["name"],
        "final_result"
    );
    assert!(
        first
            .pointer("/generationConfig/responseJsonSchema")
            .is_none()
    );
    assert!(second.to_string().contains("final_result"));
}
