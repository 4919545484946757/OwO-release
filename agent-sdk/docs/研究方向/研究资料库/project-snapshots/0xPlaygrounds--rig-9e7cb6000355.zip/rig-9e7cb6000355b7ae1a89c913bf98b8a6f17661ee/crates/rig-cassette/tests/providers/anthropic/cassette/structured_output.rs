//! Anthropic structured output smoke test.

use rig::agent::OutputMode;
use rig::providers::anthropic::completion::CLAUDE_SONNET_4_6;
use rig::providers::anthropic::wire::AnthropicConfig;
use rig::test_utils::RecordingHttpClient;
use rig_agent::test_utils::decode_structured_output;

use crate::support::{
    STRUCTURED_OUTPUT_PROMPT, SmokeStructuredOutput, assert_smoke_structured_output,
    smoke_structured_output_value,
};

fn text_response(text: &str) -> String {
    serde_json::json!({
        "content": [{"type": "text", "text": text}],
        "id": "msg_runtime_acceptance",
        "model": CLAUDE_SONNET_4_6,
        "role": "assistant",
        "type": "message",
        "stop_reason": "end_turn",
        "stop_sequence": null,
        "usage": {
            "input_tokens": 1,
            "output_tokens": 1,
            "cache_read_input_tokens": null,
            "cache_creation_input_tokens": null
        }
    })
    .to_string()
}

fn output_tool_response(name: &str) -> String {
    serde_json::json!({
        "content": [{
            "type": "tool_use",
            "id": "toolu_runtime_acceptance",
            "name": name,
            "input": smoke_structured_output_value()
        }],
        "id": "msg_runtime_acceptance",
        "model": CLAUDE_SONNET_4_6,
        "role": "assistant",
        "type": "message",
        "stop_reason": "tool_use",
        "stop_sequence": null,
        "usage": {
            "input_tokens": 1,
            "output_tokens": 1,
            "cache_read_input_tokens": null,
            "cache_creation_input_tokens": null
        }
    })
    .to_string()
}

#[tokio::test]
async fn classic_tool_mode_maps_through_anthropic_messages() {
    let http = RecordingHttpClient::new(output_tool_response("final_result"));
    let client = AnthropicConfig::new("test-key");
    let agent = rig::AgentBuilder::new(client.connect(http.clone()).completion(CLAUDE_SONNET_4_6))
        .output_schema::<SmokeStructuredOutput>()
        .output_mode(OutputMode::Tool)
        .build();

    let response = agent
        .prompt(STRUCTURED_OUTPUT_PROMPT)
        .await
        .expect("classic Anthropic Tool-mode run should succeed")
        .output();
    let structured: SmokeStructuredOutput =
        decode_structured_output("anthropic_classic_tool_mode", &response)
            .expect("output-tool arguments should deserialize");
    assert_smoke_structured_output(&structured);

    let requests = http.requests();
    assert_eq!(requests.len(), 1);
    let body: serde_json::Value =
        serde_json::from_slice(&requests[0].body).expect("request should be JSON");
    assert_eq!(body["tools"][0]["name"], "final_result");
    assert!(body.get("output_config").is_none());
}

#[tokio::test]
async fn classic_prompted_mode_maps_through_anthropic_messages() {
    let output = smoke_structured_output_value();
    let http = RecordingHttpClient::new(text_response(&output.to_string()));
    let client = AnthropicConfig::new("test-key");
    let agent = rig::AgentBuilder::new(client.connect(http.clone()).completion(CLAUDE_SONNET_4_6))
        .output_schema::<SmokeStructuredOutput>()
        .output_mode(OutputMode::Prompted)
        .build();

    let response = agent
        .prompt(STRUCTURED_OUTPUT_PROMPT)
        .await
        .expect("classic Anthropic Prompted-mode run should succeed")
        .output();
    let structured: SmokeStructuredOutput =
        decode_structured_output("anthropic_classic_prompted_mode", &response)
            .expect("prompted JSON should deserialize");
    assert_smoke_structured_output(&structured);

    let requests = http.requests();
    assert_eq!(requests.len(), 1);
    let body: serde_json::Value =
        serde_json::from_slice(&requests[0].body).expect("request should be JSON");
    assert!(body.get("tools").is_none());
    assert!(body.get("output_config").is_none());
    assert!(
        body["system"][0]["text"]
            .as_str()
            .is_some_and(|text| text.contains("JSON Schema") && text.contains("ONLY"))
    );
}
