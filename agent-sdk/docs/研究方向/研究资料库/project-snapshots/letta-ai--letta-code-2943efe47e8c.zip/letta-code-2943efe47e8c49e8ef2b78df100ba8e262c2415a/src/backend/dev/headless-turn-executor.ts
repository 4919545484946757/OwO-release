import type { Stream } from "@letta-ai/letta-client/core/streaming";
import type { LettaStreamingResponse } from "@letta-ai/letta-client/resources/agents/messages";
import type {
  ConversationMessageCreateBody,
  ConversationMessageStreamBody,
} from "@/backend/backend";
import type { LocalMessage } from "@/backend/local/local-message";
import type {
  LocalAgentRecord,
  StoredMessage,
} from "@/backend/local/local-store";

export type HeadlessTurnBody =
  | ConversationMessageCreateBody
  | ConversationMessageStreamBody;

export interface HeadlessTurnExecutorInput {
  conversationId: string;
  agentId: string;
  agent: LocalAgentRecord;
  systemPrompt?: string;
  midConversationSystemPrompt?: string;
  body: HeadlessTurnBody;
  history: StoredMessage[];
  uiMessages: LocalMessage[];
}

export interface HeadlessTurnExecutor {
  execute(
    input: HeadlessTurnExecutorInput,
  ): Promise<Stream<LettaStreamingResponse>>;
}

function createStream(
  chunks: LettaStreamingResponse[],
): Stream<LettaStreamingResponse> {
  const controller = new AbortController();
  return {
    controller,
    async *[Symbol.asyncIterator]() {
      for (const chunk of chunks) {
        yield chunk;
      }
    },
  } as unknown as Stream<LettaStreamingResponse>;
}

export function createAssistantMessageStream(
  message: Partial<Pick<StoredMessage, "id" | "date" | "content">> = {},
): Stream<LettaStreamingResponse> {
  return createStream([
    {
      message_type: "assistant_message",
      ...(message.id ? { id: message.id } : {}),
      ...(message.date ? { date: message.date } : {}),
      content: message.content ?? [{ type: "text", text: "pong" }],
    } as LettaStreamingResponse,
    {
      message_type: "stop_reason",
      stop_reason: "end_turn",
    } as LettaStreamingResponse,
  ]);
}

function hasApprovalResults(body: HeadlessTurnBody): boolean {
  const messages = (body as { messages?: Array<Record<string, unknown>> })
    .messages;
  return (messages ?? []).some((message) => message.type === "approval");
}

function summarizeApprovalResults(body: HeadlessTurnBody): string {
  const messages =
    (
      body as {
        messages?: Array<{ approvals?: Array<Record<string, unknown>> }>;
      }
    ).messages ?? [];
  const approvals = messages.flatMap((message) => message.approvals ?? []);
  const firstToolResult = approvals.find(
    (approval) => approval.type === "tool",
  );
  const status =
    typeof firstToolResult?.status === "string"
      ? firstToolResult.status
      : "unknown";
  const toolReturn = firstToolResult?.tool_return;
  const text =
    typeof toolReturn === "string"
      ? toolReturn
      : JSON.stringify(toolReturn ?? "");
  return `tool result received (${status}): ${text.slice(0, 240)}`;
}

export class DeterministicPongExecutor implements HeadlessTurnExecutor {
  async execute(_input: HeadlessTurnExecutorInput) {
    return createAssistantMessageStream();
  }
}

function isReflectionTurn(body: HeadlessTurnBody): boolean {
  return JSON.stringify(body).includes("$TRANSCRIPT_PATH");
}

/**
 * Deterministic test executor that keeps ordinary turns simple while making a
 * reflection prove it opened the transcript before returning success.
 */
export class DeterministicReflectionExecutor implements HeadlessTurnExecutor {
  private toolCallSeq = 0;

  async execute(input: HeadlessTurnExecutorInput) {
    if (hasApprovalResults(input.body)) {
      return createAssistantMessageStream({
        content: [{ type: "text", text: "reflection transcript inspected" }],
      });
    }
    if (!isReflectionTurn(input.body)) {
      return createAssistantMessageStream();
    }

    this.toolCallSeq += 1;
    const toolCallId = `tool-call-reflection-read-${this.toolCallSeq}`;
    return createStream([
      {
        message_type: "approval_request_message",
        tool_call: {
          tool_call_id: toolCallId,
          name: "Bash",
          arguments: JSON.stringify({
            command:
              "bun -e \"const fs=require('fs');const p=process.env.TRANSCRIPT_PATH;if(!p)throw new Error('TRANSCRIPT_PATH missing');process.stdout.write(fs.readFileSync(p,'utf8'))\"",
            description: "Read the reflection transcript payload",
            login: false,
          }),
        },
      } as LettaStreamingResponse,
      {
        message_type: "stop_reason",
        stop_reason: "requires_approval",
      } as LettaStreamingResponse,
    ]);
  }
}

export class DeterministicToolCallExecutor implements HeadlessTurnExecutor {
  private toolCallSeq = 0;

  async execute(input: HeadlessTurnExecutorInput) {
    if (hasApprovalResults(input.body)) {
      return createAssistantMessageStream({
        content: [{ type: "text", text: summarizeApprovalResults(input.body) }],
      });
    }

    this.toolCallSeq += 1;
    const toolCallId = `tool-call-fake-shell-${this.toolCallSeq}`;
    return createStream([
      {
        message_type: "approval_request_message",
        tool_call: {
          tool_call_id: toolCallId,
          name: "Bash",
          arguments: JSON.stringify({
            command: "echo deterministic-tool-ok",
            description: "Run the deterministic test command",
            login: false,
          }),
        },
      } as LettaStreamingResponse,
      {
        message_type: "stop_reason",
        stop_reason: "requires_approval",
      } as LettaStreamingResponse,
    ]);
  }
}
