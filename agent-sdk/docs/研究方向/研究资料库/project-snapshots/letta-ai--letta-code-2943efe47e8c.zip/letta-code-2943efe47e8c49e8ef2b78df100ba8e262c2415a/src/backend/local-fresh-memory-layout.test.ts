import { describe, expect, test } from "bun:test";
import { execFileSync } from "node:child_process";
import { mkdtemp, readdir, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { stampRootMemoryOnCreateBody } from "@/agent/memory-filesystem";
import { initialMemoryFilesFromCreateBody } from "@/backend/local/initial-memory";
import { LocalBackend } from "@/backend/local/local-backend";

describe("fresh local agent memory layout", () => {
  test("rejects labels that collapse onto the same root path", () => {
    const body = stampRootMemoryOnCreateBody({
      memory_blocks: [
        { label: "profile/details", value: "nested" },
        { label: "profile_details", value: "flat" },
      ],
    } as never);

    expect(() => initialMemoryFilesFromCreateBody(body)).toThrow(
      "Initial memory path collision at profile_details.md",
    );
  });

  test("uses the root layout when the create body omits the MEMORY block", () => {
    const files = initialMemoryFilesFromCreateBody({
      memory_blocks: [{ label: "system/persona", value: "I am rooted." }],
    } as never);

    expect(files.map((file) => file.relativePath)).toEqual([
      "MEMORY.md",
      "persona.md",
    ]);
    expect(files[1]?.content).toContain("name: Persona");
  });

  test("creates and compiles the canonical root MemFS layout", async () => {
    const storageDir = await mkdtemp(join(tmpdir(), "local-root-memfs-"));
    try {
      const backend = new LocalBackend({ storageDir });
      const agent = await backend.createAgent({
        name: "Root Memory Agent",
        system: "base {CORE_MEMORY}",
        memory_blocks: [
          {
            label: "persona",
            value: "I am rooted.",
            description: "Who the agent is",
          },
          {
            label: "human",
            value: "The human prefers concise answers.",
            description: "Who the agent works with",
          },
        ],
      } as never);
      const memoryDir = join(storageDir, "memfs", agent.id, "memory");

      expect((await readdir(memoryDir)).sort()).toEqual([
        ".git",
        "MEMORY.md",
        "human.md",
        "persona.md",
      ]);
      expect(await readFile(join(memoryDir, "MEMORY.md"), "utf8")).toBe(
        "# Memory\n",
      );
      expect(await readFile(join(memoryDir, "persona.md"), "utf8")).toContain(
        "name: Persona",
      );
      expect(await readFile(join(memoryDir, "persona.md"), "utf8")).toContain(
        "description: Who the agent is",
      );
      expect(() =>
        execFileSync("git", ["show", "HEAD:system/persona.md"], {
          cwd: memoryDir,
          stdio: "ignore",
        }),
      ).toThrow();

      const conversation = await backend.createConversation({
        agent_id: agent.id,
      } as never);
      const compiled = await backend.recompileConversation(conversation.id, {
        agent_id: agent.id,
        dry_run: true,
      } as never);
      expect(compiled).toContain("<memory>\n# Memory\n</memory>");
      expect(compiled).toContain("<persona>");
      expect(compiled).toContain("I am rooted.");
    } finally {
      await rm(storageDir, { recursive: true, force: true });
    }
  });
});
