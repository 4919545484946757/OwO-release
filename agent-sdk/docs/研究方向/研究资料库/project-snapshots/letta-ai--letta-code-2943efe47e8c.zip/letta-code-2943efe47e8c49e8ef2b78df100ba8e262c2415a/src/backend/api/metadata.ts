import { LETTA_CLOUD_API_URL } from "@/auth/oauth";
import { isLoopbackUrl } from "@/utils/url";
import { apiRequest, getApiRequestConfig } from "./request";

export interface BalanceMetadata {
  total_balance: number;
  monthly_credit_balance: number;
  purchased_credit_balance: number;
  billing_tier: string;
  /** The caller's organization (newer servers). */
  organization_id?: string;
}

type QuotaBucket = "empty" | "low" | "medium" | "high" | "full";

interface ModelTierQuota {
  bucket: QuotaBucket;
  dailyBucket?: QuotaBucket;
}

export interface ModelQuotaMetadata {
  lettaTier: ModelTierQuota;
  quotaWindowEnd: string;
  dailyQuotaWindowEnd?: string;
}

export type FeedbackClientType = "desktop" | "chat.letta.com" | "cli";

export function getFeedbackClientType(
  env: NodeJS.ProcessEnv = process.env,
): FeedbackClientType {
  if (env.LETTA_DESKTOP_MODE === "1") {
    return "desktop";
  }
  if (env.LETTA_RUNTIME_ENVIRONMENT_DEVICE_ID) {
    return "chat.letta.com";
  }
  return "cli";
}

export async function getBalanceMetadata(
  options: { signal?: AbortSignal } = {},
): Promise<BalanceMetadata> {
  return apiRequest<BalanceMetadata>(
    "GET",
    "/v1/metadata/balance",
    undefined,
    options.signal ? { signal: options.signal } : {},
  );
}

export async function getModelQuotaMetadata(): Promise<ModelQuotaMetadata> {
  return apiRequest<ModelQuotaMetadata>("GET", "/v1/organizations/self/quotas");
}

export async function getBillingTier(): Promise<string | null> {
  try {
    const balance = await getBalanceMetadata();
    return balance.billing_tier ?? null;
  } catch {
    return null;
  }
}

function isDesktopListenerRuntime(): boolean {
  return process.env.LETTA_DESKTOP_MODE === "1";
}

async function getMetadataRequestConfig(
  apiKey: string | undefined,
): Promise<{ baseUrl: string; apiKey: string }> {
  if (
    !isDesktopListenerRuntime() ||
    process.env.LETTA_LOCAL_BACKEND_EXPERIMENTAL === "1"
  ) {
    return { baseUrl: LETTA_CLOUD_API_URL, apiKey: apiKey ?? "" };
  }

  const config = await getApiRequestConfig();

  if (isLoopbackUrl(config.baseUrl)) {
    return config;
  }

  return { baseUrl: LETTA_CLOUD_API_URL, apiKey: apiKey ?? "" };
}

export async function submitFeedbackMetadata(
  apiKey: string | undefined,
  deviceId: string,
  payload: Record<string, unknown>,
): Promise<void> {
  const config = await getMetadataRequestConfig(apiKey);
  await apiRequest<void>("POST", "/v1/metadata/feedback", payload, {
    ...config,
    headers: {
      "X-Letta-Code-Device-ID": deviceId,
    },
  });
}

export async function submitTelemetryMetadata(
  apiKey: string | undefined,
  deviceId: string,
  payload: Record<string, unknown>,
  options?: { signal?: AbortSignal; actingUserId?: string | null },
): Promise<void> {
  const config = await getMetadataRequestConfig(apiKey);
  await apiRequest<void>("POST", "/v1/metadata/telemetry", payload, {
    ...config,
    // Telemetry snapshots the acting user when the event is created. `null`
    // prevents a later headless env value from replacing an empty snapshot.
    actingUserId: options?.actingUserId ?? null,
    headers: {
      "X-Letta-Code-Device-ID": deviceId,
    },
    signal: options?.signal,
  });
}
