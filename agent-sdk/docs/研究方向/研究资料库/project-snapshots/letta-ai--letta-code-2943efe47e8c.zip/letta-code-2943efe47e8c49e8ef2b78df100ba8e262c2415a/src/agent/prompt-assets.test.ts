import { describe, expect, test } from "bun:test";
import {
  buildSystemPrompt,
  isKnownPreset,
  SYSTEM_PROMPTS,
  shouldRecommendDefaultPrompt,
} from "@/agent/prompt-assets";
import initV2Prompt from "@/agent/subagents/builtin/init-v2.md";
import memoryV2Prompt from "@/agent/subagents/builtin/memory-v2.md";
import reflectionV2Prompt from "@/agent/subagents/builtin/reflection-v2.md";
import { resolveAndBuildSystemPrompt } from "@/agent/system-prompt-resolution";
import initializingMemoryPrompt from "@/skills/builtin/initializing-memory/SKILL.md";
import { TOOLSET_CATALOG } from "@/tools/toolset-catalog";

const HOSTED_EXTERNAL_MEMORY_INTRO =
  "External memory is stored outside of the system prompt, including both skills (procedural memory), general-purpose files (markdown files, images, etc.), and shared memory.";
const LOCAL_EXTERNAL_MEMORY_INTRO =
  "External memory is stored outside of the system prompt, including both skills (procedural memory) and general-purpose files (markdown files, images, etc.).";

const ROOT_ONLY_PROMPT_ASSETS = [
  initializingMemoryPrompt,
  initV2Prompt,
  memoryV2Prompt,
  reflectionV2Prompt,
];
const SYSTEM_DIRECTORY_PATH = /(^|[^A-Za-z0-9_-])(?:\$MEMORY_DIR\/)?system\//m;

function containsSystemDirectoryPath(content: string): boolean {
  return SYSTEM_DIRECTORY_PATH.test(content);
}

function withoutSharedMemoryGuidance(prompt: string): string {
  expect(prompt).toContain(HOSTED_EXTERNAL_MEMORY_INTRO);
  const withLocalIntro = prompt.replace(
    HOSTED_EXTERNAL_MEMORY_INTRO,
    LOCAL_EXTERNAL_MEMORY_INTRO,
  );
  const sectionStart = withLocalIntro.indexOf("#### Shared memory\n");
  const sectionEnd = withLocalIntro.indexOf(
    "### Syncing memory, state, and context\n",
    sectionStart,
  );
  expect(sectionStart).toBeGreaterThanOrEqual(0);
  expect(sectionEnd).toBeGreaterThan(sectionStart);
  return `${withLocalIntro.slice(0, sectionStart)}${withLocalIntro.slice(sectionEnd)}`;
}

describe("isKnownPreset", () => {
  test("returns true for known preset IDs", () => {
    expect(isKnownPreset("default")).toBe(true);
    expect(isKnownPreset("letta")).toBe(true);
    expect(isKnownPreset("source-claude")).toBe(true);
  });

  test("returns false for unknown IDs", () => {
    expect(isKnownPreset("recall")).toBe(false);
    expect(isKnownPreset("nonexistent")).toBe(false);
    // Old IDs should no longer be known
    expect(isKnownPreset("letta-claude")).toBe(false);
    expect(isKnownPreset("claude")).toBe(false);
  });
});

describe("buildSystemPrompt", () => {
  test("returns the standard full prompt for standard memory mode", () => {
    const result = buildSystemPrompt("letta", "standard");
    const preset = SYSTEM_PROMPTS.find((p) => p.id === "letta");
    expect(preset).toBeDefined();

    expect(result).toBe(preset?.content.trim() ?? "");
    expect(result).toContain("**In-context memory blocks**");
    expect(result).not.toContain("$MEMORY_DIR");
    expect(result).not.toContain("MemFS");
  });

  test("returns the memfs full prompt for memfs memory mode", () => {
    const result = buildSystemPrompt("letta", "memfs");
    const preset = SYSTEM_PROMPTS.find((p) => p.id === "letta");
    expect(preset).toBeDefined();
    expect(preset?.memfsContent).toBeDefined();

    expect(result).toBe(preset?.memfsContent?.trim() ?? "");
    expect(result).toContain("MemFS");
    expect(result).toContain("$MEMORY_DIR");
    expect(result).not.toContain("**In-context memory blocks**");
  });

  test("returns the local backend full prompt for local memfs mode", () => {
    const result = buildSystemPrompt("letta", "local-memfs");
    const preset = SYSTEM_PROMPTS.find((p) => p.id === "letta");
    expect(preset).toBeDefined();

    expect(preset?.localMemfsContent).toBeDefined();
    expect(result).toBe(preset?.localMemfsContent?.trim() ?? "");
    expect(result).not.toBe(buildSystemPrompt("letta", "memfs"));
    expect(result).toContain("$MEMORY_DIR");
    expect(result).not.toContain("git push");
    expect(result).not.toContain("Shared memory");
  });

  test("returns the root-layout full prompt for root memfs mode", () => {
    const result = buildSystemPrompt("letta", "root-memfs");
    const preset = SYSTEM_PROMPTS.find((p) => p.id === "letta");

    expect(preset?.rootMemfsContent).toBeDefined();
    expect(result).toBe(preset?.rootMemfsContent?.trim() ?? "");
    expect(result).toContain(
      "Root `MEMORY.md` is a frontmatter-free overview and index",
    );
    expect(result).toContain("exactly `name` and `description` frontmatter");
    expect(result).toContain("#### Shared memory");
    expect(result).toContain("root `persona.md`");
    expect(containsSystemDirectoryPath(result)).toBe(false);
    expect(result).not.toContain("Memory blocks are editable segments");
  });

  test("system directory matcher ignores filesystem words", () => {
    expect(
      containsSystemDirectoryPath("standard filesystem/bash operations"),
    ).toBe(false);
    expect(containsSystemDirectoryPath("filesystem/bulk operations")).toBe(
      false,
    );
    expect(containsSystemDirectoryPath("`system/`")).toBe(true);
    expect(containsSystemDirectoryPath("$MEMORY_DIR/system/persona.md")).toBe(
      true,
    );
  });

  test("root-only prompt assets contain no system directory paths", () => {
    for (const asset of ROOT_ONLY_PROMPT_ASSETS) {
      expect(containsSystemDirectoryPath(asset)).toBe(false);
    }
  });

  test.each(["memfs", "local-memfs", "root-memfs"] as const)(
    "%s defers delegation policy to the Agent tool and keeps direct editing",
    (mode) => {
      const result = buildSystemPrompt("letta", mode);
      expect(result).toContain("`memory` subagent's entry in the Agent tool");
      expect(result).not.toContain("**Memory upkeep during another task:**");
      expect(result).toContain("git commit --author=");
      expect(result).not.toContain("Delegate all memory changes");
      expect(result).not.toContain("Leave memory writes and Git repair");
    },
  );

  test("memfs prompt explains shared-memory projections", () => {
    const result = buildSystemPrompt("letta", "memfs");

    expect(result).toContain("#### Shared memory");
    expect(result).toContain("shared memory repository");
    expect(buildSystemPrompt("letta", "local-memfs")).not.toContain(
      "#### Shared memory",
    );
  });

  test("hosted and local memfs prompts differ only in shared-memory guidance", () => {
    const hosted = buildSystemPrompt("letta", "memfs");
    const local = buildSystemPrompt("letta", "local-memfs");

    expect(withoutSharedMemoryGuidance(hosted)).toBe(local);
  });

  test("default prompt variants explain future invocations", () => {
    for (const mode of [
      "standard",
      "memfs",
      "root-memfs",
      "local-memfs",
    ] as const) {
      const result = buildSystemPrompt("letta", mode);

      expect(result).toContain(
        "To act across time, you must create future invocations explicitly",
      );
      expect(result).toContain(
        "crons (also called schedules) proactively invoke you",
      );
      expect(result).toContain("monitors reactively invoke you");
      expect(result).toContain(
        "Use Wake for a future turn in the current conversation",
      );
      expect(result).toContain("advanced `letta cron` schedules");
      expect(result).not.toContain("Create one-shot or recurring crons");
      expect(result).not.toContain("proactive in creating crons");
      expect(result).toContain(
        "MUST** be proactive in arranging the appropriate future invocation",
      );
      expect(result).toContain("live in the scheduling-tasks skill");
    }
  });

  test("throws on unknown preset", () => {
    expect(() => buildSystemPrompt("unknown-id", "standard")).toThrow(
      'Unknown preset "unknown-id"',
    );
  });

  test("is idempotent — same inputs always produce same output", () => {
    const first = buildSystemPrompt("default", "memfs");
    const second = buildSystemPrompt("default", "memfs");
    expect(first).toBe(second);
  });

  test("default and letta presets resolve to same content in both memory modes", () => {
    expect(buildSystemPrompt("default", "standard")).toBe(
      buildSystemPrompt("letta", "standard"),
    );
    expect(buildSystemPrompt("default", "memfs")).toBe(
      buildSystemPrompt("letta", "memfs"),
    );
    expect(buildSystemPrompt("default", "root-memfs")).toBe(
      buildSystemPrompt("letta", "root-memfs"),
    );
    expect(buildSystemPrompt("default", "local-memfs")).toBe(
      buildSystemPrompt("letta", "local-memfs"),
    );
  });

  test("presets without a memfs variant are treated as complete prompts", () => {
    expect(buildSystemPrompt("source-claude", "memfs")).toBe(
      buildSystemPrompt("source-claude", "standard"),
    );
  });
});

describe("resolveAndBuildSystemPrompt", () => {
  test("returns known presets without appending memory sections", async () => {
    const standard = await resolveAndBuildSystemPrompt("letta", "standard");
    const memfs = await resolveAndBuildSystemPrompt("letta", "memfs");

    expect(standard).toBe(buildSystemPrompt("letta", "standard"));
    expect(memfs).toBe(buildSystemPrompt("letta", "memfs"));
  });
});

describe("shouldRecommendDefaultPrompt", () => {
  test("returns false when prompt matches current default (standard)", () => {
    const current = buildSystemPrompt("default", "standard");
    expect(shouldRecommendDefaultPrompt(current, "standard")).toBe(false);
  });

  test("returns false when prompt matches current default (memfs)", () => {
    const current = buildSystemPrompt("default", "memfs");
    expect(shouldRecommendDefaultPrompt(current, "memfs")).toBe(false);
  });

  test("returns true for a different preset", () => {
    const current = buildSystemPrompt("source-claude", "standard");
    expect(shouldRecommendDefaultPrompt(current, "standard")).toBe(true);
    expect(current).toContain("TaskCreate");
    expect(current).toContain("TaskUpdate");
    expect(current).not.toContain("TodoWrite");
    expect(TOOLSET_CATALOG.default.tools).toContain("TaskCreate");
    expect(TOOLSET_CATALOG.default.tools).toContain("TaskUpdate");
  });

  test("returns true for a fully custom prompt", () => {
    expect(
      shouldRecommendDefaultPrompt("You are a custom agent.", "standard"),
    ).toBe(true);
  });

  test("returns true for a modified default prompt", () => {
    const current = buildSystemPrompt("default", "standard");
    const modified = `${current}\n\nExtra instructions added by user.`;
    expect(shouldRecommendDefaultPrompt(modified, "standard")).toBe(true);
  });
});
