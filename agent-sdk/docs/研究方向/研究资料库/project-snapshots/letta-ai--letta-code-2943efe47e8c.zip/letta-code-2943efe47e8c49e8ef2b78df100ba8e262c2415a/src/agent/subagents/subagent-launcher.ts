// How a subagent child process is launched: the command/args to spawn, the
// working directory it runs in, and the environment it inherits (including the
// memory-subagent MEMORY_DIR wiring).
//
// Extracted from `manager.ts`. Pure resolution helpers — they depend only on
// lower-level backend/runtime/shell helpers and shared subagent types, never
// back on the subagent manager, so the graph stays acyclic.

import { homedir } from "node:os";
import { join } from "node:path";
import { ACTING_USER_ID_ENV } from "@/agent/acting-user";
import { type BackendMode, getLocalBackendStorageDir } from "@/backend";
import { getLocalBackendMemoryFilesystemRoot } from "@/backend/local/paths";
import {
  LETTA_MOD_CAPABILITY_PROFILE_ENV,
  PROVIDERS_ONLY_MOD_CAPABILITY_PROFILE,
} from "@/mods/capabilities";
import { getCurrentWorkingDirectory } from "@/runtime-context";
import { trackBoundaryError } from "@/telemetry/error-reporting";
import {
  resolveEntryScriptPath,
  resolveLettaInvocation,
} from "@/tools/impl/shell-env";
import {
  readSubagentDepth,
  SUBAGENT_DEPTH_ENV,
} from "@/utils/subagent-depth-env";
import {
  LISTENER_CONNECTION_ENV,
  SUBAGENT_LAUNCH_ENV,
  SUBAGENT_LAUNCH_PROFILE_ENV,
  SUBAGENT_NAME_ENV,
} from "@/utils/subagent-launch-marker";
import { TRANSCRIPT_ROOT_ENV } from "@/utils/transcript-paths";
import { getActiveRuntime } from "@/websocket/listener/runtime";
import type { SubagentLaunchProfile, SubagentMemoryScope } from ".";
import { MEMORY_WORKER_SESSION_ENV } from "./memory-worker-session";

interface ResolveSubagentLauncherOptions {
  env?: NodeJS.ProcessEnv;
  argv?: string[];
  execPath?: string;
  platform?: NodeJS.Platform;
  cwd?: string;
}

interface SubagentLauncher {
  command: string;
  args: string[];
}

export function resolveSubagentWorkingDirectory(
  env: NodeJS.ProcessEnv = process.env,
  fallbackCwd: string = getCurrentWorkingDirectory(),
  options: {
    subagentType?: string;
    launchProfile?: SubagentLaunchProfile;
    inheritedPrimaryRoot?: string | null;
    memoryScope?: SubagentMemoryScope;
  } = {},
): string {
  if (
    options.subagentType === "reflection" &&
    options.launchProfile === "memory-subagent" &&
    options.memoryScope
  ) {
    return env.USER_CWD || fallbackCwd;
  }

  if (
    options.subagentType !== "reflection" &&
    options.launchProfile === "memory-subagent" &&
    options.memoryScope?.primaryRoot
  ) {
    return options.memoryScope.primaryRoot;
  }

  const primaryRoot =
    options.memoryScope?.primaryRoot ?? options.inheritedPrimaryRoot;
  if (
    options.subagentType === "reflection" &&
    options.launchProfile === "memory-subagent" &&
    primaryRoot
  ) {
    return primaryRoot;
  }

  return env.USER_CWD || fallbackCwd;
}

export function resolveSubagentLauncher(
  cliArgs: string[],
  options: ResolveSubagentLauncherOptions = {},
): SubagentLauncher {
  const env = options.env ?? process.env;
  const argv = options.argv ?? process.argv;
  const execPath = options.execPath ?? process.execPath;
  const platform = options.platform ?? process.platform;
  const cwd = options.cwd ?? process.cwd();

  const invocation = resolveLettaInvocation(env, argv, execPath, cwd);
  if (invocation) {
    return {
      command: invocation.command,
      args: [...invocation.args, ...cliArgs],
    };
  }

  const currentScript = argv[1] || "";
  const resolvedCurrentScript = resolveEntryScriptPath(currentScript, cwd);

  // Preserve historical subagent behavior: any .ts entrypoint uses runtime binary.
  if (currentScript.endsWith(".ts")) {
    return {
      command: execPath,
      args: [resolvedCurrentScript, ...cliArgs],
    };
  }

  // Windows cannot reliably spawn bundled .js directly (EFTYPE/EINVAL).
  if (currentScript.endsWith(".js") && platform === "win32") {
    return {
      command: execPath,
      args: [resolvedCurrentScript, ...cliArgs],
    };
  }

  if (currentScript.endsWith(".js")) {
    return {
      command: resolvedCurrentScript,
      args: cliArgs,
    };
  }

  return {
    command: "letta",
    args: cliArgs,
  };
}

export interface ComposeSubagentChildEnvOptions {
  /** The env of the process spawning the subagent (parent). */
  parentProcessEnv: NodeJS.ProcessEnv;
  listenerConnectionId?: string | null;
  /** Active backend mode to force in the child CLI process. */
  backendMode?: BackendMode;
  /** Local backend flatfile root to forward when backendMode="local". */
  localBackendStorageDir?: string | null;
  /** Parent agent ID. When present, sets LETTA_PARENT_AGENT_ID so prompts,
   * scripts, and the cross-agent guard can identify the immediate parent. */
  parentAgentId: string | undefined;
  parentConversationId?: string;
  /** Subagent config type, used for type-specific child process isolation. */
  subagentType?: string;
  /** The subagent config's declared launch profile. Subagents with the memory-subagent profile
   * operate on the parent's memory filesystem. */
  launchProfile: SubagentLaunchProfile | undefined;
  /** Primary memory root for the parent, used by the memory-subagent launch
   * profile to point the child at its parent's memfs repo. Null means memfs
   * disabled or unresolvable — child operates without a MEMORY_DIR. */
  inheritedPrimaryRoot: string | null;
  /** Optional exact memory scope for harness-created worktrees. */
  memoryScope?: SubagentMemoryScope;
  /** Forwarded API key to avoid per-subagent keychain lookups. */
  inheritedApiKey?: string | null;
  /** Forwarded base URL to avoid per-subagent settings lookups. */
  inheritedBaseUrl?: string | null;
  /** Authenticated Cloud user responsible for the parent turn. */
  actingUserId?: string | null;
  /** Optional path to a transcript payload file, exposed to the child as
   * the TRANSCRIPT_PATH env var. Used by reflection subagents so the prompt
   * can reference `$TRANSCRIPT_PATH` (resolved via Bash) instead of
   * interpolating the absolute path. Unset → no TRANSCRIPT_PATH in child. */
  transcriptPath?: string | null;
  /** Name reserved in the parent process, only for a newly created agent. */
  subagentName?: string;
  /** Parent-process task ID used to isolate child background output files. */
  subagentId?: string;
}

function resolveMemorySubagentScratchpad(
  parentProcessEnv: NodeJS.ProcessEnv,
  subagentId?: string,
): string {
  const configuredScratchpad = parentProcessEnv.LETTA_SCRATCHPAD;
  if (configuredScratchpad?.trim()) {
    return configuredScratchpad;
  }

  const configuredTranscriptRoot = parentProcessEnv[TRANSCRIPT_ROOT_ENV];
  const transcriptRoot =
    configuredTranscriptRoot?.trim() ||
    join(parentProcessEnv.HOME?.trim() || homedir(), ".letta", "transcripts");
  const scope = subagentId
    ? encodeURIComponent(subagentId)
    : crypto.randomUUID();
  return join(transcriptRoot, "background", scope);
}

/**
 * Compose the env a subagent child process should be spawned with.
 *
 * The parent identity marker and filesystem pointer are intentionally
 * decoupled:
 *
 *   - LETTA_PARENT_AGENT_ID identifies the immediate parent. Subagents never
 *     inherit a broad cross-agent memory-guard opt-out from the parent.
 *
 *   - MEMORY_DIR / LETTA_MEMORY_DIR are only overridden when the subagent
 *     declares the memory-subagent launch profile. Those subagents operate on
 *     the parent's memory as their working filesystem (reflection, memory,
 *     init). Other subagents keep whatever MEMORY_DIR they
 *     inherited from the parent process (usually unset).
 *
 * Pure function, no side effects — straightforward to unit-test.
 */
export function composeSubagentChildEnv(
  options: ComposeSubagentChildEnvOptions,
): NodeJS.ProcessEnv {
  const {
    parentProcessEnv,
    listenerConnectionId,
    backendMode,
    localBackendStorageDir,
    parentAgentId,
    subagentType,
    launchProfile,
    inheritedPrimaryRoot,
    memoryScope,
    inheritedApiKey,
    inheritedBaseUrl,
    actingUserId,
    transcriptPath,
  } = options;

  const childEnv: NodeJS.ProcessEnv = {
    ...parentProcessEnv,
    ...(inheritedApiKey && { LETTA_API_KEY: inheritedApiKey }),
    ...(inheritedBaseUrl && { LETTA_BASE_URL: inheritedBaseUrl }),
    LETTA_CODE_AGENT_ROLE: "subagent",
    [MEMORY_WORKER_SESSION_ENV]: subagentType === "memory" ? "1" : undefined,
    [SUBAGENT_LAUNCH_ENV]: "1",
    [SUBAGENT_LAUNCH_PROFILE_ENV]: launchProfile ?? "default",
    ...((subagentType === "reflection" || subagentType === "memory") && {
      [LETTA_MOD_CAPABILITY_PROFILE_ENV]: PROVIDERS_ONLY_MOD_CAPABILITY_PROFILE,
    }),
    // Replace inherited parent addresses even when the new scope is unknown.
    LETTA_PARENT_AGENT_ID: parentAgentId,
    LETTA_PARENT_CONVERSATION_ID: options.parentConversationId,
    // Children are one level below the process (or listener turn) launching them.
    [SUBAGENT_DEPTH_ENV]: String(readSubagentDepth(parentProcessEnv) + 1),
    ...(transcriptPath && { TRANSCRIPT_PATH: transcriptPath }),
  };

  // A nested launch must never reuse its parent's assigned creation name.
  if (actingUserId) childEnv[ACTING_USER_ID_ENV] = actingUserId;
  else if (actingUserId === null) delete childEnv[ACTING_USER_ID_ENV];
  delete childEnv[SUBAGENT_NAME_ENV];
  if (options.subagentName) childEnv[SUBAGENT_NAME_ENV] = options.subagentName;

  if (backendMode === "local") {
    childEnv.LETTA_LOCAL_BACKEND_EXPERIMENTAL = "1";
    if (localBackendStorageDir) {
      childEnv.LETTA_LOCAL_BACKEND_DIR = localBackendStorageDir;
    }
  } else if (backendMode === "api") {
    childEnv.LETTA_LOCAL_BACKEND_EXPERIMENTAL = "0";
  }

  // Only subagents with the memory-subagent profile get MEMORY_DIR pointed at the parent. Other
  // subagents either have their own memfs (if memfs-enabled) or no MEMORY_DIR
  // at all — their tools will surface resolution errors appropriately.
  if (launchProfile === "memory-subagent") {
    delete childEnv[LISTENER_CONNECTION_ENV];
    childEnv.LETTA_SCRATCHPAD = resolveMemorySubagentScratchpad(
      parentProcessEnv,
      options.subagentId,
    );
    const primaryRoot = memoryScope?.primaryRoot ?? inheritedPrimaryRoot;
    if (primaryRoot) {
      childEnv.MEMORY_DIR = primaryRoot;
      childEnv.LETTA_MEMORY_DIR = primaryRoot;
    } else {
      delete childEnv.MEMORY_DIR;
      delete childEnv.LETTA_MEMORY_DIR;
    }
  } else if (listenerConnectionId?.startsWith("conn-")) {
    childEnv[LISTENER_CONNECTION_ENV] = listenerConnectionId;
  } else if (
    isUnattachedListenerLaunch({
      listenerConnectionId,
      launchProfile,
      listenerConnectionCount: getActiveRuntime()?.connections.size ?? 0,
    })
  ) {
    // A direct-API child inside a listener is unowned; later sends to it
    // start a second harness on its conversation.
    trackBoundaryError({
      errorType: "subagent_launch_missing_listener_connection",
      error: new Error(
        "Subagent launched in a listener without its connection",
      ),
      context: "subagent_launch",
    });
  }

  return childEnv;
}

/**
 * A child launched inside a running listener but without its connection would
 * fall back to a direct-API process that no listener owns.
 */
export function isUnattachedListenerLaunch(options: {
  listenerConnectionId?: string | null;
  launchProfile?: string;
  listenerConnectionCount: number;
}): boolean {
  return (
    !options.listenerConnectionId &&
    options.launchProfile !== "memory-subagent" &&
    options.listenerConnectionCount > 0
  );
}

export function shouldLaunchThroughListener(options: {
  launchProfile?: string;
  cloudBackend: boolean;
  connectionId?: string;
  computer?: string;
  ephemeral?: boolean;
}): boolean {
  if (options.ephemeral) {
    if (options.computer)
      throw new Error(
        "Ephemeral conversations cannot be routed to a Cloud computer",
      );
    return false;
  }
  // Memory workers need whole-process confinement for Edit/Write as well as
  // Bash. A listener can execute ordinary children, but cannot host that boundary.
  // They remain one-shot workers, not resumable or addressable listener sessions.
  if (options.launchProfile === "memory-subagent") {
    if (options.computer)
      throw new Error(
        "Memory subagents must run in their confined local process, not through a computer listener",
      );
    return false;
  }
  // Select explicit routes before agent lookup; validate backend compatibility
  // after lookup so an unavailable ambient agent cannot silently be replaced.
  return (
    Boolean(options.computer) ||
    (options.cloudBackend && Boolean(options.connectionId))
  );
}

export function resolveSubagentInheritedPrimaryRoot(options: {
  backendMode: BackendMode;
  parentAgentId: string | undefined;
  inheritedPrimaryRoot: string | null;
  localBackendStorageDir?: string | null;
}): string | null {
  if (options.backendMode === "local" && options.parentAgentId) {
    return getLocalBackendMemoryFilesystemRoot(
      options.parentAgentId,
      options.localBackendStorageDir ?? getLocalBackendStorageDir(),
    );
  }
  return options.inheritedPrimaryRoot;
}
