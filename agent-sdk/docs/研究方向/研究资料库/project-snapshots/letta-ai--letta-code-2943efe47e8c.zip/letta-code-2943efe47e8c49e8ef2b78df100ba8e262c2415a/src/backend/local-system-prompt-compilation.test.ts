import { describe, expect, test } from "bun:test";
import { execFileSync } from "node:child_process";
import { mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { resolveAndBuildSystemPrompt } from "@/agent/system-prompt-resolution";
import type { LocalAgentRecord } from "@/backend/local/local-store";
import {
  appendAvailableSkillsBlock,
  compileAvailableSkillsBlock,
  compileLocalSystemPrompt,
  hashRawSystemPrompt,
} from "@/backend/local/system-prompt-compilation";

function agent(system = "base {CORE_MEMORY}"): LocalAgentRecord {
  return {
    id: "agent-local-test",
    name: "Local Test",
    description: null,
    system,
    tags: [],
    model: "openai/gpt-test",
    model_settings: { provider_type: "openai" },
  };
}

async function writeMemoryFile(
  memoryDir: string,
  relativePath: string,
  description: string,
  body: string,
) {
  const fullPath = join(memoryDir, relativePath);
  await mkdir(dirname(fullPath), { recursive: true });
  await writeFile(
    fullPath,
    `---\ndescription: ${description}\n---\n${body}\n`,
    "utf8",
  );
}

function git(memoryDir: string, args: string[]) {
  execFileSync("git", args, {
    cwd: memoryDir,
    stdio: "ignore",
  });
}

function initAndCommitMemory(memoryDir: string, message = "initial memory") {
  git(memoryDir, ["init"]);
  git(memoryDir, ["config", "user.email", "agent-local-test@letta.com"]);
  git(memoryDir, ["config", "user.name", "Local Test"]);
  git(memoryDir, ["add", "."]);
  git(memoryDir, ["commit", "-m", message]);
  return execFileSync("git", ["rev-parse", "HEAD"], {
    cwd: memoryDir,
    encoding: "utf8",
  }).trim();
}

describe("local system prompt compilation", () => {
  test("loads root core memory and defers indexed children and skills", async () => {
    const memoryDir = await mkdtemp(join(tmpdir(), "local-prompt-root-memfs-"));
    try {
      await writeFile(join(memoryDir, "MEMORY.md"), "# Memory\n", "utf8");
      await writeMemoryFile(
        memoryDir,
        "persona.md",
        "Who the agent is",
        "I am a root-layout local agent.",
      );
      await mkdir(join(memoryDir, "reference"), { recursive: true });
      await writeFile(
        join(memoryDir, "reference", "MEMORY.md"),
        "# Reference\n",
        "utf8",
      );
      await writeMemoryFile(
        memoryDir,
        "reference/details.md",
        "Deferred details",
        "This must remain deferred.",
      );
      await mkdir(join(memoryDir, "skills", "pdf"), { recursive: true });
      await writeFile(
        join(memoryDir, "skills", "pdf", "SKILL.md"),
        "---\nname: pdf\ndescription: Read PDFs\n---\nSkill body.\n",
        "utf8",
      );
      initAndCommitMemory(memoryDir);

      const compiled = compileLocalSystemPrompt({
        agent: agent(),
        conversationId: "local-conv-test",
        memoryDir,
      });

      expect(compiled.content).toContain("<memory>\n# Memory\n");
      expect(compiled.content).toContain("<persona>");
      expect(compiled.content).toContain("I am a root-layout local agent.");
      expect(compiled.content).toContain(
        '<directory path="reference/" index="reference/MEMORY.md" />',
      );
      expect(compiled.content).not.toContain("This must remain deferred.");
      expect(compiled.content).not.toContain("Skill body.");
      expect(compiled.content).not.toContain('path="skills/"');
    } finally {
      await rm(memoryDir, { recursive: true, force: true });
    }
  });

  test("injects MemFS system files and metadata into CORE_MEMORY", async () => {
    const memoryDir = await mkdtemp(join(tmpdir(), "local-prompt-memfs-"));
    try {
      await writeMemoryFile(
        memoryDir,
        "system/persona.md",
        "Who the agent is",
        "I am a local agent.",
      );
      await writeMemoryFile(
        memoryDir,
        "system/project/gotchas.md",
        "Project gotchas",
        "Use Bun for tests.",
      );
      await writeMemoryFile(
        memoryDir,
        "reference/details.md",
        "Detailed reference",
        "Only projected as an external file.",
      );
      const head = initAndCommitMemory(memoryDir);

      const compiled = compileLocalSystemPrompt({
        agent: agent("hello {CORE_MEMORY}"),
        conversationId: "local-conv-test",
        memoryDir,
        now: new Date("2026-05-04T00:00:00.000Z"),
        previousMessageCount: 7,
      });

      expect(compiled.rawSystemHash).toBe(
        hashRawSystemPrompt("hello {CORE_MEMORY}"),
      );
      expect(compiled.memfsRevision).toBe(head);
      expect(compiled.content).toContain("hello Reminder: <projection>");
      expect(compiled.content).toContain("<self>");
      expect(compiled.content).toContain("I am a local agent.");
      expect(compiled.content).toContain("<project>");
      expect(compiled.content).toContain(
        "<projection>$MEMORY_DIR/system/project/gotchas.md</projection>",
      );
      expect(compiled.content).toContain(
        "<description>Project gotchas</description>",
      );
      expect(compiled.content).toContain("Use Bun for tests.");
      expect(compiled.content).toContain("<external_projection>");
      expect(compiled.content).toContain("reference/");
      expect(compiled.content).toContain("details.md");
      expect(compiled.content).toContain("<memory_metadata>");
      expect(compiled.content).toContain("- AGENT_ID: agent-local-test");
      expect(compiled.content).toContain("- CONVERSATION_ID: local-conv-test");
      expect(compiled.content).toContain(
        "- System prompt last recompiled: 2026-05-04 12:00:00 AM UTC+0000",
      );
      expect(compiled.content).toContain(
        "- 7 previous messages between you and the user are stored in recall memory",
      );
    } finally {
      await rm(memoryDir, { recursive: true, force: true });
    }
  });

  test("reads committed MemFS state instead of dirty working tree files", async () => {
    const memoryDir = await mkdtemp(join(tmpdir(), "local-prompt-head-"));
    try {
      await writeMemoryFile(
        memoryDir,
        "system/persona.md",
        "Who the agent is",
        "Committed persona.",
      );
      const head = initAndCommitMemory(memoryDir);
      await writeMemoryFile(
        memoryDir,
        "system/persona.md",
        "Who the agent is",
        "Dirty persona should not compile yet.",
      );

      const compiled = compileLocalSystemPrompt({
        agent: agent(),
        conversationId: "local-conv-test",
        memoryDir,
      });

      expect(compiled.memfsRevision).toBe(head);
      expect(compiled.content).toContain("Committed persona.");
      expect(compiled.content).not.toContain(
        "Dirty persona should not compile yet.",
      );
    } finally {
      await rm(memoryDir, { recursive: true, force: true });
    }
  });

  test("appends memory metadata when CORE_MEMORY is missing", () => {
    const compiled = compileLocalSystemPrompt({
      agent: agent("plain base prompt"),
      conversationId: "local-conv-test",
      memoryDir: join(tmpdir(), "missing-local-memory-dir"),
      now: new Date("2026-05-04T00:00:00.000Z"),
    });

    expect(compiled.content).toStartWith("plain base prompt");
    expect(compiled.content).toContain("<memory_metadata>");
  });

  test("can compile without projecting local MemFS", async () => {
    const memoryDir = await mkdtemp(join(tmpdir(), "local-prompt-no-memfs-"));
    try {
      await writeMemoryFile(
        memoryDir,
        "system/persona.md",
        "Who the agent is",
        "This should not be projected.",
      );
      initAndCommitMemory(memoryDir);

      const compiled = compileLocalSystemPrompt({
        agent: agent("plain {CORE_MEMORY}"),
        conversationId: "local-conv-test",
        memoryDir,
        includeMemfs: false,
      });

      expect(compiled.memfsRevision).toBeUndefined();
      expect(compiled.content).toContain("plain <memory_metadata>");
      expect(compiled.content).not.toContain("This should not be projected.");
      expect(compiled.content).not.toContain("$MEMORY_DIR");
    } finally {
      await rm(memoryDir, { recursive: true, force: true });
    }
  });

  test("renders exact skill IDs without exposing client filesystem locations", () => {
    const skillsBlock = compileAvailableSkillsBlock([
      {
        name: "pdf",
        description: "Read and write PDFs\nLonger details are omitted",
        location: "/repo/skills/pdf/SKILL.md",
      },
      {
        name: "linear-cli",
        description: "Manage Linear issues",
        location: "/home/user/.letta/skills/linear-cli/SKILL.md",
      },
    ]);

    expect(skillsBlock).toBe(
      "<available_skills>\n" +
        "- `linear-cli`: Manage Linear issues\n" +
        "- `pdf`: Read and write PDFs\n" +
        "</available_skills>",
    );
    expect(skillsBlock).not.toContain("/home/user");
    expect(skillsBlock).not.toContain("/repo");

    expect(appendAvailableSkillsBlock("compiled", [])).toBe("compiled");
    expect(
      appendAvailableSkillsBlock("compiled", [
        {
          name: "pdf",
          description: "Read and write PDFs",
          location: "/repo/skills/pdf/SKILL.md",
        },
      ]),
    ).toContain("compiled\n\n<available_skills>");
  });

  test("uses the shared MemFS prompt for local backend memory mode", async () => {
    const prompt = await resolveAndBuildSystemPrompt("default", "local-memfs");

    expect(prompt).toContain("$MEMORY_DIR");
    expect(prompt).toContain("git commit --author=");
    expect(prompt).not.toContain(
      "Changes you commit and push sync to the Letta server",
    );
    expect(prompt).not.toContain("git push");
  });
});
