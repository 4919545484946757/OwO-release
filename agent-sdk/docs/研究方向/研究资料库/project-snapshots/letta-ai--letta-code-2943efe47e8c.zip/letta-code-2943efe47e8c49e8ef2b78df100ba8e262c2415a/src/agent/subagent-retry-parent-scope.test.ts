import { describe, expect, test } from "bun:test";
import { readFileSync } from "node:fs";
import path from "node:path";

const managerSource = readFileSync(
  path.resolve(import.meta.dir, "./subagents/manager.ts"),
  "utf8",
);

test("initial launch and all retries preserve the parent's conversation", () => {
  expect(managerSource).toContain(
    "resolvedParentConversationId,\n    clientMessageId,\n  );",
  );
  expect(
    managerSource.match(
      /parentAgentName,\s*parentConversationId,\s*clientMessageId,/g,
    ),
  ).toHaveLength(3);
});

describe("executeSubagent provider fallback wiring", () => {
  test("retries with a new agent, the primary model, and the original memory scope", () => {
    const retryCallMatch = managerSource.match(
      /return executeSubagent\(\s*type,\s*config,\s*primaryModel,\s*userPrompt,\s*subagentId,\s*true,\s*\/\/ Mark as retry to prevent infinite loops\s*signal,\s*undefined,\s*\/\/ existingAgentId: new agent so --model applies\s*undefined,\s*\/\/ existingConversationId\s*maxTurns,\s*parentAgentIdOverride,\s*transcriptPath,\s*memoryScope,\s*systemPromptOverride,\s*environment,\s*actingUserIdOverride,\s*parentAgentName,\s*parentConversationId,\s*clientMessageId,\s*\);/s,
    );

    expect(retryCallMatch).toBeTruthy();
  });
});

describe("executeSubagent lost-output retry wiring", () => {
  const retryCallPattern =
    /return executeSubagent\(\s*type,\s*config,\s*model,\s*userPrompt,\s*subagentId,\s*true,\s*\/\/ Mark as retry to prevent infinite loops\s*signal,\s*existingAgentId,\s*existingConversationId,\s*maxTurns,\s*parentAgentIdOverride,\s*transcriptPath,\s*memoryScope,\s*systemPromptOverride,\s*environment,\s*actingUserIdOverride,\s*parentAgentName,\s*parentConversationId,\s*clientMessageId,\s*\);/gs;

  test("retries once with the original payload when the child reports lost stdout or its output looks truncated", () => {
    const retryCalls = managerSource.match(retryCallPattern);

    // One retry site for the stderr lost-stdout marker (non-zero exit) and
    // one for a clean exit whose stdout ends mid-line without a result.
    expect(retryCalls).toHaveLength(2);
  });

  test("both lost-output retries are guarded by isRetry", () => {
    const guardedSites = managerSource.match(
      /if \(!isRetry && isSubagentStdoutLostError\(stderr\)\)|if \(!isRetry && looksLikeTruncatedStreamJson\(stdout\)\)/gs,
    );

    expect(guardedSites).toHaveLength(2);
  });
});
