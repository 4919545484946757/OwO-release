/**
 * Utilities for sending messages to an agent via conversations
 **/

import { Buffer } from "node:buffer";
import type { Stream } from "@letta-ai/letta-client/core/streaming";
import type { MessageCreate } from "@letta-ai/letta-client/resources/agents/agents";
import type {
  ApprovalCreate,
  LettaStreamingResponse,
} from "@letta-ai/letta-client/resources/agents/messages";
import type { MessageCreateParams as ConversationMessageCreateParams } from "@letta-ai/letta-client/resources/conversations/messages";
import { ACTING_USER_ID_ENV, ACTING_USER_ID_HEADER } from "@/agent/acting-user";
import type { SkillSource } from "@/agent/skill-sources";
import { type Backend, getBackend } from "@/backend";
import { takePendingDiskSpaceReminder } from "@/reminders/disk-space";
import { getRuntimeContext } from "@/runtime-context";
import { trackBoundaryError } from "@/telemetry/error-reporting";
import {
  type ClientTool,
  getExecutionContextById,
  type PreparedToolExecutionContext,
  prepareCurrentToolExecutionContext,
  waitForToolsetReady,
} from "@/tools/manager";
import type { PermissionModeState } from "@/tools/permission-mode-state";
import { scrubOutgoingMessageContent } from "@/tools/secret-substitution";
import { isCloudApiShutdownRejection } from "@/utils/cloud-api-shutdown";
import { debugLog, debugWarn, isDebugEnabled } from "@/utils/debug";
import { ImageWorkerMissingError } from "@/utils/image-resize";
import {
  assertSupportedBase64ImageMediaTypes,
  type ImageFailureModesByMessageOtid,
  normalizeMessageImageParts,
} from "@/utils/message-image-normalization";
import { createStreamAbortRelay } from "@/utils/stream-abort-relay";
import { isTimingsEnabled } from "@/utils/timing";
import {
  type ApprovalNormalizationOptions,
  normalizeOutgoingApprovalMessages,
} from "./approval-result-normalization";
import {
  buildClientSkillsPayload,
  buildClientSkillsUpdateReminder,
} from "./client-skills";
import { getSkillSources } from "./context";
import { parseRetryAfterHeaderMs } from "./turn-recovery-policy";

const streamRequestStartTimes = new WeakMap<object, number>();
const streamToolContextIds = new WeakMap<object, string>();
const RESPONSE_STATE_HEADER = "X-Letta-Response-State";
const RESPONSE_STATE_CACHE_SCOPE = "approval_boundary";
const CLOUD_API_SHUTDOWN_MAX_RETRIES = 3;
const CLOUD_API_SHUTDOWN_DEFAULT_RETRY_DELAY_MS = 1000;
const responseStateIdsByScope = new Map<string, string>();
// Backend identity and agent/default-conversation scope must not share a
// notification baseline. Discovery cache invalidation must not clear it either.
const sentClientSkillsByBackend = new WeakMap<
  Backend,
  Map<string, NonNullable<ConversationMessageCreateParams["client_skills"]>>
>();

function getCloudApiShutdownRetryDelayMs(error: { headers?: unknown }): number {
  const headers = error.headers;
  if (!(headers instanceof Headers)) {
    return CLOUD_API_SHUTDOWN_DEFAULT_RETRY_DELAY_MS;
  }

  return (
    parseRetryAfterHeaderMs(headers.get("Retry-After")) ??
    CLOUD_API_SHUTDOWN_DEFAULT_RETRY_DELAY_MS
  );
}

async function waitForRetryDelay(
  delayMs: number,
  signal?: AbortSignal,
): Promise<void> {
  if (signal?.aborted) {
    throw signal.reason;
  }

  await new Promise<void>((resolve, reject) => {
    const timeout = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, delayMs);
    const onAbort = () => {
      clearTimeout(timeout);
      reject(signal?.reason);
    };
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

export type StreamRequestContext = {
  conversationId: string;
  resolvedConversationId: string;
  agentId: string | null;
  actingUserId?: string;
  requestStartedAtMs: number;
  otid?: string;
};
const streamRequestContexts = new WeakMap<object, StreamRequestContext>();

type ResponseStateChunk = {
  message_type?: unknown;
  response_id?: unknown;
  cache_scope?: unknown;
};

type ResponseStateHeaderPayload = {
  v: 1;
  cache_scope: typeof RESPONSE_STATE_CACHE_SCOPE;
  previous_response_id?: string;
};

function buildResponseStateScope(
  conversationId: string,
  agentId: string | null | undefined,
): string {
  return agentId ? `${conversationId}:${agentId}` : conversationId;
}

function getResponseStateId(chunk: unknown): string | null {
  if (typeof chunk !== "object" || chunk === null) {
    return null;
  }

  const candidate = chunk as ResponseStateChunk;
  if (
    candidate.message_type !== "response_state" ||
    candidate.cache_scope !== RESPONSE_STATE_CACHE_SCOPE
  ) {
    return null;
  }

  return typeof candidate.response_id === "string" &&
    candidate.response_id.length > 0
    ? candidate.response_id
    : null;
}

function encodeResponseStateHeader(
  payload: ResponseStateHeaderPayload,
): string {
  return Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
}

function isApprovalContinuationRequest(
  messages: Array<MessageCreate | ApprovalCreate>,
): boolean {
  if (messages.length !== 1) {
    return false;
  }

  const [message] = messages;
  return (
    Boolean(message) &&
    (message as { type?: unknown }).type === "approval" &&
    Array.isArray((message as { approvals?: unknown }).approvals)
  );
}

function attachResponseStateTracking(
  stream: Stream<LettaStreamingResponse>,
  params: {
    scope: string;
    conversationId: string;
    agentId: string | null;
  },
): Stream<LettaStreamingResponse> {
  const originalAsyncIterator = stream[Symbol.asyncIterator].bind(stream);
  const streamWithIterator = stream as Stream<LettaStreamingResponse> & {
    [Symbol.asyncIterator]: () => AsyncIterator<LettaStreamingResponse>;
  };

  streamWithIterator[Symbol.asyncIterator] = () => {
    const iterator = originalAsyncIterator();

    return {
      async next() {
        const result = await iterator.next();
        if (!result.done) {
          const responseId = getResponseStateId(result.value);
          if (responseId) {
            responseStateIdsByScope.set(params.scope, responseId);
            debugLog(
              "response-state",
              "received response_id=%s conversation_id=%s agent_id=%s",
              responseId,
              params.conversationId,
              params.agentId ?? "none",
            );
          }
        }

        return result;
      },
      return(value?: unknown) {
        if (iterator.return) {
          return iterator.return(value);
        }
        return Promise.resolve({
          done: true as const,
          value: value as LettaStreamingResponse,
        });
      },
      throw(error?: unknown) {
        if (iterator.throw) {
          return iterator.throw(error);
        }
        return Promise.reject(error);
      },
    };
  };

  return stream;
}

export function getStreamRequestStartTime(
  stream: Stream<LettaStreamingResponse>,
): number | undefined {
  return streamRequestStartTimes.get(stream as object);
}

export function getStreamToolContextId(
  stream: Stream<LettaStreamingResponse>,
): string | null {
  return streamToolContextIds.get(stream as object) ?? null;
}

export function getStreamRequestContext(
  stream: Stream<LettaStreamingResponse>,
): StreamRequestContext | undefined {
  return streamRequestContexts.get(stream as object);
}

export type SendMessageStreamOptions = {
  streamTokens?: boolean;
  background?: boolean;
  agentId?: string; // Required when conversationId is "default"
  approvalNormalization?: ApprovalNormalizationOptions;
  workingDirectory?: string;
  /** Per-conversation permission mode state. When provided, tool execution uses
   *  this scoped state instead of the global permissionMode singleton. */
  permissionModeState?: PermissionModeState;
  /** Per-request skill sources. An empty array disables client skills. */
  skillSources?: SkillSource[];
  /**
   * Per-request model override. Uses backend request-scoped override_model and
   * does not mutate agent/conversation persisted model configuration.
   */
  overrideModel?: string;
  /** Request-scoped Messages API response format. */
  responseFormat?: Record<string, unknown>;
  /** Explicit turn-scoped tool snapshot. When present, bypasses the global registry. */
  preparedToolContext?: PreparedToolExecutionContext;
  /**
   * Allow sending a cached previous response id for this request. Callers should
   * set this only for approval continuations that were fully auto-handled by
   * the client, with no human approval/denial in the loop.
   */
  allowResponseStateReuse?: boolean;
  /**
   * Per-message failure policy for best-effort channel attachments. Images are
   * always normalized; entries here only choose whether a failed conversion is
   * dropped instead of failing the request.
   */
  imageFailureModesByMessageOtid?: ImageFailureModesByMessageOtid;
  /**
   * Cloud user id of the human who pressed "send" (multi-user
   * sandbox scenario). When set, `sendMessageStream` echoes this on
   * the outbound HTTP request as the `X-Letta-Acting-User-Id`
   * header so cloud-api can re-attribute credits + rate limits to
   * the actual sender — rather than the user whose API key is the
   * bearer credential (i.e. whoever spawned the sandbox).
   *
   * Set by the listener after reading
   * `runtime.acting_user_id` from cloud's status WS frame; absent
   * for self-hosted / single-user / pre-channel-split flows.
   * Pass `null` when a queued system/unattributed input must explicitly suppress
   * an actor inherited from the execution context or process environment.
   */
  actingUserId?: string | null;
};

export type SendMessageStreamRequestOptions = {
  maxRetries?: number;
  signal?: AbortSignal;
  headers?: Record<string, string>;
};

export function buildConversationMessagesCreateRequestBody(
  conversationId: string,
  messages: Array<MessageCreate | ApprovalCreate>,
  opts: SendMessageStreamOptions = { streamTokens: true, background: true },
  clientTools: ClientTool[],
  clientSkills: NonNullable<
    ConversationMessageCreateParams["client_skills"]
  > = [],
) {
  return buildRequestBodyFromPreparedMessages(
    conversationId,
    normalizeOutgoingApprovalMessages(messages, opts.approvalNormalization),
    opts,
    clientTools,
    clientSkills,
  );
}

function buildRequestBodyFromPreparedMessages(
  conversationId: string,
  messages: Array<MessageCreate | ApprovalCreate>,
  opts: SendMessageStreamOptions,
  clientTools: ClientTool[],
  clientSkills: NonNullable<ConversationMessageCreateParams["client_skills"]>,
) {
  const isDefaultConversation = conversationId === "default";
  if (isDefaultConversation && !opts.agentId) {
    throw new Error(
      "agentId is required in opts when using default conversation",
    );
  }

  return {
    messages,
    streaming: true,
    stream_tokens: opts.streamTokens ?? true,
    include_pings: true,
    background: opts.background ?? true,
    client_skills: clientSkills,
    client_tools: clientTools,
    include_compaction_messages: true,
    ...(opts.overrideModel ? { override_model: opts.overrideModel } : {}),
    ...(opts.responseFormat ? { response_format: opts.responseFormat } : {}),
    ...(isDefaultConversation ? { agent_id: opts.agentId } : {}),
  };
}

/**
 * Send a message to a conversation and return a streaming response.
 * Uses the conversations API for all conversations.
 *
 * For the "default" conversation (agent's primary message history without
 * an explicit conversation object), pass conversationId="default" and
 * provide agentId in opts. The agent id is sent in the request body.
 */
export async function sendMessageStream(
  conversationId: string,
  messages: Array<MessageCreate | ApprovalCreate>,
  opts: SendMessageStreamOptions = { streamTokens: true, background: true },
  // Disable SDK retries by default - state management happens outside the stream,
  // so retries would violate idempotency and create race conditions
  requestOptions: SendMessageStreamRequestOptions = {
    maxRetries: 0,
  },
): Promise<Stream<LettaStreamingResponse>> {
  return sendMessageStreamWithBackend(
    getBackend(),
    conversationId,
    messages,
    opts,
    requestOptions,
  );
}

/**
 * Send a message through an explicit backend instance. Use this when a caller
 * composes several backend operations and needs fork/send to stay on the same
 * backend without reaching back through the global backend singleton.
 */
export async function sendMessageStreamWithBackend(
  backend: Backend,
  conversationId: string,
  messages: Array<MessageCreate | ApprovalCreate>,
  opts: SendMessageStreamOptions = { streamTokens: true, background: true },
  requestOptions: SendMessageStreamRequestOptions = {
    maxRetries: 0,
  },
): Promise<Stream<LettaStreamingResponse>> {
  const requestStartTime = isTimingsEnabled() ? performance.now() : undefined;
  const requestStartedAtMs = Date.now();
  const canonicalMessages = normalizeOutgoingApprovalMessages(
    messages,
    opts.approvalNormalization,
  );
  // Scrub vault and ambient secret values from outgoing message text before
  // they enter the conversation transcript. ApprovalCreate carries tool-call
  // payloads, not user text, and has no `role` field — so `role` presence
  // discriminates the union.
  const scrubbedMessages = canonicalMessages.map((message) => {
    if (!("role" in message) || message.role !== "user") {
      return message;
    }
    return {
      ...message,
      content: scrubOutgoingMessageContent(message.content, opts.agentId),
    };
  });
  let normalizedMessages: Array<MessageCreate | ApprovalCreate>;
  try {
    normalizedMessages = await normalizeMessageImageParts(scrubbedMessages, {
      failureModesByMessageOtid: opts.imageFailureModesByMessageOtid,
    });
  } catch (error) {
    if (error instanceof ImageWorkerMissingError) {
      trackBoundaryError({
        errorType: "image_worker_missing",
        error,
        context: "send_message_image_normalization",
      });
    }
    throw error;
  }
  assertSupportedBase64ImageMediaTypes(normalizedMessages);

  const preparedToolContext = opts.preparedToolContext
    ? opts.preparedToolContext
    : await (async () => {
        // Wait for any in-progress toolset switch to complete before reading tools
        // This prevents sending messages with stale tools during a switch
        await waitForToolsetReady();
        return await prepareCurrentToolExecutionContext({
          workingDirectory: opts.workingDirectory,
          permissionModeState: opts.permissionModeState,
        });
      })();
  const { clientTools, contextId } = preparedToolContext;
  const executionRuntimeContext = getExecutionContextById(
    preparedToolContext.contextId,
  )?.runtimeContext;
  const { clientSkills, errors: clientSkillDiscoveryErrors } =
    await buildClientSkillsPayload({
      agentId: opts.agentId,
      workingDirectory:
        opts.workingDirectory ??
        executionRuntimeContext?.workingDirectory ??
        undefined,
      skillsDirectory: executionRuntimeContext?.skillsDirectory,
      skillSources: opts.skillSources ?? getSkillSources(),
    });

  const resolvedConversationId = conversationId;
  const responseStateScope = buildResponseStateScope(
    resolvedConversationId,
    opts.agentId ?? null,
  );
  const skillScope = buildResponseStateScope(
    resolvedConversationId,
    conversationId === "default" ? opts.agentId : null,
  );
  let sentClientSkills = sentClientSkillsByBackend.get(backend);
  if (!sentClientSkills) {
    sentClientSkills = new Map();
    sentClientSkillsByBackend.set(backend, sentClientSkills);
  }
  const skillReminder = buildClientSkillsUpdateReminder(
    sentClientSkills.get(skillScope),
    clientSkills,
  );
  // Deliver at the next model boundary (including tool continuations), not by
  // launching an unsolicited run from a filesystem watcher. Keep approvals and
  // the original input/otid in place, then append the runtime reminder.
  // A low-disk alert held for a loop with no queue (e.g. a subagent) rides
  // this same boundary.
  const diskReminder = takePendingDiskSpaceReminder();
  const runtimeReminders = [skillReminder, diskReminder].filter(
    (text): text is string => Boolean(text),
  );
  const requestMessages = [
    ...normalizedMessages,
    ...runtimeReminders.map((content) => ({
      type: "message" as const,
      role: "user" as const,
      content,
    })),
  ];
  const isApprovalContinuation =
    isApprovalContinuationRequest(normalizedMessages);
  // Only reuse cached response state when the approval continuation was fully
  // auto-handled by the client. If a human reviewed any approval, the pause can
  // allow visible agent/conversation state to change, so use the full server path.
  // A changed skill catalog also needs that path, rather than a cached prompt.
  const canUsePreviousResponseState =
    isApprovalContinuation &&
    opts.allowResponseStateReuse === true &&
    runtimeReminders.length === 0;
  const previousResponseId = canUsePreviousResponseState
    ? responseStateIdsByScope.get(responseStateScope)
    : undefined;
  const requestBody = buildRequestBodyFromPreparedMessages(
    conversationId,
    requestMessages,
    opts,
    clientTools,
    clientSkills,
  );

  if (isDebugEnabled()) {
    debugLog(
      "agent-message",
      "sendMessageStream: conversationId=%s, agentId=%s",
      conversationId,
      opts.agentId ?? "(none)",
    );

    const formattedSkills = clientSkills.map(
      (skill) => `${skill.name} (${skill.location})`,
    );
    debugLog(
      "agent-message",
      "sendMessageStream: client_skills (%d) %s",
      clientSkills.length,
      formattedSkills.length > 0 ? formattedSkills.join(", ") : "(none)",
    );

    if (clientSkillDiscoveryErrors.length > 0) {
      for (const error of clientSkillDiscoveryErrors) {
        debugWarn(
          "agent-message",
          "sendMessageStream: client_skills discovery error at %s: %s",
          error.path,
          error.message,
        );
      }
    }
  }

  const actingUserId =
    opts.actingUserId === null
      ? undefined
      : (opts.actingUserId ??
        executionRuntimeContext?.actingUserId ??
        getRuntimeContext()?.actingUserId ??
        process.env[ACTING_USER_ID_ENV]);
  const extraHeaders: Record<string, string> = {};
  if (previousResponseId) {
    extraHeaders[RESPONSE_STATE_HEADER] = encodeResponseStateHeader({
      v: 1,
      cache_scope: RESPONSE_STATE_CACHE_SCOPE,
      previous_response_id: previousResponseId,
    });
    responseStateIdsByScope.delete(responseStateScope);
    debugLog(
      "response-state",
      "sending previous_response_id=%s cache_scope=%s conversation_id=%s agent_id=%s",
      previousResponseId,
      RESPONSE_STATE_CACHE_SCOPE,
      resolvedConversationId,
      opts.agentId ?? "none",
    );
  } else if (!canUsePreviousResponseState) {
    responseStateIdsByScope.delete(responseStateScope);
  }
  // Echo the cloud user id back to cloud-api so it can re-attribute
  // credits + rate limits on multi-user sandboxes. See
  // SendMessageStreamOptions.actingUserId for full context.
  if (actingUserId) {
    extraHeaders[ACTING_USER_ID_HEADER] = actingUserId;
  }

  const messageSummary = normalizedMessages
    .map((item) => {
      if (item.type === "approval") {
        return `approval:${item.approvals?.length ?? 0}`;
      }
      if (item.type !== "message") {
        return `unknown:${item.type}`;
      }
      const content = item.content;
      if (typeof content === "string") {
        return `message:str:${content.length}`;
      }
      return `message:parts:${content.length}`;
    })
    .join(",");

  const firstOtid = (normalizedMessages[0] as unknown as { otid?: string })
    ?.otid;
  debugLog(
    "send-message-stream",
    "request_start conversation_id=%s agent_id=%s messages=%s otid=%s stream_tokens=%s background=%s max_retries=%s",
    resolvedConversationId,
    opts.agentId ?? "none",
    messageSummary || "(empty)",
    firstOtid ?? "none",
    opts.streamTokens ?? true,
    opts.background ?? true,
    requestOptions.maxRetries ?? "default",
  );

  let stream: Stream<LettaStreamingResponse>;
  const abortRelay = createStreamAbortRelay(requestOptions.signal);
  let cloudApiShutdownRetries = 0;
  while (true) {
    try {
      stream = await backend.createConversationMessageStream(
        resolvedConversationId,
        requestBody,
        {
          ...requestOptions,
          ...(abortRelay ? { signal: abortRelay.signal } : {}),
          headers: {
            ...((requestOptions.headers as Record<string, string>) ?? {}),
            ...extraHeaders,
          },
        },
      );
      // A rejected request must not consume the notification; retries need it.
      sentClientSkills.set(skillScope, clientSkills);
      stream = attachResponseStateTracking(stream, {
        scope: responseStateScope,
        conversationId: resolvedConversationId,
        agentId: opts.agentId ?? null,
      });
      break;
    } catch (error) {
      if (
        isCloudApiShutdownRejection(error) &&
        cloudApiShutdownRetries < CLOUD_API_SHUTDOWN_MAX_RETRIES
      ) {
        cloudApiShutdownRetries += 1;
        const delayMs = getCloudApiShutdownRetryDelayMs(error);
        debugWarn(
          "send-message-stream",
          "request_retry conversation_id=%s otid=%s reason=cloud_api_shutting_down attempt=%d delay_ms=%d",
          resolvedConversationId,
          firstOtid ?? "none",
          cloudApiShutdownRetries,
          delayMs,
        );
        try {
          await waitForRetryDelay(
            delayMs,
            abortRelay?.signal ?? requestOptions.signal,
          );
        } catch (abortError) {
          abortRelay?.cleanup();
          throw abortError;
        }
        continue;
      }

      abortRelay?.cleanup();
      debugWarn(
        "send-message-stream",
        "request_error conversation_id=%s otid=%s status=%s error=%s",
        resolvedConversationId,
        firstOtid ?? "none",
        (error as { status?: number })?.status ?? "none",
        error instanceof Error ? error.message : String(error),
      );
      throw error;
    }
  }

  debugLog(
    "send-message-stream",
    "request_ok conversation_id=%s otid=%s",
    resolvedConversationId,
    firstOtid ?? "none",
  );

  abortRelay?.attach(stream as object);

  if (requestStartTime !== undefined) {
    streamRequestStartTimes.set(stream as object, requestStartTime);
  }
  streamToolContextIds.set(stream as object, contextId);
  streamRequestContexts.set(stream as object, {
    conversationId,
    resolvedConversationId,
    agentId: opts.agentId ?? null,
    ...(actingUserId ? { actingUserId } : {}),
    requestStartedAtMs,
    otid: firstOtid,
  });

  return stream;
}
