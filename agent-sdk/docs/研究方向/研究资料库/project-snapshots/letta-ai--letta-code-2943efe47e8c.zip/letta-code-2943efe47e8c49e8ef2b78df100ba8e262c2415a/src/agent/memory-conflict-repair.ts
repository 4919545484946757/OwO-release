import { execFile } from "node:child_process";
import { randomUUID } from "node:crypto";
import { readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { promisify } from "node:util";
import { getMemoryGitDir } from "@/agent/memory-git-dir";
import { debugWarn } from "@/utils/debug";
import { type FileLockOptions, withFileLock } from "@/utils/file-lock";
import {
  getOwnProcessStartTime,
  isSameProcessRunning,
  type ProcessIdentity,
} from "@/utils/process-liveness";

const ATTEMPT_FILE = "letta-memory-repair.json";
const OPERATION_HEADS = [
  "MERGE_HEAD",
  "REBASE_HEAD",
  "CHERRY_PICK_HEAD",
  "REVERT_HEAD",
];
export type MemoryRepairKind = "conflict" | "invalid";

/**
 * The attempt recorded for a repairable memory state. It is claimed under the checkout
 * lease, inside post-turn sync or a worker's sync, and advanced or forgotten
 * by the repair worker launched for it. Every later transition names the
 * attempt's token, so a worker that fails or is cancelled late can only
 * touch its own record, never one a newer claim has written since.
 */
interface RepairAttempt extends ProcessIdentity {
  signature: string;
  token: string;
  /** "launching" until the repair worker has run; "done" once it has. */
  state: "launching" | "done";
  attemptedAt: string;
}

export type MemoryConflictRepairClaim =
  /** Recorded; the caller launches a worker that carries `token`. */
  | { status: "claimed"; token: string }
  /** A running process is still repairing this conflict. */
  | { status: "in_progress" }
  /** A worker has run on this conflict and could not resolve it. */
  | { status: "attempted" };

async function readOptional(path: string): Promise<string> {
  try {
    return (await readFile(path, "utf8")).trim();
  } catch {
    return "";
  }
}

/** Identify the unfinished Git operation: HEAD plus whatever it is merging in. */
async function describeMemoryConflict(
  memoryDir: string,
  gitDir: string,
): Promise<string> {
  let head = "";
  try {
    const { stdout } = await promisify(execFile)("git", [
      "-C",
      memoryDir,
      "rev-parse",
      "--verify",
      "HEAD",
    ]);
    head = stdout.trim();
  } catch {
    /* Unborn branch. */
  }
  const heads = await Promise.all(
    OPERATION_HEADS.map((name) => readOptional(join(gitDir, name))),
  );
  return [head, ...heads].join("\n");
}

/** An invalid tree stays the same repair attempt while local commits are added on the same upstream. */
async function describeInvalidMemoryHistory(
  memoryDir: string,
): Promise<string> {
  try {
    const { stdout } = await promisify(execFile)("git", [
      "-C",
      memoryDir,
      "rev-parse",
      "--verify",
      "@{u}",
    ]);
    return `invalid\n${stdout.trim()}`;
  } catch {
    return "invalid";
  }
}

async function attemptPath(memoryDir: string): Promise<string> {
  return join(await getMemoryGitDir(memoryDir), ATTEMPT_FILE);
}

async function readAttempt(path: string): Promise<Partial<RepairAttempt>> {
  try {
    return JSON.parse(await readFile(path, "utf8"));
  } catch {
    return {};
  }
}

/**
 * Every transition is a compare-and-set on the marker. They run under this
 * lock rather than the checkout lease, so a worker forgetting its attempt
 * after the lease is gone cannot race a claim made under it. The lock is
 * reaped only once its holder's process is gone, never by age, so a paused
 * holder keeps exclusivity. Sections last microseconds. A claim that still
 * cannot get in gives up, and the conflict is reported instead of repaired;
 * a worker's own transitions wait, because dropping one would leave its
 * record in place and suppress every later repair while this process lives.
 */
const MARKER_LOCK: FileLockOptions = { reapOnlyDeadOwner: true };
const CLAIM_TIMEOUT_MS = 5_000;

async function updateAttempt<T>(
  path: string,
  fn: (attempt: Partial<RepairAttempt>) => Promise<T>,
  timeoutMs = Number.POSITIVE_INFINITY,
): Promise<T> {
  return withFileLock(`${path}.lock`, async () => fn(await readAttempt(path)), {
    ...MARKER_LOCK,
    timeoutMs,
  });
}

/** A worker's transition: no record outside a repository, never throws. */
async function transition(
  memoryDir: string,
  fn: (path: string, attempt: Partial<RepairAttempt>) => Promise<void>,
): Promise<void> {
  let path: string;
  try {
    path = await attemptPath(memoryDir);
  } catch {
    return;
  }
  try {
    await updateAttempt(path, (attempt) => fn(path, attempt));
  } catch (error) {
    // Only a filesystem failure gets here; the wait for the lock is unbounded.
    debugWarn("memory-repair", `Repair attempt not updated: ${String(error)}`);
  }
}

/**
 * Record that automatic repair is being attempted for the current conflict or
 * invalid history, unless the same state is already handled: a repair worker
 * has run and could not resolve it (reported to the agent instead of
 * relaunched every turn), or a repair is still in progress in a running
 * process. An attempt whose process is gone before the worker ran (crashed)
 * is retried. A checkout that is not a readable Git repository is left to
 * the worker, which reports the failure itself.
 */
export async function claimMemoryConflictRepair(
  memoryDir: string,
  kind: MemoryRepairKind = "conflict",
): Promise<MemoryConflictRepairClaim> {
  const token = randomUUID();
  let path: string;
  let signature: string;
  try {
    const gitDir = await getMemoryGitDir(memoryDir);
    path = join(gitDir, ATTEMPT_FILE);
    signature =
      kind === "invalid"
        ? await describeInvalidMemoryHistory(memoryDir)
        : await describeMemoryConflict(memoryDir, gitDir);
  } catch {
    return { status: "claimed", token };
  }
  return updateAttempt(
    path,
    async (previous) => {
      if (previous.signature === signature) {
        if (previous.state === "done") return { status: "attempted" };
        if (
          typeof previous.pid === "number" &&
          (await isSameProcessRunning({
            pid: previous.pid,
            ...(typeof previous.started === "string" && {
              started: previous.started,
            }),
          }))
        ) {
          return { status: "in_progress" };
        }
      }
      const started = await getOwnProcessStartTime();
      const attempt: RepairAttempt = {
        signature,
        token,
        state: "launching",
        pid: process.pid,
        ...(started && { started }),
        attemptedAt: new Date().toISOString(),
      };
      await writeFile(path, JSON.stringify(attempt));
      return { status: "claimed", token };
    },
    CLAIM_TIMEOUT_MS,
  );
}

/** The repair worker ran; the same state is not attempted again automatically. */
export async function completeMemoryConflictRepair(
  memoryDir: string,
  token: string,
): Promise<void> {
  await transition(memoryDir, async (path, attempt) => {
    if (attempt.token !== token) return;
    await writeFile(path, JSON.stringify({ ...attempt, state: "done" }));
  });
}

/**
 * The attempt never ran (launch failed, cancelled, nothing left to repair);
 * let the next turn retry. Only the record for `token` is removed, so a
 * worker forgetting its attempt after the lease is gone cannot drop a newer
 * claim.
 */
export async function clearMemoryConflictRepair(
  memoryDir: string,
  token: string,
): Promise<void> {
  await transition(memoryDir, async (path, attempt) => {
    if (attempt.token === token) await rm(path, { force: true });
  });
}
