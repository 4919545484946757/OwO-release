import os

from agno.agent import Agent
from agno.db.postgres import PostgresDb
from agno.models.anthropic import Claude
from agno.models.openai import OpenAIChat


def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    return f"The weather in {city} is sunny and 22C."


def main() -> None:
    db_url = os.getenv(
        "AGNO_POSTGRES_URL",
        "postgresql+psycopg://ai:ai@localhost:5532/ai",
    )
    db = PostgresDb(db_url)

    agent = Agent(
        model=OpenAIChat(id="gpt-5.6-luna"),
        db=db,
        add_history_to_context=True,
        num_history_runs=10,
        tools=[get_weather],
    )

    # Turn 1 — OpenAI with tool call (works fine)
    agent.print_response("What is the weather in Paris?")

    # Turn 2 — Claude with tool call (works fine)
    agent.model = Claude()
    agent.print_response("What is the weather in London?")

    # Turn 3 — OpenAI with tool call (works fine on its own)
    agent.model = OpenAIChat(id="gpt-5.6-luna")
    agent.print_response("What is the weather in Tokyo?")

    # Turn 4 — Claude summary
    agent.model = Claude()
    agent.print_response("Summarize all the weather we checked.")


if __name__ == "__main__":
    main()
