# Agent Middleware 

This sample demonstrates how to add middleware to intercept:
- Chat client calls (global and per‑request)
- Agent runs (guardrails and PII filtering)
- Function calling (logging/override)

## What This Sample Shows

1. Microsoft Foundry integration via `AIProjectClient` and `DefaultAzureCredential`
2. Chat client middleware using `ChatClientBuilder.Use(...)`
3. Agent run middleware (PII redaction and wording guardrails)
4. Function invocation middleware (logging and overriding a tool result)
5. Per‑request chat client middleware
6. Per‑request function pipeline with approval
7. Combining agent‑level and per‑request middleware
8. MessageAIContextProvider middleware via `AIAgentBuilder.Use(...)` for injecting additional context messages
9. AIContextProvider middleware via `ChatClientBuilder.Use(...)` for enriching messages, tools, and instructions at the chat client level

## Function Invocation Middleware

Not all agents support function invocation middleware.

Attempting to use function middleware on agents that do not wrap a ChatClientAgent or derives from it will throw an InvalidOperationException.

## Prerequisites

1. Environment variables:
   - `FOUNDRY_PROJECT_ENDPOINT`: Your Foundry project endpoint
   - `FOUNDRY_MODEL`: Model name (optional; defaults to `gpt-5.4-mini`)
2. Sign in with Azure CLI (PowerShell):
   ```powershell
   az login
   ```

## Running the Sample

Use PowerShell:
```powershell
cd dotnet/samples/02-agents/Agents/Agent_Step11_Middleware
dotnet run
```
