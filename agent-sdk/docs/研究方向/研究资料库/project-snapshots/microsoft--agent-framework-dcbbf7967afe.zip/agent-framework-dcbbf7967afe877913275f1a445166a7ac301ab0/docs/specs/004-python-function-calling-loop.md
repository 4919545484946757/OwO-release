---
status: proposed
contact: eavanvalkenburg
date: 2026-07-27
deciders: eavanvalkenburg
---

# Python function-calling loop contract and validation matrix

## Scope

This specification defines the required behavior and validation coverage for the Python function-calling loop.
It covers:

- normal local function execution;
- streaming and non-streaming response aggregation;
- tool approval request and resume;
- approved, rejected, mixed, and replayed approval rounds;
- reasoning content and opaque reasoning signatures bound to function calls;
- history persistence and service-side continuation;
- error, user-input, middleware-termination, middleware-failure, and loop-limit paths;
- provider and transport serialization of function calls and results.

The primary implementation is in `python/packages/core/agent_framework/_tools.py`. History replay behavior in
`python/packages/core/agent_framework/_sessions.py`, provider serializers, hosting packages, and UI transports are
part of the same contract when they carry function-call loop content.

## Maintenance policy

This document is the stable cross-package contract for the function-calling loop, not a per-PR changelog. Every change
in scope must be reviewed against it, but most such PRs should not edit it. Update only the smallest affected sections
when a change intentionally alters normative behavior, the scenario inventory, an acknowledged coverage gap, or the
authoritative scenario-to-test mapping.

Do not add implementation narration, temporary debugging guidance, or tests that merely preserve an already documented
contract. Temporary compatibility behavior belongs here only when it is itself part of the user-visible contract; its
later removal requires another deliberate contract update.

## Change sensitivity

This code is high risk. Small changes can produce duplicate side effects, orphaned calls or results, invalid
provider histories, invisible streaming results, stale approval authority, or loops that never terminate.
Dropping reasoning content that a service binds to a tool call can also make an otherwise balanced call/result
transcript invalid.

Any change to the function-calling loop or its approval/history/serialization paths must:

1. identify every affected row in the scenario matrix below;
2. add or update the corresponding regression tests;
3. validate streaming updates, streaming finalization, and non-streaming output where applicable;
4. validate both model-bound history and caller-visible responses;
5. run the full core package tests plus every affected provider or transport package;
6. run source typing, test typing, and syntax checks for every affected package;
7. receive extra review focused on call/result pairing, exactly-once execution, and history replay.

A passing narrow regression test is not sufficient evidence for changes in this area.

### Contribution ownership

Issues involving this code must not be picked up by external contributors without first checking with the Agent
Framework core team. The core team must confirm the intended behavior, affected scenario-matrix rows, ownership
across core/providers/transports, and the required validation scope before implementation starts.

## Flow diagrams and code map

### Main function-calling flow

The main control flow deliberately has separate streaming and non-streaming methods. They share policy helpers, but
their output mechanics differ: one returns an aggregated `ChatResponse`; the other yields `ChatResponseUpdate`
items and is finalized by `ResponseStream`.

The diagrams use only the generic distinction between **local tools**, which Agent Framework executes, and
**hosted-service tools**, whose calls and approval decisions are owned by a remote service. Provider-specific wire
formats and regression tests appear later in the scenario matrix.

```mermaid
flowchart TD
    Entry["FunctionInvocationLayer.get_response(...)"]
    Setup["Prepare middleware, options, session, budget state,<br/>and execute_function_calls partial"]
    Enabled{"Function invocation enabled?"}
    Direct["Delegate directly to super().get_response(...)"]
    Mode{"stream?"}
    NonStream["_get_response_with_function_invocation(...)"]
    Stream["_stream_response_with_function_invocation(...)"]
    Resolve["_resolve_approval_responses(...)<br/>runs once before the model-iteration loop"]
    ApprovalAction{"approval action"}
    Immediate["Return/yield terminal result or user-input request<br/>without another model call"]
    ApprovalPolicy["Record approval executions;<br/>apply stop/function-call-limit policy"]
    Model["Call super_get_response(...)<br/>response may contain reasoning + function_call"]
    Process["_process_model_function_calls(...)"]
    FunctionAction{"function-processing action"}
    Execute["_execute_function_calls(...)"]
    Try["_try_execute_function_calls(...)"]
    Single["_execute_single_function_call(...)"]
    Handle["_handle_function_call_results(...)"]
    PostCallPolicy["Record executions; apply error/function-call-limit policy;<br/>reset required tool choice"]
    Advance["_prepare_messages_for_next_iteration(...)"]
    More{"iteration budget remains?"}
    Final["Final model call with tool_choice = none<br/>and deterministic fallback if needed"]
    Output["Return ChatResponse or complete ResponseStream"]

    Entry --> Setup --> Enabled
    Enabled -- no --> Direct
    Enabled -- yes --> Mode
    Mode -- no --> NonStream
    Mode -- yes --> Stream
    NonStream --> Resolve
    Stream --> Resolve
    Resolve --> ApprovalAction
    ApprovalAction -- return --> Immediate --> Output
    ApprovalAction -- stop --> ApprovalPolicy
    ApprovalAction -- continue --> ApprovalPolicy
    ApprovalPolicy --> More
    Model --> Process
    Process --> Execute --> Try --> Single --> Handle --> FunctionAction
    FunctionAction -- return --> Output
    FunctionAction -- stop --> PostCallPolicy
    FunctionAction -- continue --> PostCallPolicy
    PostCallPolicy --> Advance
    Advance --> More
    More -- yes --> Model
    More -- no --> Final --> Output
```

Code-reading landmarks:

- `get_response(...)` owns setup and selects the response mode.
- `_get_response_with_function_invocation(...)` owns non-streaming aggregation.
- `_stream_response_with_function_invocation(...)` owns streamed emission/finalization.
- `_resolve_approval_responses(...)` handles only inbound approval decisions.
- `_process_model_function_calls(...)` handles only calls from a completed model response.
- `_try_execute_function_calls(...)` decides approval/declaration/execution behavior for a batch.
- `_replace_approval_contents_with_results(...)` is the occurrence-aware approval transcript normalizer.
- `FunctionInvocationLayer._update_function_invocation_continuation_state(...)` updates continuation state after
  every service response. Provider layers may override it to carry provider-specific continuation metadata into
  the next service call, but must delegate to the base implementation so generic conversation continuation remains
  synchronized with the active `AgentSession`.

### Approval pause and resume

```mermaid
sequenceDiagram
    participant Caller
    participant History as HistoryProvider
    participant Layer as FunctionInvocationLayer
    participant Tool
    participant Model

    Caller->>Layer: Initial user request
    Layer->>Model: Messages + tools
    Model-->>Layer: reasoning content + function_call
    Layer->>Layer: Tool requires approval
    Layer-->>Caller: function_call + function_approval_request

    Caller->>Layer: function_approval_response
    Layer->>Layer: Copy caller-owned messages
    Layer->>Layer: _resolve_approval_responses(...)

    alt approved
        Layer->>Tool: Execute exactly once
        Tool-->>Layer: result or exception
        Layer->>Layer: Create terminal function_result
    else rejected
        Layer->>Layer: Create synthetic rejection function_result
    end

    Layer-->>Caller: Terminal result message/update

    alt tool requests more user input
        Layer-->>Caller: User-input request with assistant role
    else middleware terminates
        Layer-->>Caller: Termination result
    else error limit reached
        Layer->>Model: Normalized reasoning/call/result history, tools disabled
        Model-->>Layer: Final assistant response
        Layer-->>Caller: Final assistant response
    else continue normally
        Layer->>Model: Normalized reasoning/call/result history
        Model-->>Layer: Final assistant response or another function_call
        Layer-->>Caller: Final assistant response / continued loop
    end

    Layer-->>History: Persist caller input + returned response
    Note over History: Later model replay filters approval request/response wrappers
```

The terminal result is caller-visible in both modes. The private normalized message copy is model-visible. The
original caller input and earlier response remain unchanged.

Before acting on a model function-call batch, the loop classifies every actionable call. A configured fatal unknown
call aborts the complete batch before approval state changes or execution. Otherwise approval-required and Host-owned
calls are returned together in model order, while session-backed executable siblings remain deferred. An incomplete
session-backed mixed approval/Host response remains pending without executing a deferred call; a stateless incomplete
response is rejected, including when no response is supplied, non-user message roles vary within the model output, or
a newer standalone request follows the incomplete batch. Stateless discovery selects the latest unresolved mixed batch
across non-user output messages. An unrelated user turn delimits standalone batches, so pauses from separate turns are
not synthesized into one mixed batch; a completed batch remains inert on later turns. Correlation is scoped to the
active mixed batch so completed or abandoned historical Host calls remain unchanged. Session-backed approval-only
batches likewise remain atomic across resume calls: decisions may be accumulated, but no call executes and the model
is not resumed until every approval in the original batch has a decision.
`ToolApprovalMiddleware` may resolve approval requests through standing or automatic policies, but it preserves
non-approval user-input requests and does not split or reorder manual approvals relative to their Host-owned siblings.

Fully executable calls run concurrently by default. When
`FunctionInvocationConfiguration["allow_concurrent_invocation"]` is `False`, the layer instead starts each call only
after the preceding call has completed, preserving model order across approval pause and replay. Middleware termination
stops the loop after the accepted batch finishes; it does not skip later calls in that batch.

### Reasoning-bound function-call groups

Some hosted services bind reasoning content or an opaque reasoning signature to the function call that follows it.
For those services, reasoning is not optional decoration; it is part of the provider-valid function-call group.

```mermaid
flowchart TD
    Response["Assistant response:<br/>reasoning content + function_call"]
    Group["One logical reasoning/function-call group"]
    Owner{"local or hosted-service tool?"}
    Local["Local execution"]
    Hosted["Hosted service owns tool execution/state"]
    Result["Terminal function_result or hosted result"]
    Continuation{"continuation mode"}
    Stateless["Stateless or framework-history replay"]
    Replayable{"reasoning payload/signature<br/>is replayable?"}
    Replay["Replay reasoning + call + result atomically"]
    Reject["Fail before the service call;<br/>do not send a lossy transcript"]
    Service["Hosted-service continuation"]
    Reference["Reference service-stored reasoning/call;<br/>send only the new result or approval decision"]
    Compact{"compaction needed?"}
    Atomic["Keep or exclude the complete<br/>reasoning/call/result group"]
    Caller["Caller-visible response retains reasoning<br/>with the function-call turn"]

    Response --> Group --> Owner
    Group --> Caller
    Owner -- local --> Local --> Result
    Owner -- hosted service --> Hosted --> Result
    Result --> Compact
    Compact -- yes --> Atomic --> Continuation
    Compact -- no --> Continuation
    Continuation -- stateless / local history --> Stateless --> Replayable
    Replayable -- yes --> Replay
    Replayable -- no --> Reject
    Continuation -- service-managed --> Service --> Reference
```

The generic contract is:

- reasoning content remains ordered immediately before or alongside the function call it explains;
- a terminal result does not replace or discard the reasoning/call portion of the active group;
- stateless replay includes the service-required reasoning payload or opaque signature;
- if required reasoning cannot be reconstructed, the adapter fails before sending invalid or lossy history;
- service-managed continuation may rely on the hosted service's stored reasoning/call items and send only new
  outputs or approval decisions;
- compaction keeps or removes the entire reasoning/call/result group atomically.

In the code, core response aggregation preserves reasoning `Content` items, compaction annotations bind reasoning to
the tool-call group, and provider adapters serialize or reconstruct the provider-specific reasoning representation.

### Approval correlation, replay, and reused ids

`call_id` is the provider/service correlation identifier and is not globally unique forever. `Content.id` on a
`function_call` is the Agent Framework identity for one locally actionable occurrence. New actionable calls receive
that occurrence id once and preserve it through streaming aggregation, serialization, and replay; existing ids are
never regenerated. Deserializing a legacy stored call without `Content.id` does not manufacture a new identity.

New local approval requests use the function call occurrence id as their request id. Provider-issued hosted approval
request ids remain unchanged and continue to follow the hosted service protocol. A response carrying the occurrence
id can bind without embedding a function call because the trusted pending snapshot is authoritative. For an
occurrence-aware local snapshot, a missing or mismatched occurrence identity fails closed without consuming the
pending request; matching a nested provider `call_id` is not a compatibility alias.

Legacy stored local pending snapshots whose function call lacks `Content.id` retain their exact request-id binding for
one resume. Taking that compatibility path emits a migration warning and consumes the matching request once. The
warning marks the staged path for removal after stored legacy approvals have drained. An empty provider `call_id` may
fall back to the generated occurrence id only when the framework is about to correlate a local actionable call; this
also warns so provider adapters can supply a real service id. Deserialization itself never warns or rewrites either id.

Pending approval state is a trusted session-state boundary: hosts must authorize and tenant-scope the session store and
must prevent untrusted callers from replacing snapshots. Consume-on-bind prevents replay within one authoritative
session state, but it is not a durable exactly-once guarantee across crashes or concurrent workers without external
transactional coordination.

The normalizer tracks open logical occurrences in transcript order instead of keeping one global result per id.

```mermaid
flowchart TD
    Scan["Scan normalized messages in order"]
    Kind{"content type"}
    Call["function_call:<br/>open a call occurrence"]
    Request["function_approval_request"]
    Bind{"unbound call occurrence<br/>with same call_id?"}
    BindExisting["Bind request id to existing occurrence<br/>and remove wrapper"]
    Duplicate{"same request identity<br/>already restored?"}
    DropDuplicate["Remove replayed duplicate wrapper"]
    Restore["Restore embedded function_call<br/>as a new occurrence"]
    Placeholder["function_result with APPROVAL_PENDING:<br/>attach placeholder to open occurrence"]
    Completed["terminal function_result:<br/>close earliest open occurrence"]
    Response["function_approval_response"]
    Pending{"response still pending?"}
    RemoveOld["Remove already-resolved historical response"]
    Decision{"approved?"}
    Approved["Pop next execution result for this call_id"]
    Rejected["Create synthetic rejection result"]
    HasPlaceholder{"occurrence has placeholder?"}
    Replace["Replace placeholder and remove response wrapper"]
    ReplaceResponse["Replace response wrapper with terminal content"]
    Close["Close occurrence; append terminal content<br/>to resumed response"]
    Next["Continue scan"]

    Scan --> Kind
    Kind -- function_call --> Call --> Next
    Kind -- approval request --> Request --> Bind
    Bind -- yes --> BindExisting --> Next
    Bind -- no --> Duplicate
    Duplicate -- yes --> DropDuplicate --> Next
    Duplicate -- no --> Restore --> Next
    Kind -- pending placeholder --> Placeholder --> Next
    Kind -- terminal result --> Completed --> Next
    Kind -- approval response --> Response --> Pending
    Pending -- no --> RemoveOld --> Next
    Pending -- yes --> Decision
    Decision -- yes --> Approved --> HasPlaceholder
    Decision -- no --> Rejected --> HasPlaceholder
    HasPlaceholder -- yes --> Replace --> Close --> Next
    HasPlaceholder -- no --> ReplaceResponse --> Close --> Next
    Next --> Kind
```

This flow corresponds to `_ApprovalCallOccurrence`, `_collect_approval_responses(...)`, and
`_replace_approval_contents_with_results(...)`.

### History and service-side continuation

```mermaid
flowchart LR
    Store["History backing store<br/>(may retain approval wrappers for audit)"]
    Load{"HistoryProvider.load_messages?"}
    Filter["_filter_approval_control_messages(...)"]
    Context["SessionContext model history:<br/>function_call + terminal function_result"]
    Current["Current caller input:<br/>new function_approval_response"]
    Layer["FunctionInvocationLayer private copy"]
    Local{"local or hosted-service approval?"}
    LocalResult["Execute locally and normalize to function_result"]
    Hosted["Hosted-service adapter"]
    StoredRequest["Prior service-issued approval request"]
    NewResponse["Current hosted approval decision"]
    Skip["Do not replay the stored request inline"]
    Send["Send the approval decision exactly once"]
    Later["Later turn"]
    Manual["Manual-history caller"]

    Store --> Load
    Load -- yes --> Filter --> Context --> Layer
    Load -- no --> Layer
    Current --> Layer
    Layer --> Local
    Local -- local --> LocalResult --> Later
    Local -- hosted service --> Hosted
    StoredRequest --> Hosted --> Skip
    NewResponse --> Hosted --> Send --> Later
    Later --> Store
    Manual -. owns equivalent filtering .-> Layer
```

When `load_messages=False`, no history is replayed and the history filter is intentionally not invoked. Callers
that manually replay messages own the equivalent rule: do not resend an approval response after its terminal result.

## Normative contract

### Function calls and results

- A newly completed, actionable local `function_call` is eligible for execution when argument preparation and schema
  validation succeed. The enclosing response `finish_reason` is not a generic authorization gate: providers may
  report another reason, including `length`, while still returning a complete and service-usable call.
- A provider adapter that knows its protocol invalidated or cancelled partial response output raises
  `ResponseInvalidatedException`; any local function calls already exposed from that response must not execute. The
  function invocation layer then abandons only that current model/tool iteration, clears its request budget state,
  restores the last valid service continuation, and re-raises
  the same exception. It emits no new approval request or function result, invokes no function middleware or tool
  body, makes no second model request or dangling-call settlement request, and does not success-persist that service
  response. Approval decisions resolved before the invalidated provider call retain their existing semantics.
  Streaming providers may yield local function-call deltas before discovering invalidation; direct stream consumers
  must treat the exception as an explicit instruction to discard those calls and never execute them. Caller
  cancellation remains cancellation rather than becoming this provider signal.
- Every actionable local `function_call` produces exactly one terminal `function_result`, unless execution pauses
  for a new user-input request or the run is aborted by a fail-closed error.
- An ordinary exception raised by function middleware or a tool body becomes one terminal error `function_result`
  and the loop continues. `MiddlewareFailure` is the execution-time fail-closed escape: it is never converted into a
  tool result, the in-flight parallel batch is cancelled, no further tool call starts, no further model turn is
  consumed, and the exception propagates to the caller (for streaming runs, when the stream is consumed). A
  configured fatal unknown call likewise raises `KeyError` and propagates, but complete-batch classification detects
  it before any call executes. On a service-managed conversation the loop first settles either aborted batch — one
  error `function_result` per dangling call (approval-response wrappers unwrap to their underlying calls; hosted-tool
  approvals are left to their own provider protocol), submitted with `tool_choice="none"` in a single extra request —
  so the hosted thread is not left ending in unresolved function calls that the service would reject on the session's
  next request; the persisted continuation then advances to the settlement response (for response-ID continuations
  the settled endpoint is the new handle; for conversation-object ids the advance is a no-op) and the settlement
  response is otherwise discarded. Settlement covers the approval-resolution phase too: a fatal abort while an
  approved tool is replayed settles the original, already-persisted calls. Without a service-managed conversation no
  extra request is made. Batch cancellation is cooperative: an async sibling stops at its next suspension point,
  while a synchronous tool body already executing in a worker thread cannot be interrupted and may complete its side
  effects — its result is discarded either way and never reaches the transcript, the model, or history. Middleware
  must not catch `MiddlewareFailure` — swallowing it converts a fail-closed abort back into a running, possibly
  unguarded loop.
- `Content.exception` is host-internal diagnostic state. Default `Content.to_dict()` and nested response serialization replace it with a fixed non-sensitive failure marker,
  while the original field remains directly available to trusted local code. Remote protocol serializers use the
  marker only for status and use the channel-visible `result` or `items` for output text. `include_detailed_errors=False` keeps the channel-visible
  result generic; enabling it explicitly may place diagnostic text in the result for that configured channel.
- An ordinary exception raised by a custom `FunctionTool.result_parser` follows the same terminal tool-error
  contract, including `include_detailed_errors`; the raw return value does not replace the failed custom conversion.
  Default parsing retains its string fallback, and explicit skip-parsing behavior is unchanged.
- Parallel calls retain model order in the returned transcript.
- `call_id` remains the provider/service correlation id; a locally actionable `function_call` also carries a stable
  Agent Framework occurrence identity in `Content.id`.
- Reused `call_id` values are correlated by logical occurrence, not one global value per id.
- Existing `Content.id` values survive aggregation and replay and are never regenerated; legacy deserialization does
  not invent one.
- A completed function call/result pair is inert on later turns.
- Informational-only and declaration-only calls are not executed as local tools.
- For automatic local execution, provider arguments are JSON-parsed before function middleware. Schema-compatible
  arguments retain the existing normalized mapping contract. A provisional validation failure is not terminal:
  middleware receives the raw mapping and may repair it before calling `call_next()`. The innermost handler validates
  changed or previously invalid arguments immediately before the tool body and writes the normalized mapping back to
  `FunctionInvocationContext.arguments`; unchanged provisionally normalized arguments are reused without running
  validators twice. Middleware that short-circuits without `call_next()` skips final validation and tool execution.
- Argument-repair middleware must precede security or policy middleware so enforcement observes the effective,
  normalized invocation. Built-in security middleware normalizes hidden-value expansions before policy inspection.
  Changing arguments after security middleware has processed them fails closed with `MiddlewareFailure`.
- Argument-validation failures after middleware retain the established `Argument parsing failed` result contract.
  Exceptions raised by middleware or the tool body retain the separate `Function failed` contract.
- Provider-hosted shell calls remain informational transcript content. Only a well-formed explicit `local_shell_call`
  or a shell call marked with a local environment, paired with a configured local executor, can enter the local
  function loop and its approval boundary. Stateless replay preserves provider shell call/output items in their
  original shape and fails explicitly when that provider representation is unavailable or inconsistent. Locally
  generated shell outputs preserve stdout, stderr, truncation notices, non-zero exits, and timeout outcomes and are
  sent in both service-side and stateless continuation modes.

### Reasoning-bound calls

- Reasoning content or opaque reasoning metadata that a service binds to a function call is part of the same logical
  group as that call and its terminal result.
- Active function loops preserve the reasoning content, function call, function result, and final assistant output
  in caller-visible responses.
- Framework-managed/stateless replay includes the service-required reasoning representation before the paired call.
- Service-managed continuation may omit inline reasoning/call items only when the hosted service already owns them.
- Missing non-reconstructable reasoning fails explicitly before a provider request instead of silently dropping the
  content.
- Foundry clients do not request `reasoning.encrypted_content` implicitly; callers may opt in explicitly when the
  selected deployment supports encrypted reasoning.
- Compaction preserves or excludes the complete reasoning/call/result group atomically.

### Approval request and resume

- A tool that requires approval does not execute before an approved response.
- With an `AgentSession`, every surfaced local or hosted approval request is stored as an immutable snapshot in one
  active model batch. A new surfaced batch replaces an abandoned batch instead of accumulating session state.
- Initial local approval request IDs use the recorded `function_call.id` occurrence identity. A policy replacement
  retains that occurrence identity on the function call but rotates a separate request-generation identity; only a
  response bound to the current server-held generation can authorize execution. Provider-issued hosted approval
  request IDs remain unchanged. Duplicate request IDs within one batch are rejected as malformed.
- An inbound response is honored only when its occurrence identity and current request generation match the pending
  server-held snapshot. A new local response may omit its embedded function call because the snapshot is authoritative;
  a mismatched embedded occurrence identity or stale generation fails closed.
- Legacy stored local snapshots without `function_call.id` retain exact request-id matching for one consume-on-bind
  resume and emit a migration warning. Deserialization does not rewrite the snapshot or emit that warning.
- Approval requests replayed in inbound message history do not create, replace, or resurrect approval authority.
- The executable call id, tool name, arguments, and local or hosted tool metadata are sourced from the recorded
  request, never from the response payload.
- A matched approval response consumes its pending entry once. Unmatched, duplicate, and replayed responses do not
  reach local execution.
- If policy middleware detects that the exact resolved invocation changed after approval, the old response executes
  nothing and yields a caller-visible, session-persisted replacement request for the same occurrence; execution
  requires a second approval and happens exactly once.
- If function middleware repairs an approval-bound call, the old response likewise executes nothing and yields a
  caller-visible, session-persisted replacement request containing the repaired approval-visible arguments in
  JSON-native form. The replacement retains the call occurrence identity, rotates request-generation identity, and
  requires a second approval before exactly-once execution. A repair whose JSON form would not prepare back to the
  same values (for example a datetime `fold` or a standard-library time zone) fails closed instead, because no
  approval of that request could settle. Security middleware transformations that preserve an approval-visible
  placeholder do not disclose the resolved value or trigger a spurious replacement.
- If session-bound middleware no longer holds the reviewed authority because it expired or was evicted, the matched
  response executes nothing and produces a replacement approval request with the same occurrence identity and a fresh
  request generation. The replacement is caller-visible, becomes the authoritative pending session snapshot, and
  requires a second approval before the tool can execute; replaying the prior serialized grant cannot authorize it.
  Rejection or cancellation releases only the matching occurrence in the owning session, including authenticated
  AG-UI lifecycle decisions.
- Unmatched occurrence-aware responses leave the pending request intact for a corrected retry and produce an
  observable warning/log. A nested `call_id` is never accepted as an occurrence-identity alias.
- Session-backed pending snapshots are trusted host state and require tenant-scoped, authorized storage. Consume-on-bind
  does not claim durable exactly-once behavior across crashes or concurrent workers.
- Tool lookup uses the recorded name against the current registry. A same-name implementation upgrade is allowed;
  removing the name prevents local execution.
- Only the strict boolean `True` grants approval. Missing decisions and non-boolean values are rejection, not consent.
- A local (non-hosted) approval response authorizes execution only when it binds to an approval request recorded in
  an authoritative `AgentSession`. Direct chat-client or agent invocation without one drops inbound local approval
  responses with an observable warning and authorizes nothing: an approval request that merely appears in the
  caller-supplied message history is never by itself proof that the framework asked a human to approve it, so a
  caller-assembled request plus its own response cannot authorize an arbitrary call. Provider-issued (hosted)
  approvals are protocol data and continue to pass through untouched. A response whose occurrence is already settled
  by a terminal result is replayed history rather than a pending authorization: it can no longer execute anything, so
  it is left in place and does not warn, keeping full-transcript replay of completed conversations (including
  completed mixed batches) working without a session. Settlement uses the same occurrence-aware correlation that
  drives execution, so fabricating a result to reach this exemption also guarantees the call will not run. The
  exemption is an allow-list evaluated per response object rather than per approval id, because several responses can
  share one approval id and only the first is eligible to execute; filtering by id would leave the remaining
  duplicates behind for a later collection to honor. Filtering runs before stateless mixed-batch completeness is
  enforced, so a dropped response is never counted as an answer and the remaining history is validated on its own
  merits. The `disable_approval_response_binding` function invocation configuration option restores the previous
  unbound pass-through. Authorization sinks still require strict `True`.
- An approved tool executes exactly once.
- A rejected tool executes zero times and produces one synthetic rejection `function_result` using the original
  function `call_id`.
- The resumed response contains the newly resolved approved and rejected terminal results before any final assistant
  message.
- Streaming yields the same logical result content and ordering as non-streaming output and
  `ResponseStream.get_final_response()`.
- The function invocation layer normalizes a private copy of caller messages. It must not mutate the caller's
  approval `Message`, approval `Content`, or an earlier returned response.
- Approval-time `UserInputRequiredException` and `MiddlewareTermination` return immediately without another model
  call.
- `Agent.as_tool()` keeps child function approvals inside the delegated invocation. A child
  `ToolApprovalMiddleware` may resolve them through runtime `auto_approval_rules`; any unresolved child function
  approval does not enter the caller's approval state or model transcript. An approval-only response fails the
  agent-tool invocation; a mixed response preserves its non-approval user-input requests while discarding the child
  approval continuation. Interactive, delayed, or durable approval belongs in a workflow. When
  `propagate_session=True`, child application-state changes merge back into the parent while framework approval and
  invocation-budget state remain isolated, including approval queues stored under custom child middleware
  `source_id` values. Parent and child `ToolApprovalMiddleware` instances must use distinct `source_id` values; an
  overlap fails before the child runs. The automatic function loop also supplies the parent agent/client's declared
  provider-owned state keys. A custom loop that directly invokes the agent tool must set
  `FunctionInvocationContext.parent_service_session_state_keys` explicitly; when that ownership is unavailable, a
  non-empty parent session fails before the child runs rather than propagating unknown provider state.

### Approval control content

- `function_approval_request` and `function_approval_response` are control-plane contents, not durable model
  transcript items.
- A current hosted approval response must be sent once on the immediate resume request.
- AG-UI removes a local approval response from its request and snapshot replay when a terminal result belongs to an
  already-consumed occurrence, including result-before-response replay. A client-authored result in the occurrence
  that is still registered as pending does not prove completion: AG-UI removes that result, keeps the validated
  response for local execution, and leaves hosted approval responses as provider protocol data.
- Hosted AG-UI approval interrupts expose an accept/reject decision only; argument edits are rejected because the
  hosted provider executes the server-owned request rather than client-edited arguments.
- AG-UI tool approval resumes accept the standard `approved` decision and full-replacement `editedArgs` payload.
  Existing MAF clients remain compatible through the `accepted` decision alias and direct partial argument edits.
- An AG-UI `cancelled` resume is a valid terminal decision, not a run error. In a resume covering parallel open
  interrupts, resolved siblings still execute and cancelled calls do not. An identical cancellation retry during
  the retained terminal window also completes normally without restoring authority.
- AG-UI Approval State capacity is enforced independently for each trusted application scope. Abandoned pending
  authority expires after its configured window, and indeterminate execution records remain non-retryable until
  their separate safety window permits reclamation. Reclamation never recreates approval authority.
- A server-issued approval request must not be replayed inline during service-side continuation.
- History providers may retain approval control contents in their backing store for audit, but base history replay
  filters them before later model calls.
- Callers that manually own and replay message history without a loading `HistoryProvider` must likewise omit a
  previously submitted approval response from later continuation requests.

### History and continuation

- Model-bound history contains one function call/result pair per completed logical occurrence.
- Append-only history must not replay stale approval request/response wrappers to the model.
- Framework-managed and service-managed continuation must preserve the same logical call/result transcript.
- A streaming response rebuilt from updates by an intermediate middleware must carry over the inner response's
  conversation id and its internal-conversation-id marker, so framework-managed continuation appends only the latest
  message instead of replaying a transcript the provider already holds. The rebuilt response mirrors the inner
  conversation id exactly, including clearing it, and never retains an id emitted by an earlier service call in the
  same turn.
- A trusted terminal result consumes the corresponding approval authority in explicit stateless replay; a result in a
  server-registered pending occurrence cannot consume that authority before local execution.
- A matched `function_result` is terminal regardless of its text, including an exact or embedded
  `[APPROVAL_PENDING]`. Legacy textual placeholder results are no longer supported. Applications that persisted
  those placeholders must migrate genuine pending occurrences using authoritative pending state and typed
  `function_approval_request` controls, without synthetic `function_result` contents. Actual completed results must
  remain in history; their text must not be used to infer pending approval state.
- Non-streaming runs that exclude tool groups through in-run compaction return the inserted summary messages in the
  final response transcript, each positioned before the group it replaces, so history loaded with `skip_excluded`
  keeps the summarized content; summaries of caller-owned input messages stay out of the returned transcript.

## Scenario-to-test matrix

### Normal function invocation

| Scenario | Required invariant | Primary regression test |
|---|---|---|
| Single non-streaming call | Call, result, and final assistant message are returned in order. | `packages/core/tests/core/test_function_invocation_logic.py::test_base_client_with_function_calling` |
| Usable call under a non-tool finish reason | A schema-usable call executes once and the normal loop continues in both response modes even when the enclosing response reports `finish_reason="length"`. | `packages/core/tests/core/test_function_invocation_logic.py::test_function_call_with_length_finish_reason_executes_and_continues`, `test_streamed_function_call_with_length_finish_reason_executes_and_continues` |
| String input | Flexible string input follows the same loop behavior. | `test_base_client_with_function_calling_string_input` |
| Multiple sequential rounds | Each round retains one call/result pair. | `test_base_client_with_function_calling_resets` |
| Streaming call | Call chunks, one result update, and final text are emitted in order. | `test_base_client_with_streaming_function_calling` |
| Function-call occurrence identity | Actionable calls gain one stable `Content.id`; a safe local empty-`call_id` fallback uses that id with a migration warning, and streaming aggregation preserves provider-assigned occurrence ids across interleaved fragments. OpenAI Chat Completions scopes fragment correlation to each request and `(choice.index, tool.index)`. | `test_actionable_function_call_gets_stable_occurrence_identity`, `test_actionable_function_call_uses_occurrence_identity_for_empty_call_id`, `test_streaming_empty_call_id_keeps_occurrence_identity_through_approval`, `test_streaming_empty_call_id_delta_reuses_opening_call_identity`, `test_streaming_interleaved_indexed_call_fragments_coalesce_by_occurrence`, `packages/core/tests/core/test_types.py::test_function_call_occurrence_id_roundtrips_without_regeneration`, `packages/openai/tests/openai/test_openai_chat_completion_client.py::test_streaming_tool_call_identity_is_request_local_and_scoped_by_choice_index` |
| Reasoning-bound call | Finalized output retains reasoning, function call, function result, and final text. | `test_streaming_function_calling_response_includes_reasoning_and_tool_results` |
| Calls across response messages | Every actionable call is executed once. | `test_base_client_executes_function_calls_across_multiple_response_messages` |
| Parallel calls | Results retain the corresponding call ids and execution count. | `test_max_function_calls_limits_parallel_invocations`, `test_streaming_multiple_function_calls_parallel_execution` |
| Sequential calls | Calls execute one at a time in model order, including after approval replay; mixed local/Host-owned siblings retain that order, approval-only batches wait for every decision before executing, each call has isolated context, and middleware termination takes effect after the accepted batch finishes. | `packages/core/tests/core/test_tools.py::test_sequential_function_invocation_runs_calls_in_model_order`, `test_sequential_function_invocation_isolates_context`, `test_sequential_function_invocation_finishes_batch_after_termination`, `packages/core/tests/core/test_harness_tool_approval.py::test_mixed_batch_hides_already_approved_request_until_approval_replay`, `test_sequential_approval_replay_preserves_model_order_when_responses_are_reversed`, `test_sequential_approval_replay_waits_for_the_complete_batch`, `packages/core/tests/core/test_function_invocation_logic.py::test_sequential_mixed_batch_preserves_approval_and_host_model_order`, `packages/core/tests/workflow/test_agent_executor_tool_calls.py::test_workflow_cancels_host_member_of_mixed_batch_with_terminal_result`, `test_workflow_host_cancellation_preserves_occurrence_with_reused_call_id` |
| Informational-only call | The call is returned but not executed or approved. | `test_informational_only_function_call_is_not_invoked`, `test_informational_only_function_call_does_not_request_approval`, `test_streaming_informational_only_function_call_is_not_invoked` |
| OpenAI hosted/local shell boundary | Hosted shell calls remain informational in streaming and non-streaming responses even when a local executor is configured; only valid explicit local-shell items or shell calls marked with a local environment can execute, local execution preserves its configured approval mode, stateless loops preserve the complete provider shell transcript or fail explicitly, and locally generated shell outputs preserve stdout, stderr, truncation notices, non-zero exits, and timeout outcomes in every continuation mode. | `packages/openai/tests/openai/test_openai_chat_client.py::test_response_content_creation_with_shell_call_remains_hosted_with_local_tool`, `test_parse_chunk_from_openai_shell_call_done_remains_hosted`, `test_parse_chunk_from_openai_local_environment_shell_call_done_emits_command`, `test_mixed_shell_calls_only_invoke_explicit_local_shell_call`, `test_stateless_shell_transcript_without_provider_item_fails`, `test_prepare_messages_keeps_local_shell_output_under_storage`, `test_shell_output_payloads_use_structured_function_result_items`, `test_malformed_local_environment_shell_call_is_not_executable`, `test_response_content_creation_with_local_shell_call_maps_to_function_call`, `test_malformed_local_shell_call_is_not_executable`, `test_response_function_call_named_local_shell_is_informational`, `test_parse_chunk_function_call_named_local_shell_is_informational`, `test_local_shell_tool_requires_approval_before_function_loop_execution` |
| Declaration-only call | The call is surfaced as user input and is not executed; streaming arguments appear once while finalized request metadata remains available. | `test_declaration_only_tool`, `test_streaming_declaration_only_tool_preserves_metadata_without_duplicate_arguments` |
| Declaration-only mixed batch | Known local siblings are never converted into Host pauses. With an authoritative session they remain deferred until every Host pause occurrence is answered, survive session serialization with a process-portable logical-run budget (including a reclassified approval continuation), reclassify against the current tool policy, execute exactly once using the configured concurrent or sequential invocation mode, replay results in original model order, and remain inert on replay; without one they execute on the same turn under the same configured invocation mode. Streaming updates and finalization preserve one Host pause and one result per local sibling. | `test_mixed_declaration_only_batch_defers_siblings_until_all_host_results`, `test_mixed_declaration_only_deferred_call_keeps_ordinary_middleware_semantics`, `test_mixed_declaration_only_deferred_call_reclassifies_changed_approval_policy`, `test_mixed_declaration_only_budget_survives_reclassification_to_approval`, `test_mixed_declaration_only_deferred_call_does_not_execute_removed_tool`, `test_mixed_declaration_only_budget_is_process_portable_without_approval_middleware`, `test_sessionless_mixed_declaration_only_batch_executes_siblings_sequentially`, `test_sessionless_mixed_declaration_only_batch_executes_siblings_concurrently`, `test_streaming_sessionless_mixed_declaration_only_batch_returns_pause_and_result` |
| Function invocation disabled | The client bypasses the invocation loop without losing invocation kwargs. | `test_function_invocation_config_enabled_false`, `test_function_invocation_config_enabled_false_preserves_invocation_kwargs`, `test_streaming_function_invocation_config_enabled_false` |
| Runtime tool changes | Added tools become available on the next iteration and retain approval behavior. | `test_add_tools_available_next_iteration`, `test_add_tools_with_approval_required_tool` |
| Direct delegated session propagation | A custom loop must explicitly identify parent provider-owned state before sharing a non-empty session; missing ownership fails before the child runs, while declared parent keys remain isolated and application state still propagates. | `packages/core/tests/core/test_agents.py::test_chat_agent_as_tool_direct_propagation_requires_parent_provider_ownership`, `test_chat_agent_as_tool_direct_propagation_uses_explicit_parent_provider_ownership` |
| In-run compaction summaries | Summaries inserted for tool groups excluded by in-run compaction are returned in the final non-streaming response transcript before the group they replace, so history loaded with `skip_excluded` keeps the summarized content; summaries of caller-owned input messages are not added. | `packages/core/tests/core/test_clients.py::test_function_loop_returns_compaction_summaries_in_final_response`, `test_function_loop_returns_compaction_summaries_when_iteration_budget_exhausted`, `test_function_loop_reconciles_nested_compaction_summaries`, `test_function_loop_returns_compacted_transcript_on_early_terminal_exit`, `packages/core/tests/core/test_agents.py::test_agent_run_returns_and_persists_compaction_summaries` |
| Per-service-call provider context | When framework-managed history is loaded around each model call, tools and instructions contributed by `HistoryProvider.before_run` remain available to the model and function loop without duplication in streaming or non-streaming execution. | `packages/core/tests/core/test_agents.py::test_vector_history_search_tool_is_available_with_per_service_call_persistence` |

### Approval pause and resume

| Scenario | Required invariant | Primary regression test |
|---|---|---|
| Initial approval request | Assistant response contains the original call and approval request; tool does not execute. | `test_approval_requests_in_assistant_message`, `test_streaming_approval_request_generated`, `test_streaming_approval_requests_in_assistant_message` |
| Approved non-streaming resume | Result precedes final text; tool executes once; inputs remain unchanged. | `packages/core/tests/core/test_harness_tool_approval.py::test_approval_resume_returns_result_without_mutating_inputs[non-streaming-approved]` |
| Rejected non-streaming resume | Rejection result precedes final text; tool executes zero times; inputs remain unchanged. | `test_approval_resume_returns_result_without_mutating_inputs[non-streaming-rejected]` |
| Approved streaming resume | Result update precedes final text and final response matches non-streaming shape. | `test_approval_resume_returns_result_without_mutating_inputs[streaming-approved]`, `test_streaming_approval_resume_yields_terminal_result_before_model_text[approved]` |
| Rejected streaming resume | Rejection result update precedes final text and tool executes zero times. | `test_approval_resume_returns_result_without_mutating_inputs[streaming-rejected]`, `test_streaming_approval_resume_yields_terminal_result_before_model_text[rejected]` |
| Mixed approved/rejected batch | Every call gets one correctly correlated terminal result. | `packages/core/tests/core/test_function_invocation_logic.py::test_rejected_approval` |
| Persisted approval replay | Resume executes with the prior call available. | `test_persisted_approval_messages_replay_correctly` |
| Hosted approval pass-through | Hosted requests/responses are bound to the recorded provider request and are not processed as local calls. | `test_hosted_tool_approval_response`, `test_hosted_mcp_approval_response_passthrough`, `test_session_approval_binding_reconstructs_hosted_response`, `test_mixed_local_and_hosted_approval_flow` |
| Agent-tool child approval | A child `ToolApprovalMiddleware` can auto-approve runtime tool requests inside one delegated invocation; unresolved child approvals execute nothing and do not enter the caller's approval state or dispatch a same-named parent tool, including with propagated application state. Mixed batches preserve non-approval user-input requests. Shared parent and child state rejects overlapping `ToolApprovalMiddleware.source_id` values before running the child; parent approval state is neither visible nor mutable inside the child, and custom child approval queues do not leak into later delegations. | `packages/core/tests/core/test_agents.py::test_chat_agent_as_tool_auto_approves_child_tool_with_middleware`, `test_chat_agent_as_tool_fails_closed_for_unresolved_child_approval`, `test_chat_agent_as_tool_child_approval_does_not_dispatch_same_named_parent_tool`, `test_chat_agent_as_tool_preserves_non_approval_requests_from_mixed_child_batch`, `test_chat_agent_as_tool_shared_session_requires_distinct_tool_approval_source_ids`, `test_chat_agent_as_tool_isolates_custom_parent_approval_state`, `test_chat_agent_as_tool_approved_delegation_does_not_confuse_framework_approval_state`, `test_chat_agent_as_tool_does_not_restore_custom_approval_queue_on_fresh_delegation` |
| Approval-time user input | Every user-input request from one approved execution returns in order with assistant role and no extra model call; the execution consumes one call-budget unit. | `packages/core/tests/core/test_harness_tool_approval.py::test_approval_resume_returns_all_user_input_requests_without_another_model_call`, `packages/core/tests/core/test_function_invocation_logic.py::test_approval_resume_user_input_counts_toward_function_call_budget` |
| Mixed terminal result and follow-up input | Completed siblings remain tool-role while only follow-up input requests use assistant-role messages/updates. | `packages/core/tests/core/test_function_invocation_logic.py::test_approval_resume_separates_terminal_results_from_follow_up_requests`, `packages/openai/tests/openai/test_openai_chat_completion_client.py::test_mixed_approval_resume_roles_serialize_function_result_as_tool`, `packages/core/tests/core/test_harness_tool_approval.py::test_dynamic_policy_approval_partitions_safe_sibling_result_roles` |
| Approval-time middleware termination | Terminal result returns with no extra model call in either response mode. | `packages/core/tests/core/test_function_invocation_logic.py::test_approval_resume_honors_middleware_termination` |
| Approval re-entry after iteration budget | Pending approved calls resolve once even when prior model calls consumed `max_iterations`. | `packages/core/tests/core/test_harness_tool_approval.py::test_auto_approval_resolves_after_iteration_budget_is_exhausted` |
| Approval resume with reasoning | Model-bound resume history retains reasoning before the call and terminal result in both modes. | `packages/core/tests/core/test_harness_tool_approval.py::test_approval_resume_replays_reasoning_with_function_call_group` |
| Changed resolved policy invocation | The stale decision executes nothing; a same-occurrence replacement request is visible and persisted in both modes, and the second approval executes exactly once. | `packages/core/tests/core/test_harness_tool_approval.py::test_changed_hidden_snapshot_requires_visible_second_approval` |
| Expired or evicted policy authority | The old response executes nothing, surfaces and persists a same-occurrence replacement with a fresh request generation in both modes, and executes exactly once only after the replacement is approved; restored model history remains balanced and stale prior-generation replay is inert. | `packages/core/tests/core/test_harness_tool_approval.py::test_policy_reapproval_is_visible_persisted_and_executes_once`, `packages/core/tests/test_security.py::TestPolicyEnforcementMiddleware::test_pending_policy_approval_ttl_is_deterministic_and_durable` |
| Session-bound policy cleanup | FIFO/TTL lifecycle and authenticated rejection/cancellation cleanup use occurrence identity within only the owning session, including fixed provider scopes. | `packages/core/tests/test_security.py::TestPolicyEnforcementMiddleware::test_pending_policy_approvals_are_fifo_bounded_by_occurrence`, `test_pending_policy_approval_ttl_is_deterministic_and_durable`, `test_non_grant_cleanup_is_authenticated_session_and_occurrence_bound`, `test_fixed_scope_non_grant_cleanup_keeps_unrelated_occurrence` |
| Session-bound substituted response | A response is rebound to the immutable recorded call and cannot replace its call id, tool name, arguments, or first decision through a conflicting duplicate in the same request or a later retry. | `packages/core/tests/core/test_function_invocation_logic.py::test_session_approval_binding_rebinds_consumes_and_rejects_duplicates`, `packages/core/tests/core/test_harness_tool_approval.py::test_approval_batch_uses_the_first_decision_for_duplicate_responses`, `test_approval_batch_preserves_first_decision_across_partial_retries` |
| Occurrence-aware local binding | New local requests use `function_call.id`; missing, mismatched, or stale occurrence ids do not execute or consume pending state, while the canonical occurrence id binds without an embedded call. | `test_occurrence_aware_approval_rejects_stale_reused_call_id_response`, `test_occurrence_aware_approval_mismatched_identity_does_not_consume_pending`, `test_occurrence_aware_approval_binds_without_embedded_function_call` |
| Legacy stored approval | A serialized pending request without `function_call.id` retains exact request-id binding once and warns only when resumed. | `test_legacy_serialized_pending_approval_resumes_once_with_migration_warning`, `packages/core/tests/core/test_types.py::test_legacy_function_call_deserialization_does_not_generate_an_occurrence_id` |
| Hosted approval identity | Provider-issued hosted approval request ids are unchanged by local occurrence correlation. | `test_hosted_approval_keeps_provider_issued_request_id` |
| Truthy non-boolean decision | Strings, integers, null, and other non-booleans do not authorize execution. | `packages/core/tests/core/test_function_invocation_logic.py::test_session_approval_binding_treats_truthy_non_boolean_as_rejection`, `packages/core/tests/core/test_types.py::test_function_approval_response_deserialization_rejects_non_boolean_decisions`, `packages/ag-ui/tests/ag_ui/test_message_adapters.py::test_function_approval_requires_real_boolean`, `packages/ag-ui/tests/ag_ui/test_approval_result_event.py::test_resolve_approval_responses_treats_non_boolean_decision_as_rejection` |
| Active batch replacement | A newly surfaced model batch replaces abandoned approval authority instead of growing session state. | `packages/core/tests/core/test_function_invocation_logic.py::test_session_approval_binding_replaces_abandoned_batch` |
| Duplicate request id | Ambiguous request IDs within one active batch fail explicitly. | `packages/core/tests/core/test_function_invocation_logic.py::test_session_approval_batch_rejects_duplicate_request_ids` |
| Tool registry changes | Same-name upgrades may execute the recorded operation; removing the recorded name executes nothing. | `packages/core/tests/core/test_harness_tool_approval.py::test_approval_resume_allows_same_name_tool_upgrade`, `test_approval_resume_does_not_execute_when_recorded_tool_disappears` |

### Approval correlation and replay

| Scenario | Required invariant | Primary regression test |
|---|---|---|
| Result matching without placeholders | Results match calls by id even when the result list is reordered. | `test_replace_approval_contents_with_results_uses_result_call_ids_without_placeholders` |
| Reused id after completion | A later round with the same id creates a second valid pair. | `test_replace_approval_contents_with_results_allows_reused_call_id_after_completion` |
| Replayed approval wrapper | A duplicated wrapper does not restore another function call. | `test_replace_approval_contents_with_results_deduplicates_replayed_approval_request` |
| Historical resolved response plus new round | The old response is removed from normalized input and is not converted into a rejection result. | `test_replace_approval_contents_with_results_ignores_already_resolved_response` |
| Replacement request with reused occurrence id | A request after a stale response starts a new unanswered round rather than inheriting the old decision. | `test_collect_unanswered_approval_requests_tracks_replacement_request` |
| Multiple reused-id rounds | Approved and rejected rounds retain separate call/result occurrences. | `test_replace_approval_contents_with_results_correlates_reused_call_id_occurrences` |
| Multi-content result with reused id | Every content produced by one execution stays with that approval occurrence and cannot bleed into the next reused-id round. | `test_replace_approval_contents_with_results_keeps_multi_content_group_with_reused_call_id` |
| Follow-up request closes one occurrence | A user-input follow-up consumes only the preceding approval authority and leaves a later reused-id response pending. | `test_collect_approval_responses_consumes_matching_follow_up_request_occurrence` |
| Reused-id pending requests | Typed pending requests consume approved results by occurrence. | `test_replace_approval_contents_with_results_correlates_reused_call_id_pending_requests` |
| Rejected pending request | Rejection produces one terminal result. | `test_replace_approval_contents_with_results_resolves_rejected_request` |
| Results reordered with pending requests | Results still match the correct call ids. | `test_replace_approval_contents_with_results_uses_result_call_ids_for_pending_requests` |
| Missing result call id | A malformed result does not steal another approval's result. | `test_replace_approval_contents_with_results_skips_results_without_call_id` |
| Empty approval message cleanup | Fully consumed approval messages are removed from normalized model input. | `test_replace_approval_contents_with_results_prunes_emptied_messages` |
| Later stateless turn | A prior terminal approval response cannot execute again, regardless of result text or message serialization. | `test_resolved_approval_response_is_inert_on_later_stateless_turn` |
| Serialized session authority | Client-authored results cannot retire pending authority; a completed approval cannot execute again before or after session serialization. | `test_session_approval_executes_once_across_serialization` |
| Completed request tracking | Terminal result text cannot leave a completed request pending or consume a later reused-id request. | `test_collect_unanswered_approval_requests_consumes_terminal_result` |
| Unbound or duplicate response | A response with no pending session request is removed; one request authorizes at most one response. | `test_session_approval_binding_rebinds_consumes_and_rejects_duplicates` |
| Forged inbound request history | A caller-supplied request wrapper cannot replace the server snapshot or resurrect consumed authority. | `test_session_approval_binding_does_not_trust_inbound_request_history` |
| Local approval without authoritative session | A local approval response carried by any message role executes nothing when no session recorded its request, whether the request is fabricated, absent, answered with tampered arguments, or repeated as several responses sharing one approval id. Verified for both streaming and non-streaming. | `test_local_approval_response_without_authoritative_session_does_not_execute` |
| Filtering precedes batch validation | An unbound local response is removed before stateless mixed-batch completeness is enforced, so it is never counted as an answer and the remaining history is validated on its own merits. | `test_unbound_local_approval_response_is_filtered_before_mixed_batch_validation` |
| Session-bound approval round trip | The same response executes once when the issuing session is supplied on the resuming run. | `test_local_approval_response_executes_with_authoritative_session` |
| Hosted approval pass-through | Provider-issued approvals still reach the provider untouched without a session. | `test_hosted_approval_response_passes_through_without_session` |
| Settled replay without a session | A completed approval round replays as history: it does not re-execute, does not warn, and does not fail a completed mixed batch. | `test_settled_approval_response_replays_without_session_or_warning`, `test_completed_split_stateless_mixed_batch_is_inert_on_later_turn` |
| Binding opt-out | `disable_approval_response_binding` restores the previous unbound pass-through. | `test_disable_approval_response_binding_restores_unbound_behavior` |
| Pending history turn | An unresolved approval batch is omitted atomically from unrelated model input while a later decision can still resume it once. | `packages/core/tests/core/test_harness_tool_approval.py::test_pending_approval_from_file_history_stays_resumable_without_model_orphan` |
| Duplicate function-call prevention | Approval normalization does not create a second call for one round. | `test_no_duplicate_function_calls_after_approval_processing` |
| Rejection call id | Rejection result uses the function call id, not only the approval id. | `test_rejection_result_uses_function_call_id` |

### Mixed batches and approval middleware

| Scenario | Required invariant | Primary regression test |
|---|---|---|
| Fatal call mixed with pauses | Complete-batch classification raises before approval or execution, independent of call order. | `packages/core/tests/core/test_function_invocation_logic.py::test_mixed_batch_fatal_unknown_precedes_every_pause` |
| Approval and Host-owned calls | Both pause types are returned in model order; a session-backed partial response remains pending across serialization; occurrence-identified Host results reserve their slots before id-less results use the unique unanswered occurrence, while authoritative session state recognizes equivalent duplicates and conflicting duplicates fail closed; stateless replay does not treat an ambiguous id-less result as a Host duplicate without occurrence provenance; a stateless zero-response or partial response fails closed across non-user message roles and cannot be hidden by a newer standalone request; standalone pauses separated by an unrelated user turn remain independent and response-order invariant when call IDs are reused; exact Host occurrence identity outranks newer call-ID-only candidates; each stateless response belongs to the nearest compatible request batch even when it cannot be assigned to one item, response ownership is discovered in linear time, and Host-result exclusions close only their Host occurrences without keeping historical completed calls open or reinterpreting later local terminal results during approval normalization; completed mixed batches remain inert even when approval and Host requests reuse a call ID; historical Host calls do not participate; a complete response executes the exact approved arguments once. Stateless scenarios in this row that resume a still-pending approval are exercised through the `disable_approval_response_binding` opt-out, since binding is required by default; the completed/inert scenarios run on the default path because settled occurrences are exempt. | `test_mixed_batch_returns_approval_and_host_pause_in_model_order`, `test_mixed_batch_requires_complete_responses_before_execution`, `test_stateful_mixed_batch_accepts_equivalent_idless_host_result_replay`, `test_stateful_mixed_batch_assigns_idless_equal_result_to_unanswered_occurrence`, `test_stateless_mixed_batch_rejects_conflicting_identified_host_results`, `test_stateless_split_mixed_batch_rejects_incomplete_replay_before_execution`, `test_stateless_mixed_batch_across_non_user_message_roles_requires_complete_responses`, `test_stateless_abandoned_approval_does_not_join_later_host_request`, `test_stateless_separated_pauses_with_reused_call_id_are_order_independent`, `test_exact_older_host_result_does_not_consume_newer_reused_call_approval`, `test_later_standalone_request_does_not_hide_incomplete_stateless_mixed_batch`, `test_later_idless_host_result_does_not_complete_older_stateless_mixed_batch`, `test_completed_approval_result_is_not_claimed_by_older_stateless_host_request`, `test_historical_stateless_host_result_does_not_capture_later_reused_call_approval`, `test_excluded_host_result_closes_own_occurrence_before_reused_call_approval`, `test_ambiguous_later_host_result_does_not_complete_older_stateless_mixed_batch`, `test_id_bearing_result_for_idless_host_request_does_not_consume_approval`, `test_stateless_pause_response_ownership_scans_contents_linearly`, `test_completed_split_stateless_mixed_batch_is_inert_on_later_turn`, `test_completed_stateless_mixed_batch_with_reused_call_id_is_inert`, `test_equal_idless_terminal_result_does_not_reexecute_completed_stateless_mixed_approval`, `test_active_mixed_pause_ignores_historical_host_requests` |
| Safe and approval-required calls in one batch | Hidden safe calls replay only with the matching visible approval. | `packages/core/tests/core/test_harness_tool_approval.py::test_mixed_batch_hides_already_approved_request_until_approval_replay` |
| Restored approval state | Serialized `ToolApprovalState` restores mixed-batch behavior. | `test_mixed_batch_accepts_restored_tool_approval_state` |
| Unrelated turn before approval | Hidden calls do not execute on an unrelated turn. | `test_hidden_mixed_batch_requests_do_not_replay_on_unrelated_turn` |
| Multiple abandoned batches | Hidden calls replay only for the matching batch. | `test_hidden_mixed_batch_requests_replay_only_for_matching_visible_approval` |
| Queued approvals | One unresolved approval is surfaced per run without premature execution. | `test_tool_approval_middleware_queues_multiple_approval_requests`, `test_tool_approval_middleware_queues_streamed_approval_requests` |
| Middleware state plus hidden core state | State saves do not discard hidden mixed-batch calls. | `test_tool_approval_middleware_preserves_hidden_mixed_batch_requests` |
| Auto-approval callback | Callback receives the original function call and executes the approved set once. | `test_tool_approval_middleware_auto_approval_rule_receives_function_call` |
| Approval policy with Host-owned sibling | Reordering the same calls has the same outcome; auto-approved and safe calls remain deferred until Host input arrives; separately streamed Host input stays immediately visible while later manual approvals remain in model order and in the same batch; an approved Host tool returns to Host-owned handling before local execution. | `test_tool_approval_middleware_mixed_batch_is_order_independent`, `test_tool_approval_middleware_auto_approves_with_host_pause_and_cached_safe_call`, `test_tool_approval_middleware_keeps_manual_approvals_together_with_host_pause`, `test_tool_approval_middleware_preserves_split_streamed_mixed_batch_order`, `test_tool_approval_middleware_streams_standalone_user_input_immediately`, `test_tool_approval_middleware_policy_approval_reclassifies_host_tool` |
| Shared call budget | Auto-approved re-entry does not reset `max_function_calls`, and every executed approval group counts even when it pauses for input. | `test_tool_approval_middleware_auto_approved_loops_share_function_call_budget`, `test_approval_resume_user_input_counts_toward_function_call_budget` |
| Standing tool rule | Tool-level approval applies only to later matching tools. | `test_tool_approval_middleware_always_approve_tool_rule` |
| Forged standing rule | An unbound or substituted hosted response cannot create a standing middleware approval rule for caller-selected metadata. | `test_tool_approval_middleware_drops_forged_standing_approval`, `test_tool_approval_middleware_rebinds_hosted_standing_approval` |
| Hosted server boundary | Standing approval does not cross `server_label`. | `test_tool_approval_middleware_standing_rules_include_hosted_server_boundary` |
| Argument-scoped rule | Exact arguments are required; empty arguments are not tool-wide. | `test_tool_approval_middleware_always_approve_tool_with_arguments_rule`, `test_tool_approval_middleware_empty_arguments_rule_is_not_tool_wide` |
| Provider-injected approval tool | A tool added during `before_run` defers to in-run resolution, executes once, and emits one result. | `packages/ag-ui/tests/ag_ui/test_endpoint.py::test_endpoint_agent_approval_deferred_provider_tool_executes` |
| AG-UI provider boundary | Completed local approval controls from AG-UI request and snapshot replay are absent from raw chat-client input while deferred and hosted approvals keep their respective in-run/provider paths. Lifecycle-authenticated local approvals preserve current request-generation authority through occurrence rebinding; authenticated rejection/cancellation cleans only the matching fixed provider-scoped policy record, while malformed or unauthorized controls clean nothing. | `packages/ag-ui/tests/ag_ui/test_endpoint.py::test_endpoint_does_not_forward_resolved_local_approval_control_to_chat_client`, `test_endpoint_agent_approval_deferred_provider_tool_executes`, `test_endpoint_canonical_resume_preserves_hosted_approval_for_provider`, `test_endpoint_fides_non_grant_cleans_authenticated_fixed_scope_only`, `test_endpoint_fides_approval_uses_lifecycle_bound_request_generation`, `packages/ag-ui/tests/ag_ui/test_run.py::test_filter_local_approval_responses_for_provider_removes_duplicate_completed_controls`, `test_filter_local_approval_responses_for_provider_pairs_reused_call_ids_by_occurrence`, `test_canonical_hosted_approval_resume_rejects_edited_arguments_without_mutating_pending` |
| AG-UI standard approval payload | Agent and workflow tool approvals emit canonical `tool_call` interrupts. `approved` plus full-replacement `editedArgs` executes once and replays idempotently, while legacy `accepted` plus direct partial edits remains supported. Hosted approvals remain decision-only. | `packages/ag-ui/tests/ag_ui/test_endpoint.py::test_endpoint_agent_approval_resume_entry_applies_standard_full_replacement_edited_args`, `test_endpoint_agent_approval_replayed_standard_edited_resume_is_idempotent`, `test_endpoint_agent_approval_resume_entry_applies_edited_arguments`, `test_workflow_endpoint_emits_canonical_tool_approval_interrupt`, `test_workflow_endpoint_accepts_canonical_tool_approval_resume`, `test_workflow_endpoint_applies_canonical_approval_edited_args`, `test_workflow_endpoint_accepts_legacy_partial_approval_edits`, `test_workflow_endpoint_hosted_approval_rejects_argument_edits` |
| AG-UI cancellation | A cancelled interrupt executes zero times and completes normally, including an identical retry during retained cancellation state; resolved siblings in the same complete resume still execute once. Workflow cancellation clears both runner correlation and the owning agent executor's pending request so later approvals remain resumable. | `packages/ag-ui/tests/ag_ui/test_endpoint.py::test_endpoint_agent_approval_cancelled_resume_entry_completes_without_execution`, `test_endpoint_agent_approval_replayed_cancellation_completes_idempotently`, `test_endpoint_agent_approval_mixed_cancelled_and_resolved_resume_executes_resolved_tool`, `test_endpoint_workflow_request_info_cancelled_resume_completes_normally`, `test_workflow_endpoint_cancelled_agent_approval_does_not_block_next_approval` |
| AG-UI shared workflow interrupt ownership | A direct shared `Workflow` request-info interrupt can only be resolved or cancelled by the Snapshot Scope and AG-UI thread that created it. Ownership follows the authoritative pending request occurrence, and explicitly threaded cold checkpoint resumes fail closed when ownership is unavailable. | `packages/ag-ui/tests/ag_ui/test_endpoint.py::test_endpoint_workflow_request_info_rejects_resume_from_different_thread`, `test_endpoint_workflow_request_info_rejects_resume_from_different_scope`, `test_endpoint_workflow_request_info_rejects_cancellation_from_different_thread`, `test_endpoint_workflow_request_info_remains_owned_after_client_disconnect`, `test_endpoint_workflow_request_info_rejects_unowned_pending_interrupt`, `test_endpoint_workflow_checkpoint_resume_rejects_threaded_resume_after_restart` |
| AG-UI approval retention and capacity | Pending authority expires automatically, indeterminate outcomes remain non-retryable until their safety window permits reclamation, and one trusted scope cannot consume another scope's occurrence quota. | `packages/ag-ui/tests/ag_ui/test_approval_lifecycle.py::test_abandoned_pending_occurrence_expires_and_releases_capacity`, `test_indeterminate_occurrence_is_reclaimed_after_its_safety_window`, `test_capacity_is_enforced_per_trusted_scope` |
| AG-UI local executor unavailable on resume | A claimed local occurrence whose executor disappeared releases its unstarted claim, reports temporary unavailability, and remains safely retryable. | `packages/ag-ui/tests/ag_ui/test_endpoint.py::test_endpoint_agent_approval_resume_remains_retryable_when_local_tool_is_temporarily_unavailable` |
| AG-UI forwarded execution interruption | A provider failure, cancellation, or stream close after forwarding an approval recovers the open occurrence as indeterminate when no idempotency key proves retry safety. | `packages/ag-ui/tests/ag_ui/test_endpoint.py::test_endpoint_hosted_approval_becomes_indeterminate_when_provider_stream_fails` |

### Errors, control flow, and limits

| Scenario | Required invariant | Primary regression test |
|---|---|---|
| Rejected execution | Rejection is a normal terminal result, not an exception to the caller. | `test_unapproved_tool_execution_raises_exception` |
| Approved tool exception | Generic and detailed error modes preserve one result and one execution. | `test_approved_function_call_with_error_without_detailed_errors`, `test_approved_function_call_with_error_with_detailed_errors` |
| Tool exception diagnostics | Internal diagnostics remain available to trusted local code, serialization preserves only a fixed failure marker, and explicit detailed-error configuration affects only the channel-visible result. | `packages/core/tests/core/test_types.py::test_function_result_exception_is_internal_by_default`, `packages/core/tests/core/test_function_invocation_logic.py::test_function_invocation_config_include_detailed_errors_false`, `test_function_invocation_config_include_detailed_errors_true`, `test_streaming_function_invocation_config_include_detailed_errors_false`, `test_streaming_function_invocation_config_include_detailed_errors_true` |
| Custom result-parser exception | Failed custom conversion produces one tool-error result rather than the raw return value, in both response modes and with observability enabled or disabled; detailed-error configuration is preserved. | `packages/core/tests/core/test_function_invocation_logic.py::test_function_invocation_result_parser_failure`, `packages/core/tests/core/test_tools.py::test_invoke_result_parser_exception_propagates` |
| Approved validation error | Validation failure returns one result without invoking the function body. | `test_approved_function_call_with_validation_error` |
| Pre-validation middleware repair | Schema-compatible calls retain normalized middleware arguments without duplicate validation. Prepared-value reuse does not require validator outputs to be copyable, and unchanged NaNs remain stable. Identity-only opaque values may be reused for ordinary execution, but security authority rejects them before downstream middleware or the tool body because in-place mutation cannot be detected safely. When provisional validation fails, function middleware observes raw parsed arguments, may repair them before final validation, and the body receives normalized values; short-circuiting skips final validation and execution. Repair after security middleware fails closed using recursive type-aware, float-bit-exact comparison, including invalid and short-circuited mutations. Security inspects exact normalized values, and validation errors after hidden-value resolution do not disclose resolved values or mapping keys, including validator `TypeError` paths. | `test_function_middleware_keeps_normalized_arguments_for_valid_calls`, `test_prepared_arguments_support_noncopyable_validator_output`, `test_nan_prepared_and_approval_snapshots_are_stable`, `test_function_middleware_repairs_raw_arguments_before_validation`, `test_function_middleware_can_short_circuit_before_argument_validation`, `test_invalid_arguments_produced_by_middleware_keep_argument_error_contract`, `packages/core/tests/test_security.py::TestVariableArgumentPolicy::test_security_rejects_opaque_mutable_validator_output`, `test_argument_mutation_after_security_middleware_fails_closed`, `test_security_snapshot_accepts_unchanged_nan`, `test_argument_mutation_after_security_short_circuit_fails_closed`, `test_security_policy_observes_custom_validator_transform_once`, `test_hidden_argument_validation_error_does_not_disclose_resolved_value`, `test_hidden_mapping_key_is_not_disclosed_by_validation_error`, `test_hidden_value_is_not_disclosed_by_validator_type_error`, `test_hidden_argument_can_be_normalized_after_security_check` |
| Approved middleware repair | Approval binds to the normalized middleware-entry representation, so ordinary Pydantic coercion still completes in one approval round. A changed approval-bound call executes zero times under the old grant, returns a persisted occurrence-bound replacement request in both response modes, and executes once only after the replacement is approved. Recursive type-aware, float-bit-exact comparison treats booleans and numbers, and positive and negative zero, as distinct while keeping unchanged NaNs stable; set elements and mapping entries are counted, so removing one of several NaNs is detected. Opaque mutable normalized values fail closed before approval authority is established. The replacement holds JSON-native arguments that survive session serialization, and a repair whose JSON form would prepare to different values fails closed. The same replacement rule applies when middleware short-circuits instead of calling the tool. Security expansion preserves approval-visible placeholders. | `test_approved_coercing_arguments_execute_without_replacement`, `test_approved_argument_repair_requires_replacement_approval`, `test_approved_argument_repair_short_circuit_requires_replacement_approval`, `test_approval_snapshot_distinguishes_exact_values`, `test_approval_rejects_opaque_mutable_validator_output`, `test_approval_detects_changes_to_converted_values`, `test_approval_change_that_json_cannot_represent_fails_closed`, `test_argument_tokens_count_items_that_share_a_token`, `test_approved_repair_replacement_round_trips_through_json`, `packages/core/tests/test_security.py::TestVariableArgumentPolicy::test_hidden_argument_resolution_does_not_require_reapproval` |
| Approved success | Successful approved execution returns one result. | `test_approved_function_call_successful_execution` |
| Consecutive error cap | Error threshold stops repeated failures, submits collected results, and makes only the required final no-tool model call. | `test_function_invocation_config_max_consecutive_errors`, `test_streaming_function_invocation_config_max_consecutive_errors`, `test_approval_resume_error_limit_forces_final_no_tool_response` |
| Unknown call handling | Configured false returns an error result; configured true raises before any call executes. A service-managed continuation settles every call in the aborted batch and advances to the settlement response before the `KeyError` propagates; without one, including local per-service-call history persistence, no extra request is made. | `test_function_invocation_config_terminate_on_unknown_calls_false`, `test_function_invocation_config_terminate_on_unknown_calls_true`, streaming equivalents, `test_fatal_unknown_settles_service_conversation`, `test_fatal_unknown_with_local_history_makes_no_settlement_request` |
| Middleware termination | Normal non-approval loop stops without a second model call. | `test_terminate_loop_single_function_call`, `test_terminate_loop_multiple_function_calls_one_terminates`, `test_terminate_loop_streaming_single_function_call` |
| Middleware failure (fatal) | `MiddlewareFailure` from function middleware or a tool body propagates to the caller without becoming a tool result; the tool does not execute (pre-invocation) or its result never feeds another model call (post-invocation); the cause chain is preserved; ordinary exceptions still become tool-error results and the loop continues. | `packages/core/tests/core/test_middleware_with_agent.py::TestMiddlewareFailure::test_failure_before_tool_aborts_run`, `test_failure_after_tool_aborts_run_before_next_model_turn`, `test_failure_cause_chain_reaches_caller`, `test_failure_from_tool_escapes_without_middleware`, `test_failure_streaming_reaches_stream_consumer`, `test_ordinary_exception_still_becomes_tool_error` |
| Middleware failure batch cancellation | A fatal signal fails the whole parallel batch: in-flight sibling tool invocations are cancelled and awaited before the failure propagates. Cancellation is cooperative — an async sibling stops at its next suspension point; a synchronous tool body already executing in a worker thread cannot be interrupted and may complete its side effects, but its result is discarded and never reaches the transcript, the model, or history, and failure propagation is not delayed behind it. | `TestMiddlewareFailure::test_failure_cancels_concurrent_sibling_tool`, `test_failure_with_sync_sibling_discards_late_result` |
| Middleware failure on a service-managed conversation | The continuation state is already persisted when the batch fails, so before propagating, the loop settles the hosted thread: one error `function_result` per dangling call, sent with `tool_choice="none"` in one extra request; the persisted continuation advances to the settlement response (required for response-ID continuations, a no-op for conversation-object ids) and the settlement response is otherwise discarded; a settlement failure never masks the abort. Without a service-managed conversation no extra request is made. | `TestMiddlewareFailure::test_failure_settles_dangling_calls_on_service_conversation`, `test_failure_settles_service_conversation_streaming`, `test_failure_settlement_advances_response_id_continuation`, `test_failure_without_service_conversation_makes_no_settlement_request` |
| Middleware failure during approved-tool replay | A fatal abort while the approval-resolution phase replays an approved tool escapes loudly (never absorbed into a rejection result), the tool's original — already service-persisted — call is settled the same way, and the continuation advances; both response modes. | `TestMiddlewareFailure::test_failure_during_approved_replay_settles_and_escapes`, `test_failure_during_approved_replay_streaming` |
| Provider-invalidated partial response output | `ResponseInvalidatedException` propagates unchanged in both response modes after clearing request budget state and restoring the last valid continuation. Partial streamed call deltas may remain visible, but no new approval, function middleware, tool body, result, follow-up model call, or settlement occurs. Anthropic requires every local call block to close, terminal `stop_reason="tool_use"`, and `message_stop`; non-tool terminal reasons, open blocks, missing `message_stop`, and non-cancellation stream errors after local call start invalidate the call. AG-UI maps `RUN_ERROR` after an exposed local client-tool call to the same invalidation signal while preserving complete calls that omit provider-specific end markers. Hosted/server-only calls and caller cancellation remain unaffected. | `packages/core/tests/core/test_function_invocation_logic.py::test_response_invalidation_short_circuits_current_iteration`, `test_invalidated_final_no_tool_response_preserves_prior_continuation`, `packages/anthropic/tests/test_anthropic_client.py::test_non_streaming_local_tool_call_with_invalidating_stop_reason_raises`, `test_valid_streaming_local_tool_call_executes_and_continues`, `test_streaming_local_tool_call_invalid_terminal_sequences_raise`, `test_streaming_provider_error_after_local_call_is_wrapped_as_invalidation`, `test_streaming_cancellation_after_local_call_is_not_wrapped`, `test_streaming_hosted_tool_pause_turn_is_not_invalidated`, `packages/ag-ui/tests/ag_ui/test_ag_ui_client.py::TestAGUIChatClient::test_run_error_invalidates_partial_client_tool_call`, `test_streaming_run_error_invalidates_partial_client_tool_call`, `test_complete_client_tool_call_does_not_require_tool_call_end`, `test_streaming_complete_client_tool_call_does_not_require_tool_call_end` |
| Maximum iterations | No orphan calls; a final no-tool response or deterministic fallback is returned. | `test_max_iterations_limit`, `test_max_iterations_no_orphaned_function_calls`, `test_max_iterations_makes_final_toolchoice_none_call`, `test_max_iterations_blank_final_fallback_synthesizes_message`, streaming equivalents |
| Maximum function calls | Parallel overshoot is bounded after the batch; every executed result group counts even without a `function_result`; blank final responses get fallback content. | `test_max_function_calls_limits_parallel_invocations`, `test_max_function_calls_single_calls_per_iteration`, `test_user_input_request_multiple_contents_propagate`, `test_approval_resume_user_input_counts_toward_function_call_budget`, `test_max_function_calls_blank_final_fallback_synthesizes_message`, streaming equivalent |
| Provider tool content after an active limit | Locally actionable calls and local approval requests returned despite `tool_choice="none"` are removed in both response modes. Provider-executed informational call/result pairs, hosted approval requests, and metadata-only streaming updates remain visible; fallback text never replaces retained transcript content. | `test_function_invocation_limit_drops_unexecutable_tool_content`, `test_streaming_function_invocation_limit_drops_unexecutable_tool_content`, `test_streaming_function_invocation_limit_preserves_metadata_after_tool_content_is_dropped`, `test_function_invocation_limit_preserves_provider_executed_tool_pair`, `test_streaming_function_invocation_limit_preserves_provider_executed_tool_pair`, `test_function_invocation_limit_appends_fallback_after_provider_executed_tool_pair`, `test_streaming_function_invocation_limit_appends_fallback_after_provider_executed_tool_pair`, `test_function_invocation_limit_preserves_hosted_approval_request`, `test_streaming_function_invocation_limit_preserves_hosted_approval_request` |
| Conversation continuation | Conversation id updates between iterations and is cleared on stop where required. | `test_conversation_id_updated_in_options_between_tool_iterations`, `test_function_invocation_stop_clears_conversation_id_non_stream`, `test_streaming_function_invocation_stop_clears_conversation_id` |

### History and provider serialization

| Scenario | Required invariant | Primary regression test |
|---|---|---|
| Append-only history replay | Resolved approval wrappers do not reach a later model call; one call/result pair remains. | `packages/core/tests/core/test_harness_tool_approval.py::test_approval_resume_filters_resolved_control_items_from_file_history` |
| Typed pending history | An approval response remains replayable until its occurrence completes, without synthetic results. | `packages/core/tests/core/test_sessions.py::test_filter_approval_controls_keeps_response_without_terminal_result` |
| Terminal result history | Every matched function result consumes completed approval controls regardless of its text. | `packages/core/tests/core/test_sessions.py::test_filter_approval_controls_consumes_terminal_result_regardless_of_text`, `packages/ag-ui/tests/ag_ui/test_run.py::test_filter_local_approval_responses_for_provider_removes_only_completed_local_controls` |
| Pending hosted history replay | Stateless hosted approval requests remain replayable until a response is recorded, then both controls become inert. | `packages/openai/tests/openai/test_openai_chat_client.py::test_stateless_history_preserves_pending_hosted_approval_request_until_response` |
| Non-history provider plus session | Local history is still auto-injected for approval resume. | `packages/core/tests/core/test_agents.py::test_non_history_context_provider_still_injects_inmemory` |
| Hosted per-service-call persistence | A host-managed transcript remains available throughout a local function-call loop without being persisted into the framework session and replayed on the next hosted request. | `packages/foundry_hosting/tests/test_responses.py::TestAgentSessionPersistence::test_per_service_call_persistence_preserves_function_loop_history` |
| Invocations durable function history | A later invocation restores one completed call/result pair across host recreation without re-executing the tool; both streaming and non-streaming responses preserve the final text and model-bound conversation history. | `packages/foundry_hosting/tests/test_invocations.py::TestSessionLifecycle::test_function_history_is_restored_without_reexecuting_completed_tool` |
| Invalidated per-service-call persistence | An invalidated service response, its partial calls, and any nonexistent results are not success-persisted, and invalid content does not advance session continuation state. | `packages/core/tests/core/test_function_invocation_logic.py::test_invalidated_response_is_not_persisted` |
| Streaming message injection with per-service-call persistence | A streaming response rebuilt from updates mirrors the inner conversation id exactly, including clearing it, and keeps its internal marker, so the next iteration appends only the latest message rather than replaying the whole turn on top of provider-held history, and never persists a conversation id from an earlier injected service call. | `packages/core/tests/core/test_middleware_with_chat.py::TestChatMiddleware::test_message_injection_middleware_streaming_preserves_inner_continuation_state`, `test_message_injection_middleware_streaming_keeps_service_conversation_id_external`, `test_message_injection_middleware_streaming_clears_conversation_id_when_final_call_has_none`, `test_message_injection_middleware_conversation_id_matches_across_streaming_modes`, `packages/core/tests/core/test_harness_agent.py::test_streaming_harness_tool_call_does_not_duplicate_transcript` |
| Service-side approval decision | Stored hosted request is skipped; the current approved or rejected hosted response is sent, while local approval controls are omitted from provider input. | `packages/openai/tests/openai/test_openai_chat_client.py::test_prepare_messages_strips_approval_request_but_keeps_response_under_storage`, `test_prepare_messages_drops_local_approval_controls` |
| OpenAI approval serialization | Hosted approval id and decision serialize to `mcp_approval_response`; local approvals remain in-process. | `test_prepare_message_for_openai_with_function_approval_response`, `test_prepare_content_for_opentool_approval_response`, `test_function_approval_response_with_mcp_tool_call` |
| OpenAI end-to-end hosted approval | Hosted request parses, response sends, and continuation completes. | `test_end_to_end_mcp_approval_flow` |
| Stored function call/result | Service-side storage drops server-issued calls but keeps new outputs. | `test_prepare_options_with_conversation_id_strips_server_issued_items`, `test_prepare_messages_for_openai_full_conversation_with_reasoning` |
| Stateless reasoning replay | Replay reconstructs reasoning, call, and result together; missing required reasoning fails before the request. | `test_tool_loop_store_false_replays_encrypted_reasoning_group`, `test_stateless_request_rejects_non_replayable_reasoning_bound_mcp_output`, `test_prepare_messages_for_openai_full_conversation_with_reasoning` |
| Remote tool error serialization | Foundry Responses, Responses hosting, and AG-UI preserve channel-visible results without host-internal diagnostics. A2A and MCP hosting omit unsupported intermediate function results entirely, including their diagnostics. | `packages/foundry_hosting/tests/test_responses.py::TestNonStreaming::test_function_result_omits_internal_exception`, `TestStreaming::test_function_result_omits_internal_exception`, `packages/hosting-responses/tests/hosting_responses/test_parsing.py::TestResponsesRunHelpers::test_responses_from_run_omits_internal_function_exception`, `test_responses_from_streaming_run_omits_internal_function_exception`, `packages/ag-ui/tests/ag_ui/test_run_common.py::TestEmitToolResult::test_tool_result_does_not_emit_internal_exception`, `packages/hosting-a2a/tests/hosting_a2a/test_conversion.py::test_a2a_from_run_omits_unsupported_content`, `packages/hosting-mcp/tests/hosting_mcp/test_conversion.py::test_mcp_from_run_omits_content_not_supported_in_tool_results` |
| Foundry encrypted reasoning opt-in | Foundry clients omit `reasoning.encrypted_content` by default and preserve an explicit caller opt-in. | `packages/foundry/tests/foundry/test_foundry_chat_client.py::test_get_response_does_not_request_encrypted_reasoning_by_default`, `test_get_response_preserves_explicit_encrypted_reasoning_opt_in`, `packages/foundry/tests/foundry/test_foundry_agent.py::test_foundry_agent_basic_call_does_not_request_unsupported_encrypted_reasoning`, `test_foundry_agent_preserves_caller_requested_encrypted_reasoning`, `packages/foundry_hosting/tests/test_responses_int.py::TestReasoningHostedMcpReplay::test_second_turn_replays_mcp_call_with_encrypted_reasoning` |
| Opaque reasoning signature replay | Provider-specific opaque reasoning metadata is captured and restored on reconstructed calls. | `packages/gemini/tests/test_gemini_client.py::test_function_call_part_captures_thought_signature_as_reasoning_content`, `test_reconstructed_function_call_replays_thought_signature_from_reasoning_content` |
| Chat Completions approval wrappers | Framework approval wrappers are not sent as chat messages. | `packages/openai/tests/openai/test_openai_chat_completion_client.py` approval serialization tests |
| DevUI conversation-bound approval ownership | A pending function approval is bound to the conversation that originated it. A response from another conversation is rejected without consuming the pending approval, and identical request IDs in different conversations remain independent. | `packages/devui/tests/devui/test_approval_validation.py::test_approval_request_must_be_bound_to_originating_conversation`, `test_same_approval_request_id_is_scoped_per_conversation` |
| AG-UI approval result event | Approved result emits once with content and persists in snapshot. | `packages/ag-ui/tests/ag_ui/test_approval_result_event.py::test_approved_call_emits_one_live_result_under_original_identity`, `packages/ag-ui/tests/ag_ui/test_endpoint.py::test_endpoint_agent_approval_resume_persists_replayable_tool_results`, `test_endpoint_agent_approval_replayed_resume_entry_reprojects_retained_result` |
| AG-UI rejection/mixed decision | Transport emits only the events defined for approved and rejected calls without duplicates. | `packages/ag-ui/tests/ag_ui/test_approval_result_event.py::test_rejected_call_does_not_execute_or_emit_live_result`, `test_mixed_batch_preserves_approved_result_identity_and_order`, `packages/ag-ui/tests/ag_ui/test_endpoint.py::test_endpoint_agent_approval_rejection_releases_already_approved_sibling` |
| AG-UI approval-time follow-up | The full grouped user-input pause remains in message history and emits no synthetic `TOOL_CALL_RESULT`. | `packages/ag-ui/tests/ag_ui/test_approval_result_event.py::test_approval_follow_up_group_remains_in_history_without_live_tool_result` |
| AG-UI approval execution failure | A grouped executor failure becomes one deterministic terminal error result for the approved call. | `packages/ag-ui/tests/ag_ui/test_approval_result_event.py::test_approval_execution_failure_emits_one_terminal_error_result` |
| AG-UI no-approval path | Ordinary tool results do not gain an extra approval result event. | `packages/ag-ui/tests/ag_ui/test_approval_result_event.py::test_no_approval_path_emits_no_approval_specific_duplicate_result` |
| AG-UI client-tool request isolation | Client tool declarations are validated before use and remain request-scoped; a rejected collision or earlier successful request cannot change a later request's server-tool execution. | `packages/ag-ui/tests/ag_ui/test_endpoint.py::test_endpoint_failed_client_tool_collision_does_not_affect_next_request`, `test_endpoint_client_tools_do_not_persist_into_next_request` |
| AG-UI `confirm_changes` snapshot | An accepted synthetic confirmation is replaced only when its original function call has a real result; rejection is cleaned explicitly, and missing accepted results remain inert. | `packages/ag-ui/tests/ag_ui/test_confirm_changes_snapshot.py` |
| AG-UI malformed `confirm_changes` metadata | Non-list tool-call metadata and malformed argument JSON are ignored without guessing a target call. | `test_confirm_changes_target_ignores_non_list_tool_calls`, `test_confirm_changes_target_rejects_malformed_arguments_json` |
| Compaction pair integrity | Adjacent and non-adjacent pairs, including assistant-embedded results and completed reused-id occurrences, remain atomic without pairing ambiguous or out-of-order ids. | `packages/core/tests/core/test_compaction.py::test_group_annotations_keep_tool_call_and_tool_result_atomic`, `test_group_annotations_include_reasoning_in_tool_call_group`, `test_group_annotations_pair_nonadjacent_function_result_by_call_id`, `test_group_annotations_pair_multiple_nonadjacent_results_with_declaration`, `test_group_annotations_pair_completed_reused_call_id_occurrences`, `test_group_annotations_close_assistant_embedded_result_before_reused_call_id`, `test_sliding_window_does_not_retain_orphan_result_after_assistant_embedded_result`, `test_sliding_window_keeps_reused_call_id_occurrences_atomic`, `test_group_annotations_do_not_pair_ambiguous_duplicate_call_ids` |

## Required coverage gaps

These scenarios are required but are not fully covered by merged tests on `main`:

| Gap | Tracking |
|---|---|
| Service-owned `previous_response_id` continuation cannot execute a terminal approval again on a later turn. | #6851 |

Do not mark these rows covered by nearby tests; each needs a dedicated regression at the owning layer.

## Minimum validation commands

Run from `python/` for any core function-loop change:

```bash
uv run poe test -P core
uv run poe syntax -P core
uv run poe pyright -P core
uv run poe test-typing -P core
```

Also run every affected package. Common approval-loop changes require:

```bash
uv run poe test -P openai
uv run poe syntax -P openai
uv run poe pyright -P openai
uv run poe test-typing -P openai
uv run poe test -P ag-ui
uv run poe test -P declarative
uv run --directory packages/foundry_hosting poe test
```

Run focused regression files first while iterating, but do not substitute them for the full package commands above.

## Review checklist

Before accepting an update, reviewers must confirm:

- the changed behavior is represented in this specification;
- the matrix names a regression test for every affected scenario;
- approved tools cannot execute twice;
- rejected tools cannot execute;
- no call or result becomes orphaned or duplicated;
- call/result matching does not assume `call_id` is globally unique forever;
- reasoning content or opaque signatures remain in the same logical group as the paired call/result, or replay fails
  explicitly before sending a lossy provider request;
- caller messages and previous responses remain immutable;
- streaming updates and final response agree with non-streaming output;
- history replay does not reintroduce approval authority;
- full package, syntax, source typing, and test typing checks were run.

## Related issues

- #7241 — approval-resolution result streaming
- #7522 — first-class fatal signal (`MiddlewareFailure`) for function middleware
- #7267 / #7271 and #7304 — replayed calls and reused ids
- #7043 — provider-injected approval execution
- #6828 — AG-UI `confirm_changes` snapshot correlation
- #7212 — non-adjacent and reused-id compaction integrity
- #7125 — service-side approval response serialization
- #7045 — post-limit tool-content transcript integrity
- #6973 — declaration-only streaming metadata and argument integrity
- #6851 — duplicate side effects after approval continuation
- #7383 — bind approval responses to framework-issued requests after this foundation merges
- #6963 / #7095 — opaque reasoning-signature replay
- #6074 / #7233 — reasoning-paired tool-call replay
- #6450 / #6794 — provider message and tool-result serialization
- #8099 — in-run compaction summaries in the returned transcript
