# Based on https://github.com/anthropics/skills
"""
Skill Packager - Creates a distributable .skill file of a skill folder

Usage:
    python package_skill.py <path/to/skill-folder> [output-directory]

Example:
    python package_skill.py skills/public/my-skill
    python package_skill.py skills/public/my-skill ./dist
"""

import sys
import zipfile
from pathlib import Path

# Files and directories to exclude from the packaged skill
EXCLUDED_PATTERNS = {
    '.DS_Store',
    '.git',
    '.gitignore',
    '.gitattributes',
    '__pycache__',
    '.pyc',
    '.pyo',
    '.pyd',
    '.so',
    '.egg-info',
    '.eggs',
    '.pytest_cache',
    '.mypy_cache',
    '.ruff_cache',
    '.coverage',
    '.env',
    '.venv',
    'venv',
    '.idea',
    '.vscode',
    'node_modules',
    '*.log',
    '.tox',
    'dist',
    'build',
}


def _should_exclude(file_path: Path) -> bool:
    r"""Check if a file should be excluded from packaging.

    Args:
        file_path: Path to check

    Returns:
        True if the file should be excluded, False otherwise
    """
    # Check each part of the path
    for part in file_path.parts:
        # Check exact matches
        if part in EXCLUDED_PATTERNS:
            return True
        # Check suffix matches (e.g., .pyc files)
        for pattern in EXCLUDED_PATTERNS:
            if pattern.startswith('.') and part.endswith(pattern):
                return True
            if pattern.startswith('*') and part.endswith(pattern[1:]):
                return True
    return False


# Import from same directory - add parent to path for module resolution
_script_dir = Path(__file__).parent.resolve()
if str(_script_dir) not in sys.path:
    sys.path.insert(0, str(_script_dir))

from quick_validate import validate_skill  # noqa: E402


def package_skill(skill_path, output_dir=None):
    r"""Package a skill folder into a .skill file.

    Args:
        skill_path: Path to the skill folder
        output_dir: Optional output directory for the .skill file (defaults to
            current directory)

    Returns:
        Path to the created .skill file, or None if error
    """
    skill_path = Path(skill_path).resolve()

    # Validate skill folder exists
    if not skill_path.exists():
        print(f"❌ Error: Skill folder not found: {skill_path}")
        return None

    if not skill_path.is_dir():
        print(f"❌ Error: Path is not a directory: {skill_path}")
        return None

    # Validate SKILL.md exists
    skill_md = skill_path / "SKILL.md"
    if not skill_md.exists():
        print(f"❌ Error: SKILL.md not found in {skill_path}")
        return None

    # Run validation before packaging
    print("🔍 Validating skill...")
    valid, message = validate_skill(skill_path)
    if not valid:
        print(f"❌ Validation failed: {message}")
        print("   Please fix the validation errors before packaging.")
        return None
    print(f"✅ {message}\n")

    # Determine output location
    skill_name = skill_path.name
    if output_dir:
        output_path = Path(output_dir).resolve()
        output_path.mkdir(parents=True, exist_ok=True)
    else:
        output_path = Path.cwd()

    skill_filename = output_path / f"{skill_name}.skill"

    # Create the .skill file (zip format)
    try:
        with zipfile.ZipFile(
            skill_filename, 'w', zipfile.ZIP_DEFLATED
        ) as zipf:
            # Walk through the skill directory
            for file_path in skill_path.rglob('*'):
                if file_path.is_file():
                    # Skip excluded files
                    rel_path = file_path.relative_to(skill_path)
                    if _should_exclude(rel_path):
                        print(f"  Skipped: {rel_path}")
                        continue
                    # Calculate the relative path within the zip
                    arcname = file_path.relative_to(skill_path.parent)
                    zipf.write(file_path, arcname)
                    print(f"  Added: {arcname}")

        print(f"\n✅ Successfully packaged skill to: {skill_filename}")
        return skill_filename

    except Exception as e:
        print(f"❌ Error creating .skill file: {e}")
        return None


def main():
    if len(sys.argv) < 2:
        print(
            "Usage: python package_skill.py "
            "<path/to/skill-folder> [output-directory]"
        )
        print("\nExample:")
        print("  python package_skill.py skills/public/my-skill")
        print("  python package_skill.py skills/public/my-skill ./dist")
        sys.exit(1)

    skill_path = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None

    print(f"📦 Packaging skill: {skill_path}")
    if output_dir:
        print(f"   Output directory: {output_dir}")
    print()

    result = package_skill(skill_path, output_dir)

    if result:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
