# Changelog

## [2.11.0](https://github.com/google/adk-python/compare/v2.10.0...v2.11.0) (2026-10-01)


### Highlights

This release adds graceful cancellation and tool confirmation to workflows, a tool for consulting another model mid-task, and a built-in SQLite memory service.

* **Execution cancellation**: Pass an `abort_signal` to `Runner`, `Workflow`, and nodes to stop a run gracefully; `/run_sse` now cancels the run when the client disconnects. See the [unit guide](https://github.com/google/adk-python/blob/main/docs/guides/runners/runner/abort.md) for more details. ([ef5bbcf](https://github.com/google/adk-python/commit/ef5bbcfe51670bd211645a043914c162e7c1cd60), [3d73603](https://github.com/google/adk-python/commit/3d73603deb180a6518982b2b60f036c764f0cf7e))
* **Tool confirmation in workflows**: Tool nodes now pause for user approval via `RequestInput`, the same way an `LlmAgent` does, instead of passing an error downstream. ([ce132b9](https://github.com/google/adk-python/commit/ce132b92d471b8df903524593d863171b000a764))
* **ModelConsultTool**: Let an agent consult another model mid-task, capped by per-turn and per-session budgets. See the [unit guide](https://github.com/google/adk-python/blob/main/docs/guides/tools/model_consult/model_consult_tool/index.md) for more details. ([84cc99a](https://github.com/google/adk-python/commit/84cc99abd53010817a85b51fdcdc5d4f48366769))
* **SQLite memory service**: Keep agent memory in a local SQLite database, selected with a `sqlite://` memory service URI. ([9625b06](https://github.com/google/adk-python/commit/9625b06c9a1be6b9ecd85225657690ae5c0e9d3e))
* **MCP SDK 2.x**: Connect to MCP servers over the modern protocol through a new opt-in path. ([e738c26](https://github.com/google/adk-python/commit/e738c26fe5abcecffe2fbeba31f8d837086aad8a))

<details>
<summary>All changes</summary>

### Features

* add a sample preloading memory profiles into the instruction ([fdf1b7f](https://github.com/google/adk-python/commit/fdf1b7fbac216b98181cbfa83609f186f3cde2d0))
* add avatar configuration to server commands ([e4c0d94](https://github.com/google/adk-python/commit/e4c0d946f6d602b0ac23804328473b8d9e597b3e)), closes [#5435](https://github.com/google/adk-python/issues/5435)
* add max llm calls to server commands ([14f4154](https://github.com/google/adk-python/commit/14f4154893e15f293cc09a8ea2cd824a17b04ed8)), closes [#5434](https://github.com/google/adk-python/issues/5434)
* add optional abort_signal support to Runner, Workflow, and Nodes ([ef5bbcf](https://github.com/google/adk-python/commit/ef5bbcfe51670bd211645a043914c162e7c1cd60)), closes [#4796](https://github.com/google/adk-python/issues/4796)
* add pagination to list_accessible_data_agents in data_agent toolset ([46d5a2d](https://github.com/google/adk-python/commit/46d5a2d37d13303bd8ede3ee4558b850a4b3409f))
* add sqlite memory service ([9625b06](https://github.com/google/adk-python/commit/9625b06c9a1be6b9ecd85225657690ae5c0e9d3e))
* add the model consult session context handover layer ([b2da4c6](https://github.com/google/adk-python/commit/b2da4c6030dcd4b4f156743201a49f01bd4ec61a))
* **cli:** wire abort_signal to /run_sse on client disconnect ([3d73603](https://github.com/google/adk-python/commit/3d73603deb180a6518982b2b60f036c764f0cf7e))
* default Vertex project from GCP metadata ([8d8bbd2](https://github.com/google/adk-python/commit/8d8bbd286ffa6f1d00753f40dbba8c928aacce19))
* **events:** add internal metadata for ADK events ([8e29f16](https://github.com/google/adk-python/commit/8e29f16645e0607d2942bbdfe2010f7d7bacd7c1))
* honor tool_thread_pool_config for sync tools outside live mode ([c50ade3](https://github.com/google/adk-python/commit/c50ade39c88f391032887bcd1ba5e9299697d8c8))
* let BigQuery tools run where CMEK is required ([4d06641](https://github.com/google/adk-python/commit/4d06641e7dff5f2f2fa77feea24f68885110cf6d)), closes [#3931](https://github.com/google/adk-python/issues/3931)
* **live:** default to a pre-built avatar for VIDEO live sessions ([d5c9b11](https://github.com/google/adk-python/commit/d5c9b11b6440bbc66e0482c3c88cb28324a8544e))
* mark spans whose response came from a callback ([9633ab9](https://github.com/google/adk-python/commit/9633ab9f8227ebeba18b5ceca12e58377ab8ab4a))
* **mcp:** add an opt-in modern-protocol connect path for MCP SDK 2.x ([e738c26](https://github.com/google/adk-python/commit/e738c26fe5abcecffe2fbeba31f8d837086aad8a))
* **plugins:** add optional ToolCallIntegrityPlugin ([b7efc4e](https://github.com/google/adk-python/commit/b7efc4edb4deee133f13c7358b5164e8ac23a67d))
* propagate grounding metadata from MCP _meta ([0960104](https://github.com/google/adk-python/commit/09601045f4daced76b00f92c641fb1899ae3fa53)), closes [#6081](https://github.com/google/adk-python/issues/6081)
* skip __init__.py for config-based adk create ([d594b69](https://github.com/google/adk-python/commit/d594b693053fb29c3b30815270a31cd17990eab2)), closes [#6753](https://github.com/google/adk-python/issues/6753)
* synthesize abort event and function response on cancellation ([da65851](https://github.com/google/adk-python/commit/da65851a9e25005480db8164f8f0fff92ba31922))
* **telemetry:** move skill telemetry span attributes out of experimental ([e0f4c97](https://github.com/google/adk-python/commit/e0f4c979e119ee31f58882d4823cdb3bcd568b1e))
* **tools:** add ModelConsultTool with turn and session budgets ([84cc99a](https://github.com/google/adk-python/commit/84cc99abd53010817a85b51fdcdc5d4f48366769))
* **tools:** invoke advisor models without tools for model_consult ([28c47b5](https://github.com/google/adk-python/commit/28c47b550d29746ce4f4b38a30617e0f6e14c1eb))
* **workflow:** pause tool nodes for tool confirmation via RequestInput ([ce132b9](https://github.com/google/adk-python/commit/ce132b92d471b8df903524593d863171b000a764))
* **workflow:** propagate skip_summarization from node tools to tool response ([5a0421c](https://github.com/google/adk-python/commit/5a0421cbc58ae7b9e00ae4cd41f124863b0cbb70))
* **workflow:** run plugin tool callbacks around ToolNode calls ([cfeece9](https://github.com/google/adk-python/commit/cfeece9efbb93a6ad3efb7baf7e9bf9061c83e69))


### Bug Fixes

* accept a client factory written against either httpx major ([438c3eb](https://github.com/google/adk-python/commit/438c3eb65564d8e1f14896be37886a2c4905b14a))
* accept dotted registry ids in GCPSkillRegistry ([cbbdec3](https://github.com/google/adk-python/commit/cbbdec3f79b2ae830cc8d34de83d2cc18e128222)), closes [#7136](https://github.com/google/adk-python/issues/7136)
* **antigravity:** extract real execution output for built-in tool steps ([3fd932d](https://github.com/google/adk-python/commit/3fd932d525789c0ba616ac762897930392033e45))
* **artifacts:** return None for negative versions in InMemoryArtifactService ([6193957](https://github.com/google/adk-python/commit/6193957a53d58b7dc14942c09ac53b71a4cbc21f))
* cancel the in-flight tool call when the caller is cancelled ([f0dd560](https://github.com/google/adk-python/commit/f0dd560a6db286f9aa9c903a19b63278023c6716))
* classify plugin output before persisting events ([044a1ec](https://github.com/google/adk-python/commit/044a1ec3f434cf2e3f7acfdbd52305b60d16f6e5)), closes [#7184](https://github.com/google/adk-python/issues/7184)
* detect a dead MCP session whose transport sits behind a dispatcher ([8632980](https://github.com/google/adk-python/commit/86329806d1eb5c4cc767ab291730ccdf338d5ae5))
* drop stale replies to superseded tool updates ([fdca5e7](https://github.com/google/adk-python/commit/fdca5e7b20db78347a19966354af4219c2bd012a))
* drop unpairable trailing FRs in rearrange ([643df96](https://github.com/google/adk-python/commit/643df966a0fa223454e34a4eee1eddd68931ffa3)), closes [#6751](https://github.com/google/adk-python/issues/6751)
* **eval:** skip content-less events when mapping Vertex multi-turn turns ([fd2ca87](https://github.com/google/adk-python/commit/fd2ca8773ed51ec13a96670fdeb11f333727217a))
* **flows:** detect thought-only and whitespace turns as empty content ([dea8110](https://github.com/google/adk-python/commit/dea81109d15066b89dd3447f7c20523cc06d5e6a))
* follow redirects when downloading skills in GcpSkillRegistry ([fd14aec](https://github.com/google/adk-python/commit/fd14aec26534adb9743e963f39af468f1f0c329f))
* install greenlet with the db extra and name it when missing ([ffc2494](https://github.com/google/adk-python/commit/ffc2494a656d4fdaaec1c930d1124bba339a3cfd))
* isolate and clean up single_turn LlmAgent node_input events ([6f30039](https://github.com/google/adk-python/commit/6f3003907564e93e625477f1856a483937aae3d6)), closes [#7227](https://github.com/google/adk-python/issues/7227)
* keep credential-request events out of the compaction prompt ([b562ef4](https://github.com/google/adk-python/commit/b562ef4de858adc81d62f1438771c77bb06ff8e0))
* keep default credentials out of pickled AgentRegistry toolsets ([345a1a8](https://github.com/google/adk-python/commit/345a1a83307b868aaf966ac02f1fbee9be46836e))
* keep identical streamed function calls that have no model-provided id ([46b22e4](https://github.com/google/adk-python/commit/46b22e4e8ac3cb800dd9d8e8b5c936c22c655a77))
* **live:** only cache audio blobs in the live input realtime cache ([b627a15](https://github.com/google/adk-python/commit/b627a15b6b3862a197815a123be6a1a702d33355))
* load validated MCP toolsets under adk web ([f44d512](https://github.com/google/adk-python/commit/f44d51244a59a6a05210d45d23e1f6e75148a7df)), closes [#6735](https://github.com/google/adk-python/issues/6735)
* look up padded session ids the same way create_session stores them ([eef75de](https://github.com/google/adk-python/commit/eef75de8db16f3aea98e7a99e068046b66822313)), closes [#6941](https://github.com/google/adk-python/issues/6941)
* make conformance runs report replay and recording failures ([5355c7c](https://github.com/google/adk-python/commit/5355c7c60684e38e9ea158e34a41974e525be90f))
* only apply --avatar_config to live sessions requesting video ([4d241bf](https://github.com/google/adk-python/commit/4d241bff1bdf63ddf5ef947a2aa5d145b008c013))
* persist sibling tool results before a tool confirmation request ([67d3e49](https://github.com/google/adk-python/commit/67d3e494b610c6962ca8290dcb66c9f6b8b08735)), closes [#6732](https://github.com/google/adk-python/issues/6732)
* **plugins:** let tools run as workflow nodes under ToolCallIntegrityPlugin ([b057697](https://github.com/google/adk-python/commit/b0576978ec1f341980abdf385cf47f8b22da4178))
* **plugins:** record content_formatter failure class in error_message ([e5a24b6](https://github.com/google/adk-python/commit/e5a24b6f168581a1904049a8896a6939cdb88e30))
* preserve single-turn structured output ([6b96ba1](https://github.com/google/adk-python/commit/6b96ba199b3e2684272fad870d9e0ab45b79ec33)), closes [#6089](https://github.com/google/adk-python/issues/6089)
* prevent improper merging of parallel streaming function calls ([cacf92a](https://github.com/google/adk-python/commit/cacf92a5f4b72bd49f552da584725e79a7e2153f))
* propagate url_prefix to FastAPI root_path ([2daa303](https://github.com/google/adk-python/commit/2daa303fe495a2e8048484bcd8bf748cec377524)), closes [#7070](https://github.com/google/adk-python/issues/7070)
* refresh the access token in the BigQuery MCP sample ([9a33588](https://github.com/google/adk-python/commit/9a33588b445be5f204983b2b2c929821b2c513ef)), closes [#7217](https://github.com/google/adk-python/issues/7217)
* reject RestApiTool path params with "." or ".." segments ([6f3aabe](https://github.com/google/adk-python/commit/6f3aabeef09bccb63db235f6496d4d4af218c3f9)), closes [#7065](https://github.com/google/adk-python/issues/7065)
* render Jinja2 instructions in a sandbox and expose a read-only state mapping ([0e19550](https://github.com/google/adk-python/commit/0e19550c53b8bddaf380b50849189a5201892191))
* replay a parallel tool call that never ran when a sibling answered ([7298e09](https://github.com/google/adk-python/commit/7298e09acb485c4b226ec552c899f661df64fe49)), closes [#7108](https://github.com/google/adk-python/issues/7108)
* report the events the SQLite migration actually migrated ([31e5358](https://github.com/google/adk-python/commit/31e5358c7742021b9bc72663ebeb68366f9edc08)), closes [#7298](https://github.com/google/adk-python/issues/7298)
* resolve Agent Registry MCP bindings for the deployed agent at runtime ([9115d61](https://github.com/google/adk-python/commit/9115d612ea0286f867273042d6f23f04f75540cc))
* resume a remote A2A agent when a human answers its relayed pause ([caf2356](https://github.com/google/adk-python/commit/caf235659a5e75e265882dfc617aeaff00000384)), closes [#6721](https://github.com/google/adk-python/issues/6721)
* run BigQuery tools off the event loop via BigQueryToolset async adapter ([497b65b](https://github.com/google/adk-python/commit/497b65b14b3337a0450e7452c215cf1204d3bb7b)), closes [#7160](https://github.com/google/adk-python/issues/7160)
* **runner:** collect and close toolsets from Workflow graph nodes in Runner.close() ([6fbb22b](https://github.com/google/adk-python/commit/6fbb22b14e80c8cb2733f83611094e52df847a98))
* **runners:** safely skip non-BaseNode instances in _collect_toolset ([018c41c](https://github.com/google/adk-python/commit/018c41c8dddac3fcd2b4ca53feec128498b3b823))
* serve the dev UI runtime config from the server instead of a file ([3722746](https://github.com/google/adk-python/commit/3722746568a33226d54ba51876801c5948479eb5))
* **sessions:** disable pool reset on return for StaticPool in DatabaseSessionService ([74bb82b](https://github.com/google/adk-python/commit/74bb82bc9989dc8213e15aedd7279a5b1a7549bd))
* **sessions:** let any colon-prefixed key bypass state_schema validation again ([6e1ec09](https://github.com/google/adk-python/commit/6e1ec0931ec7a7d37c402d69cfeae5883897396f))
* stamp Redis sessions with the event timestamp ([def458b](https://github.com/google/adk-python/commit/def458b609c2811d137b0332b2fc7b201dddd5c0)), closes [#7292](https://github.com/google/adk-python/issues/7292)
* stop live session teardown hanging and lazy-load the auth transport ([41bebdc](https://github.com/google/adk-python/commit/41bebdc0ad5bb53fd07827643a01c0a7591a2417))
* stop RemoteA2aAgent failing on a2a-sdk 0.3.4 to 0.3.10 ([5b079ee](https://github.com/google/adk-python/commit/5b079eedbfbbe44441a537741acc3477e6118b8d))
* stop update_time onupdate from overriding explicit writes ([aec7c0a](https://github.com/google/adk-python/commit/aec7c0ad09af620c837c4ba7bbb596219bf3cc07)), closes [#7276](https://github.com/google/adk-python/issues/7276)
* **tools:** apply the load_web_page SSRF checks on the proxy path ([d7a7c3c](https://github.com/google/adk-python/commit/d7a7c3c6881785420fc9a25374629b08c18aad25))
* **tools:** package model_consult advisor prompt as a single user content block ([ecb429c](https://github.com/google/adk-python/commit/ecb429c941d213a1a44f739bb2ec46a23973f307))
* **tools:** stop marking every NodeTool as long-running ([0478224](https://github.com/google/adk-python/commit/0478224ba50d4044325fbccb474aa6aaf46987d5))
* **tools:** surface NodeTool failures to on_tool_error and return dict validation errors ([b4c5272](https://github.com/google/adk-python/commit/b4c5272c53eb5401480ad7472535d1099ef4e9d7))
* treat inbound new_message in Runner.run_async as a user turn ([15ec279](https://github.com/google/adk-python/commit/15ec2791315db8d63a700c1ae2ad87a58b0bcaec))
* **workflow:** keep outputs of sibling nodes that finished in the same tick as a failing node ([2c759e9](https://github.com/google/adk-python/commit/2c759e9e6e0a12e74e2d114a962559e1152d9f26))
* **workflow:** run ToolNode tools with the node context so deltas are emitted ([cffc967](https://github.com/google/adk-python/commit/cffc9677dac4f00c55a38e4331318da2b1595c6c))


### Documentation

* add known issues for A2A workflow output schema and serialization ([f7967c3](https://github.com/google/adk-python/commit/f7967c35fecbd2080953d28d0f9f9a8d71674fc2))
* add unit guide for Node and `@node` ([3e59f4d](https://github.com/google/adk-python/commit/3e59f4dd18391cd9d56cc712c64ec030cba9fab7))
* document execution cancellation, node tool direct output, and span provenance ([76af4b0](https://github.com/google/adk-python/commit/76af4b08cbc81e46c933d1558305f7336d876cc0))
* explain local lockfile needed by tox in adk-setup skill ([96319fc](https://github.com/google/adk-python/commit/96319fc85d01c64137610de85250f950055e9747))
* explain why live audio is not flushed on generation_complete ([dcd5d76](https://github.com/google/adk-python/commit/dcd5d76036aa28048cf52c1fb902082290d20c90))
* fix to_a2a import so the task mode sample runs ([e6bdb4d](https://github.com/google/adk-python/commit/e6bdb4dab7a1657a871ef63292f9b76e26a95bd0))
* **runners:** add developer guide for execution cancellation ([4e48bb0](https://github.com/google/adk-python/commit/4e48bb07292ac80a0c897bf1311454750bda8097))
* **tools:** add ModelConsultTool developer guide and sample agent ([89ebdec](https://github.com/google/adk-python/commit/89ebdecf233b9d57fcd27cc4b003a9a62b107097))

</details>

## [2.10.0](https://github.com/google/adk-python/compare/v2.9.2...v2.10.0) (2026-09-24)


### Highlights

This release introduces advanced skill lifecycle management, expands database and model integration support, and brings richer efficiency metrics to agent evaluation.

* **Skills**: Control resource usage and tool persistence dynamically using new ephemeral lifecycles and active skill limits (experimental; enable with `ADK_ENABLE_SKILL_LIFECYCLE=1`). ([43b73e4](https://github.com/google/adk-python/commit/43b73e4fc0920c08693bcec3985c832c7d9870b0))
* **Database Integrations**: Perform high-performance vector and hybrid searches seamlessly within your agent flows with the new MongoDB toolset. ([0961ced](https://github.com/google/adk-python/commit/0961ced3e3dd92056ecf10c7b10aa736eead08f1))
* **Evaluation**: Optimize agent execution costs and latency with new evaluation metrics for tracking duration, token consumption, and model call counts. ([2d428ea](https://github.com/google/adk-python/commit/2d428ead3860fbc131de362b485eb15551373665))
* **Model Support**: Integrate OpenAI reasoning models more effectively with automated request parameter adaptation and precise reasoning token reporting. ([52a2f0f](https://github.com/google/adk-python/commit/52a2f0f09f2910043127042e6ba3dd805d5a1479))

#### Behavior changes

* **BigQuery protected write mode** now runs a non-SELECT statement only when the dry run places it in the session's anonymous dataset, so multi-statement scripts, `CALL`, `EXPORT DATA` and other statements the dry run gives no destination are rejected. ([8b883d0](https://github.com/google/adk-python/commit/8b883d07147f62f8e9979ec8e6b1205437d60f4f))
* **BigQuery protected mode** keeps its BigQuery session in process memory instead of session state, so its temporary tables do not survive a restart or carry over to another replica. ([094012b](https://github.com/google/adk-python/commit/094012b4509fc136083e6be95f273ad1163fbf2c))
* **`OpenAIResponsesLlm`** ignores `thinking_config` (`thinking_level` / `thinking_budget`) with a warning; use `OpenAIGenerateContentConfig.effort` instead. ([b3d1392](https://github.com/google/adk-python/commit/b3d1392a1a9caf382b9483c5fecd4b9140949abb))
* **`AgentEvaluator.evaluate` and `evaluate_eval_set`** raise `ValueError` when no eval cases are evaluated, instead of passing. ([9dbc2ae](https://github.com/google/adk-python/commit/9dbc2aebd7a0ad88183d166c19398bbbab93d507))
* **Instruction templating** leaves `${var}` and backslash-escaped `\{var}` as written instead of filling them from state. ([0caecd2](https://github.com/google/adk-python/commit/0caecd236f95131da625a3bf1de282130f6aa437))
* **Legacy live-audio modules** under `google.adk.flows.llm_flows` (`audio_cache_manager`, `audio_transcriber`, `transcription_manager`) emit a `DeprecationWarning` on import; move to `google.adk.live`. Test suites run with `-W error` will fail on these imports. ([bf2bc56](https://github.com/google/adk-python/commit/bf2bc561ef9c2b9cfaec5bc6ca441b6c1d3b3496))

<details>
<summary>All changes</summary>

### Features

* add a duration efficiency metric to ADK eval ([49e7264](https://github.com/google/adk-python/commit/49e7264bf6a72a6b42813300a2192e0898ff5b23))
* add an EPHEMERAL skill lifecycle that lasts one turn (experimental, off by default; enable with `ADK_ENABLE_SKILL_LIFECYCLE=1`) ([f938abd](https://github.com/google/adk-python/commit/f938abd8beb213774eda069dd2a315fe998c399e))
* add an opt-in unload_skill tool to SkillToolset (experimental, off by default; enable with `ADK_ENABLE_SKILL_LIFECYCLE=1`) ([ce53a36](https://github.com/google/adk-python/commit/ce53a36c0a221542afbd22dc4f3d6f5e3c8fecd7))
* add dev-only deploy endpoints for Agent Runtime, Cloud Run, and GKE ([1235104](https://github.com/google/adk-python/commit/1235104b6598eb3a6b92abc5d07c52edb62dee5b))
* add informational efficiency metrics (tokens, calls) to ADK eval ([2d428ea](https://github.com/google/adk-python/commit/2d428ead3860fbc131de362b485eb15551373665))
* add MongoDB toolset with vector and hybrid search ([0961ced](https://github.com/google/adk-python/commit/0961ced3e3dd92056ecf10c7b10aa736eead08f1))
* add name-based request processor helpers to BaseLlmFlow ([fd335cd](https://github.com/google/adk-python/commit/fd335cda08be4764c2ef3570d172cf0fcd468ef7))
* add on_error handler to skill listing functions ([9b220e7](https://github.com/google/adk-python/commit/9b220e7546858fecfc1bb94430d8e2af9b50f78c))
* add optional context_builder to RemoteA2aAgent ([322e3bf](https://github.com/google/adk-python/commit/322e3bf0ae4896f44ce4589926c1daa930c781b5)), closes [#3301](https://github.com/google/adk-python/issues/3301)
* add programmatic skill activation APIs to SkillToolset ([a0f3955](https://github.com/google/adk-python/commit/a0f395570461f2eccfecb132c6c751064b1e6bbe))
* add skill lifecycle modes and an active-skill cap to SkillToolset (experimental, off by default; enable with `ADK_ENABLE_SKILL_LIFECYCLE=1`) ([43b73e4](https://github.com/google/adk-python/commit/43b73e4fc0920c08693bcec3985c832c7d9870b0))
* **bigquery:** add default_project_id and default_dataset_id to BigQueryToolConfig ([6f301fc](https://github.com/google/adk-python/commit/6f301fcc6b7a31d61c35d606e8a5968769ffd357))
* **cli:** add gemini-3.8-flash to the `adk create` model options ([6592ee5](https://github.com/google/adk-python/commit/6592ee5b5b11dbc6a8dfa33703cb4a682990af47))
* **cli:** auto-configure session and memory services on Agent Runtime ([fede561](https://github.com/google/adk-python/commit/fede5618df90c1d9ab340334519068916fa3af50))
* **context:** add abort signal primitives to InvocationContext and Context; the Runner and workflows do not act on an abort yet ([d99b23f](https://github.com/google/adk-python/commit/d99b23fbf1dc32383f88708f3b84453dde97897f))
* drop an unloaded skill's instructions from later requests (experimental, off by default; enable with `ADK_ENABLE_SKILL_LIFECYCLE=1`) ([accb906](https://github.com/google/adk-python/commit/accb906eac1534e4cc8ba66a7b2d5a389996522b))
* expose serving tier via `RunConfig.service_tier` ([3e3d1dc](https://github.com/google/adk-python/commit/3e3d1dce4d6015a1d88fedcd8e3cffb789037835))
* expose session options in api_server REST endpoint ([fa4719e](https://github.com/google/adk-python/commit/fa4719e78db01ec6333875dc26fd2bd88c786f6c)), closes [#6342](https://github.com/google/adk-python/issues/6342)
* **integrations:** add a google-adk[openai] extra ([9be86bf](https://github.com/google/adk-python/commit/9be86bf610390202ad233bfc34219862c1885410))
* **integrations:** move the OpenAI models to `google.adk.integrations.openai`; `google.adk.labs.openai` still re-exports them ([95c0591](https://github.com/google/adk-python/commit/95c0591031edfd7068b5c71d6ae61fd9a34f2809))
* let SkillToolset notice that a loaded skill has changed ([f848b7e](https://github.com/google/adk-python/commit/f848b7e3bd4943d245b324fd233483c9857804cf))
* **mcp:** identify ADK in the MCP clientInfo handshake ([5117f28](https://github.com/google/adk-python/commit/5117f286de5587af254d22830962108221e1c98a))
* **mcp:** identify ADK in the User-Agent of MCP HTTP requests ([061dcd6](https://github.com/google/adk-python/commit/061dcd64bcc6abba8586a71e5c868eaad51e6d4b))
* **openai:** adapt request params for reasoning models on both surfaces ([137eba8](https://github.com/google/adk-python/commit/137eba8431e4e66bc469ddf6c6b8f6c38b56cc52))
* **openai:** add api_key/base_url with per-request key resolution to OpenAILlm ([56aabce](https://github.com/google/adk-python/commit/56aabce2323cd132554471b403c11110c7f9daf3))
* **openai:** add OpenAIGenerateContentConfig and per-model reasoning effort ([bb9023d](https://github.com/google/adk-python/commit/bb9023d1fae8bf2d273f47281570a23732a7e128))
* **openai:** honor tool_config mode and all tool declarations in OpenAILlm ([ed758bb](https://github.com/google/adk-python/commit/ed758bbabf7a4ca76f13602e0e1cbb24c793abef))
* **openai:** report reasoning tokens on Chat Completions; add live tests ([52a2f0f](https://github.com/google/adk-python/commit/52a2f0f09f2910043127042e6ba3dd805d5a1479))
* **openai:** surface streaming usage and finish reason in OpenAILlm ([ed030cb](https://github.com/google/adk-python/commit/ed030cbf431ef6c12a2b3a75dcc7aff08378cb82))
* **openai:** use build_reasoning_effort for reasoning in OpenAIResponsesLlm ([b3d1392](https://github.com/google/adk-python/commit/b3d1392a1a9caf382b9483c5fecd4b9140949abb))
* send the deferred service tier on interactions API requests ([cc912d5](https://github.com/google/adk-python/commit/cc912d587464051f3a3f4197d58a14a5c42ddc83))
* **skills:** add SkillDiscoveryMode to control how the skill catalog is disclosed ([3d3c1d9](https://github.com/google/adk-python/commit/3d3c1d90c89128d721569f54115be2b1d0ac5a74)), closes [#7092](https://github.com/google/adk-python/issues/7092)
* stamp the Agent Registry URN as gen_ai.main_agent.id ([5c3f64e](https://github.com/google/adk-python/commit/5c3f64e08c21912194acf71d0992e59f897c3229))
* stream partial function-call arguments across model adapters ([f449780](https://github.com/google/adk-python/commit/f44978013378ecba9e3cfc0c955b7890ceb7951b))
* **telemetry:** allow per-feature enabling of experimental telemetry ([0add163](https://github.com/google/adk-python/commit/0add163161099f435ce32bf3ba35d4502c80efd7))
* **tools:** add `behavior` field to control Live non-blocking function calls ([6189b2e](https://github.com/google/adk-python/commit/6189b2e03ab7979950bca90755b0d628822e97d7))
* when using interactions api with deferred tier, wait on an interaction operation ([b011fb2](https://github.com/google/adk-python/commit/b011fb21bd50ac006273d71dba8c32f1123a5519))
* **workflow:** filter rewound invocations during workflow rehydration ([ab4dba6](https://github.com/google/adk-python/commit/ab4dba6ef14c1deed57f9759a4cb6e089a94de67))
* **workflow:** let DEFAULT_ROUTE fan out to several nodes ([ffc191b](https://github.com/google/adk-python/commit/ffc191bbe57145da82c0776e56c5d5c410c442ec))
* **workflow:** unwrap NodeTool in build_node and bind state in _ToolNode ([5c59a73](https://github.com/google/adk-python/commit/5c59a730974546c7f56e72c2e06a91ec114cda92))


### Bug Fixes

* accept a client factory written against either httpx major ([b726964](https://github.com/google/adk-python/commit/b7269649074507e9c8640135472cc1c9e5c09f57))
* **agents:** accept the default hint in request_confirmation ([768969d](https://github.com/google/adk-python/commit/768969db14c0764dd72b04107d4fa25811772791))
* **agents:** allow descriptionless BaseNode in LlmAgent tools ([6373f23](https://github.com/google/adk-python/commit/6373f232c79136b80fe196bde1b351ddde13f9f4))
* **agents:** trigger after_agent_callback on cancellation ([37aa730](https://github.com/google/adk-python/commit/37aa7308bbcfd41a2eebee73f51e6f40a5448e78))
* allow forwarding session ID as context_id for remote A2A agents ([e10a1be](https://github.com/google/adk-python/commit/e10a1becd3ab44654a57e45b3b288b810c5b5602))
* **auth:** keep the OAuth2 client secret out of session state ([9b9aac0](https://github.com/google/adk-python/commit/9b9aac038fcc8a2358331bc93d58dca4b85d31d2))
* **auth:** report an auth scheme that carries no OAuth2 flows ([b22cfc4](https://github.com/google/adk-python/commit/b22cfc43c2d2a8dfd5dc5666aa5afc5f9fde847a))
* **bigquery:** reject writes protected mode cannot place in the session dataset ([8b883d0](https://github.com/google/adk-python/commit/8b883d07147f62f8e9979ec8e6b1205437d60f4f))
* **bigtable:** release the per-call data client in execute_sql ([f39cbf5](https://github.com/google/adk-python/commit/f39cbf560d08f727de0693e4bb8860dcb96fecd2))
* bound artifact reference resolution depth in load_artifact ([87b9f25](https://github.com/google/adk-python/commit/87b9f25b372733d8899a47817c7f3b72cbad5959))
* build the Gemini API clients once per event loop ([8164341](https://github.com/google/adk-python/commit/8164341ec5dc7d21d405e553c51cb0bd41cc7afa))
* **cli:** omit http_options from the generated recordings file ([09326ca](https://github.com/google/adk-python/commit/09326ca18a8d545f48199544078a5b190839697c))
* **cli:** reject multi-line env values when generating the Dockerfile ([8192d1b](https://github.com/google/adk-python/commit/8192d1bf75eadcf4e53c15abb948f2e3fcf7705c))
* **cli:** use exec-form RUN/CMD in generated Dockerfiles and validate app names ([9327437](https://github.com/google/adk-python/commit/93274370ffc60feb500f44665bb52a8c54e515b7))
* **cli:** validate the test name on every dev server test endpoint ([4c2bafb](https://github.com/google/adk-python/commit/4c2bafb7ed197046e44a2fa3a57f636c4f79054b))
* coerce integral floats inside list[int] tool parameters ([b1cba29](https://github.com/google/adk-python/commit/b1cba290b2505e5e1c324fc34e4cf53605ccefa7))
* **compaction:** stop backwards prompt token scan at compaction boundary ([4d9abb5](https://github.com/google/adk-python/commit/4d9abb5840a2f4d4135850cc4f9ee0c1ccf9fd24))
* complete an A2A task whose run ends without a status message ([9750c4c](https://github.com/google/adk-python/commit/9750c4c4a8658b6d92ccecfe7feecf9967866f8c))
* confine agent builder file globs to the configured directory ([896a29a](https://github.com/google/adk-python/commit/896a29a94abfae5387ca4e6f92eb07747f190d5e))
* **confirmation:** skip confirmation requests authored by other agents before resolving history ([e19ce05](https://github.com/google/adk-python/commit/e19ce0579b849a96df41fb27079d26548978970e))
* **core:** stop executing code found in the model's private reasoning ([a2a2f66](https://github.com/google/adk-python/commit/a2a2f6656aca4d7fe3606162e807462afa21e2ff))
* correct get_bigtable_data_client return annotation ([c673c59](https://github.com/google/adk-python/commit/c673c59c979822128ecdad8c63c378ffc1a9600e))
* do not match dollar-brace or escaped patterns in instructions ([0caecd2](https://github.com/google/adk-python/commit/0caecd236f95131da625a3bf1de282130f6aa437)), closes [#5706](https://github.com/google/adk-python/issues/5706)
* **eval:** ignore UI-only InvocationEvent fields on eval case save ([a4a50a4](https://github.com/google/adk-python/commit/a4a50a4d5bfe54e4ebe5173464b74bb4c2c0c055))
* **eval:** pin the specific version for safety_v1 ([997f408](https://github.com/google/adk-python/commit/997f40899042e0f00be83929bcf094fddded9355))
* exclude the local .adk folder from deployed agent images ([c409bd3](https://github.com/google/adk-python/commit/c409bd334b821c779fecb06cbdfcb4fa97a3b9f4))
* extract URL fragment key-value pairs as query params ([0cfe43b](https://github.com/google/adk-python/commit/0cfe43b657ead31fe463866f2a348b7d7ce38119))
* fence server-supplied tool description before reaching the model ([a519b6f](https://github.com/google/adk-python/commit/a519b6f6235146d5bc18f19582f8d4360b9adb64))
* **flows:** hold a tool call that requires confirmation in the framework ([1d0daeb](https://github.com/google/adk-python/commit/1d0daebaf7fbc286d3fad9b03ecf75efa9039d8d))
* **flows:** keep the streaming flags when after_model_callback replaces a response ([39e4538](https://github.com/google/adk-python/commit/39e4538578cc1c07be7bd201c3cda0e34040a271)), closes [#7035](https://github.com/google/adk-python/issues/7035)
* **flows:** only hold a tool call when its confirmation hook answers True ([659e28f](https://github.com/google/adk-python/commit/659e28f1a2cd9f9d9ffe2b662527623a2aa1bbc7))
* **flows:** prune orphaned function calls on interrupted turns ([54274cd](https://github.com/google/adk-python/commit/54274cdeba42a46e4346f48589c84fe2ebcc0da2))
* **flows:** release a tool thread pool when its event loop closes ([7ae1c9b](https://github.com/google/adk-python/commit/7ae1c9b026c84bf8a65921003f71b0f30c8e3166))
* forward tool output schema on the LiteLLM path ([fca7b88](https://github.com/google/adk-python/commit/fca7b887fba94e3b328025cd62e6a77830e0edc5)), closes [#6784](https://github.com/google/adk-python/issues/6784)
* give each LocalEvalService its own default UserSimulatorProvider ([55d47ae](https://github.com/google/adk-python/commit/55d47aea2ef7a495cb6de2358cd0df9f30c83553))
* hide run_skill_script when no skill has a script ([d8d9715](https://github.com/google/adk-python/commit/d8d97159c9fa02a3b3bbce9326674964b8b61ed0)), closes [#6281](https://github.com/google/adk-python/issues/6281)
* honor capability for schema and tools ([e37af14](https://github.com/google/adk-python/commit/e37af1435a7d4424c3d29c6cfd543c46e57a106e)), closes [#6954](https://github.com/google/adk-python/issues/6954)
* instruct models to format code for non-builtin sandbox executors ([8aafa4e](https://github.com/google/adk-python/commit/8aafa4eee65f50337b4f1234b3c7dd7bf51c2242))
* **integrations:** hold sandbox and BigQuery session bindings in process ([094012b](https://github.com/google/adk-python/commit/094012b4509fc136083e6be95f273ad1163fbf2c))
* join streamed reasoning into one thought part per block ([fed0e88](https://github.com/google/adk-python/commit/fed0e88b79eba197630bd0febec05de3bb557f13)), closes [#6895](https://github.com/google/adk-python/issues/6895)
* keep the latest write when parallel tool calls update a state list ([d42a3be](https://github.com/google/adk-python/commit/d42a3bebb847c8b9df3ee02cc011fa7260c8bc89))
* **litellm:** report malformed tool-call arguments instead of raising ([75d84b1](https://github.com/google/adk-python/commit/75d84b11c660e15e5065c43285ca00f73f25a1f7)), closes [#5896](https://github.com/google/adk-python/issues/5896) [#6716](https://github.com/google/adk-python/issues/6716)
* **live:** enqueue background function response events ([7807005](https://github.com/google/adk-python/commit/7807005e8df76644a378bc4e9fa115ecd47421b1))
* **live:** screen live content that does not complete the turn ([58b4fab](https://github.com/google/adk-python/commit/58b4fab2e7821102d203ddf890b10f0c19540fce))
* make shell JSON envelope parsing robust to other stdout garbage ([b07ec93](https://github.com/google/adk-python/commit/b07ec93f8be250d9c28a1633106c76608e18c08a))
* mark a workflow's span failed when one of its nodes failed ([dfc4b58](https://github.com/google/adk-python/commit/dfc4b5803f49033227b49e7f53d291299d304148))
* match a Latin word embedded in unspaced-script text ([13ecc31](https://github.com/google/adk-python/commit/13ecc31aca16ff8d862abcba9ba7974f5fb796fc))
* match tool response by name instead of assuming first part ([f199858](https://github.com/google/adk-python/commit/f199858e0f62c9e2e2aba81410f39c07eccf8619)), closes [#6603](https://github.com/google/adk-python/issues/6603)
* **mcp:** only attach application default credentials over https ([5a018c9](https://github.com/google/adk-python/commit/5a018c9af6a5ec47ef67e95481cd800b36ac1215))
* **mcp:** rebuild a session the server reports it no longer holds ([86ea33d](https://github.com/google/adk-python/commit/86ea33d7e9f0ca0623351ffa7da76d16913b67fa)), closes [#7060](https://github.com/google/adk-python/issues/7060)
* **mcp:** report an api key auth scheme that declares no key location ([d7370e1](https://github.com/google/adk-python/commit/d7370e11c47e156435eeb76ba737800489a94a5b))
* **mcp:** widen MCP bound to admit MCP 2.x ([d64dcfa](https://github.com/google/adk-python/commit/d64dcfaaca7601fe705605f6a8bde7ddb110d701))
* measure the compaction token threshold against the agent's own prompt ([8ccea93](https://github.com/google/adk-python/commit/8ccea93fdaec4faf197dff986b7a12b686dfceca))
* **models:** keep the keys beside "result" in a Claude tool result ([ffb5363](https://github.com/google/adk-python/commit/ffb5363b7e69d3c232e746fdbca20da4db61da23)), closes [#7073](https://github.com/google/adk-python/issues/7073)
* **models:** say how to reach a third-party model when a bare name misses ([87ccdc7](https://github.com/google/adk-python/commit/87ccdc796c8a231ae305fa59556263e8e613d0b6))
* only load artifacts listed for the current session ([cb7c469](https://github.com/google/adk-python/commit/cb7c4691ad23e02670052c54d5c63487f21b4194))
* **openai:** robustly parse Chat Completions responses (finish_reason, usage, choices) ([f28d28a](https://github.com/google/adk-python/commit/f28d28a37cce6e122f436d02edb3b5ee3301c830))
* **openai:** serialize non-string system_instruction ([783463d](https://github.com/google/adk-python/commit/783463dab1ff62b4a804f2eab3ae4c5e3ca9b140))
* **openapi:** handle HTTP 401 in RestApiTool and recover stale OAuth2 credentials ([9511479](https://github.com/google/adk-python/commit/9511479d6b165d012f4d3a539d6e25e061664b69))
* persist sandbox session state and add warning for static sandbox in AgentEngineSandboxCodeExecutor ([73ab76d](https://github.com/google/adk-python/commit/73ab76da459fcf34d6252013b6bd7f5be18a60ce))
* **plugins:** verify BigQuery table readiness once, not on every restart ([a9cf81f](https://github.com/google/adk-python/commit/a9cf81fe2165a7e5727a6867f3546d8217baeb2a)), closes [#7017](https://github.com/google/adk-python/issues/7017)
* preserve Annotated metadata in tool declarations and arg conversion ([2ecb3fb](https://github.com/google/adk-python/commit/2ecb3fb02467bcdcdf1e61c5f64d114261ac5f2c))
* preserve empty text and bytes in memory ([df55309](https://github.com/google/adk-python/commit/df55309744107fc13126179e14298438a541e3f7))
* preserve eval case order when updating ([a6c6623](https://github.com/google/adk-python/commit/a6c6623455e6064f1934bdff260abdc3f6eb5025)), closes [#7220](https://github.com/google/adk-python/issues/7220)
* preserve file artifact creation timestamps ([e93ff5b](https://github.com/google/adk-python/commit/e93ff5b01067ef1401796e6982de3b3740d18170))
* prevent cubic backtracking in _strip_json_code_fence ([3a06a86](https://github.com/google/adk-python/commit/3a06a8621d04fd87aad9f6b078c999c78a96fb66))
* prevent filenames from colliding with version storage ([26e8af2](https://github.com/google/adk-python/commit/26e8af2c0c1fc21c6b4bf08b34d651ece3ce9103))
* raise a clear error when conformance replay recordings are missing ([7a1b49f](https://github.com/google/adk-python/commit/7a1b49fd20ab2dd5c352ce00202dd77c028422eb)), closes [#7128](https://github.com/google/adk-python/issues/7128)
* raise clear ImportError when VertexAiSearchTool bypass needs gcp ([4e73b7d](https://github.com/google/adk-python/commit/4e73b7db48674cbcd9281e13fdb4ca7935cf058b))
* raise InvocationNotFoundError instead of bare ValueError on rewind ([fc16a78](https://github.com/google/adk-python/commit/fc16a78a2bba393f35c9b44025cf45548cdda3f9))
* raise when evaluate or evaluate_eval_set evaluates zero cases ([9dbc2ae](https://github.com/google/adk-python/commit/9dbc2aebd7a0ad88183d166c19398bbbab93d507)), closes [#6951](https://github.com/google/adk-python/issues/6951)
* redact signed URIs and HTTP options from errors and logs ([f425287](https://github.com/google/adk-python/commit/f42528732e73b5f13dc633e1558f0313099b0db9))
* reject num_samples=0 in JudgeModelOptions at construction time ([85e0868](https://github.com/google/adk-python/commit/85e08686f8310e00b2b031a042db86405920b4b2))
* reject parallelism < 1 in LocalEvalService instead of hanging ([9beb524](https://github.com/google/adk-python/commit/9beb52416d6b0c377e58e7e84bdfcd7e88eea415))
* reject reserved path segments with slashes in validate_path_segment ([5e29872](https://github.com/google/adk-python/commit/5e29872b1c29850929e126191af1bd2d8a7f94d1)), closes [#6973](https://github.com/google/adk-python/issues/6973)
* reject the reserved segment 'user' as a session_id ([b8de426](https://github.com/google/adk-python/commit/b8de4266d90fb9a6500079d062561cfdd4cf21d6)), closes [#7063](https://github.com/google/adk-python/issues/7063)
* report an A2A stream that ends before the remote task finishes ([e29ee23](https://github.com/google/adk-python/commit/e29ee231e02ec9e82dc91ee008c8a2798d021f3d)), closes [#6585](https://github.com/google/adk-python/issues/6585)
* report the event fields a session backend cannot store ([3e1ae9f](https://github.com/google/adk-python/commit/3e1ae9faed934532b9f5015578d1b9731817ce60))
* require agent authorship before resume-dispatching a function call ([2c61b84](https://github.com/google/adk-python/commit/2c61b8444a600c8d42ffaad36bdc31dfc31d13ed))
* resolve agent transfers from the caller's declared targets ([1538efe](https://github.com/google/adk-python/commit/1538efe880e88ea264f0b5a9c0f7b799bfd9d131))
* resolve deepcopy recursion in VertexAiCodeExecutor ([b3fe92b](https://github.com/google/adk-python/commit/b3fe92b38aa281efd083068ec5fc042f1011f1a2)), closes [#1762](https://github.com/google/adk-python/issues/1762)
* restore oldest-first Redis session lists ([6863842](https://github.com/google/adk-python/commit/686384246751dfa4703657f4730f02194fc028a9))
* run on_event callbacks for before_run early exits ([63e918a](https://github.com/google/adk-python/commit/63e918a31304802b3d466c6841f0aef67241c45a)), closes [#7007](https://github.com/google/adk-python/issues/7007)
* **runners:** ensure after_run plugin callback executes on early generator exit ([ba89707](https://github.com/google/adk-python/commit/ba89707af49279b14e36315b4565c70149846f9e))
* **runners:** keep the caller's OpenTelemetry trace in sync Runner.run ([1760b06](https://github.com/google/adk-python/commit/1760b06a903de4bb93cedadd15209a7911e43b2a))
* **sessions:** avoid redundant temp state processing in append_event and exclude temp keys from rewind delta ([52b247e](https://github.com/google/adk-python/commit/52b247eccabb8b2f16bbc795fe8a35670aa2f371))
* **sessions:** avoid runtime index drop and guard concurrent index creation ([cd6dee0](https://github.com/google/adk-python/commit/cd6dee0503f5d5495125e5b023e64230f8da4b7b))
* **sessions:** disable pool reset on return for StaticPool in DatabaseSessionService ([8ff50af](https://github.com/google/adk-python/commit/8ff50af7f0135b758b84e1c6c4405443f3464f5a))
* **sessions:** report the redacted database URL when migration cannot connect ([1579927](https://github.com/google/adk-python/commit/1579927e5eb95593d5b0a56f1e272fec1f9dc892))
* **sessions:** stop get_user_state aliasing stored user state ([dd96b81](https://github.com/google/adk-python/commit/dd96b811ea1abd2febfac781ad4f4b43efd8e36f))
* skip unreplayable function responses ([7dcfade](https://github.com/google/adk-python/commit/7dcfadedafc280c1c5e07ddf0a7b3fe30b00c107))
* stop a re-emitted output echo from reordering the replay sequence ([4b819ab](https://github.com/google/adk-python/commit/4b819ab7f28c639cff79991a3ea095a16d715e81)), closes [#7027](https://github.com/google/adk-python/issues/7027)
* stop Agent import loading authlib ([ac1d51b](https://github.com/google/adk-python/commit/ac1d51b456c8f5666c480b472c7abc25794306c7))
* stop background tools before the transfer delay ([c79f60f](https://github.com/google/adk-python/commit/c79f60f8acf572e9c45a611bc3726b27420d220b)), closes [#7006](https://github.com/google/adk-python/issues/7006)
* stop internal Agent Config subclassing from warning on plain imports ([3699fad](https://github.com/google/adk-python/commit/3699fad41bfecdd3ef8c43116ed7de89c339692b)), closes [#6968](https://github.com/google/adk-python/issues/6968)
* stop probing for mTLS credentials on every MCP session ([dfc96d0](https://github.com/google/adk-python/commit/dfc96d0aa9bca3af3bd788eeebc0485b4f7d8fac))
* stop retaining spans on servers with no debug trace endpoint ([7560061](https://github.com/google/adk-python/commit/756006175ade27be2de7530c415db22fa9f5f82f)), closes [#6915](https://github.com/google/adk-python/issues/6915)
* stop returned sessions aliasing scoped state ([557643b](https://github.com/google/adk-python/commit/557643bb32bd53696b1697d0bc9508ecbe3a27c6))
* stop the multimodal tool results plugin sending media twice ([a4d97b7](https://github.com/google/adk-python/commit/a4d97b7c3cf476202ba4adf65263e714fcbb1257))
* StreamingResponseAggregator drops/duplicates function calls in streaming mode ([3cf4ce2](https://github.com/google/adk-python/commit/3cf4ce2b8d6d1523903e32f772f9112e09ac0c74)), closes [#6566](https://github.com/google/adk-python/issues/6566)
* support openapi basic auth ([f2fe475](https://github.com/google/adk-python/commit/f2fe4759f1648439663a1f3b06957fd362c12a7f)), closes [#5492](https://github.com/google/adk-python/issues/5492)
* **telemetry:** make `google.adk.telemetry.tracing` importable on OpenTelemetry 1.39; `google.adk.telemetry.google_cloud` still needs a newer OpenTelemetry ([8f1323a](https://github.com/google/adk-python/commit/8f1323ae6daf5cc0a7e12f856fd56e5fa8c9c81b))
* **telemetry:** record only the function responses on a merged tool span ([42358b1](https://github.com/google/adk-python/commit/42358b156bd4862c1f86261ed76bf3ca7462fd2b))
* **tools:** clarify google_search_agent instruction to use built-in grounding ([56d3cae](https://github.com/google/adk-python/commit/56d3caece5229d912faa1dbed7770f695a467dec))
* **tools:** propagate outer CancelledError in stop_streaming ([b8836bd](https://github.com/google/adk-python/commit/b8836bdb22d75438640ec11edffec2b66bb9a30b))
* **tools:** stop ExampleTool crashing a live run that opens with no message ([1414fac](https://github.com/google/adk-python/commit/1414fac5474b685e3a1b297c71cf7468ed322867))
* trace tool calls under the agent, not under the model call ([83d966c](https://github.com/google/adk-python/commit/83d966cfe8b31a12629a10fca23a6c462083cfe6))
* use full query text and own logger in PreloadMemoryTool ([82687cf](https://github.com/google/adk-python/commit/82687cf819f64531376da9062dfa3cb2e5beff9e)), closes [#6884](https://github.com/google/adk-python/issues/6884)
* validate and coerce function tool argument types (opt-in; enable with `ADK_ENABLE_FUNCTION_TOOL_ARG_VALIDATION=1`) ([24b37e1](https://github.com/google/adk-python/commit/24b37e1716582bd3e6b0d27d142f70707d960bb4)), closes [#4612](https://github.com/google/adk-python/issues/4612)
* validate the detect_anomalies target data subquery ([60d0a9b](https://github.com/google/adk-python/commit/60d0a9bfb48e0b14691e40111a3bd79b07897a2c))
* **workflow:** allow resolved interrupts to resume without rerun_on_resume ([307d041](https://github.com/google/adk-python/commit/307d0413b4ab9a0458e3a9c5d2177af466a1eb74))
* **workflow:** do not leak descendant isolation_scope to parent in _reconstruct_node_states ([2fb34bc](https://github.com/google/adk-python/commit/2fb34bc69be71c1ec121e37bf5e87d0f64b4e96d))
* **workflow:** isolate peer task-mode agents in dynamic run_node calls ([ddbb59e](https://github.com/google/adk-python/commit/ddbb59ebf5306b5b09de01f35de20aa42af43078))
* **workflow:** resume interrupted agent transfers in static workflows ([97aefd8](https://github.com/google/adk-python/commit/97aefd87d315242d5060ad30fc6d33ca7ea77ee6))
* **workflow:** unwrap Content inputs for parallel workers after START ([e80677d](https://github.com/google/adk-python/commit/e80677dda26fd21450f6a23d46bef49a4003d1fb))


### Performance Improvements

* **sessions:** add id DESC to events composite index to eliminate filesort ([a00a2a9](https://github.com/google/adk-python/commit/a00a2a9771e3e48831457ce2b5038aa8fef17706))
* **sessions:** cache TypeAdapter in State and support key iteration ([220acfd](https://github.com/google/adk-python/commit/220acfdec67477c69941001be38b4d57444e35f3))
* trace a streamed model call once instead of once per chunk ([733162e](https://github.com/google/adk-python/commit/733162e8f848c79ca6c7981240ac294e1da914fe))
* **workflow:** avoid redundant event scans in _apply_rewinds and NodeRunner ([f5ef8df](https://github.com/google/adk-python/commit/f5ef8dfd52d44097acfd33aac3af38ec92766117))


### Documentation

* add unit guides for the third-party and cloud integrations ([3d70669](https://github.com/google/adk-python/commit/3d70669b4218ba10d6546ffff00f00008f0f4878))
* **agents:** add BaseAgent unit guide ([7d42b78](https://github.com/google/adk-python/commit/7d42b784f93653f09c1bfeea18d394ac27b6b8ec))
* **agents:** add Context unit guide ([c03683a](https://github.com/google/adk-python/commit/c03683a83853f03cb4dca830bc4a544787ec0d1a))
* **agents:** add InvocationContext unit guide ([5f3b6f0](https://github.com/google/adk-python/commit/5f3b6f0624cf43211eac30adecee194ce11847fe))
* **agents:** add LlmAgent unit guide ([75bf1dc](https://github.com/google/adk-python/commit/75bf1dc8a04e102e7cd84c4db06cc7f7308869aa))
* **apps:** describe the sliding-window compaction that actually runs ([9cb4eed](https://github.com/google/adk-python/commit/9cb4eedc95eab37ea41323688ae86a9361e1e979))
* list the twenty guides missing from the guides index ([68204f5](https://github.com/google/adk-python/commit/68204f58ec316acecc1e1e03846236e8a51f5e98))
* make the single-turn node example runnable ([06d4895](https://github.com/google/adk-python/commit/06d4895ba5a051b606127010ca3961832734faf5))
* **models:** add developer unit guide for ServiceTier ([0636bf8](https://github.com/google/adk-python/commit/0636bf8b3966536a3249903bf97e4a8995930a2a))
* **readme:** point the eval quickstart at a sample that exists ([c3f4e63](https://github.com/google/adk-python/commit/c3f4e63f1e0819631c3ff23eceb3102d3b734e7f))
* remove the 1.x breaking-changes callout from the README ([d69f995](https://github.com/google/adk-python/commit/d69f995c2e7ba7676bce3036c58d6b9cfbd60de2))
* rewrite the unit guides for the third-party integrations ([1addd76](https://github.com/google/adk-python/commit/1addd76c594f2eb05b9e5ba1c1860d8b08d08ed9))
* **samples:** add a Grok-4.6-on-Vertex sample using the labs OpenAI model ([40a0a8d](https://github.com/google/adk-python/commit/40a0a8d1368b4c17b1bbf48f76228983b36d0ecf))
* **samples:** add a hello-world OpenAI sample using the labs OpenAI model ([eb1a002](https://github.com/google/adk-python/commit/eb1a00245cd1fff0af34794e349fc65e40d2847b))
* **sessions:** document runtime DDL and concurrent index guidelines ([0002760](https://github.com/google/adk-python/commit/0002760ffd57b979cd0725f199bd1742d82ba6a3))
* **telemetry:** name the real do_not_elide parameter ([c7ae45a](https://github.com/google/adk-python/commit/c7ae45ad1aea4598549aa222021635f698921ea0))
* **workflow:** index BaseNode unit guide in documentation ([692b40a](https://github.com/google/adk-python/commit/692b40aed6fe0f88c7ffeedbc115f540605ae13e))


</details>

## [2.9.2](https://github.com/google/adk-python/compare/v2.9.1...v2.9.2) (2026-09-18)


### Highlights

This release focuses on refining telemetry behavior by correcting how OpenTelemetry event names are handled across different environments.

* **Telemetry**: OpenTelemetry event names are now preserved on platforms outside of Agent Engine, ensuring more accurate and consistent tracking. ([9110770](https://github.com/google/adk-python/commit/9110770dc487283b95844ad843db9eec9e56e92d))

### Bug Fixes

* **telemetry:** only drop the OTel event name on Agent Engine ([9110770](https://github.com/google/adk-python/commit/9110770dc487283b95844ad843db9eec9e56e92d))

## [2.9.1](https://github.com/google/adk-python/compare/v2.9.0...v2.9.1) (2026-09-15)


### Highlights

This release focuses on improving visibility into model reasoning steps when utilizing Claude's adaptive thinking capabilities.

* **Claude Integration**: Access the step-by-step reasoning process of Claude models by ensuring visible thoughts are requested during adaptive thinking tasks. ([ba0d542](https://github.com/google/adk-python/commit/ba0d542181df87b6e1da9709fa0410082484443a))

### Bug Fixes

* request visible thoughts for Claude adaptive thinking ([ba0d542](https://github.com/google/adk-python/commit/ba0d542181df87b6e1da9709fa0410082484443a))

## [2.9.0](https://github.com/google/adk-python/compare/v2.8.0...v2.9.0) (2026-09-10)


### Highlights

This release focuses on agent resilience and ecosystem integration by introducing automatic model failover, native voice support via LiveKit, and compatibility with MCP SDK 2.x.

* **Models**: Safeguard agent uptime by automatically failing over to backup models when the primary model encounters errors. ([c300b8d](https://github.com/google/adk-python/commit/c300b8ded62b8bc4168cdede4c85bec66d1aa8ee))
* **Integrations**: Build rich voice and telephony agents using the newly added LiveKit runner. ([f277d91](https://github.com/google/adk-python/commit/f277d9117781fb4e2d8cd2608a1d484c29884e60))
* **Workflows**: Simplify graph workflow management by authoring and loading ADK 2.0 graphs directly from declarative YAML configurations. ([2a9461b](https://github.com/google/adk-python/commit/2a9461b1da1c3f7bf732cb37ac43a865f907c6a4))
* **MCP**: Upgrade to MCP SDK 2.x capabilities seamlessly while retaining full backward compatibility with 1.x servers. ([856acf2](https://github.com/google/adk-python/commit/856acf21e3155d2145f9af0709434dd46843539c))

#### Behavior changes

* **Workflow node resumption**: A node that failed now runs again when the workflow resumes, where before it replayed as though it had completed. Make node bodies idempotent: a node that performs an external side effect and then fails will perform that side effect again on every resume. ([91573eb](https://github.com/google/adk-python/commit/91573eb9f40aaef0b43b15c828557cc69249ef9a))
* **GCS tool local paths**: The GCS tools now read and write local files only inside the directory named by `local_file_root`, and refuse local file access entirely when that setting is absent. Paths may be absolute or relative, and are judged by where they resolve. ([c569796](https://github.com/google/adk-python/commit/c5697961f883be9eed4b923a41793fa907822178))
* **In-memory sessions only**: `InMemorySessionService` now raises `SessionNotFoundError` when an event is appended to a session it does not hold, instead of accepting the event and discarding it. The database-backed services already behaved this way, so this affects in-memory sessions alone. ([15b1392](https://github.com/google/adk-python/commit/15b13922d0efeb4882efae06dc0f9fd19cf892f8))

<details>
<summary>All changes</summary>

### Features

* add a2a_state_forwarding sample ([1b28de4](https://github.com/google/adk-python/commit/1b28de4891d35bc9e9d6fa91f896796577cdf6b6))
* add FallbackModel for automatic failover between models ([c300b8d](https://github.com/google/adk-python/commit/c300b8ded62b8bc4168cdede4c85bec66d1aa8ee))
* add get_authenticated_url and get_signed_url to GcsArtifactService ([10ac52b](https://github.com/google/adk-python/commit/10ac52b5f05c5a3e7f9c6b6bbbc867cc962c657b))
* add ignore_args option to tool trajectory evaluation ([e2a213f](https://github.com/google/adk-python/commit/e2a213f5e4c56d3aa4b5129d5c9db644b0543ceb))
* add transfer_reason to transfer_to_agent to prevent loops ([22ab4d8](https://github.com/google/adk-python/commit/22ab4d82ca026adc87ffbf47a7ea2ed8e99676d1))
* agent evaluations print detailed results when all tests pass ([e1ae543](https://github.com/google/adk-python/commit/e1ae543766212106bcee62b595fd10f854445291)), closes [#3891](https://github.com/google/adk-python/issues/3891)
* generalize docker build and run for multicloud environments ([0673f05](https://github.com/google/adk-python/commit/0673f0548f30c5fd42280553123582c4e4ef1e95))
* **integrations:** add LiveKit runner for voice and telephony ([f277d91](https://github.com/google/adk-python/commit/f277d9117781fb4e2d8cd2608a1d484c29884e60))
* load ADK 2.0 graph workflows from YAML configuration ([2a9461b](https://github.com/google/adk-python/commit/2a9461b1da1c3f7bf732cb37ac43a865f907c6a4))
* **mcp:** support MCP SDK 2.x alongside 1.x ([856acf2](https://github.com/google/adk-python/commit/856acf21e3155d2145f9af0709434dd46843539c))
* support hyphenated column names in BigQuery tools ([b736b0d](https://github.com/google/adk-python/commit/b736b0d142acefd8ac9bc3d7b4acd1ef664c4282))
* **telemetry:** add ability to track skill loads ([0cd24c8](https://github.com/google/adk-python/commit/0cd24c84a9160450d8f1254557fd65a194448338))
* **telemetry:** add script execution instrumentation ([0dbc37d](https://github.com/google/adk-python/commit/0dbc37d67e928d22acef937a8f441683c88af415))
* **telemetry:** export logs over OTLP to telemetry.googleapis.com ([5e6df42](https://github.com/google/adk-python/commit/5e6df4207e42a1192f88f731ce30a5ade8770c1c))
* **tools:** support FunctionNode auto-inference in NodeTool ([ea8609d](https://github.com/google/adk-python/commit/ea8609d3457e54e67606a47289f4c10eb58091d4))


### Bug Fixes

* **a2a:** quote a fetched card description and drop relayed auth responses ([7ee3ae9](https://github.com/google/adk-python/commit/7ee3ae9cce4c89b2a56fbb4d1616f92e00cf7787))
* **a2a:** require https for a non-loopback agent card URL ([fe30ebb](https://github.com/google/adk-python/commit/fe30ebbe729aecc622b5dd82d29bccb29d8723a2))
* **a2a:** stop a completed task delegation breaking later peer delegations ([04be48b](https://github.com/google/adk-python/commit/04be48b26048631e914175798d16dc6de5c2d062)), closes [#6831](https://github.com/google/adk-python/issues/6831)
* add optional OIDC verification for Pub/Sub and Eventarc triggers ([73d9fe0](https://github.com/google/adk-python/commit/73d9fe053f99188e01ad186df5dcc401c48e79d7))
* append the user's next turn when it joins a paused task ([678d7e9](https://github.com/google/adk-python/commit/678d7e9394acea792115610cea4dcd332ffb68c6))
* apply state_delta when resuming without a new_message ([6de43b0](https://github.com/google/adk-python/commit/6de43b05a07f8ca89909664b3a21049646d7336c)), closes [#6644](https://github.com/google/adk-python/issues/6644)
* **artifacts:** give concurrent gcs artifact saves distinct versions ([0a12027](https://github.com/google/adk-python/commit/0a12027c737ac7b4c01abdb1c4805b57e98ab1fe))
* **auth:** declare that AuthHandler.generate_auth_uri can return None ([e4c8994](https://github.com/google/adk-python/commit/e4c8994d159eee7e337142a2aaf8df9e078a006e))
* balance callback lifecycle for hallucinated tool calls ([f842a15](https://github.com/google/adk-python/commit/f842a15cdbd3e4efb2ae205bbee111b0eca3b95d)), closes [#4775](https://github.com/google/adk-python/issues/4775)
* **bigquery:** lazy-load Dataplex so BigQueryToolset imports without it ([b65be01](https://github.com/google/adk-python/commit/b65be0155cd68b849809b9a13dc1eda8e43474f6))
* **callables:** extract unified CallableSpec and resolve doc and unwrap edge cases ([c506ddf](https://github.com/google/adk-python/commit/c506ddf3bc34a6312ffc81899221bfa3f2da3b1d))
* cancel the invocation when a sync run() generator is closed early ([080d5e7](https://github.com/google/adk-python/commit/080d5e7829be649c8928f7afcd58befa8303b91b))
* **cli:** explicitly set memory_service_uri='memory://' when --in_memory is passed ([b0bb3dd](https://github.com/google/adk-python/commit/b0bb3dd28e1cebbb9d6ce32e2017ffccf5b40a4a))
* **cli:** make the decorators on API and dev server routes take effect ([308cc32](https://github.com/google/adk-python/commit/308cc32de316182f87efb1cd7ded9acf460ed58d))
* **cli:** sync the Agent Engine class-method catalogue with its source ([0043044](https://github.com/google/adk-python/commit/00430445f5c3554f07ed1c7f8c3da66dff1f9adb))
* close a task-mode delegation when the remote agent finishes ([4cd8aa4](https://github.com/google/adk-python/commit/4cd8aa4043277b7c40aabad77ebb7c8bd11c6ca0))
* coerce an integral float back to int for an int-typed tool parameter ([adbee3c](https://github.com/google/adk-python/commit/adbee3cd86256dda90cfd3235a1b89b4720d3e80))
* coerce callable AgentInfo.instruction for app-info ([ada8652](https://github.com/google/adk-python/commit/ada8652cdf68e855a9754888a304916e66d770a4)), closes [#6909](https://github.com/google/adk-python/issues/6909)
* confine GCS tool local file paths to a configured root ([c569796](https://github.com/google/adk-python/commit/c5697961f883be9eed4b923a41793fa907822178))
* default AgentCardBuilder capabilities to streaming=True ([b018062](https://github.com/google/adk-python/commit/b0180620f4c2f4f4467a89c37a30f75bf849700b)), closes [#6672](https://github.com/google/adk-python/issues/6672)
* defer local state/event mutation until Vertex append succeeds ([903f37f](https://github.com/google/adk-python/commit/903f37fda5f6624cdaf2c28f6e072c3b6ba8472a)), closes [#6998](https://github.com/google/adk-python/issues/6998)
* end a live session when the client closes the request queue, instead of reconnecting or busy-waiting ([07b1173](https://github.com/google/adk-python/commit/07b1173e6a694e05d40554daaba74cc21e2e75cd))
* end tool callback chains on the first non-None result ([895b6f2](https://github.com/google/adk-python/commit/895b6f2a59ff1881127261ec71891d494da999f0))
* **environment:** terminate the whole process tree when a local command times out ([fa321f1](https://github.com/google/adk-python/commit/fa321f1b49f7bd961b58ad19fd8b8e6fa285b918))
* fail a workflow when a detached dynamic node errors or interrupts ([34e13df](https://github.com/google/adk-python/commit/34e13df41750fc5243a1cd42a86491ee5acdd876))
* **flows:** keep code execution going instead of reporting no content ([ae30506](https://github.com/google/adk-python/commit/ae305062a026ca9f7c0f3a6c76a8b60eb8e951e8)), closes [#7002](https://github.com/google/adk-python/issues/7002)
* **flows:** move before_tool_callback from prepare phase into per-tool execution ([fb45e24](https://github.com/google/adk-python/commit/fb45e242c8054f024bb15a0e6e58244c8973d82b))
* **flows:** propagate contextvars set in before_tool_callback to the tool ([0b75a66](https://github.com/google/adk-python/commit/0b75a66d17a8b8a251c5f2bd903d47a4bdf05dc1))
* **flows:** restrict agent transfer to the declared transfer targets ([8fefa37](https://github.com/google/adk-python/commit/8fefa3769d74ac4b2b3e352f0a1ac075a0fc26d2))
* forward GenerateContentConfig.seed to LiteLLM ([668e024](https://github.com/google/adk-python/commit/668e024b68218947df4595ea6a50adcf1fce67c3)), closes [#6513](https://github.com/google/adk-python/issues/6513)
* forward the agent's generation config (temperature, top_p, top_k, max_output_tokens, seed, media_resolution) to the Live API ([bd74c42](https://github.com/google/adk-python/commit/bd74c42b4e73fd6ded01b737c336773ff528ef0f))
* **gcs:** judge a local path by where it lands, not by whether it is absolute ([48b28de](https://github.com/google/adk-python/commit/48b28deeb8d3d761ffff5b7ce51300142d5cbff3))
* guard malformed tool call argument JSON in LiteLlm response parsing ([6e59663](https://github.com/google/adk-python/commit/6e5966353630bc45a1538c9d6ae67977eb6746e9)), closes [#5896](https://github.com/google/adk-python/issues/5896)
* handle failed inference cases gracefully in GEPA pipeline ([7bffb0a](https://github.com/google/adk-python/commit/7bffb0af29ebfc42b5e5248bdfebff9828f525e8)), closes [#6004](https://github.com/google/adk-python/issues/6004)
* honor save_live_blob when caching live user audio ([b2c7664](https://github.com/google/adk-python/commit/b2c7664eb4c589cd234e5a3196db3fc80583839c))
* initialize Anthropic client off event loop ([e421017](https://github.com/google/adk-python/commit/e4210172e995a3fbe62e62734968a667a837013b))
* invalidate import caches during agent module validation ([c7ffcfa](https://github.com/google/adk-python/commit/c7ffcfa85a8e8970f6318306479d9c4c110583b2)), closes [#6948](https://github.com/google/adk-python/issues/6948)
* keep the original event id when reloading a Vertex session ([864914b](https://github.com/google/adk-python/commit/864914ba9865811515080475c35a2f955e72f93f)), closes [#6530](https://github.com/google/adk-python/issues/6530)
* keep the tool filter and name prefix when cloning a skill toolset ([e4f1700](https://github.com/google/adk-python/commit/e4f1700e012ba1c0f5fbaff1de5f730423707295))
* keep the turn anchor when a long-running tool result is posted back ([b499fbe](https://github.com/google/adk-python/commit/b499fbece77309400cd96f2b73dbf4bb80b860ba))
* label the dynamic instruction so a model does not read it as a user turn and imitate it ([8cdbbb1](https://github.com/google/adk-python/commit/8cdbbb158c70d22c414bd943ad29ec080d1a52b6))
* log an error when a model returns multiple candidates ([25f5214](https://github.com/google/adk-python/commit/25f5214c83f56b2fcffd35757e886026632f3c2b))
* make SkillToolset system instruction respect tool_filter ([66d7609](https://github.com/google/adk-python/commit/66d76090baae16c2393bc7ab4a82aff2503b2303)), closes [#6448](https://github.com/google/adk-python/issues/6448)
* match a branch's run ids exactly when resolving HITL interrupts ([8db82ba](https://github.com/google/adk-python/commit/8db82ba298af92256f9566a766bbe55a4912d873))
* **mcp:** keep resolving MCP 1.x by default ([46edaa2](https://github.com/google/adk-python/commit/46edaa24a4ee1e14b542638950d3043096a56032))
* **mcp:** only attach application default credentials to Google API hosts ([f9f4a39](https://github.com/google/adk-python/commit/f9f4a3901a7a6c932b336ce0936aece66b459954))
* **mcp:** skip summarization when a tool call pauses for confirmation ([cb0eb22](https://github.com/google/adk-python/commit/cb0eb2288bfe6536bd6e98f0601d3736844062ca))
* **memory:** do not let a failing temp-file cleanup mask the upload error ([2778930](https://github.com/google/adk-python/commit/2778930080239e473ac32b2b9beb226d1d0c7087))
* microsecond-safe DatabaseSessionService on SQL Server (mssql) ([7d7bac0](https://github.com/google/adk-python/commit/7d7bac0fa97c91a53904ca1c0ae26300d4d78d82))
* **models:** stop a content-free thought signature from wedging a session ([a5d6238](https://github.com/google/adk-python/commit/a5d6238cb761db93e56deabc27d3a5f3dbcfc40c))
* name the async driver when a database URL uses a sync one ([76601c6](https://github.com/google/adk-python/commit/76601c65c22b05be3badba5cb2e49194f44a05aa))
* never empty the request contents when applying a context cache ([8e30a30](https://github.com/google/adk-python/commit/8e30a30884cb9355c711695f446fb2db6e94e2c1)), closes [#6945](https://github.com/google/adk-python/issues/6945)
* normalize session_id before duplicate check in in-memory service ([bfeb04c](https://github.com/google/adk-python/commit/bfeb04cfe11dd21264707f63af3e13589213adaa)), closes [#6887](https://github.com/google/adk-python/issues/6887)
* **openapi:** bound the REST API tool's default HTTP waits ([5d0bd5f](https://github.com/google/adk-python/commit/5d0bd5f641866352794ebbaa513c0b67f6a3e735))
* **plugins:** keep a staticmethod a staticmethod when auto-tracing wraps it ([939ff92](https://github.com/google/adk-python/commit/939ff92d2ccc90bf79b145cca66e904a3a4a3944))
* point misplaced generation kwargs at generate_content_config ([e51aadc](https://github.com/google/adk-python/commit/e51aadcfa27cdb2443dfe2deb716788043abeec3)), closes [#6836](https://github.com/google/adk-python/issues/6836)
* populate model_version on AnthropicLlm responses ([408f57d](https://github.com/google/adk-python/commit/408f57d2ed3388255e53907024ccd308107edb3a)), closes [#6847](https://github.com/google/adk-python/issues/6847)
* preserve anyOf and camelCase aliases in LiteLLM tool schemas ([0e97a8f](https://github.com/google/adk-python/commit/0e97a8f4342f74ddaba38a9c7596b064c18371ce)), closes [#6738](https://github.com/google/adk-python/issues/6738)
* preserve Gemini 3 thought signatures in interaction history ([51f21e7](https://github.com/google/adk-python/commit/51f21e724b036cb17f23514fb2e054a0bdbc7d48))
* raise a sub-agent's own error from ParallelAgent, not a group ([3ecd3d7](https://github.com/google/adk-python/commit/3ecd3d719b8bebeb5a331338365e7a7b9b8bde2e))
* raise AlreadyExistsError on concurrent create_session races ([cbccae6](https://github.com/google/adk-python/commit/cbccae64b3dc1a1e1de29aad674f2c13fba7f5bd))
* raise SessionNotFoundError when appending to an unknown session ([15b1392](https://github.com/google/adk-python/commit/15b13922d0efeb4882efae06dc0f9fd19cf892f8))
* read an MCP tool's schema under either spelling in telemetry ([40c8333](https://github.com/google/adk-python/commit/40c8333460c6337fdf05f1e33964110bd8567f5a))
* rebind an agent's own callback methods when cloning ([f449bb7](https://github.com/google/adk-python/commit/f449bb70c3b87854cb84aecf6276d39c00cdc835))
* **redis:** match app_name and user_id literally when listing sessions ([4b26bba](https://github.com/google/adk-python/commit/4b26bba94dc3698478ce049a8d6a308be731262f))
* refuse a tool call whose arguments a broken stream cut short ([da22e43](https://github.com/google/adk-python/commit/da22e4307ea2de902a304e6a4aa3768560c31290)), closes [#6716](https://github.com/google/adk-python/issues/6716)
* refuse a transfer to a forbidden parent or peer agent ([b0503a0](https://github.com/google/adk-python/commit/b0503a03663368688f19881a9813152b5db3e2ca))
* reload changed agent correctly ([397ed42](https://github.com/google/adk-python/commit/397ed423550da5114aa7fcaa2d5da4f77679460a)), closes [#4956](https://github.com/google/adk-python/issues/4956)
* report a metric that never ran as not evaluated, not as failed ([9c9b81a](https://github.com/google/adk-python/commit/9c9b81a17295333e396c7826050d186c30ffadcb))
* report an unknown tool name to the model instead of raising ([f337793](https://github.com/google/adk-python/commit/f33779378c58ff0cf7bacad62c25ef194b5fa24e))
* report the real finish reason from a LiteLlm stream ([eaed0aa](https://github.com/google/adk-python/commit/eaed0aa8b25220b63890c72746f3b314686f2812))
* rerun a failed node on resume instead of replaying it as complete ([91573eb](https://github.com/google/adk-python/commit/91573eb9f40aaef0b43b15c828557cc69249ef9a))
* rerun a paused workflow node after the user answers it ([2fb877c](https://github.com/google/adk-python/commit/2fb877cd0ea5f866d2b66153b00749ebb61bdce4))
* resolve every Claude model id rather than enumerated generations ([01919b3](https://github.com/google/adk-python/commit/01919b3794f3cd8d5bbfb2b7c319e626e0edeb8f))
* resolve scheduler leakage and use node.clone() in DynamicNodeScheduler ([64b5b9c](https://github.com/google/adk-python/commit/64b5b9c04f358c01fb3a0d5efa4beffb18a1b444))
* retry a nested workflow when a node inside it fails ([2dc8b8d](https://github.com/google/adk-python/commit/2dc8b8d3ce997d195461b50bc7ac852b57863718))
* retry once on 429 in VertexAiSessionService ([cc5985a](https://github.com/google/adk-python/commit/cc5985a1b021e5818d5c0fe0593690792d835ab8))
* return custom_metadata from VertexAiMemoryBankService.search_memory ([3a37d7a](https://github.com/google/adk-python/commit/3a37d7ac2abc7a9e73e922b87ef7116f654b3957)), closes [#6946](https://github.com/google/adk-python/issues/6946)
* route interleaved interactions function-call deltas by step index ([f73bb37](https://github.com/google/adk-python/commit/f73bb37c559dcf7cd2f50a19f329be4bc31323de)), closes [#6832](https://github.com/google/adk-python/issues/6832)
* **samples:** correct the live audio path, the live eval config and the multimodal samples ([6499a44](https://github.com/google/adk-python/commit/6499a44a7ef1262c53ce571ab08213e7d2fc6e92))
* **samples:** read the knowledge agent data store from the environment ([d5129f3](https://github.com/google/adk-python/commit/d5129f3aa05be2017078f98d7307b5727a2b6a63))
* sanitize anyOf schemas for Vertex AI function declarations ([642439c](https://github.com/google/adk-python/commit/642439cd5a8e8027947823a5d5f669daf22032fc)), closes [#6373](https://github.com/google/adk-python/issues/6373)
* show adk create --type in --help ([d0d5ade](https://github.com/google/adk-python/commit/d0d5adeffd69775ed15af90cec950d645e8caf07)), closes [#6737](https://github.com/google/adk-python/issues/6737)
* skip duplicate user event append on invocation retry ([d06a7fe](https://github.com/google/adk-python/commit/d06a7fed56dff71cbfa709edb5bb1d72989eca8e)), closes [#4506](https://github.com/google/adk-python/issues/4506)
* skip rewound invocations when resuming agent in _find_agent_to_run ([ed1306f](https://github.com/google/adk-python/commit/ed1306f58796648a58b5ee2f99f80e81e92cd7de)), closes [#4169](https://github.com/google/adk-python/issues/4169)
* skip summarization for terminal A2A task states ([aef3a9c](https://github.com/google/adk-python/commit/aef3a9c4d43c1fff961c2dd6dde920851248c69a))
* **spanner:** release the client, transports and sessions each tool call creates ([edf99a3](https://github.com/google/adk-python/commit/edf99a3ac2e2bfb22e820b73cdfcbecac2491e37))
* stop a child branch stamped on a user event moving the invocation root ([181d52e](https://github.com/google/adk-python/commit/181d52e402d8c0d921a0e3dd80d5c743a5b40589))
* stop after final preprocessing responses ([764e2cb](https://github.com/google/adk-python/commit/764e2cbdac854e8fe7b31af98222b6bcf4238d80)), closes [#4472](https://github.com/google/adk-python/issues/4472)
* stop caching a remote agent card that failed validation ([2685acd](https://github.com/google/adk-python/commit/2685acd3705bc19988611e33aa644268993d4095))
* stop CompletionsHTTPClient leaking its httpx client via atexit ([3fcda36](https://github.com/google/adk-python/commit/3fcda36d852ceeaf7e78e52aa48d71aa22c2808e))
* stop ContainerCodeExecutor leaking via atexit ([04f8df1](https://github.com/google/adk-python/commit/04f8df11e0fce6b78958aaa1780c1c689bce3e6e))
* stop declaring dict value types to Google AI ([73803f4](https://github.com/google/adk-python/commit/73803f46f0699823629c4d9cc64914621d96bd6b))
* stop offering run_skill_script when no code executor is configured ([66315da](https://github.com/google/adk-python/commit/66315daea81f1ea181ae7b89d33cfa4ed8204359))
* stop sending the OAuth client secret to the client ([393b3b0](https://github.com/google/adk-python/commit/393b3b0d50acdd94a2cccfa812b8e85aec001d2d))
* stop silently dropping sampling settings on interactions API ([cd0dddc](https://github.com/google/adk-python/commit/cd0dddce9c56ca23adcc2a3cfeb065c0a1d6444a))
* support multi-turn nested HITL pause and resumption across workflows and agent tools ([6d14518](https://github.com/google/adk-python/commit/6d145180611956b2065704189517fd6a0ff1a063))
* **telemetry:** end the inference span at the finish reason, not at the first chunk ([6364060](https://github.com/google/adk-python/commit/6364060916d8e757b370c8ddf18ba390e94f402b))
* **telemetry:** keep thought signatures out of span attributes ([5d965c3](https://github.com/google/adk-python/commit/5d965c33deaca4369c5cf2f669260e5d0ba5874e))
* **telemetry:** remove helper methods for type-safe hallucination checking and update function signatures ([e1e4331](https://github.com/google/adk-python/commit/e1e4331ac20cbdc534b1112ebd89334451583486))
* **tools:** import the two annotation names that are referenced but unbound ([13376d4](https://github.com/google/adk-python/commit/13376d4ad4c67e8f3ab0f560ee4f473c64bf2c79))
* **tools:** support zero-argument nodes in NodeTool ([8128b84](https://github.com/google/adk-python/commit/8128b84e39e463dc19aa8b4a049677861e6beb11))
* **tools:** treat an empty openapi security requirement as optional auth ([3c6a5b7](https://github.com/google/adk-python/commit/3c6a5b7fa20d9424eab35f5a30e99a1b77e39658))
* treat a max_iterations of zero as zero loop passes ([afbcaff](https://github.com/google/adk-python/commit/afbcaff7b8744edbd2992c5ea6bf03ecb5e78787))
* treat an error event without function calls as a final response ([75ae2db](https://github.com/google/adk-python/commit/75ae2dbf948ac3911f3f4d6026f7c092d9950a9d))
* update max_llm_calls validation to reject values greater than or equal to sys.maxsize ([44e0b2a](https://github.com/google/adk-python/commit/44e0b2a8b1215aa98f057c4a781ddc24bae220da))
* **utils:** adapt callback keyword arguments to positional parameters ([a213e76](https://github.com/google/adk-python/commit/a213e76d4356de923068ead7118cd67304deae8e))
* **utils:** include agent name in instruction context variable missing error ([86b2e5b](https://github.com/google/adk-python/commit/86b2e5baaa487558b10fc9f2b48fe0d4ceefb755))
* **utils:** report an unknown session id in the cache performance analyzer ([f7c0c01](https://github.com/google/adk-python/commit/f7c0c010126b371115bf406f631c25c1162d3dd8))
* validate app_name before interpolating into deploy Dockerfile ([6eb1d35](https://github.com/google/adk-python/commit/6eb1d35d84a9cb28445249119d951b13f604c823))
* validate function call author before resuming auth-gated tool calls ([328ecb9](https://github.com/google/adk-python/commit/328ecb938d0db97738de92dd6e7c92d57f76e39b))
* **vmaas:** cache the sandbox access token on the computer instance ([21c2fbd](https://github.com/google/adk-python/commit/21c2fbd2cd0ad4590261e4c5f58f1a4657e28d88))
* warn once per experimental surface instead of on every use ([391fdc6](https://github.com/google/adk-python/commit/391fdc6ccca767ece55a8242b626d10cb4d40890))
* **workflow:** drop resume inputs from the resumable node checkpoint ([790cb7c](https://github.com/google/adk-python/commit/790cb7c4c7af3f2a0812ba86f50a2b0154f769ae))
* **workflow:** omit the oauth client secret from the credential request event ([fdfa4b1](https://github.com/google/adk-python/commit/fdfa4b11473069d4107c986802fb1705c86a3818))
* **workflow:** retry subclasses of a configured retry exception ([f6fe8d2](https://github.com/google/adk-python/commit/f6fe8d265bff283aa28cdeec9780e789a8847435))


### Performance Improvements

* defer imports in code executors ([d9648b0](https://github.com/google/adk-python/commit/d9648b01237aeef4cd829a13c0b40de17fd151fa))
* extend the workflow replay index instead of rebuilding it per event ([f8fdfed](https://github.com/google/adk-python/commit/f8fdfed281186489dc915e767e7f9f4a18081ae2))
* stop rescanning the session for every user response event ([4295bd0](https://github.com/google/adk-python/commit/4295bd0238f1b1244ac8325cc4a0c14fac56a739))


### Documentation

* **a2a:** explain the human-input resume tests in their own terms ([909ace1](https://github.com/google/adk-python/commit/909ace11669dc569310ca58b5cbe7c42f3dad438))
* add node as tool developer unit guide and sample docs ([9fcd97e](https://github.com/google/adk-python/commit/9fcd97e1a1c66d892983f712de8a5b7548473fef))
* add unit guides for A2A, skills and the execution backends ([b89037d](https://github.com/google/adk-python/commit/b89037d95a71799eb3403ae5ec3a8b6044f878cd))
* add unit guides for evaluation, serving and observability ([eb532ca](https://github.com/google/adk-python/commit/eb532caf4814bdfaba94d4998b4de82d9efdd813))
* **agents:** state the lazy-import rule the comment only pointed at ([ac96686](https://github.com/google/adk-python/commit/ac96686c3aa5079ef14c15b171400c1180e88133))
* align callback contracts with runtime behavior ([6a811d2](https://github.com/google/adk-python/commit/6a811d2bfcea004d1edad685fb7ca3eeb4f5f716))
* **antigravity:** add the AntigravityAgent unit guide ([86b50c4](https://github.com/google/adk-python/commit/86b50c40485be91a1e0193e23001b01c1a5f1687))
* **antigravity:** describe the scenario a compaction-turn test covers ([ef714fe](https://github.com/google/adk-python/commit/ef714fe07d4f76bfcf30e21989080a8d31a32802))
* **antigravity:** name the Antigravity SDK in full and disambiguate "agent" ([b71a59c](https://github.com/google/adk-python/commit/b71a59cb4aab1cd8e0f1e66d816064d08ef41dc1))
* correct the heading in the llms-full.txt pointer ([2880fbf](https://github.com/google/adk-python/commit/2880fbf2a39e6a262b4ac2442b8e2dc784d1a936))
* document Live streaming in adk-agent-builder and adk-architecture ([a80d264](https://github.com/google/adk-python/commit/a80d2640ba2b291dd9996e0404c41f8870381aab))
* document replacing a failed tools listing via get_tools ([c7ef8cf](https://github.com/google/adk-python/commit/c7ef8cfa8269738033180f49338f160254b8b137)), closes [#6748](https://github.com/google/adk-python/issues/6748)
* **features:** use a real feature name in the is_feature_enabled example ([93cd316](https://github.com/google/adk-python/commit/93cd316a9fc757a9025d5ab0f90d5b358ec8e5ca))
* **flows:** drop the incorrect move instruction from three compatibility shims ([d637d1b](https://github.com/google/adk-python/commit/d637d1b449aa4382045f71ee84d3f674403d41d5))
* give the unit guide skill a voice section ([10333f2](https://github.com/google/adk-python/commit/10333f26f1042497c9004b1a40c831e0855d2a60))
* **live:** move LiveRequestQueue developer guide to docs/guides/live ([d563bde](https://github.com/google/adk-python/commit/d563bdea44d093b2d25be246727357a5842e27ae))
* **memory:** describe ttl as the revision_ttl alias it actually is ([c3f785c](https://github.com/google/adk-python/commit/c3f785c43074550e0a230e1cff9eed0b4125f38f))
* **openai:** drop the third-party gateway from the OPENAI_BASE_URL tip ([8d624bd](https://github.com/google/adk-python/commit/8d624bdc52afc3f1bf0b39598ab3d626c9e0124f))
* **plugins:** say what the reflect-and-retry failure counter's lock guarantees ([6762652](https://github.com/google/adk-python/commit/6762652ac1a7077888568b7f88f5233d36ef6ab1))
* scope the gVisor claim to the mode that provides it ([bd4c6d7](https://github.com/google/adk-python/commit/bd4c6d77d06c90412d46cef59f21a5b8efbd8fa4))
* state what a parallel branch isolates and what it shares ([a28c66b](https://github.com/google/adk-python/commit/a28c66b39e62402a82d574097bfec0cd07dc22c3))
* **tests:** remove the internal notebook link from the hello world fixtures ([7988f4c](https://github.com/google/adk-python/commit/7988f4c48582bac17d48984fe39b1c0f31cbae81))
* **tools:** scope the Spanner capabilities setting to the toolset that reads it ([c4a7ee2](https://github.com/google/adk-python/commit/c4a7ee2920d30eca9f604836457aa5e435b2f91c))


### Miscellaneous Chores

* release as 2.9.0 ([187a693](https://github.com/google/adk-python/commit/187a693904c5a708595cad0b72d5ef5c5febb44e))

</details>

## [2.8.0](https://github.com/google/adk-python/compare/v2.7.1...v2.8.0) (2026-08-25)


### Features

* **a2a:** add native task mode support to RemoteA2aAgent ([72f3ff5](https://github.com/google/adk-python/commit/72f3ff5cfb11fdf7432c6c2faa01befcc350ad7e))
* add ADK_MAX_LLM_CALLS environment variable to configure max LLM calls limit ([75679db](https://github.com/google/adk-python/commit/75679db3fa42521a9316d1f8325225e51f5e9090))
* add create_data_agent tool to data_agent toolset ([5cd38a0](https://github.com/google/adk-python/commit/5cd38a0b3d944eb3e5ac252140f0dc01ab6d5fd0))
* add delete_data_agent tool to data_agent toolset ([9b451fc](https://github.com/google/adk-python/commit/9b451fca3b4b81ed5c3bba64594caeb64ac1d214))
* add location parameter to list_accessible_data_agents in data_agent toolset ([393ec08](https://github.com/google/adk-python/commit/393ec0858baa61c5ebb8b733cd29e1ff673ead19))
* add Model Armor guardrail plugin ([11efc3f](https://github.com/google/adk-python/commit/11efc3f8e9bcc00660740ad4807e406d97dd5dd3))
* add nvidia nim integration sample ([c6bba8d](https://github.com/google/adk-python/commit/c6bba8dcc8cee4b78a36a751416dbbff284a146f))
* add sample for skill state injection via adk_inject_state ([9384127](https://github.com/google/adk-python/commit/93841270bc479028bbe0209f3291d82e84276698))
* add spreadsheet mime types to load_artifact_tool ([370027a](https://github.com/google/adk-python/commit/370027a770b413ab7991afa3395dbf8be1eb89e5))
* add update_data_agent tool to data_agent toolset ([92d00aa](https://github.com/google/adk-python/commit/92d00aa937a50bdd35a24df856dbdc513b9bed4f))
* allow configuring Vertex AI API version ([ede87c2](https://github.com/google/adk-python/commit/ede87c26edc716069eb760bbe0fdb046048084fd)), closes [#3246](https://github.com/google/adk-python/issues/3246)
* allow streaming tools to set response scheduling per yield ([bf2efd7](https://github.com/google/adk-python/commit/bf2efd71d6f9433673b8e7465a9dcc7f045a3dc4))
* **antigravity:** capture client-side tool outcomes for a function_response ([4599a52](https://github.com/google/adk-python/commit/4599a52659f9c3655263b3aabd39a189c692c0d2))
* **cli:** Support Cloud Build worker pools for Agent Engine deploy ([e577c30](https://github.com/google/adk-python/commit/e577c301d5f4a50b2a3c827631c53463268bb5fc))
* **eval:** support custom metrics in AgentEvaluator ([babb11c](https://github.com/google/adk-python/commit/babb11c83c4b4c21c7d7af8b8e3ecf50c20b34a9))
* guard against SQL injection vulnerabilities in BigQuery tools ([d6290a0](https://github.com/google/adk-python/commit/d6290a0b2e344a92b8879acfeab02e4252d1b47c))
* **live:** Add VIDEO to the allowed modalities in the ADK API server ([dd998a7](https://github.com/google/adk-python/commit/dd998a7d5352225b944806abfe0fc7f463abbf38))
* **live:** let a live streaming tool send messages to the user directly ([98896eb](https://github.com/google/adk-python/commit/98896eb2aaafb57577c02fc00b62db4367cb003c))
* **live:** run before and after model callbacks in live mode ([ef2d680](https://github.com/google/adk-python/commit/ef2d68080a05f2fc3e00634c4f6c4d3d43c2a7f1))
* **live:** surface live `interaction_status` on LlmResponse and Event ([b858904](https://github.com/google/adk-python/commit/b8589042c50986fb5cb446952f0b1bd8631ffa96))
* **live:** use RunConfig.session_resumption.handle when opening a live session ([eac32c3](https://github.com/google/adk-python/commit/eac32c3ccc64a1ee4df80d6e4ffe9f1d33033c18))
* **mcp:** report MCP HTTP exchanges as OpenTelemetry log records ([85a6fa1](https://github.com/google/adk-python/commit/85a6fa1e44f4d66a0e3a2be754355aa8be9b7af4))
* parallelize LLM-as-judge evaluation using asyncio.gather() ([0dbb88c](https://github.com/google/adk-python/commit/0dbb88c7c43c004a00d71458e30e54c7d5a9a6b4))
* preserve field descriptions in set_model_response schema ([a30858b](https://github.com/google/adk-python/commit/a30858b11ce87b51be49c67021b892af16a2a311)), closes [#6707](https://github.com/google/adk-python/issues/6707)
* record context cache state on the LLM call span ([c0614d6](https://github.com/google/adk-python/commit/c0614d65806be5e7525b72e662e0987378996b53))
* resolve auth for RemoteA2aAgent in AgentRegistry ([d695494](https://github.com/google/adk-python/commit/d6954946df8b156ab27554ca02d2d6234c8595a1))
* support auth_scheme and auth_credential in RemoteA2aAgent ([d42c634](https://github.com/google/adk-python/commit/d42c634bd6ef4041440d833327d63969a39315be))
* support injecting custom LLM clients into Gemini and AnthropicLlm ([a01d516](https://github.com/google/adk-python/commit/a01d516a6bcf93f12d26a083af587455d0bb2592)), closes [#5027](https://github.com/google/adk-python/issues/5027)
* support memory_id and allowed_topics in Vertex Memory Bank ([bf73360](https://github.com/google/adk-python/commit/bf733602b61f2542add406235706fc9b1b7bfed2))
* support opt-in session retention in MultimodalToolResultsPlugin ([775c1bd](https://github.com/google/adk-python/commit/775c1bd36e205eec65e207ad29fdc4cf2184e47e)), closes [#6695](https://github.com/google/adk-python/issues/6695)
* support sub-agent escalation event in ParallelAgent ([0fd681e](https://github.com/google/adk-python/commit/0fd681e7d203d2bc7b86c72e4b539de6c735c889)), closes [#5104](https://github.com/google/adk-python/issues/5104)
* **telemetry:** add per-invocation token spend metrics for invoke_agent ([dc00db5](https://github.com/google/adk-python/commit/dc00db51bc5dc195a21633b295aa9eac33732ccf))
* **telemetry:** add per-workflow inference and tool call counts ([6e6c4a5](https://github.com/google/adk-python/commit/6e6c4a505e29bb0ba632c92add3a0e1be1bbaf00))
* **telemetry:** add per-workflow token spend metrics ([dd8797e](https://github.com/google/adk-python/commit/dd8797e77f7e7dbac6fd5bfffc945ae20d3cd611))
* **telemetry:** Expand telemetry for `load_skill_resource` span ([6e0facf](https://github.com/google/adk-python/commit/6e0facf9370261c788149a5330bb5632985e3531))
* **telemetry:** honor RunConfig.telemetry at the runner's invocation span ([00fc6eb](https://github.com/google/adk-python/commit/00fc6ebd1990bd53b8615cdbd309702d50e51e62))


### Bug Fixes

* **a2a:** keep file payloads out of the debug log line ([ef158d3](https://github.com/google/adk-python/commit/ef158d32e974e5e794aca3daf89bc60e55663edf))
* **agents:** report which toolset an agent lost when one fails to load ([66930e6](https://github.com/google/adk-python/commit/66930e65265e6bbf7f669575bb3c02dd8180ac35))
* **artifacts:** Publish file artifact versions atomically ([94475c9](https://github.com/google/adk-python/commit/94475c9a76c7c71246d6f5e4b083b3c3ee6869c0))
* **auth:** take the auth scheme from the request, not the client's response ([8989aea](https://github.com/google/adk-python/commit/8989aeadced4eda437f3435653fd60f11109c0e0))
* avoid O(n^2) deep event comparison during rehydration ([b8dd086](https://github.com/google/adk-python/commit/b8dd08604c997b1e91e038f96eacb01eea878872)), closes [#6657](https://github.com/google/adk-python/issues/6657)
* block yaml and ruamel deserialization in agent-config code references ([924d802](https://github.com/google/adk-python/commit/924d802f5bb232a294df8e5a5c036d000077e19a))
* cache read write token counts in LiteLLM and Anthropic models ([d0b33a0](https://github.com/google/adk-python/commit/d0b33a0569c940be0364cd4e0d4317a99bf52330)), closes [#5835](https://github.com/google/adk-python/issues/5835)
* check every function response, not just the first, when inferring which invocation to resume ([5449314](https://github.com/google/adk-python/commit/54493140a6697af5b82e03b9d7ecb77c15df4eb6))
* **cli:** clean up pytest subprocesses on test-client disconnect ([a84a4b5](https://github.com/google/adk-python/commit/a84a4b52aa90eeed5bb6819e8c4d69542b8b52db))
* **cli:** Preserve non-ASCII text in `adk test --rebuild`, Web UI test saving, and CLI JSONL ([dc735bd](https://github.com/google/adk-python/commit/dc735bd9534ff30c98db47743223815954d55e9f))
* **cli:** report env var names instead of values when overriding env_vars ([b0c599f](https://github.com/google/adk-python/commit/b0c599f21fab3ca1bf1d4984e2b0298b8bbc027d))
* count tool call and response chars in compaction ([66908e4](https://github.com/google/adk-python/commit/66908e4c613ff3686e85374696640e84c4d0f20f))
* declare a2a-sdk[http-server] so the a2a extra can serve ([65234e7](https://github.com/google/adk-python/commit/65234e761bc055a45425e8950b614efc4e2a1954))
* deduplicate events in InMemorySessionService.append_event ([4d74774](https://github.com/google/adk-python/commit/4d747747ee0313d7b30db1eed1b723ff329279d3)), closes [#5723](https://github.com/google/adk-python/issues/5723)
* deliver parallel sub-agent failures to the caller ([ece924c](https://github.com/google/adk-python/commit/ece924c2dd6bd5124a70e5bbc4164bf886ceb852)), closes [#5455](https://github.com/google/adk-python/issues/5455)
* detect MCP tool errors under either field spelling ([d18df2f](https://github.com/google/adk-python/commit/d18df2fa1c9cd8ceaad7e54c79a5acbcff95b812))
* disable Windows glob expansion for CLI args ([2638155](https://github.com/google/adk-python/commit/26381552c0a00bf4d5bbb0e0c9dbd5d6384f93a1)), closes [#6248](https://github.com/google/adk-python/issues/6248)
* emit Anthropic prompt cache breakpoints for ContextCacheConfig ([811d379](https://github.com/google/adk-python/commit/811d379fdf5b302861a237bfbae34e5f4ddfbf47)), closes [#5395](https://github.com/google/adk-python/issues/5395)
* fence relayed agent output so it cannot pose as instructions ([9ffe8be](https://github.com/google/adk-python/commit/9ffe8be6f92fae76541cc948c38c5ef5dc3755b9))
* filter thought parts from A2A client user-facing response ([8963a04](https://github.com/google/adk-python/commit/8963a0484662d27548fcdbe4dcf31a3c60a11542)), closes [#4676](https://github.com/google/adk-python/issues/4676)
* Fix built-in search tools in agent hierarchy when transfer_to_agent is present ([f3250bd](https://github.com/google/adk-python/commit/f3250bd9650a3654e3699c1e615b14e7b134fae0))
* Fix crashes and cross-invocation leaks from copying RunConfig.http_options ([67ca98c](https://github.com/google/adk-python/commit/67ca98c2c0b467ed397357eef2b2941c92dac40c))
* **flows:** pair a function response with the call it answers ([deee6d2](https://github.com/google/adk-python/commit/deee6d2c474ccb9710e0b25a0b290bb76cc54c45)), closes [#6761](https://github.com/google/adk-python/issues/6761)
* **flows:** sort function_call.args when rendering cross-agent context ([735402d](https://github.com/google/adk-python/commit/735402d01aaacf64eaf5034bf0517981c4886ce7))
* Guard `invocation_context.branch` assignment against mock `SessionService` instances ([9917922](https://github.com/google/adk-python/commit/99179223d01e7c86ca1fcb245b232eb00cb9b813))
* guard against Content with no parts in _content_to_message_param ([1ed8d48](https://github.com/google/adk-python/commit/1ed8d486203e240767251f2ca6d270cb8e5e9de3))
* handle read-only .git files in deploy cleanup on Windows ([c93fcc0](https://github.com/google/adk-python/commit/c93fcc09304209a11fe2d5647a7b0cb5cb727353))
* honor before_run_callback early-exit for Workflow runs ([dac1869](https://github.com/google/adk-python/commit/dac18699b9ce423f7e98d1cb245cfdde20b18147)), closes [#6013](https://github.com/google/adk-python/issues/6013)
* honor ContextCacheConfig on the LiteLLM path ([b1c984b](https://github.com/google/adk-python/commit/b1c984baa236887bb53eace6fa4d9cb483baff09))
* improve clarity and actionable context in error messages ([7c2af5f](https://github.com/google/adk-python/commit/7c2af5f9c1774474b316948b70b8215db230255f))
* include grounding metadata in rubric judge prompt ([b0cdecf](https://github.com/google/adk-python/commit/b0cdecfc3f846e8124f0a964e64174c12a696a2e)), closes [#5831](https://github.com/google/adk-python/issues/5831)
* **integrations:** send api registry credentials only to google api endpoints ([cc275f0](https://github.com/google/adk-python/commit/cc275f0c75bc4d84a5fc315dd6f6bd8a82cb1155))
* keep non-text static_instruction as a stable request prefix ([deda5b3](https://github.com/google/adk-python/commit/deda5b30e8ff40cb2f6dcb8d4d2b19bc97c5ea57)), closes [#6652](https://github.com/google/adk-python/issues/6652)
* keep session identity across single-turn node contexts ([c602065](https://github.com/google/adk-python/commit/c6020659a09a7d823f59205bde12f948342a3413)), closes [#6691](https://github.com/google/adk-python/issues/6691)
* keep tool calls at most once ([5bcf5cd](https://github.com/google/adk-python/commit/5bcf5cdd18127bb53156c5e7902d998a91fe261b))
* **live:** stop background tool tasks when a live agent run ends ([0088abb](https://github.com/google/adk-python/commit/0088abbe6651da6a6c644cace087a79d6a674821))
* **live:** stop live runs from writing back into the caller's RunConfig ([0b39e72](https://github.com/google/adk-python/commit/0b39e7280a14dd61d0faa3efef9c95206363f60c))
* make SqliteSessionService state merges use dict.update() semantics ([e4ba704](https://github.com/google/adk-python/commit/e4ba7040fb12f9a3ea468052567ec174dc31d443)), closes [#6728](https://github.com/google/adk-python/issues/6728)
* **mcp:** evict idle sessions from the MCP session pool ([69a3ca5](https://github.com/google/adk-python/commit/69a3ca5e119a821bc375246f0bfa2e9e2cfefc79))
* only attach default credentials to https endpoints ([5d3d152](https://github.com/google/adk-python/commit/5d3d1524debbff4158274f28e2798435bde13b0d))
* only emit --gemini_enterprise_app_name for adk_version &gt;= 2.2.0 ([00932e6](https://github.com/google/adk-python/commit/00932e617e3772381f16dbc9b9ddd06b50b2a5cb))
* pass file metadata tuple to Azure for PDF uploads ([ff4567d](https://github.com/google/adk-python/commit/ff4567df38d0cc5f1cd4f9423e416910cbe6ff2c)), closes [#6539](https://github.com/google/adk-python/issues/6539)
* percent-encode path parameter values in RestApiTool ([25f53bd](https://github.com/google/adk-python/commit/25f53bdc81f2e350285c91679885e8d8ba740f72))
* point to Gemini Enterprise registration docs after agent_engine deploy ([1d2d1ed](https://github.com/google/adk-python/commit/1d2d1eda3c9b795cd90ad643390f4da5a8cd27bf)), closes [#6633](https://github.com/google/adk-python/issues/6633)
* populate developer_instructions when invocation_events is empty ([69c9090](https://github.com/google/adk-python/commit/69c909000f73e47272fcab508e96f184c5cd81b3)), closes [#5593](https://github.com/google/adk-python/issues/5593)
* prefer the function response's own invocation over a caller-supplied id on the node path ([4d0d63c](https://github.com/google/adk-python/commit/4d0d63c74cf161f90ef33c7b310b6fd6641d3249))
* prevent contextvars leak across async generators ([bb86bdd](https://github.com/google/adk-python/commit/bb86bdd737c1792d40e05c1d388d9ad4020aa702)), closes [#5722](https://github.com/google/adk-python/issues/5722)
* prevent duplicate function execution when support_cfc is enabled ([c986ff0](https://github.com/google/adk-python/commit/c986ff0fceedef2107485cf136dc3b70acec32d8))
* prevent duplicate OAuth prompts and fix tool resumption ([eaad2f8](https://github.com/google/adk-python/commit/eaad2f83b93d7e0c678336923ca5be7a3b9d1260))
* prevent duplicate synthetic user event on single-turn agent resumption ([e753651](https://github.com/google/adk-python/commit/e753651b7df26febe00bde2cb043225e644cd207))
* prevent prompt injection via GitHub event data in workflows ([4f558f1](https://github.com/google/adk-python/commit/4f558f19d4dc0916437269dade3b03554e9ab0f4))
* rank and bound the results of InMemoryMemoryService.search_memory ([f3fae72](https://github.com/google/adk-python/commit/f3fae72e6a52f33c4fca4a7b90d37270c64990be))
* re-raise agent errors from the synchronous Runner.run() ([b55000d](https://github.com/google/adk-python/commit/b55000d9dce8960eeca8834dec7921597c532e0c))
* read long-running function name from data, not metadata ([029c17b](https://github.com/google/adk-python/commit/029c17b3384f4ad584c4b4f6f83335be98a04f02)), closes [#6295](https://github.com/google/adk-python/issues/6295)
* redact credentials from DebugLoggingPlugin output file ([a86bd25](https://github.com/google/adk-python/commit/a86bd2525042e806e422c8b0c3e78dba9d3e6547))
* redact credentials from generate_content_config.http_options in debug logs ([1cd6f46](https://github.com/google/adk-python/commit/1cd6f464e5b8ececa957928ca67d65145be558ab))
* reject negative recent-event limits ([26110c7](https://github.com/google/adk-python/commit/26110c75596cb7743e0614eebb8267221003303a))
* reject tool confirmations arriving over A2A ([9e9eaa6](https://github.com/google/adk-python/commit/9e9eaa69bdcc16f004af9c63f40f1dae6404c29b)), closes [#6461](https://github.com/google/adk-python/issues/6461)
* report root_agent type mismatch instead of 'No root_agent found' ([4f07c93](https://github.com/google/adk-python/commit/4f07c93b6ef760626906a2851b8f151500d13982)), closes [#6606](https://github.com/google/adk-python/issues/6606)
* resolve Claude 5 model names in the LLM registry ([42a4a5f](https://github.com/google/adk-python/commit/42a4a5f0e723ce71d0a1f34ae9c55c85a419ab67))
* resolve NameError in legacy create-eval-set route ([023f45c](https://github.com/google/adk-python/commit/023f45c3e5846c3e72525b53f16ef018b5ecdaa6))
* resolve nested provider behind litellm_proxy prefix ([602e58d](https://github.com/google/adk-python/commit/602e58db7171a49086d0c5b2b3e0fd8a8bd6d681)), closes [#6538](https://github.com/google/adk-python/issues/6538)
* resolve server disconnect logs ([3f2d399](https://github.com/google/adk-python/commit/3f2d399cd9e3945e4015b78ade8ecf3a6c2603e3))
* resolve systemic parts[0] indexing bugs ([2109ea9](https://github.com/google/adk-python/commit/2109ea96e1c7431225e57fb6db6c4c116e632867)), closes [#6616](https://github.com/google/adk-python/issues/6616)
* Restore `invocation_context.branch` from session history when executing a non-root agent node or resuming a sub-agent in `Runner` ([676d1e7](https://github.com/google/adk-python/commit/676d1e76457db9dd49ca23d49770136e5aef10a1))
* restrict unpickling of legacy v0 session event actions ([97c2af0](https://github.com/google/adk-python/commit/97c2af0bc294aa77744ddf5fb0c207f60ebf19fc)), closes [#5634](https://github.com/google/adk-python/issues/5634)
* resume an invocation whose user message leads with a non-text part ([6d8c588](https://github.com/google/adk-python/commit/6d8c588e12870ddeacc884bb3ee992d6464301d3))
* revert the A2A guard that broke every HITL tool confirmation ([9a32eba](https://github.com/google/adk-python/commit/9a32eba1e271981fd079bdee489b9159c6ecc72a))
* route workflow IDs and retry jitter through platform seams ([8f85107](https://github.com/google/adk-python/commit/8f85107cca7fa9d88eea5ca60e32b85173b4ec7c))
* **samples:** widen numeric tool parameters to match their docstrings ([0c67410](https://github.com/google/adk-python/commit/0c67410a66275aa989f3c10d4d083bff5f8d6139))
* sanitize state deltas before writing them to JSON state columns ([3f9e6be](https://github.com/google/adk-python/commit/3f9e6bec37cd66315d619a2dbb339f545c86e09a))
* send the required list on a CrewAI or LangChain function declaration ([186d9f7](https://github.com/google/adk-python/commit/186d9f739d1dc3655d88bffd96c943db05a87d7d))
* **sessions:** dedupe InMemorySessionService events by equality not id ([c9323d5](https://github.com/google/adk-python/commit/c9323d586153eab8cae31bc33f1114c8849cdd80))
* **sessions:** load legacy v0 event actions with the restricted unpickler ([fb15710](https://github.com/google/adk-python/commit/fb15710548e36a25605f0d0e3b346123e7c88356))
* **sessions:** stop dropping event actions on v0 PostgreSQL migration ([e3ae4ac](https://github.com/google/adk-python/commit/e3ae4ac2b431c589887e9bf2d70b452e8360f0c5))
* **skills:** skip search results that fail frontmatter validation ([3c977bc](https://github.com/google/adk-python/commit/3c977bc2ef31cf0fd7d94592f660cec5fc68b722)), closes [#6838](https://github.com/google/adk-python/issues/6838)
* skip non-agent directories in AgentLoader.list_agents() ([caac070](https://github.com/google/adk-python/commit/caac070837e9001367fd90846e896577cba3a92e))
* skip non-numeric response keys in generate_return_doc ([920bc3e](https://github.com/google/adk-python/commit/920bc3e14b5e2b3ee61d3809c42d8c8f7d972bfb)), closes [#6174](https://github.com/google/adk-python/issues/6174)
* stop re-sending thought summaries as conversation history ([e4f5900](https://github.com/google/adk-python/commit/e4f59004f74c4151d2ba5c6f02872634637de77c), [3c1b1bc](https://github.com/google/adk-python/commit/3c1b1bc236122a81fc5a70e30d5d6b48d1b2c029))
* stop RemoteA2aAgent forwarding credential requests to the remote peer ([2aea859](https://github.com/google/adk-python/commit/2aea8595fb1c5e0fddef7893a1985dc96dc82692))
* stop the session liveness probe from crashing when the SDK moves its streams ([d9f4d3d](https://github.com/google/adk-python/commit/d9f4d3d288257593471fc708a9ab851779005ca5))
* strip internal planning tags from PlanReActPlanner output ([ac8dad2](https://github.com/google/adk-python/commit/ac8dad258065ff58e91a1ca44afc72368250d241)), closes [#3378](https://github.com/google/adk-python/issues/3378)
* **telemetry:** End the inference span when the inference ends ([ecc730c](https://github.com/google/adk-python/commit/ecc730ceac33c2f71fdecdb55b6c095241888914))
* **telemetry:** record call_llm span attributes when a plugin short-circuits the model call ([0321136](https://github.com/google/adk-python/commit/0321136775fac560142dc1135bec34f00e88a69a))
* **tools:** report no match instead of raising on empty retrieval ([99660d9](https://github.com/google/adk-python/commit/99660d90308f37d377efcbb08318dbac1ec1fba9))
* **tools:** run AgentTool nested agent in unary mode ([0d5752b](https://github.com/google/adk-python/commit/0d5752bb5d7d33b94462082a00157b60213286a9))
* **tools:** run an agent tool under the caller's RunConfig ([983c280](https://github.com/google/adk-python/commit/983c28056f664b6229a541bcbd442cd20c1b6345))
* trigger Gemini 3.x Live response after sending conversation history ([7616c78](https://github.com/google/adk-python/commit/7616c78a1e94a8ff6751617ea5176a05e94e3939))
* use OAuth2 client-credentials scheme for OpenAPI SA helpers ([9897217](https://github.com/google/adk-python/commit/989721746aba65e90f644e51606375699175f709)), closes [#6656](https://github.com/google/adk-python/issues/6656)
* use Unicode-aware keyword extraction in InMemoryMemoryService ([b8ea1e8](https://github.com/google/adk-python/commit/b8ea1e8eba45c191776529392d808ab3485c6b6f)), closes [#5501](https://github.com/google/adk-python/issues/5501)
* validate session initialization events ([3fa71b6](https://github.com/google/adk-python/commit/3fa71b6349dbabb47dff5a3e9dea689cae6904e9)), closes [#5290](https://github.com/google/adk-python/issues/5290)
* validate SQL identifiers in Spanner search tool ([8d2f277](https://github.com/google/adk-python/commit/8d2f2779e6143aaa75460ca698476b4114759d5b)), closes [#5913](https://github.com/google/adk-python/issues/5913)
* **workflow:** cancel parallel worker items when the worker is cancelled ([dec729f](https://github.com/google/adk-python/commit/dec729f15721bcc78aac75f133aa6e153e9e4af0))
* **workflow:** declare abc.ABC on BaseNode so abstract subclasses type-check ([f3b59fd](https://github.com/google/adk-python/commit/f3b59fd62e51cb684d853995b5b3b42b4b11041f))
* **workflow:** do not act on function calls in partial events ([816ada5](https://github.com/google/adk-python/commit/816ada531870e36c57e3f100e96c63bbf94ad222)), closes [#6583](https://github.com/google/adk-python/issues/6583)
* **workflow:** honor START as a satisfied JoinNode predecessor ([d8df6fd](https://github.com/google/adk-python/commit/d8df6fd1fe8fa52ed9d6c275f4c5deb8464079a4))
* **workflow:** resume node auth from the node's own auth config ([5b59139](https://github.com/google/adk-python/commit/5b59139e0ec944a8618d4a1df4182db464337566))


### Performance Improvements

* buffer streamed function call arguments instead of concatenating ([f604de2](https://github.com/google/adk-python/commit/f604de2b960513ab0f1eff7f6bad9088d6210497))
* key the Pub/Sub publisher cache on its options' value ([51231cd](https://github.com/google/adk-python/commit/51231cd4acd8c5a28fc6db1960c4fa83e242a4d6))
* remove redundant event scans in prompt assembly ([d7adc1c](https://github.com/google/adk-python/commit/d7adc1ce3e9dab246e5baacd8b4579b23ebecd54), [e66fdd2](https://github.com/google/adk-python/commit/e66fdd2b2be25ddc740a988042c1dd91e6ac6662))
* resolve the optional id-pairing providers once, not per request ([203461c](https://github.com/google/adk-python/commit/203461cdc407eb6f7864847529dfc3ae7c3d72d4))
* run local code execution in a plain child interpreter ([c244a9c](https://github.com/google/adk-python/commit/c244a9c8330589d93046823ea21da80ae33a1406))
* run the Google credential refresh off the event loop ([2aa2b46](https://github.com/google/adk-python/commit/2aa2b469b062cf94718edd6b2ebdfb52cfcad076))


### Documentation

* add audio_stream_end documentation for realtime input ([17cb265](https://github.com/google/adk-python/commit/17cb2657cef9503b94598348e13cebdcbc1a2d3a))
* correct node schema docstrings about which variants validate ([e649a38](https://github.com/google/adk-python/commit/e649a382aae18ba0a495b837e009ca20ec6a6570))
* correct the documented contract of the invocation-subtree event filter ([be8fcf4](https://github.com/google/adk-python/commit/be8fcf4dd692d8098f4954ceee9f2ea2f3409b44))
* fix typos and grammar in README ([ffe518a](https://github.com/google/adk-python/commit/ffe518aff062932671ee78adabb4a5f55aca23c6))
* **guides:** add developer unit guide for BaseCodeExecutor ([b370fc0](https://github.com/google/adk-python/commit/b370fc00d1a54f4629b73b74ce70fae13ac75304))
* **guides:** add developer unit guide for BasePlanner ([ea23a89](https://github.com/google/adk-python/commit/ea23a89d734eead60f69c0b7f0fb6b13c9624c7a))
* **guides:** add developer unit guide for Runner and Runner Live Streaming ([1d89e0f](https://github.com/google/adk-python/commit/1d89e0ff8dd00ce499e194089903ca183495ed44))
* repair the workflow guides and document BaseNode ([7c7d2ba](https://github.com/google/adk-python/commit/7c7d2baec4316b5689a16d2b19c51d1c5a0d4298))

## [2.7.1](https://github.com/google/adk-python/compare/v2.7.0...v2.7.1) (2026-08-17)


### Bug Fixes

* **deps:** restore the OpenTelemetry 1.42.1 ceiling ([8e6f361](https://github.com/google/adk-python/commit/8e6f3613acb6ec07568a75461b964b311f404132))
* validate session initialization events ([e2b8ace](https://github.com/google/adk-python/commit/e2b8acefa2580b566b6fd9863dda203534294536)), closes [#5290](https://github.com/google/adk-python/issues/5290)

## [2.7.0](https://github.com/google/adk-python/compare/v2.6.3...v2.7.0) (2026-08-13)

### Highlights

A correctness release: most of the work went into what an agent sends to the model and what it gets back, alongside a long tail of fixes across tools, sessions, evaluation and the CLI.

* **Models declare their own capabilities**: an agent pairs an output schema with tools when the model actually supports it, instead of ADK inferring support from the model id. ([2aff82c](https://github.com/google/adk-python/commit/2aff82c30923e5f7df5ce4101db52bce82740329), [dc5dbfa](https://github.com/google/adk-python/commit/dc5dbfa2e475f2461177e80f7fa28c96a2bc3592))
* **Tools can return media**: a tool's function response carries images and other media straight back to the model, on Gemini and on Anthropic, LiteLLM, Apigee and OCI alike. ([df9d6de](https://github.com/google/adk-python/commit/df9d6dec58f4cb22a1010b72e9fd8d347ce8145a), [703cf43](https://github.com/google/adk-python/commit/703cf43f6b03550ec2b02def526f3f4ba98f7abd))
* **Conversation history keeps what Gemini needs**: thought signatures, server-side tool call parts, and every result of a parallel function call survive the round trip. ([d4ed347](https://github.com/google/adk-python/commit/d4ed3475397d16f9eb8d851f8945a6ed8121b6a8), [e908137](https://github.com/google/adk-python/commit/e908137125f9e14b3061f45f34f5379b48693313), [93dff41](https://github.com/google/adk-python/commit/93dff41417e81bad6150bd91acf1d73dedc298dc))
* **Jinja2 instruction templates**: pass `use_jinja2=True` to `inject_session_state` and an instruction can use conditionals and loops over session state, with artifacts loaded through a `{{ artifact("name") }}` helper. Jinja2 stays an optional dependency and the regex engine remains the default. ([4a00a34](https://github.com/google/adk-python/commit/4a00a344cfa03062f74e71dac0a5580514d9cea4))
* **Faster startup and hot paths**: `import google.adk` does less work, and the request path avoids Pydantic round-trips and quadratic streaming accumulation in the LiteLLM adapter. ([8806dc2](https://github.com/google/adk-python/commit/8806dc2bd8fb37004dee9ca50d9e774481f89afb), [9e1adde](https://github.com/google/adk-python/commit/9e1addedfff7e35e95a2ad120c8b30fe543af04c), [36fd2c8](https://github.com/google/adk-python/commit/36fd2c8e0cf9dddec66bb0c109518cdc2fbdb3b6))

#### Breaking changes

* **`pyarrow` left the `gcp` extra**: it lives in the new `bigquery-analytics` extra, which takes roughly 50 MB off `pip install google-adk[gcp]`. If you use `BigQueryAgentAnalyticsPlugin`, install `google-adk[bigquery-analytics]`. ([ac71709](https://github.com/google/adk-python/commit/ac717091f6644f348c6f7e65a43cc0475a28fe45))

### ⚠ BREAKING CHANGES

* **deps:** move pyarrow out of the gcp extra

<details>
<summary>All 212 changes</summary>

### Features

* accept a pre-configured client on the labs OpenAI model ([461205c](https://github.com/google/adk-python/commit/461205c8bac7f8679dc38a818c7839f18e855e95)), closes [#4180](https://github.com/google/adk-python/issues/4180)
* add express mode telemetry logging for ADK CLI onboarding ([4ccc6be](https://github.com/google/adk-python/commit/4ccc6be6d4229adea8f7738b1444b1683673d145))
* add gen_ai.agent.name attribute to execute_tool spans ([1a80962](https://github.com/google/adk-python/commit/1a80962124d54dbbb052327c00c7ba9f215fb39b))
* add Jinja2 templating with use_jinja2 flag ([4a00a34](https://github.com/google/adk-python/commit/4a00a344cfa03062f74e71dac0a5580514d9cea4)), closes [#2942](https://github.com/google/adk-python/issues/2942)
* add option to save eval results to CSV ([3bbc8ed](https://github.com/google/adk-python/commit/3bbc8ed2cf8c719f163b9a6d9de5833ec05a1675)), closes [#2652](https://github.com/google/adk-python/issues/2652)
* add parent terminal grouping and TTL pruning to ADK CLI telemetry ([2c6a7ff](https://github.com/google/adk-python/commit/2c6a7ffb4a8f46e2bf94359290476a2664ddf8b6))
* **agent:** add native task mode support to root LlmAgent ([dd0de52](https://github.com/google/adk-python/commit/dd0de5229fb21ff93c07da5124a9a0aee82b3eea))
* Allow clients using the load_artifacts_tool to customize how attachment data is fed to the LLM ([b66cba2](https://github.com/google/adk-python/commit/b66cba28097e5922786571bc46224030a9c08d57))
* capture TTY connectivity in CLI environment telemetry ([c12a025](https://github.com/google/adk-python/commit/c12a025184cec7859d829d8ce7178ddbe3e2e302))
* **cli:** auto-discover test_config.json for single eval file in adk eval ([0477e57](https://github.com/google/adk-python/commit/0477e5743bdf5e0cce5a698951c7b70a07baa80a)), closes [#4410](https://github.com/google/adk-python/issues/4410)
* enforce unit guide requirement for new Python files ([942b38d](https://github.com/google/adk-python/commit/942b38df34a3963618f92ced9499b863de5a082d))
* **environment:** Add support for executing skill scripts within an Environment ([fa31b6c](https://github.com/google/adk-python/commit/fa31b6ca9886eb48b9ac9c0dfe4f70c4443e1488))
* **evaluation:** add optional eval set result persistence to AgentEvaluator ([76027dd](https://github.com/google/adk-python/commit/76027ddb2f1f932d45dc0611c07c08b6025c2774))
* **eventarc:** Support Context callables and correct OMIT behavior ([a3bd111](https://github.com/google/adk-python/commit/a3bd11152db6562054db1c509ec44509436d99e7))
* Extend HTTP trace debugging to MCP Toolset operations ([6d8045c](https://github.com/google/adk-python/commit/6d8045c23fe0b6624d2dd928a2a21e1c07ad8957))
* honor model-declared capabilities when pairing an output schema with tools ([dc5dbfa](https://github.com/google/adk-python/commit/dc5dbfa2e475f2461177e80f7fa28c96a2bc3592))
* honor return_direct on Langchain tools wrapped by LangchainTool ([c2249f3](https://github.com/google/adk-python/commit/c2249f390e3d67a6c4eb6aa4dffc7b2aca8c3f13)), closes [#2157](https://github.com/google/adk-python/issues/2157)
* Introduce a capability reporting system for LLM models ([2aff82c](https://github.com/google/adk-python/commit/2aff82c30923e5f7df5ce4101db52bce82740329))
* **labs/antigravity:** allow mode='single_turn' AntigravityAgents to be sub-agents ([6ed484d](https://github.com/google/adk-python/commit/6ed484dc8762efe42cdaf6286c20fbab177ba5e8))
* let McpToolset reuse the MCP server's tool list ([9cd5975](https://github.com/google/adk-python/commit/9cd5975380ad977d7e38f926a1d993eb295c9457))
* let tools return media in the function response ([df9d6de](https://github.com/google/adk-python/commit/df9d6dec58f4cb22a1010b72e9fd8d347ce8145a))
* **live:** forward safety_settings from generate_content_config to the Live API ([0a6d05d](https://github.com/google/adk-python/commit/0a6d05da3b6ce912fa6f53eef1d97f638522817c))
* **plugins:** add BigQuery Agent Analytics delivery and termination observability ([04b8b72](https://github.com/google/adk-python/commit/04b8b72709f6d17b503cf674c8ac1b89798f655e))
* Promote Data Agent tools to stable ([fd33158](https://github.com/google/adk-python/commit/fd33158f3db2cbb2faf9aab9f82836949fa274fd))
* record implicit vs explicit context cache type in analytics ([5072828](https://github.com/google/adk-python/commit/5072828f70ca3c1c9bb98650fb4b596ce3895ba6))
* **skills:** support non-blocking skill loading in async runtimes ([61ddc5f](https://github.com/google/adk-python/commit/61ddc5fa8e850ac9082fc260d26cd10e3388d6e4)), closes [#6057](https://github.com/google/adk-python/issues/6057)
* Stop using the obsolete Gemini 1.x / Gemini 2+ model-id check in ADK ([745de0a](https://github.com/google/adk-python/commit/745de0ac13c4f2d5b3b158cf8431feb3156ea4fa))
* Stop using the obsolete Gemini 1.x / Gemini 2+ model-id check in ADK url context tool ([eaab262](https://github.com/google/adk-python/commit/eaab26219ad4b14c3b4ae1f3d06571e072a830cc))
* support audio_stream_end for realtime input ([0f738a5](https://github.com/google/adk-python/commit/0f738a549413713a059fd24b12e7f34580f6613a))
* Support elicitation_callback in McpToolset ([4824619](https://github.com/google/adk-python/commit/48246195ac55f7cf57c7dbe74c511bf43a787e20))
* **telemetry:** add feature gate for experimental telemetry ([75fb254](https://github.com/google/adk-python/commit/75fb2544e1d4b9e8753f1a30dc4dc3ad4097a7b9))
* **telemetry:** Expand load_skill telemetry ([bddbb3d](https://github.com/google/adk-python/commit/bddbb3dd8cedb3a2e49449573d87ff51f846df40))
* update skill model to include its origin ([08bd589](https://github.com/google/adk-python/commit/08bd5890552d33ed17ae3640c61992cec9065d25))
* warn when agent transfer runs without a context cache config ([0cf10a5](https://github.com/google/adk-python/commit/0cf10a543ec9aef582f83fe216eaa2b7e28d26eb))


### Bug Fixes

* **a2a:** adopt a directly supplied agent card's description ([4f58306](https://github.com/google/adk-python/commit/4f583064778bcacd7ea7baa1fbe16fdd0aa2e630))
* **a2a:** flatten human-input responses on resume to avoid mixing them with text ([aec7aa3](https://github.com/google/adk-python/commit/aec7aa33c8c6b16a15dcfb79bd3dd7689c206924))
* add .adk/ to the .gitignore generated by adk create ([374aab3](https://github.com/google/adk-python/commit/374aab372a0359226f52ec921b98741fecf8704d)), closes [#6647](https://github.com/google/adk-python/issues/6647)
* add 20MB file size validation to SaveFilesAsArtifactsPlugin ([9827790](https://github.com/google/adk-python/commit/98277905ba1b3445474dc3334427aad31617573c)), closes [#3751](https://github.com/google/adk-python/issues/3751)
* Add regional and MREP endpoint routing for DataAgentToolset ([20842eb](https://github.com/google/adk-python/commit/20842eb8e035a6e128b7585ca81f4625e00147c2))
* **adk:** share a single component-owner map between the triaging agents ([1ad0543](https://github.com/google/adk-python/commit/1ad05439e0381ca863c182e8051affb4db7fadd1))
* allow injecting credentials into VertexAiMemoryBankService ([18903ca](https://github.com/google/adk-python/commit/18903cadb5968b427220933d5ad1b42ea90dbc2c))
* **artifacts:** list artifacts nested under another artifact from disk ([a5864a0](https://github.com/google/adk-python/commit/a5864a0ed6050c5d3498ceae856f8783746e419b))
* **artifacts:** reject rooted, drive-qualified and traversing artifact paths ([2716ad5](https://github.com/google/adk-python/commit/2716ad55b8e9eb0c4f719f65bdc0b3f2a26cc551))
* **artifacts:** sort and guard GCS artifact version listing ([1f354b8](https://github.com/google/adk-python/commit/1f354b8937c16efbfd689b16ca2d56e77cbe93e8))
* **artifacts:** stop conflating an artifact with the artifacts nested under it ([08d21cc](https://github.com/google/adk-python/commit/08d21cc35569939d033fdac296e349be7c5d2268))
* attribute a compaction summary to the agent reading it ([c20ccef](https://github.com/google/adk-python/commit/c20ccefe5ef5e21f974923b8a8c9c3817e79787b))
* **auth:** set a request timeout on OAuth2 token exchange and refresh ([3f3c8f5](https://github.com/google/adk-python/commit/3f3c8f527d23702ea6e077ead63d32438a85b0bd))
* block the whole standard library in agent-config code references ([a16f6da](https://github.com/google/adk-python/commit/a16f6da3314b8dcd9925884cd6fc7fc9ffdd570d))
* bound Apigee completions HTTP client timeout and redirects ([f57a67d](https://github.com/google/adk-python/commit/f57a67d638a71899404dba2d4899ff42459e9f09))
* bound the entries and bytes read from a skill zip archive ([fa136c4](https://github.com/google/adk-python/commit/fa136c432a416706b12f667110e3742e422c0311))
* **bqaa:** skip synchronous log flush to prevent blocking responses ([6fd7eaf](https://github.com/google/adk-python/commit/6fd7eaf92a59ffb13806281d51628136e812cc6d))
* call build_planning_instruction on custom planners ([2bdf4de](https://github.com/google/adk-python/commit/2bdf4debd0f657a4666471ec0c6dcaadd9c8c51f))
* **ci:** run the update-constraints hook in check mode ([74e7167](https://github.com/google/adk-python/commit/74e7167d13a75b8eaab6e30a7af39e8c55315fc0))
* **ci:** stop CI resolving against half-published PyPI releases ([f4b432d](https://github.com/google/adk-python/commit/f4b432db114e58aa8f406017bf5e1b871d31e1bf))
* **cli:** implement early telemetry recording for long-running web servers and log successful exit code upon routine teardown ([77726c5](https://github.com/google/adk-python/commit/77726c55b33d6da1688a3d6893fe5e474d79116b))
* **cli:** normalize trigger user ids for sessions ([e03dbab](https://github.com/google/adk-python/commit/e03dbab2d480d85f2ae3f61e66e1ace5344d1727))
* **cli:** stream_reasoning_engine raises StopIteration RuntimeError on sync generators ([aa9c187](https://github.com/google/adk-python/commit/aa9c187f46e7ce06cdab28f0dcd51ba7c1497ee7))
* **cli:** track full server duration and log routine Ctrl+C termination as success ([0fcfe99](https://github.com/google/adk-python/commit/0fcfe99a50e75795407af7cd281a4b45580fef44))
* **cli:** update gcloud command to use beta flag ([9630559](https://github.com/google/adk-python/commit/9630559830da28a187ba75ef1c26c64780dd7987))
* coerce non-string enum values to strings on string-typed Gemini schemas ([30f32e3](https://github.com/google/adk-python/commit/30f32e3a9599ee165a323a8c72bfae2bb308cb95)), closes [#3401](https://github.com/google/adk-python/issues/3401)
* collect eval state from workflow nodes ([568b4f6](https://github.com/google/adk-python/commit/568b4f6b54d63dd8f5be16a6b704ecec8816bab3))
* constrain the RPC targets of a network-fetched A2A agent card ([16cbb7d](https://github.com/google/adk-python/commit/16cbb7d1c6020ec9a2d26ef97b6041410f0d256c))
* **core:** stop the Cloud Run sandbox executor waiting forever ([a39e71a](https://github.com/google/adk-python/commit/a39e71aace8490772b9fb554713ba964f7225adf))
* declare the redis extra that RedisSessionService asks for ([957dc2b](https://github.com/google/adk-python/commit/957dc2bd9fae932ee56aa8d4bffeb6331c10607f))
* **deps:** exclude LangGraph releases with unsafe checkpoint loading ([1b12ee3](https://github.com/google/adk-python/commit/1b12ee39ab07897d2290bcce2551625ed422e060))
* **deps:** exclude nltk 3.10.1, which breaks venvs living inside the working directory ([1a0c3bd](https://github.com/google/adk-python/commit/1a0c3bd49f512dc3b01e3e83185a6315ae3e954b))
* **deps:** stop the published constraints from pinning google-adk itself ([c44c543](https://github.com/google/adk-python/commit/c44c543e938d259c4ce145b66c62873bd9d330ec))
* disable dev endpoints for production deployment both AE and Cloud Run ([b795a9b](https://github.com/google/adk-python/commit/b795a9ba8680f70ca4e705a80e4d0951ad0a0e60))
* emit additional_properties with value type schema in dict branch ([93f57f4](https://github.com/google/adk-python/commit/93f57f472796bc8ccdf922fcc085169e1585768a)), closes [#4868](https://github.com/google/adk-python/issues/4868)
* **eval:** fail the eval when an agent crashes before any metric runs ([efeec70](https://github.com/google/adk-python/commit/efeec703dad61357ad1d79860a4696d4801ce487))
* **eval:** grade judge metrics against the criterion's threshold ([bcce415](https://github.com/google/adk-python/commit/bcce415ee80fa008dee796d8a6f24ebb77d6f6f8))
* **eval:** grade rouge metric against its criterion threshold ([83f7912](https://github.com/google/adk-python/commit/83f79123aae4d2473f1fe374a696250cca60de5d))
* **evaluation:** validate path segments in GCS eval set/result managers ([a56f6e1](https://github.com/google/adk-python/commit/a56f6e13ae38296b608808c7a3b37efe4b8c862e))
* fix inconsistencies in sample paper content and naming ([423434a](https://github.com/google/adk-python/commit/423434aa9dbe04837dec84fac9223f3b331f3c25)), closes [#6651](https://github.com/google/adk-python/issues/6651)
* Fix permissions for release cherry pick workflow ([07a37da](https://github.com/google/adk-python/commit/07a37da11bfd96d73d1a78cd9fb0ac1fb4d786b8))
* **flows:** count compositional function calling against max_llm_calls ([bb9709d](https://github.com/google/adk-python/commit/bb9709d74b0ce7c316de162531cb9f7dad28042a))
* **flows:** inject transfer_to_agent tool for HITL confirmation resume ([0897bee](https://github.com/google/adk-python/commit/0897bee6a01928cc89a2ba229d42834f77b33e85)), closes [#5633](https://github.com/google/adk-python/issues/5633)
* gate --sandbox-launcher behind gcloud beta run deploy ([547f1eb](https://github.com/google/adk-python/commit/547f1ebaf42ed5dbc81755bf9dd0919190778ee6)), closes [#6511](https://github.com/google/adk-python/issues/6511)
* guard reads in the local API server against DNS rebinding ([2cf4fd1](https://github.com/google/adk-python/commit/2cf4fd1ddcceea93d60df8eb6c0a7e775e867230))
* handle non-numeric OpenAPI response keys in return-doc generation ([b5be64c](https://github.com/google/adk-python/commit/b5be64c075ae3068d96bc3e0bf6930e4526fce55))
* handle optional and union pydantic models with string annotations ([94d08cd](https://github.com/google/adk-python/commit/94d08cd69ff97d8c59ac9af4d26e40316bbb3102))
* honor Apigee request timeouts ([2547db6](https://github.com/google/adk-python/commit/2547db61dd4599d5e0ac2f77cd0b45f5ded6b498))
* honor num_recent_events=0 in VertexAiSessionService.get_session ([923dee7](https://github.com/google/adk-python/commit/923dee79707049d93e94d081a90f7aa70e0896f2))
* ignore unsafe A2A peer-supplied event actions metadata ([0ba7d3c](https://github.com/google/adk-python/commit/0ba7d3cba7004c0fcc0a05f1f4cfb6ea78e38f91))
* import jinja2 lazily so it is not a required dependency ([f828667](https://github.com/google/adk-python/commit/f828667ee07f620e4680dd7acd460ee324302163))
* install every optional runtime dependency with the all extra ([f5c09dc](https://github.com/google/adk-python/commit/f5c09dce1120bdc14f12026dd5fb6a3ee401b8dc))
* isolate per-toolset failures in additional-tools resolution ([cdf895f](https://github.com/google/adk-python/commit/cdf895fe2c5f621fa522b2f938bde7ee7ffe16ea))
* keep agent instructions out of the published A2A agent card ([efdecf4](https://github.com/google/adk-python/commit/efdecf4c457639fb8bee793dc2c7b54e59140a94))
* keep preloaded context turn-scoped ([be103fb](https://github.com/google/adk-python/commit/be103fbd2f2ef4804afd691e37de53def2b4f934))
* keep regular-tool FRs on mixed task turns ([4cab3ac](https://github.com/google/adk-python/commit/4cab3ac1bfb7ad2be264cf2adae32685fe695338)), closes [#6581](https://github.com/google/adk-python/issues/6581)
* keep server-side tool call parts in conversation history ([e908137](https://github.com/google/adk-python/commit/e908137125f9e14b3061f45f34f5379b48693313))
* keep subpackages reachable as attributes of a lazy package ([ae5118d](https://github.com/google/adk-python/commit/ae5118d5b20d031def0d60f2439b6748428656c8))
* keep thought signature parts in conversation history ([d4ed347](https://github.com/google/adk-python/commit/d4ed3475397d16f9eb8d851f8945a6ed8121b6a8))
* keep thought signatures when merging streamed text ([fae470f](https://github.com/google/adk-python/commit/fae470f7bd8fd96341e78af6f069f5410d65f3d8))
* Key directory-loaded skill resources with forward slashes ([bc2c97c](https://github.com/google/adk-python/commit/bc2c97cbdf086c08aca345225a63e69992d28341))
* key in-memory memory store by app_name and user_id tuple ([fd8f7eb](https://github.com/google/adk-python/commit/fd8f7eb2a31e62c892751943b941e141d2e87f59))
* kill runaway code on timeout in container and local executors ([27548e3](https://github.com/google/adk-python/commit/27548e392f8a8503609a6abce0fb8081e8fb24f5))
* **labs/antigravity:** report node input and output from AntigravityAgent ([fd7df0e](https://github.com/google/adk-python/commit/fd7df0e75bd0c768f8669c51d9e5261705b4ab76))
* lift file references and nested parts out of tool results ([22f5546](https://github.com/google/adk-python/commit/22f55462fdbf629eee386a27f1159de15c2edbdd)), closes [#2577](https://github.com/google/adk-python/issues/2577)
* **litellm:** convert http_options.timeout from milliseconds to seconds ([e74917e](https://github.com/google/adk-python/commit/e74917e71905bb9d341302ce059c46245b7b727f))
* **live:** end the Live agent when `task_completed` is called in parallel ([cebfd74](https://github.com/google/adk-python/commit/cebfd74afc786a573fbf425a52aefe3873d38e68))
* **live:** transfer to the target agent regardless of function response order ([c198695](https://github.com/google/adk-python/commit/c1986951236b96db4726afd5e920ad7e9783fef2))
* lower oneOf to anyOf so a union schema reaches Gemini intact ([4da8dd7](https://github.com/google/adk-python/commit/4da8dd7f8bff9a9ff84a23cb707ac5696512cb60))
* make advertised tool names match the names tools are registered under ([b26d4f6](https://github.com/google/adk-python/commit/b26d4f67cb99046be5819c7da163cc79a7c2acbc))
* make parallel worker failure propagation test deterministic ([308c818](https://github.com/google/adk-python/commit/308c818867ecefdf68b13eca73a11e5b618b6746))
* mark the session type decorators as safe for statement caching ([e182146](https://github.com/google/adk-python/commit/e182146f9532474f8d2224368b07ba058223fffa))
* **mcp:** bound the wait for an MCP session to become ready ([de200b5](https://github.com/google/adk-python/commit/de200b50bc6e7d37ad6665e2a2a852221e4d18f6))
* **mcp:** reject stdio MCP servers declared in agent configs by default ([a61d8ec](https://github.com/google/adk-python/commit/a61d8ecf294515016a42080cc833fd8f73915695))
* **memory:** scope Vertex RAG retrieval to the requesting app and user ([fbeab00](https://github.com/google/adk-python/commit/fbeab000103fb67440b2ccbbc566a1b44723e643))
* **models:** honor an LLM registered after that name was resolved ([03f44c8](https://github.com/google/adk-python/commit/03f44c8e108e43f13c1de5acb53a88940f9e77f1))
* **models:** keep streamed usage metadata when a later chunk reports none ([aebb2a1](https://github.com/google/adk-python/commit/aebb2a13b35159723286caf00e736811dfa415c7))
* **models:** report a missing Anthropic credential when the client is built ([42f220a](https://github.com/google/adk-python/commit/42f220a61bb620e3c08d4e4d08098ea5857c436e))
* **models:** report Anthropic thinking tokens without double counting output ([a95b008](https://github.com/google/adk-python/commit/a95b008f91d82f1acd8c686e5a0d861aed707c20))
* **models:** use the reported total token count for interactions usage ([955325d](https://github.com/google/adk-python/commit/955325ddbbe7163d19bd32f3ac822eb3c498f6ee))
* **models:** wrap Anthropic rate limit errors ([cde301b](https://github.com/google/adk-python/commit/cde301ba68dc2970465b1b847fa805aad6f1f2ed))
* narrow broad except in OAuth2 credential refresher ([7d16478](https://github.com/google/adk-python/commit/7d164786f4cc97df7bfb53c2793a55963a481260))
* omit HTTP options from Gemini debug logs ([d63a255](https://github.com/google/adk-python/commit/d63a255880115d98bcc1f7260b461d2d338bd270))
* order database sessions deterministically ([8455cf8](https://github.com/google/adk-python/commit/8455cf8afcbbda23f4ebdddcaa83cdbea3124562)), closes [#6272](https://github.com/google/adk-python/issues/6272)
* order list_sessions results by last update time ([53e1afb](https://github.com/google/adk-python/commit/53e1afbcb5b211ad097985594a038bab49e2f509)), closes [#6272](https://github.com/google/adk-python/issues/6272) [#6431](https://github.com/google/adk-python/issues/6431)
* prefer application/json for OpenAPI return type docs ([9b4b2c5](https://github.com/google/adk-python/commit/9b4b2c51c64c8066b770ed6e2e7287ec32703697))
* preserve all tool results for parallel function calls ([93dff41](https://github.com/google/adk-python/commit/93dff41417e81bad6150bd91acf1d73dedc298dc)), closes [#6589](https://github.com/google/adk-python/issues/6589)
* preserve function-tool preflight in thread pool ([0156bc5](https://github.com/google/adk-python/commit/0156bc5a91845930e233ec04f5c725f9bf0be3ed))
* preserve per-part media fields across A2A conversion ([1a9d003](https://github.com/google/adk-python/commit/1a9d003a6ac30bac8ed3b64ddd9ab0425d48021b))
* preserve required body properties ([9b31268](https://github.com/google/adk-python/commit/9b31268d17d9dc000914ee515d458963ea0dca53)), closes [#6503](https://github.com/google/adk-python/issues/6503)
* preserve turns when stale compaction loses ([40ccbee](https://github.com/google/adk-python/commit/40ccbeec6f23939cd676ecc43ab1b99dc2774616))
* prevent update_constraints.sh from rewriting files when dependencies are unchanged ([470d59e](https://github.com/google/adk-python/commit/470d59e4a3a0edc7d906dfa02228ddde5c8dad7d))
* propagate context cache config to the AgentTool sub-runner ([5835f5a](https://github.com/google/adk-python/commit/5835f5a4e5cf8334573e8bac6a76a69187cfa2c9))
* propagate context cache config to the AgentTool sub-runner ([9488408](https://github.com/google/adk-python/commit/948840820095b9bb7d1e5a5b906b46201d5c11bd))
* prune orphaned function responses instead of failing the request ([73e8625](https://github.com/google/adk-python/commit/73e862546c077e4416667bc422131efa6b0f1477))
* read and write eval data files as utf-8 ([2e878ed](https://github.com/google/adk-python/commit/2e878ed4120b1009080ec4bd189cf8b436d03ccf))
* redact credential values from auto-tracing span attributes ([fd44a63](https://github.com/google/adk-python/commit/fd44a633d63af0ea23edfc8c7e20f01e2ffd702b))
* redact database password from session service errors and logs ([4ad3ecc](https://github.com/google/adk-python/commit/4ad3ecccec39d43f7256a1f8fa4e764716012d51))
* redact secret credentials from AuthCredential repr and error messages ([beb66ee](https://github.com/google/adk-python/commit/beb66ee15de58f5b773efce8bd63b94c3e5f0532))
* refuse MCP tools that take a reserved ADK tool name ([77d4647](https://github.com/google/adk-python/commit/77d4647c8ec771600bb822bd33d57929d046317c))
* Reject reserved ADK tool names in McpTool initialization ([2785aa9](https://github.com/google/adk-python/commit/2785aa9a5d2a3f71d85a1c05ae246c1cd2ad1697))
* remove invalid event from 10_burgers sample test trace ([6930be4](https://github.com/google/adk-python/commit/6930be4305238660ad5cae7f50f44f400dee2c31))
* resolve Claude 5 model names to the Claude LLM class ([e300ae7](https://github.com/google/adk-python/commit/e300ae7aa6a50ec0f71c01dc3b7291f4111a3f90))
* resolve GitHub Actions CI collection and flakiness issues ([4e65350](https://github.com/google/adk-python/commit/4e65350eeee3c9fd075986464dffcffe68ea4dbd))
* resolve shared-state concurrency contention in GCP auth provider using thread-local REST client caching ([b1c6f44](https://github.com/google/adk-python/commit/b1c6f44da559bba167d0013de3ea82e5ca466444))
* resolve zizmor security findings in GitHub Actions workflows ([0075954](https://github.com/google/adk-python/commit/00759548aa8978257e31daf9681ba6ef3092c5f4))
* restrict builder YAML code references to the app being edited ([8995005](https://github.com/google/adk-python/commit/899500510d6820734d2c83857aea9f958dea8ed5)), closes [#5292](https://github.com/google/adk-python/issues/5292)
* return schema validation feedback to models ([b5b27cb](https://github.com/google/adk-python/commit/b5b27cb074d00f2e6889098514d8f716bc1cdfad))
* revert runtime behavior changed by the strict-typing pass ([3eae315](https://github.com/google/adk-python/commit/3eae315d367e1679fb712f78312a6170c36ea62b))
* rollback reject reserved ADK tool names in McpTool initialization ([53b8a4d](https://github.com/google/adk-python/commit/53b8a4d6daf1df9595e80790bcb1f1ecf8b9c2b4))
* route apigee, o-series and unlisted LiteLLM provider models ([d58caa6](https://github.com/google/adk-python/commit/d58caa6c7804e613609e0d1a66cc0194a17cac3b))
* run synchronous OAuth2 token calls off the event loop ([b0f52f0](https://github.com/google/adk-python/commit/b0f52f0d970e16877d748284b6a68664385fb97f))
* **samples:** fail the maintenance run when issue discovery dies mid-page ([cf42e86](https://github.com/google/adk-python/commit/cf42e866cd755505e6571a9b830d1ee1d7df4631))
* **samples:** make the human-in-the-loop sample respect the human's decision ([d92bb42](https://github.com/google/adk-python/commit/d92bb42ccfeac7255ad367974d79629ef368db32))
* **samples:** make the MCP auth sample actually enforce auth, move MCP samples off the deprecated toolset name, and correct code execution claims ([c840dbe](https://github.com/google/adk-python/commit/c840dbe991dfb77c0ba2b61317913e64f0bab159))
* **samples:** repair integrations samples that no longer run against the current API ([64dddf2](https://github.com/google/adk-python/commit/64dddf2bf3cb98db7a504bde681642aa729d6cf9))
* **samples:** repair the adk_team samples against the current API ([41ec592](https://github.com/google/adk-python/commit/41ec5926ab4eb57f9dfd1aa92498bb882abf53be))
* **samples:** repair the core, tools, plugins and skills samples ([c620a73](https://github.com/google/adk-python/commit/c620a7347c30bd2ee04d9612518b185ce69d728a))
* **samples:** repair the session database migration recipe ([161f2b3](https://github.com/google/adk-python/commit/161f2b32b45bf47e765570584c7e7467cb55bbdd))
* **samples:** repair the workflow samples that produce the wrong output ([a308848](https://github.com/google/adk-python/commit/a3088489696f90f82fbb44f46c766d3cfcb469b5))
* **samples:** report failed stale agent audits and exit non-zero ([5418b73](https://github.com/google/adk-python/commit/5418b731564743aa7b981fd77741fb1cb5242faa)), closes [#6520](https://github.com/google/adk-python/issues/6520)
* **samples:** separate skipped from failed issues in the monitoring agent ([d8d8a6e](https://github.com/google/adk-python/commit/d8d8a6ef16eebf925e7ef8229a883f833d47bc4d))
* scope custom metrics per registry and trust only the config path ([5d2aca0](https://github.com/google/adk-python/commit/5d2aca08eb47e78d5915cd27c41db1541d9b18f8))
* scope file artifact reads and deletes to the requesting app ([c27d868](https://github.com/google/adk-python/commit/c27d8688ed9ea619587ad96cbfd641c34dd7340c))
* scope LangGraph checkpointer thread id to app and user ([19e2a72](https://github.com/google/adk-python/commit/19e2a7283f1de16e206f84ade687f9f16f0274cb))
* scope skip_summarization text-append to AgentTool ([84c7711](https://github.com/google/adk-python/commit/84c771105294e1c3dd7620c5f775e4ce0c1b3992)), closes [#6230](https://github.com/google/adk-python/issues/6230)
* Secure and harden FileArtifactService against tampered metadata and partial writes ([c567203](https://github.com/google/adk-python/commit/c5672030b7b9c76967a18665120c8ac36e5c7fef))
* select the mTLS endpoint only when a client certificate exists ([f324d1b](https://github.com/google/adk-python/commit/f324d1beed830c35d00727ddb973a46cb644007f))
* send media attached to a tool response to non-Gemini models ([703cf43](https://github.com/google/adk-python/commit/703cf43f6b03550ec2b02def526f3f4ba98f7abd))
* serialize merged tool calls instead of recording a placeholder ([6ec23cc](https://github.com/google/adk-python/commit/6ec23ccbb8e7c5e07f06493f49559382bfb103bc))
* **sessions:** make event reads deterministic and timezone-correct ([4ca975e](https://github.com/google/adk-python/commit/4ca975eb9acd30a64b2c8615a93d31dada63052c))
* **sessions:** store and filter event timestamps in UTC ([1b8ed3d](https://github.com/google/adk-python/commit/1b8ed3d9c0b125852df1902dd32b65bcab63ce1d))
* **skills:** load binary references and assets as bytes instead of skipping them ([3f21e89](https://github.com/google/adk-python/commit/3f21e891d74a8dc20b8af525d5b848dfe0ab14b3))
* stop live tool execution from bypassing run_async ([8b9d222](https://github.com/google/adk-python/commit/8b9d22228c3503376e121bfe6720c0bf38ba076f))
* stop LlmAgent resume path from ending parent on pause ([3bb1011](https://github.com/google/adk-python/commit/3bb10115d3ae69cfc42bebcdfa4a935031c8e1a1)), closes [#6017](https://github.com/google/adk-python/issues/6017)
* stop logging the full live LlmRequest in base_llm_flow ([6fb5e04](https://github.com/google/adk-python/commit/6fb5e04fcd68de404e1714a4fcdb7f3d17914c8c))
* stop marking defaulted output_schema fields as required ([d4ec2fc](https://github.com/google/adk-python/commit/d4ec2fc382db84362d6116d424a5eb56ebd14403))
* stop per-run HTTP options and labels leaking onto the agent ([8160d47](https://github.com/google/adk-python/commit/8160d47805a8ae16befd29ac847f280b7b5a40a8))
* Stop re-validating already-consumed tool confirmations ([76d5723](https://github.com/google/adk-python/commit/76d5723f74217750d874118fda2bd31befd9f8b6))
* stop request assembly writing into the agent's own config ([0730d73](https://github.com/google/adk-python/commit/0730d73cb183403dd1afe92393b9fbf513a9073d))
* strip markdown and typographic decoration from rubric text ([bf8388a](https://github.com/google/adk-python/commit/bf8388aaed968c11552977799899b242df1fdab2)), closes [#6072](https://github.com/google/adk-python/issues/6072)
* support fallback OAuth token and prefixless credential lookups ([f4e7233](https://github.com/google/adk-python/commit/f4e7233469e3595336dfb0d84c281b2f6245ce4c)), closes [#4712](https://github.com/google/adk-python/issues/4712)
* Support multi-content responses from agents within AgentTool ([e805872](https://github.com/google/adk-python/commit/e8058726c8735bc3f58c43f5ebf215d83a76e8cd))
* Support multi-content responses from agents within AgentTool ([544831c](https://github.com/google/adk-python/commit/544831c042640cf68a596c73551ed66e7e5c91fd))
* **telemetry:** mark failed tool spans as errors and fix provider naming ([6396ce6](https://github.com/google/adk-python/commit/6396ce60f9e3f6d6b20aaa3d108ed8094d9094dc))
* **telemetry:** summarize inline binary data instead of writing it to a span ([fbf5bd5](https://github.com/google/adk-python/commit/fbf5bd5fad4621bf4187c231846baedc90ea6d40))
* **test:** tolerate both click exit codes when a group is invoked without a subcommand ([bb9465b](https://github.com/google/adk-python/commit/bb9465bc486abf963f2d282016e860104d38b154))
* **tools:** recognize Context | None as the context parameter ([c457556](https://github.com/google/adk-python/commit/c4575560e6e58415a854e31ffbbcc2e36ac46f14))
* **tools:** stop gcs clients being shared across credentials ([3d29750](https://github.com/google/adk-python/commit/3d2975025bfecd5fe63f1669cf3336c7340f02ac))
* Update CI workflow to use uv and adjust codespell configuration ([566fca3](https://github.com/google/adk-python/commit/566fca3fa9ac35c812a3b9a1804a130d9b726ed4))
* use _GCLOUD_CMD for gcloud calls in GKE deploy on Windows ([f0b3ca6](https://github.com/google/adk-python/commit/f0b3ca601adee824d400ed555868155188e41535))
* Use official SDK for credential finalization in GCP auth sample ([6ccb837](https://github.com/google/adk-python/commit/6ccb83734ed22e79737406a54a9a205f3feed0ab))
* use typing.Optional in cleanup_unused_files to fix parse error ([cbedafd](https://github.com/google/adk-python/commit/cbedafd9e4c18d462dc571e1bb079177a496ef51))
* validate audio sample rates ([d24c84c](https://github.com/google/adk-python/commit/d24c84cdd90d8b2cc78f4162c42d14b53b8f37d6))
* validate skill name before building Agent Registry skill URL ([11101ac](https://github.com/google/adk-python/commit/11101acc681022d5b06e9ddcb99ca86f0e5c35e8))
* validate urls before computer use navigate opens them ([b0fff3f](https://github.com/google/adk-python/commit/b0fff3f02d0a4f573c3ef17d6afef4a483c1efdd))
* wire App plugins through eval paths ([73ecb5b](https://github.com/google/adk-python/commit/73ecb5b535a7fde3e604eeb1148442f9cc5699c4)), closes [#5503](https://github.com/google/adk-python/issues/5503)
* **workflow:** keep jittered retry delay within max_delay ([b333c85](https://github.com/google/adk-python/commit/b333c859084f9ca036887e42269a5543ade8c7e3))


### Performance Improvements

* avoid Pydantic deep-copy / dump-validate round-trips and precompile regex ([9e1adde](https://github.com/google/adk-python/commit/9e1addedfff7e35e95a2ad120c8b30fe543af04c))
* avoid quadratic streaming accumulation in the LiteLLM adapter ([36fd2c8](https://github.com/google/adk-python/commit/36fd2c8e0cf9dddec66bb0c109518cdc2fbdb3b6))
* drop use_attribute_docstrings from LlmCapabilities ([d42e222](https://github.com/google/adk-python/commit/d42e222c4f32763dcd2eaa4193a97b37d43abda1))
* improve adk import loading ([8806dc2](https://github.com/google/adk-python/commit/8806dc2bd8fb37004dee9ca50d9e774481f89afb))
* memoize the model adapter resolved from LlmAgent.model ([490946b](https://github.com/google/adk-python/commit/490946ba3234ce68a8ec33bf4093fd9597d1abdf))
* reuse one execute_sql function object across BigQuery toolsets ([bfe33b1](https://github.com/google/adk-python/commit/bfe33b1c4a4e6e2d6e393a60515d778a15cf1577))


### Documentation

* add a test-file placement rule to the testing style guide ([d64f1af](https://github.com/google/adk-python/commit/d64f1afb6284e3d26b8272f16d19a99be307a33c))
* add App unit guide ([d24ec83](https://github.com/google/adk-python/commit/d24ec83ccdc22cb79f635e86613ae35be622975d))
* add artifact service unit guide ([b8c099d](https://github.com/google/adk-python/commit/b8c099d37fdd938886f2b90a70316936a68d8ba7))
* add memory service unit guide ([aac410a](https://github.com/google/adk-python/commit/aac410a66f9282c3d6b2bc1bc85995cbd74fa4ab))
* add model registry unit guide ([2353dde](https://github.com/google/adk-python/commit/2353dde8e9081439d8d9f8358469ddf44ce997fc))
* add session State unit guide ([5a2a59b](https://github.com/google/adk-python/commit/5a2a59b74fe22dfafe8133a50858610da3997e03))
* add Session unit guide ([3df5a65](https://github.com/google/adk-python/commit/3df5a6519a626368aea4f7fd3e26fd5a56ba5477))
* add tool authentication unit guide ([78a4ee2](https://github.com/google/adk-python/commit/78a4ee2c69cadc025bf2aa7c7e98f90e6da31923))
* correct the list of built-in agent skills ([4cad8cc](https://github.com/google/adk-python/commit/4cad8cc958963ab2818d8f18de0643a3a04697fd))
* fix broken README links and publish the constraints files ([06111f1](https://github.com/google/adk-python/commit/06111f127bf01ba24bad468e4c7ccb2a82ede4bf))
* fix mcp sample link ([5647699](https://github.com/google/adk-python/commit/56476999931f2b32f8e112b4665cda32dac31b71)), closes [#6490](https://github.com/google/adk-python/issues/6490)
* note the adk web/api servers are unauthenticated and local-only ([76c64ef](https://github.com/google/adk-python/commit/76c64efd003f142e5374965d695e4792d1bcba7b))


### Miscellaneous Chores

* **deps:** move pyarrow out of the gcp extra ([ac71709](https://github.com/google/adk-python/commit/ac717091f6644f348c6f7e65a43cc0475a28fe45))
* release this candidate as 2.7.0 ([e22b75a](https://github.com/google/adk-python/commit/e22b75aac1b86c9d264cb3def4965df218acf471))

</details>

## [2.6.3](https://github.com/google/adk-python/compare/v2.6.2...v2.6.3) (2026-08-07)


### Bug Fixes

* gate --sandbox-launcher behind gcloud beta run deploy ([8120292](https://github.com/google/adk-python/commit/8120292dd108704f5ed071b30dab2e8f019078ff))

## [2.6.2](https://github.com/google/adk-python/compare/v2.6.1...v2.6.2) (2026-08-03)

### Bug Fixes

* **cli:** update gcloud command to use beta flag ([9630559](https://github.com/google/adk-python/commit/9630559830da28a187ba75ef1c26c64780dd7987))

## [2.6.1](https://github.com/google/adk-python/compare/v2.6.0...v2.6.1) (2026-07-30)


### Features

* add parent terminal grouping and TTL pruning to ADK CLI telemetry ([99bbd83](https://github.com/google/adk-python/commit/99bbd83ddac5f1ade93cdde1be98a1e3164e1da7))
* capture TTY connectivity in CLI environment telemetry ([c12a025](https://github.com/google/adk-python/commit/c12a025184cec7859d829d8ce7178ddbe3e2e302))


### Bug Fixes

* **cli:** implement early telemetry recording for long-running web servers and log successful exit code upon routine teardown ([77726c5](https://github.com/google/adk-python/commit/77726c55b33d6da1688a3d6893fe5e474d79116b))
* Stop re-validating already-consumed tool confirmations ([2b1204d](https://github.com/google/adk-python/commit/2b1204d0a0dd0d97f1e23f1188ea7366bfcb61e1))

## [2.6.0](https://github.com/google/adk-python/compare/v2.5.0...v2.6.0) (2026-07-29)


### BREAKING CHANGES

* **artifacts:** namespace file artifacts by app ([f72f0db](https://github.com/google/adk-python/commit/f72f0db58c5c1f4e8b8d4f04b8c592c9e49cbe9e))
* require patched async LangGraph runtime and update graph field type ([551372b](https://github.com/google/adk-python/commit/551372bcd88b21f38c2b68b4a9b9738484a9d0fd))


### Features

* **a2a:** support per-invocation auth headers when fetching agent cards ([3dd1156](https://github.com/google/adk-python/commit/3dd1156c33fe9e4857c467fbd16f209fb0ac5b4b))
* add --extra_packages option to `adk deploy agent_engine` ([93db97d](https://github.com/google/adk-python/commit/93db97db338fa72cf5b4fef8125552f30e614b57)), closes [#3936](https://github.com/google/adk-python/issues/3936)
* Add ADK evaluation samples: shared home-automation agent ([6ba41ef](https://github.com/google/adk-python/commit/6ba41ef35ea5fb83653d38b10ab67d2042805a61))
* add agent identity auth manager finalize endpoint for 3 legged OAuth flow with auth manager ([8d2ded3](https://github.com/google/adk-python/commit/8d2ded3bec122845d06eb7b6ad6ab99723ab8160))
* Add basic_criteria ADK eval sample ([fdebd9d](https://github.com/google/adk-python/commit/fdebd9d5635abd4e7aa607ac42292252128f0db3))
* Add bigquery-graph skill to ADK BigQuery tools ([f1a0a14](https://github.com/google/adk-python/commit/f1a0a1480bbcd3d6a23fbe75630303c9f8a9720d))
* add capability to log commands run in CLI ([a58220c](https://github.com/google/adk-python/commit/a58220cd05a671082b913fd4955613f806b2bd49))
* Add custom_metric ADK eval sample ([f71d9df](https://github.com/google/adk-python/commit/f71d9df9179a4d37a54051ffceb6dda5c821e4c4))
* Add llm_judge_match ADK eval sample ([0f0fa6b](https://github.com/google/adk-python/commit/0f0fa6bb4a6af4e16f88cd7283daab4451c03714))
* add metadata extraction symmetry to A2A converters ([3127f36](https://github.com/google/adk-python/commit/3127f368915eb6450dfd551914628ded0e58c610))
* add opt-in final_response_tool_names to BigQueryAgentAnalyticsPlugin ([07455ee](https://github.com/google/adk-python/commit/07455ee62cbd5c11625aed8c75380b88eba55e6d))
* Add ReflectAndRetryModelPlugin for self-healing model errors ([322f455](https://github.com/google/adk-python/commit/322f45591c61da6a15f404ba2e7d0fb520f16356))
* Add rubric_criteria ADK eval sample ([852a66a](https://github.com/google/adk-python/commit/852a66ad62a051beb2284517369fdd1d9e8dd4f0))
* add state_delta support to LiveRequest for live mode ([8219774](https://github.com/google/adk-python/commit/82197740a603e146ee35e0f18d2761a5c8f155d6)), closes [#4220](https://github.com/google/adk-python/issues/4220)
* add telemetry consent check, status commands, and interrupt safety to CLI ([6bab08f](https://github.com/google/adk-python/commit/6bab08fc803d26853417c4d6e71704b1a72e035e))
* Add telemetry consent configuration endpoints and local writing utility ([26f3d45](https://github.com/google/adk-python/commit/26f3d454c7c3346d4b0be406b24561940436b4a5))
* add telemetry metrics collection for ADK CLI execution ([2280f1c](https://github.com/google/adk-python/commit/2280f1cc5b7cc3c6ecf657273d92ea5fb4f5b439))
* Add test_file_vs_evalset ADK eval sample ([57a34ba](https://github.com/google/adk-python/commit/57a34ba77a1e98587d477fae5828bfcf7c0f7bf9))
* Add user_simulation ADK eval sample ([481fe21](https://github.com/google/adk-python/commit/481fe21cff0502f3e9c14861bd5f885b7f5969f9))
* **agents:** add instruction field to ManagedAgent ([720af3d](https://github.com/google/adk-python/commit/720af3d5c94708cb80294f2eafe9734cf92582ab))
* **agents:** forward ManagedAgent instruction as system_instruction ([49fdc26](https://github.com/google/adk-python/commit/49fdc26e40018a268da43803d555151dafe988b8))
* **eval:** Make live and audio evals reachable via public entrypoints ([5091f0a](https://github.com/google/adk-python/commit/5091f0a65acb963e0dd3f1db152c2a8d413dc9e4))
* **eventarc:** add Eventarc Advanced toolset for ADK ([217a90a](https://github.com/google/adk-python/commit/217a90a2e6c9725aeaac3dffedca8d63c25037fd))
* **eventarc:** add Eventarc Advanced toolset for ADK ([d4f157d](https://github.com/google/adk-python/commit/d4f157d2ed6fad21a6aa4c6e29e6133e3fe5db76))
* forward the OAuth2 nonce to the authorization request ([79cc1f2](https://github.com/google/adk-python/commit/79cc1f2970faeae7889a0f8b75bb2f5415cbe4eb)), closes [#2067](https://github.com/google/adk-python/issues/2067)
* **integrations:** add OCI Generative AI provider ([625ef1a](https://github.com/google/adk-python/commit/625ef1aa693ebb1980620be39c02d3ddd5154672)), closes [#5069](https://github.com/google/adk-python/issues/5069)
* make agent evaluation compatible with pre-loaded artifacts ([02e32a4](https://github.com/google/adk-python/commit/02e32a4d53e7e477453785818843ba8f085a318b)), closes [#2075](https://github.com/google/adk-python/issues/2075)
* make EventsCompactionConfig sliding-window fields optional ([ec42cfa](https://github.com/google/adk-python/commit/ec42cfa237bc2613f62759962454aed6dea43130)), closes [#6398](https://github.com/google/adk-python/issues/6398)
* Publish companion constraints-3.11.txt and constraints-3.12.txt file for transitive dependency protection (4 day buffer to protect from supply chain attack) ([75c773e](https://github.com/google/adk-python/commit/75c773ed9d2a369e69fb1ce387cf31983bf9450b))
* refresh expired OAuth2 tokens in OpenAPI credential exchanger ([b3c9783](https://github.com/google/adk-python/commit/b3c9783427b2d6cfad945bdb841396fb0a63c82f))
* **samples:** add ManagedAgent create-and-use custom-agent sample ([d86ae20](https://github.com/google/adk-python/commit/d86ae20c6a1d6a0ebddcf35f3ebd64eabbb4a56b))
* support audio generation user simulator ([327afeb](https://github.com/google/adk-python/commit/327afeb427fba2152814744a639d86e6561b2199))
* support serving a to_a2a agent under a path prefix ([1ae292f](https://github.com/google/adk-python/commit/1ae292fc9627f5991795c2a792f29b59c5559f57)), closes [#4448](https://github.com/google/adk-python/issues/4448)
* support user labels in RunConfig ([13bef9c](https://github.com/google/adk-python/commit/13bef9cf93e4b5a7e97362bc8514c9684cd2eb03))
* **telemetry:** add request-driven metric export for Agent Engine ([8930d9b](https://github.com/google/adk-python/commit/8930d9b19338873d091215a1e56f99ce6fd2060b))
* **telemetry:** derive gen_ai error.type from provider status code ([b956d15](https://github.com/google/adk-python/commit/b956d15ce5c58f1237154002f1755c33b4ed31ce))
* Update agent_registry to handle mTLS endpoints internally ([66cf08d](https://github.com/google/adk-python/commit/66cf08d1876b49168cf5ea67853a319e3d9eee56))


### Bug Fixes

* **a2a:** honor task cancellation instead of raising NotImplementedError ([fb55d4a](https://github.com/google/adk-python/commit/fb55d4a669e35fd9da69bbb951945d1a19792f9f))
* **agents:** await cancelled tasks in pre-3.11 ParallelAgent merge ([bc55099](https://github.com/google/adk-python/commit/bc550991b97e586c4bcca86facf3ad9dba049940)), closes [#5297](https://github.com/google/adk-python/issues/5297)
* **agents:** skip output_key processing on intermediate conversational text in task-mode LlmAgent ([54344ed](https://github.com/google/adk-python/commit/54344edfb95febc31ba2b80f5578205208f1efa1))
* allow invocation-level rubrics ([67ab27f](https://github.com/google/adk-python/commit/67ab27f2547db48f7248b1689aab4c18502aee17))
* assemble only the current turn ([c328cec](https://github.com/google/adk-python/commit/c328cec9462ac6a5459f19e6fb548c5b2e40cd39))
* bound integration HTTP waits ([bf4143a](https://github.com/google/adk-python/commit/bf4143ac2269d3a23c4abc680c3a39f727db21bd))
* bypass Protobuf Gencode/Runtime version check in antigravity integration ([91038f2](https://github.com/google/adk-python/commit/91038f2ba4b48b8916f58ab56a695b516222044c))
* **caching:** prevent prompt cache invalidation when using dynamic tools ([509be09](https://github.com/google/adk-python/commit/509be09d342decab5abca29345aec3a187956c41)), closes [#3227](https://github.com/google/adk-python/issues/3227)
* Call mtls.should_use_mtls_endpoint with client_cert_available argument ([b315b00](https://github.com/google/adk-python/commit/b315b0024a903b91f7c8fa971eb4621133c47845))
* canonicalize context cache fingerprint for stable hashing ([425dda1](https://github.com/google/adk-python/commit/425dda190457bffb159a1373e30ea396eba5f536))
* **ci:** mark imported PRs as merged even if already closed ([2eca8b1](https://github.com/google/adk-python/commit/2eca8b11ceb890614370c64a2ad56a0164059c97))
* **cli:** treat agent folder with subfolders as single agent in adk web ([40cf97b](https://github.com/google/adk-python/commit/40cf97bf2ce11b581e7b0409af299910b52773ea))
* close A2A response stream when the caller stops consuming ([31392ba](https://github.com/google/adk-python/commit/31392bad27b911d78a3de124f03a372227777878))
* close AsyncDaytona client in DaytonaEnvironment.close ([ecf6d13](https://github.com/google/adk-python/commit/ecf6d13f64d6df4b0860c1b32643d12cc1c0d381))
* collect all tools so native tools aren't dropped ([c429d75](https://github.com/google/adk-python/commit/c429d7549d3780227630bac764c42f1627b981ae)), closes [#6091](https://github.com/google/adk-python/issues/6091)
* derive an SDK-conforming Antigravity conversation id ([64b758a](https://github.com/google/adk-python/commit/64b758ae8e2e325e830a2a112c18f3c1cc87635c))
* do not mount a cluster credential into the GKE code sandbox ([8207880](https://github.com/google/adk-python/commit/8207880101292bdf1037cb3bfdf90d3a3691ce0c))
* emit only new artifact parts on streaming artifact updates ([088be86](https://github.com/google/adk-python/commit/088be86040bd486cf42eae561e77b3b0ad979688)), closes [#6343](https://github.com/google/adk-python/issues/6343)
* emit resumability checkpoints from workflow graph nodes ([cecc1f9](https://github.com/google/adk-python/commit/cecc1f98d5837de3157a606e7a6409fece5deefc))
* **eval:** support `get_agent_async` in `adk eval` ([ebaef9f](https://github.com/google/adk-python/commit/ebaef9f63291cb77b3ea54918cbb8a5b7926862a))
* **evaluation:** support non-English responses in ROUGE-1 matching ([8200fae](https://github.com/google/adk-python/commit/8200faec6d42c10e5c3cf5f9613bcb6bd5d51240))
* guard multimodal tool results plugin against empty contents ([5a248de](https://github.com/google/adk-python/commit/5a248de58f80c4b6574e5d0bd10838964f478218))
* handle Windows paths in `adk eval` ([6f6106f](https://github.com/google/adk-python/commit/6f6106f672d26596f909bd555e954825ba4044b4)), closes [#6415](https://github.com/google/adk-python/issues/6415)
* harden A2A metadata serialization and parser type validation ([eee700a](https://github.com/google/adk-python/commit/eee700a01696cabb42583611766806de2d8574be))
* include credential failure details ([13c7272](https://github.com/google/adk-python/commit/13c727291098947d8f44c532cd9b76a588a016cd))
* isolate delegated task branches ([95feafa](https://github.com/google/adk-python/commit/95feafa3b23dbcce19c287cf749a2076fb9c5db9)), closes [#6457](https://github.com/google/adk-python/issues/6457)
* let httpx set the multipart boundary Content-Type ([3367b5b](https://github.com/google/adk-python/commit/3367b5bf72e2117c7e766c27ef4e35a33172affb))
* make InvocationEvent.content optional so the Web UI can save eval cases ([b549ab4](https://github.com/google/adk-python/commit/b549ab41c906a1746e316788c2bd9366efb1cc0d)), closes [#6336](https://github.com/google/adk-python/issues/6336)
* make ParallelWorker concurrent failure exceptions deterministic ([d31b5e7](https://github.com/google/adk-python/commit/d31b5e7dcec3b1c8da8c35ad9a1d14d046f56cc3))
* match rubric verdicts by echoed id so paraphrased rubrics are not dropped ([0b7355b](https://github.com/google/adk-python/commit/0b7355baa385270cf0be59e601dc7c1e898980c4)), closes [#6171](https://github.com/google/adk-python/issues/6171)
* **memory:** honor Vertex RAG top-k configuration ([d4d2f6e](https://github.com/google/adk-python/commit/d4d2f6e600590e80b4880313dbeb7ea5bacafdc1))
* **memory:** make Vertex RAG uploads async-safe ([80a05b7](https://github.com/google/adk-python/commit/80a05b7f639216c8bf60a870598f0d44efcba339))
* migrate v0 event timestamps as local time, not UTC ([6f1efe7](https://github.com/google/adk-python/commit/6f1efe7b2a70cef00ef89de6ea3690f0914b692f))
* **models:** capture Anthropic thinking-block signatures during streaming ([bb56aa5](https://github.com/google/adk-python/commit/bb56aa56f79da843d50e0c01637f97e7f26435a2))
* **models:** guard Gemini.client_kwargs against missing-field AttributeError ([df02689](https://github.com/google/adk-python/commit/df0268921cb8662fd4984e6ca40577b0953a083a))
* **models:** populate finish_reason on AnthropicLlm responses ([716be89](https://github.com/google/adk-python/commit/716be893d201c25859c44cc0cab5b060c2977021))
* narrow broad except in agent identity credential providers ([0598c9b](https://github.com/google/adk-python/commit/0598c9ba26e543b0a090b0e869eac3badea81c1e))
* percent-encode context id fields so ids with separators round-trip ([fab5347](https://github.com/google/adk-python/commit/fab5347f56413d8b28b0d023fc56274e9bf9701c))
* pin third-party github actions to commit shas ([4e16855](https://github.com/google/adk-python/commit/4e16855e0d6038d0e0011e3c1855deff314e5fef))
* **plugins:** complete BigQuery Agent Analytics privacy and shutdown hardening ([9adf011](https://github.com/google/adk-python/commit/9adf0113ea7adb14044f010cbe1366f6eab53565))
* **plugins:** correct lazy import path for ReflectAndRetryModelPlugin ([c59fd0e](https://github.com/google/adk-python/commit/c59fd0ed4f603305f3401ca0b9068b8274748925))
* **plugins:** harden BigQuery agent analytics against fail-open privacy, GCS concurrency, and startup-loss gaps ([2919bf5](https://github.com/google/adk-python/commit/2919bf5b8d426f9a74bd5bd4e4a8a7927b3170bd))
* **plugins:** restore failure counter properties on retry tool plugin ([66a7233](https://github.com/google/adk-python/commit/66a72337b3c8b366636cfbf09655569edc4122c0))
* guard finish_reason on Anthropic LLM responses against null values ([802a079](https://github.com/google/adk-python/commit/802a0793f0b1233d4b02c8037db3ebe927ab8b66))
* populate function name in FunctionResponse parts ([540cfdf](https://github.com/google/adk-python/commit/540cfdf737fd878f87b57b00894fbfc58b97feaa))
* present client certificate and use mTLS endpoint for API Hub calls ([2cf5433](https://github.com/google/adk-python/commit/2cf543322b397c865701b432ed6fd9867db187b0))
* preserve ADK behavior on Windows ([6e9895c](https://github.com/google/adk-python/commit/6e9895c55cdc5b3b39a336c6c999bc1731273cdc))
* preserve explicit false and zero OpenAPI query parameters ([b3abcb2](https://github.com/google/adk-python/commit/b3abcb2b28ccda194fd0499c9f32a6a783b6fde4)), closes [#6287](https://github.com/google/adk-python/issues/6287)
* preserve metadata in A2A artifact updates ([2316b83](https://github.com/google/adk-python/commit/2316b83468b6fa99405d8ee5c2fba4174846c466))
* Prevent `adk deploy` from uploading `.adk/session.db` file ([dab351b](https://github.com/google/adk-python/commit/dab351beca00ef4e735f5bca0b72dd10be5bf69f))
* Prevent continuation forgery in tool confirmation ([4b002c4](https://github.com/google/adk-python/commit/4b002c4b56e0b5fa83a0d989ef7663fbedf23211))
* prevent transfer_to_agent loop on resumable invocation replay ([19df9b9](https://github.com/google/adk-python/commit/19df9b9b9b9153a2e1fcf3c96bb15f86a22835d7))
* propagate custom metadata from RunConfig to InvocationContext ([79ba5af](https://github.com/google/adk-python/commit/79ba5aff17cf1203b6d4b0948e493802847dfae8))
* raise SessionNotFoundError when appending to a missing session ([0a70337](https://github.com/google/adk-python/commit/0a70337f29fd76dba18da6b82e072621d60f9117))
* register custom metrics from eval config in LocalEvalSampler ([79a879f](https://github.com/google/adk-python/commit/79a879f5833a223d3d3f0e78abc2fc6c5da8c1fa)), closes [#6177](https://github.com/google/adk-python/issues/6177)
* reject base_url and extra_body in generate_content_config ([472e463](https://github.com/google/adk-python/commit/472e4635fb4014f7ed2c77db7c2b97f17bbd45bf))
* reject incomplete evaluation inputs ([8ca9128](https://github.com/google/adk-python/commit/8ca9128a6397389c171625fb6ac0475c516ccfae))
* resolve tool confirmation resumption failure in production ([c427020](https://github.com/google/adk-python/commit/c4270203c657d4abb14188b90ed692465f1f36c9))
* respect A2A Message.role in inbound event conversion ([968845f](https://github.com/google/adk-python/commit/968845fd5c9a8c60535f0d32cf14ea4db9c56c5e)), closes [#5186](https://github.com/google/adk-python/issues/5186)
* return empty list from _get_required_fields when no properties ([1890557](https://github.com/google/adk-python/commit/1890557584f58ec5094344a501e5041ef041694d)), closes [#5920](https://github.com/google/adk-python/issues/5920)
* scope replay sequence to the current invocation ([455853b](https://github.com/google/adk-python/commit/455853b5bca2dad68923a9100f9ba945845ad6d0)), closes [#6497](https://github.com/google/adk-python/issues/6497)
* scope the tool thread pool to its event loop ([a1792a7](https://github.com/google/adk-python/commit/a1792a712ae6b90dee4fecdee79cf0ddff1b5609))
* serialize eval criteria as their concrete subclass ([623da49](https://github.com/google/adk-python/commit/623da4930a43cbaa5386a096c5a54266bae02522))
* serialize raw bytes as base64 in A2A converters ([e6604e1](https://github.com/google/adk-python/commit/e6604e1d2109261bb548975b0897b76dd3fcc8b2))
* **sessions:** apply after_timestamp and num_recent_events together in VertexAiSessionService ([021f6f6](https://github.com/google/adk-python/commit/021f6f6c1e6b55f71e2144ec5857820cd010b6e4))
* share one event id across the partial chunks of a streaming response ([8f98bcd](https://github.com/google/adk-python/commit/8f98bcd513df19aa67b0ac6ba2607f2bb1cb4695)), closes [#1006](https://github.com/google/adk-python/issues/1006)
* single-flight Discovery Engine mode detection ([3a9a88c](https://github.com/google/adk-python/commit/3a9a88c975117a8cfde1ef9d920a978eb4ffe701)), closes [#6101](https://github.com/google/adk-python/issues/6101)
* stop automatic function calling from failing on Vertex AI return types ([268815d](https://github.com/google/adk-python/commit/268815df6427b7cb0dc08f18dc8c51ab96ce0c1b)), closes [#3543](https://github.com/google/adk-python/issues/3543)
* stop tracing credentials passed via config.http_options ([761f1ac](https://github.com/google/adk-python/commit/761f1ac75d0479e21d9f3386189d0b54990d05b4))
* strip markdown code fences before validating output_schema JSON ([28c649a](https://github.com/google/adk-python/commit/28c649a466c660635ab1ed8de163b5d294c3be00))
* support nested agent paths in dot_adk_folder resolution ([d33ca5f](https://github.com/google/adk-python/commit/d33ca5fa7cd92d330d48e9e4b0ea1c3d280c557b))
* surface sub-agent RPC errors from AgentTool ([e737f22](https://github.com/google/adk-python/commit/e737f22957b671000c60a690ebfaee68d3ca6f34))
* tolerate a malformed traceparent header in the span processor ([de2e66e](https://github.com/google/adk-python/commit/de2e66e9836512aabe0431ee0c1c8169e0fc271a))
* **tools:** bind JSONDecodeError in ToolConnectionAnalyzer.analyze ([a60d5b9](https://github.com/google/adk-python/commit/a60d5b95227bb63198e247acee880ea8b4f4cbd1))
* treat GitHub content as untrusted in the adk_team sample agents ([f4979b5](https://github.com/google/adk-python/commit/f4979b5c78be9d709a29a7aa4175b31864fba7e6))
* wait for in-flight BigQuery writes ([6e43800](https://github.com/google/adk-python/commit/6e43800fcb9263c9debdb570dab837bce6f51f31))
* **workflow:** fix task agent resumption in nested workflows ([fd006db](https://github.com/google/adk-python/commit/fd006db9153fe6c51f281f36e35b40d243e5fca0))
* propagate tool_choice to LiteLLM ([550189c](https://github.com/google/adk-python/commit/550189ce4f3cc1e69a108b1f38ba6c31f2f40e65))


### Performance Improvements

* avoid quadratic text/audio accumulation in streaming ([7fd8760](https://github.com/google/adk-python/commit/7fd876027049f86a4a580a56c45373c8e2908e24))
* cache the FunctionTool declaration across LLM calls ([57f3af2](https://github.com/google/adk-python/commit/57f3af24a00de46096089bd3279791a6a98b5c48))
* **import:** lazy-load heavy dependencies ([88b388e](https://github.com/google/adk-python/commit/88b388ecde41950d9bd9ac886df23a17a366ca2a))
* **tools:** avoid double Schema serialization in Optional/Union dedup ([6264576](https://github.com/google/adk-python/commit/6264576784dd2e265b2092c759989db60162e34e))


### Documentation

* Add developer unit guide for ReflectAndRetryToolPlugin ([94832a5](https://github.com/google/adk-python/commit/94832a515161b97689a940e95f9f1119b3dd637c))
* **agents:** add system-instruction sample and guide section ([597fac3](https://github.com/google/adk-python/commit/597fac3a4fa370a41df377cef023e571edac30c3))
* document creating and using a custom managed agent ([52c3e9e](https://github.com/google/adk-python/commit/52c3e9eb60f9f087f01e97de52cddcd031f4b93a))
* document workflow resumability model and direction ([d4804e2](https://github.com/google/adk-python/commit/d4804e20843f831c19a1f02afc4d2796138c36f4))
* explain how an accepted pull request lands ([b6c2575](https://github.com/google/adk-python/commit/b6c257572bedfbe6e48902b351b23b48f6fb1779))
* fix broken relative links in documentation ([096ecfc](https://github.com/google/adk-python/commit/096ecfcf56ad47a9a63da1d76a062f56d7586692))

## [2.5.0](https://github.com/google/adk-python/compare/v2.4.0...v2.5.0) (2026-07-16)


### Features

* add Cloud Run sandbox option in code executors ([5b1088a](https://github.com/google/adk-python/commit/5b1088acbefb7eb55488ed9ebf90683f24bfe54a))
* Add search agents and search MCP severs to agent registry ([ed579c1](https://github.com/google/adk-python/commit/ed579c1304cf7ad4c16868323632e6350f462548))
* add skill to verify markdown code snippets ([c0fa51b](https://github.com/google/adk-python/commit/c0fa51b33f3e32812f307caa2ac3c5c2425c5224))
* Add strict input schema validation for LlmAgent workflow nodes ([6f66814](https://github.com/google/adk-python/commit/6f66814e194994a9ab38cf3959a1d8f53cae3d89))
* add to_mcp_server to serve an ADK agent over MCP ([50ff37f](https://github.com/google/adk-python/commit/50ff37f8b027f5147f0baf5906414e7ac6163b9e))
* **agents:** add single_turn mode field to ManagedAgent ([da50578](https://github.com/google/adk-python/commit/da50578bc5833c76eb96bc8f005fc9e5e5c154e7))
* **agents:** bridge node_input to user_content for ManagedAgent nodes ([a680cea](https://github.com/google/adk-python/commit/a680cea874fcf0496df9697be5962dbedde70d42))
* **agents:** support remote MCP servers for ManagedAgent with runtime header callbacks ([2e2ec09](https://github.com/google/adk-python/commit/2e2ec09a760b5cb956082526296450842da28487))
* **agents:** wrap single_turn non-LlmAgent sub-agents as inline tools ([fc98549](https://github.com/google/adk-python/commit/fc985492447a133cbbd7d90bf34cb849b445a26b))
* **bigquery:** log tool descriptions and parameter schemas in LLM_REQUEST ([ecef5f8](https://github.com/google/adk-python/commit/ecef5f859f050c206efab93a9a200cad6d75d62d))
* enable a2a-sdk 1.x by widening the dependency constraint ([b46dd13](https://github.com/google/adk-python/commit/b46dd136aafe0f1ed5b269b7e3c92055726a5125))
* **live:** allow Voice activity detection (VAD) events to be returned ([820a910](https://github.com/google/adk-python/commit/820a910ef860c42b519b7c3519c5b1065a172a52))
* **live:** Run non-blocking tools in a background task ([5620d8f](https://github.com/google/adk-python/commit/5620d8f4f16864a68d04187f31ac0a0d532a3efa))
* **plugins:** add on_agent_error_callback and on_run_error_callback ([7d0ae63](https://github.com/google/adk-python/commit/7d0ae63ab13ad68dc1558a3a2c40c18baa531386))
* Support HITL resumption for standalone nodes and NodeTool ([00760f8](https://github.com/google/adk-python/commit/00760f84556cacef6fb24fc12a24075fd617f558))
* Support LoadArtifacts parsing for binary text documents (e.g., DOCX) ([ccbedd8](https://github.com/google/adk-python/commit/ccbedd80c2b8c55f4d80b4324f8bb23ea48d6996))
* Validate that no old orchestrators are used inside Workflow graphs ([7e245c4](https://github.com/google/adk-python/commit/7e245c48c278e96d6064b0475c7b0b4fe01d033b))
* Validate that no old orchestrators are used inside Workflow graphs ([eaffb0e](https://github.com/google/adk-python/commit/eaffb0ec64ed0d73013ffe0aa2ebf08682559a26))
* **workflow:** Support state-based resumption for task-mode agent workflow nodes ([9d306f5](https://github.com/google/adk-python/commit/9d306f5d322eccbc5022ac72407fa8a994f64cf6))


### Bug Fixes

* Add mTLS support for for API registry ([41693dc](https://github.com/google/adk-python/commit/41693dce67f5e8c39802db2fff75e7c6d8c876f0))
* Add mtls support for gcp_utils ([3fa993b](https://github.com/google/adk-python/commit/3fa993bf82b7dd9f8334d84ea492adad5a477bfe))
* Add support for list_artifact_versions and get_artifact_version to ForwardingArtifactService ([61ba59a](https://github.com/google/adk-python/commit/61ba59a23f06d78bbd5ed49bac918787e2739066))
* avoid crash on first turn with empty user content ([c9bacd4](https://github.com/google/adk-python/commit/c9bacd40ee4f8ad9951d543b240ce3f2f59ebb42))
* Avoid shell execution in ReadFileTool ranged reads ([1ac6875](https://github.com/google/adk-python/commit/1ac68752ad30563e17d3cbf40e667df3c8df850a))
* block posix, nt, _posixsubprocess, and _socket modules in agent config validation ([faa1744](https://github.com/google/adk-python/commit/faa174425453b7adc1243c5217a2a40e13b4f031))
* **cli:** Block special internal agents in ApiServer mode ([3f6eb1f](https://github.com/google/adk-python/commit/3f6eb1f0a1884a9c04cc34c0c57c7b9d8665bf2f))
* confine docs-agent file tools to the managed repos directory ([f00fc5a](https://github.com/google/adk-python/commit/f00fc5a329f2ff58c34ded1f27a0a1daa89ce0d4))
* decode shell skill output as UTF-8 ([b7ad76a](https://github.com/google/adk-python/commit/b7ad76a28dfbdc3bcab71e9e81aaa546ebd287be))
* **environment:** add integer validation in ReadFileTool ([3c0fb65](https://github.com/google/adk-python/commit/3c0fb65caa989b6d48ba78cb55ec3a15f476c6f8))
* exclude LiteLlm llm_client from JSON serialization ([ecbefd9](https://github.com/google/adk-python/commit/ecbefd9547839752ab8d28146a51bad7dd6833f1)), closes [#6164](https://github.com/google/adk-python/issues/6164)
* exclude rewound invocations from event compaction ([0d4d378](https://github.com/google/adk-python/commit/0d4d3783f7825a620c95a7b9dca919db790b879f))
* explicitly preserve language and tools during event compaction ([b44d2c9](https://github.com/google/adk-python/commit/b44d2c9d6c381e44a9a24727fe973fc94d572854)), closes [#6273](https://github.com/google/adk-python/issues/6273)
* Fix InputTokensDetails validation in OpenAI responses test and formatting in a2a_agent_executor ([99ea228](https://github.com/google/adk-python/commit/99ea228f0068de94a2a540929b83b3e16fa17897))
* Fix sub-branch event routing for nested sub-agents and tools in InvocationContext ([3cdc102](https://github.com/google/adk-python/commit/3cdc102204696e2dd9c92ece66daee4c5b1010ca))
* GitHub CI for the verify-snippets skill ([ccc8ab4](https://github.com/google/adk-python/commit/ccc8ab4efb86d03cf4cb7a5b63c0ca67e1406618))
* grow eligible Gemini cache prefixes ([98fc036](https://github.com/google/adk-python/commit/98fc03690b5fb611b11072a354061dd10a886c50))
* guard decode_model against non-dict session values ([8c60d99](https://github.com/google/adk-python/commit/8c60d99a5267eca02d01365982837bc16f4d292c)), closes [#6348](https://github.com/google/adk-python/issues/6348)
* handle sqlite float timestamps in PreciseTimestamp ([2da09e6](https://github.com/google/adk-python/commit/2da09e60d7d03d27bf9aa721db37cf0475157c21)), closes [#6352](https://github.com/google/adk-python/issues/6352)
* honor server-reported Gemini cache expiry ([4fdc94c](https://github.com/google/adk-python/commit/4fdc94c79185f13db9f8c20870add6b611a235c3))
* **litellm:** preserve reasoning replay and optionally share agent thoughts ([6290aec](https://github.com/google/adk-python/commit/6290aec5cefea5ebc362eb74b5a73897e9b73d41))
* **litellm:** preserve signature-only blocks for Anthropic streaming thinking aggregation ([78d1957](https://github.com/google/adk-python/commit/78d1957a0d877ab976d44599cafd304632adc043))
* make agent and run error callbacks best-effort so they never mask the original error ([2f48ad3](https://github.com/google/adk-python/commit/2f48ad3f0e4721e25d31641d564415c1d0f51e29))
* make discussion answering model configurable ([de4ac2d](https://github.com/google/adk-python/commit/de4ac2d93f4bde068e7b68fa5e01cd552f14a33d))
* match HF-style gemma-4 model names for tool_responses role ([4930155](https://github.com/google/adk-python/commit/49301558dcdc767b3844eec928d5c3457645301a)), closes [#6334](https://github.com/google/adk-python/issues/6334)
* **models:** Allow context caches with empty content prefixes ([ee7174d](https://github.com/google/adk-python/commit/ee7174da1fc1101f16b1b4f067d9beb2bc0a1de7))
* **models:** forward request headers on google_llm interactions path ([b5a3e34](https://github.com/google/adk-python/commit/b5a3e34f2dd973736b3197c0024c62cfb901452e))
* preserve non-ASCII characters in agent input ([7006e33](https://github.com/google/adk-python/commit/7006e33e98f8e5b84414a6588d911c2280fb287b)), closes [#6279](https://github.com/google/adk-python/issues/6279) [#6282](https://github.com/google/adk-python/issues/6282)
* preserve non-image file MIME type in LiteLlm content conversion ([065234e](https://github.com/google/adk-python/commit/065234e27973d4af0084cbac1db3d21561ba6e66)), closes [#4174](https://github.com/google/adk-python/issues/4174)
* Prevent continuation forgery in tool confirmation ([c03f333](https://github.com/google/adk-python/commit/c03f333769feaeaa9fe8910fbe95cb9f2d513f54))
* prevent model bypass in resumable mode by rejecting user-authored function calls ([283e92e](https://github.com/google/adk-python/commit/283e92efc2297246ff6f70ceb220b9b299aa2d67))
* prevent synchronous code executors from blocking the event loop ([585809c](https://github.com/google/adk-python/commit/585809cf98838fb64b076400fe5bfbe92f8543ad)), closes [#6353](https://github.com/google/adk-python/issues/6353)
* recover a compacted sibling's latest response, not its placeholder ([0bd7ea0](https://github.com/google/adk-python/commit/0bd7ea05d6d8459f9648b201afbf34ee6b39d903))
* recover compacted function calls during prompt assembly ([0c517e7](https://github.com/google/adk-python/commit/0c517e767efc8661f6d1667db4a4a565ef2cc1d7)), closes [#5602](https://github.com/google/adk-python/issues/5602)
* remove OpenTelemetry event logger setup since the Events API/SDK has been deprecated and is soon being removed entirely ([bb3b2a4](https://github.com/google/adk-python/commit/bb3b2a47f887bd3ae0b2f363cb38c27a9f012fe5))
* repair two broken contributing samples ([ee3a381](https://github.com/google/adk-python/commit/ee3a3815a16795402242c5c620bb83c6e49b27bd))
* require starlette&gt;=1.3.1 to clear known CVEs ([221bad9](https://github.com/google/adk-python/commit/221bad92b8ed659fc0d34c610d5b3bc469e0bac5)), closes [#6038](https://github.com/google/adk-python/issues/6038)
* Resolve scheduler leakage and make scheduler instantiation explicit ([ce2e4ca](https://github.com/google/adk-python/commit/ce2e4caf147ebcc8e6a7bb9997e6e961f626807b))
* Resolve scheduler leakage and make scheduler instantiation explicit ([d4f0772](https://github.com/google/adk-python/commit/d4f0772f5d94e5887fe465c98e0c5b1730b633d8))
* Retain user input across transfer_to_agent when include_contents='none' ([ad5445a](https://github.com/google/adk-python/commit/ad5445a1bdf6a2b9e79ebdb706b0410490feef90)), closes [#3535](https://github.com/google/adk-python/issues/3535)
* Return 404 instead of 500 when app_name does not match any agent ([f4decf6](https://github.com/google/adk-python/commit/f4decf61d134a782482c184ca2a5c2f864aaf5a1)), closes [#5374](https://github.com/google/adk-python/issues/5374)
* return MCP tools in stable sorted order for cache stability ([2aba05c](https://github.com/google/adk-python/commit/2aba05cff814e664d7ed3520000f453fcc810473))
* reuse current-step tool resolution ([3164504](https://github.com/google/adk-python/commit/3164504f649168e3ff87de9657260fcc8e88dee6))
* reuse fetched session and honor get_session_config on chat path ([81306bb](https://github.com/google/adk-python/commit/81306bbbd442d4b09dc7afb26a7dcf98e01a2168))
* rollback of path segment validation in InMemoryArtifactService and GcsArtifactService ([961f3e8](https://github.com/google/adk-python/commit/961f3e885c68385d67823885897f1c5690ff5b4c))
* **samples:** Fix monitor_video_stream in live bidi streaming sample ([7c11f58](https://github.com/google/adk-python/commit/7c11f5861fabc1f963d99ec213118c1460c374b3))
* scope Gemini cache identity ([8de4237](https://github.com/google/adk-python/commit/8de4237e18bc7a6a8bed3f252bca7d1b15ddbec9))
* **sessions:** prevent PydanticSerializationError when session state contains non-serializable objects ([757ef22](https://github.com/google/adk-python/commit/757ef22435970df8816222f8091046948af2c4d3))
* shield toolset cleanup from cancellation ([a69ba4f](https://github.com/google/adk-python/commit/a69ba4fa74e87f3dc742f3cfaece6cff1cc86eee))
* snapshot events under lock in InMemoryMemoryService.search_memory ([aeccd3b](https://github.com/google/adk-python/commit/aeccd3bb2cf76058cf9be82bc33927d2d70c8fbc)), closes [#6167](https://github.com/google/adk-python/issues/6167)
* Support passing credentials to GCPSkillRegistry ([c441ab2](https://github.com/google/adk-python/commit/c441ab2763b871db5e66048944d179bdf76bc56e))
* support unencrypted workload certificates for mTLS in GoogleApiToolset ([d831ee6](https://github.com/google/adk-python/commit/d831ee6e76d390a2a32d1733afee428ae3cba450))
* **telemetry:** add 0 bucket boundary to per-invocation call count histograms ([c291821](https://github.com/google/adk-python/commit/c2918211f82a84f91f8ee852e1b90a225f17f0b2))
* **test:** correct polling timeout unit test in IAM Connector credentials provider ([4448117](https://github.com/google/adk-python/commit/4448117076c97a164f5aad5037236a7c6f02fadc))
* Update GCP Skill Registry to use agentregistry/skill endpoint ([fa884e3](https://github.com/google/adk-python/commit/fa884e3d028e2809526dc732592a6b5b944a8c17))
* Update VertexAiRagMemoryService methods to use latest RAG module ([96d2914](https://github.com/google/adk-python/commit/96d2914339ade4409b2366b80a0668ca8001aedb))
* Validate path segments in GcsArtifactService and InMemoryArtifactService to prevent cross-user artifact access ([45a77dc](https://github.com/google/adk-python/commit/45a77dc514f1e151c08e32f7c9a94b0a222eea36))
* Validate path segments in GcsArtifactService and InMemoryArtifactService to prevent cross-user artifact access ([8718aef](https://github.com/google/adk-python/commit/8718aefff01d3ad37a4f9de73ca6abfdb3bb452e)), closes [#6115](https://github.com/google/adk-python/issues/6115) [#6116](https://github.com/google/adk-python/issues/6116)
* **workflow:** Process all completed tasks in batch before exiting on error ([8db2ace](https://github.com/google/adk-python/commit/8db2ace37308c15d59d40d1b8c3b8dc30eb64cfd))
* **workflow:** treat RetryConfig(max_attempts=0) as no retries ([3b3f127](https://github.com/google/adk-python/commit/3b3f127d8fdd3189c2527edc128e64375b5f5f88))


### Performance Improvements

* lazy-load ManagedAgent to keep the interactions API off startup ([995628c](https://github.com/google/adk-python/commit/995628c9e2b2449b37d4a146e9d014d073932023))
* **litellm:** track brace depth incrementally for streaming tool-call args ([e5fdb51](https://github.com/google/adk-python/commit/e5fdb51e7ca8ac964e75c0458567f88a37c0b7be))
* Optimize workflow rehydration performance with indexing ([64a7448](https://github.com/google/adk-python/commit/64a7448fc6e05f37e6dedadd6c0e65bc19264057))
* skip disabled request-log formatting ([cba2827](https://github.com/google/adk-python/commit/cba28271b4bd0de3201b468578f3cb3da6113a5f))
* skip non-recording LLM trace work ([0c63a89](https://github.com/google/adk-python/commit/0c63a892e2d4bdae4cdf33a5bde21e4266e03371)), closes [#4233](https://github.com/google/adk-python/issues/4233)


### Documentation

* add to_mcp_server unit guide ([534e8d5](https://github.com/google/adk-python/commit/534e8d50cc275e717b21b8a950df5439e251dc76))
* Fix token exceeded error on ADK release analyzer's final summary agent ([989af4d](https://github.com/google/adk-python/commit/989af4d81eea05befb33348deb0b604bc483ee75))
* **guides:** Add ManagedAgent unit guide ([ab839d5](https://github.com/google/adk-python/commit/ab839d51d338e8231a79e0e65aec5d9a3fd896b4))
* **guides:** note single_turn works for non-LlmAgent agents ([26ed6fe](https://github.com/google/adk-python/commit/26ed6fe382881fe6c8e9caaf31f9b0a6c655389b))
* **samples:** add ManagedAgent remote MCP (Maps Grounding Lite) sample ([cc444b6](https://github.com/google/adk-python/commit/cc444b6cbf0e60f2c2b5d4f1f7ae5d6fda03fc0e))
* **samples:** Add ManagedAgent single-turn sub-agent sample ([57e1ba6](https://github.com/google/adk-python/commit/57e1ba66ee5f762e22cf5aa727f10fea3485a572))
* **samples:** Link ManagedAgent sample READMEs to the guide ([3834c0b](https://github.com/google/adk-python/commit/3834c0bdb65476661ad2b2c939ed19cba2a3fcd6))
* **samples:** Remove NOT WORKING YET comments from workflow samples ([f3f602f](https://github.com/google/adk-python/commit/f3f602f1fa7ee4d6822b68e798ae09b145d898c5))
* simplify sample graph guidance in adk-sample-creator skill ([27edb1a](https://github.com/google/adk-python/commit/27edb1afdca5b32d050915f5c45b8a812045994f))
* **skills:** Add coding conventions and state lifecycle rules to style and architecture guides ([367ab9a](https://github.com/google/adk-python/commit/367ab9aeaeb1ef869e5d7d18d96c1452420447e5))
* **tools:** encourage using mode='single_turn' in AgentTool and document manual artifacts configuration ([a9b4276](https://github.com/google/adk-python/commit/a9b4276447453a85bffc2cdd35561f2e44779d06))
* **tools:** recommend mode='single_turn' in AgentTool docstring ([f4072a4](https://github.com/google/adk-python/commit/f4072a4d38fd3dcbdcb694b3276ff672e8ce3653))
* Update models owner for ADK PR triaging agent ([b8a1dab](https://github.com/google/adk-python/commit/b8a1dabf9ed3ab8119249403a507fa49202c4a4c))

## [2.4.0](https://github.com/google/adk-python/compare/v2.3.0...v2.4.0) (2026-07-07)


### Features

* Add mTLS support for DiscoveryEngineSearchTool ([8ba0e6a](https://github.com/google/adk-python/commit/8ba0e6aa657107f4e959051cd56e71fff16b9eaa))
* Add mTLS support to Google API tools ([3466586](https://github.com/google/adk-python/commit/3466586bab018fcb275ed125888803ba971b4520))
* add OpenAI Responses API support in labs ([6b831d5](https://github.com/google/adk-python/commit/6b831d5aa0e39b75f69df87746f073bfd66a60a0)), closes [#3209](https://github.com/google/adk-python/issues/3209)
* Add support for reusing an existing SQLAlchemy AsyncEngine in DatabaseSessionService ([f4c7e4c](https://github.com/google/adk-python/commit/f4c7e4cac30954ebe703be21d0219c38b729689a))
* add support for session TTL and expiration in Vertex AI session service ([49d4441](https://github.com/google/adk-python/commit/49d4441ebd4b715919c52ea15319df0abdff9609))
* add Anthropic `effort` config handling, thinking parameter propagation, and conflict mitigation ([4c862b9](https://github.com/google/adk-python/commit/4c862b9660679caa1a24bb05f7f91500bcf8af58))
* **agents:** add ManagedAgent backed by the Managed Agents API ([cf91b84](https://github.com/google/adk-python/commit/cf91b8443fffca4561668a424f80e9c3feee2a78))
* **bigquery:** expose thinking and tool-use token columns in analytics views ([c14258d](https://github.com/google/adk-python/commit/c14258dffc77804f638f5abbeb434d979ec3149b))
* **bigtable:** Support parameterized views with secure parameter inj… ([14a24f2](https://github.com/google/adk-python/commit/14a24f2beeb8583d98c5b1b1933e82652751e0aa))
* HTTP traces for MCP server requests/errors ([4c4f77a](https://github.com/google/adk-python/commit/4c4f77ae39f7c98591b9469e70a145d08a170151))
* Implement Workflow as Tool core feature ([1263ed6](https://github.com/google/adk-python/commit/1263ed64e30805464fff3391554f65ebbf72746b))
* **integrations:** Add DaytonaEnvironment for remote sandbox workspaces ([df6baf4](https://github.com/google/adk-python/commit/df6baf4acf5f91a2c038834a0881608d02b1abff))
* **interactions:** stream thought, media, code-exec and function-result deltas ([b2dda6e](https://github.com/google/adk-python/commit/b2dda6eb6cf9b0ef38824787f542d6f2bc0ed444))
* **interactions:** surface streamed grounding and final usage metadata ([6a50b8d](https://github.com/google/adk-python/commit/6a50b8d17f618e1241b94eab58d38e10e16a9d81))
* **memory:** add Vertex AI load_profiles tool ([fb2b3af](https://github.com/google/adk-python/commit/fb2b3afea11fc2b1c0d22bb2cfca28370ccf8122))
* **models:** Add configuration options to Gemini class ([037ec12](https://github.com/google/adk-python/commit/037ec127e4adfce70dfe8772e10921209439c061)), closes [#3813](https://github.com/google/adk-python/issues/3813)
* **models:** surface and recover environment_id from interactions ([81f9f2e](https://github.com/google/adk-python/commit/81f9f2ecaa2272a5461ead62e7b5ef2b7a222f04))
* **plugins:** add otel correlation, custom_metadata allowlist, and column projection to BigQuery analytics ([38d715c](https://github.com/google/adk-python/commit/38d715cbae2ab160ea1833baa3eebd8c3c93120f))
* **scripts:** add check for private-by-default new Python files ([63561ce](https://github.com/google/adk-python/commit/63561ce7192faa77cc0abb45b29f07f512cfbb9c))
* support file_data URI references in GcsArtifactService ([43115b2](https://github.com/google/adk-python/commit/43115b222b2a9d7a58bab9fe3d0fe54aa5a1a583))
* support mTLS and GOOGLE_API_USE_MTLS_ENDPOINT for GDA client ([e85a7b2](https://github.com/google/adk-python/commit/e85a7b28df66c4e47cdf32cf8c981d3918d68bcc))
* Support passing dynamic custom headers to LiteLLM via RunConfig ([000d74d](https://github.com/google/adk-python/commit/000d74da704f4185a9de4e33423f3b46e8a4df67))
* Support provider-prefixed Gemini model IDs ([816a87f](https://github.com/google/adk-python/commit/816a87f35615edecc3a52335ab539d4ae8d62848))
* **tools:** add response_scheduling to control Live function response behavior ([7443bfa](https://github.com/google/adk-python/commit/7443bfaed1356b22adce7e741a94490667b7374d))
* **tools:** exposed configurable parameter as property in McpToolset ([cca8c56](https://github.com/google/adk-python/commit/cca8c5678d1066221f881debe7751ae08b84ab02))
* **tools:** resolve built-in tools for managed-agent requests ([f11d19d](https://github.com/google/adk-python/commit/f11d19d25b8a706dd9741e47da5fb80a146aad14))
* **tools:** Support tuple tool parameters ([a57c3e4](https://github.com/google/adk-python/commit/a57c3e4bfb8d21ace1337476b700b811f3c57cde))
* **utils:** Add support for nested state access in template injection ([94c43a2](https://github.com/google/adk-python/commit/94c43a269dcf6691556d38aef46360f04f736584))
* **workflow:** Allow ToolNode to accept JSON string or Content inputs ([4e44632](https://github.com/google/adk-python/commit/4e4463248b170664759d801f49131110e1b6c980))


### Bug Fixes

* adapt interactions conversion to google-genai 2.9 SDK changes ([9f3aeef](https://github.com/google/adk-python/commit/9f3aeef55dd5c300618dd1be11393644fd672630))
* Add credential_key to ApplicationIntegrationToolset and IntegrationConnectorTool ([c6a94b8](https://github.com/google/adk-python/commit/c6a94b8b2bec9d7089bcd102c5911df0ed980c41)), closes [#4553](https://github.com/google/adk-python/issues/4553)
* Add debug level logging to mcp sse agent sample ([3962d0b](https://github.com/google/adk-python/commit/3962d0bca88c056c1165db8c469f341107f2aeab))
* add DNS-rebinding protection to _OriginCheckMiddleware ([9a4f479](https://github.com/google/adk-python/commit/9a4f479d9fdce9d1d7830a9df40ba59fe01088ea))
* add module blocklist for YAML agent config code references ([6a5be34](https://github.com/google/adk-python/commit/6a5be34bed12614f549f1a0d948b4bd281b775a6))
* add parameter validation for sync tools in ADK functions.py ([9b9d27d](https://github.com/google/adk-python/commit/9b9d27dae37cf2cb131c0308604444540a7d85cc))
* add trailing newline to check_new_py_files.sh ([21512ea](https://github.com/google/adk-python/commit/21512ea13cbe988404ad0a10b1ae6919faa10928))
* Address mypy failures in google_api_tool/ ([5301ffa](https://github.com/google/adk-python/commit/5301ffa2c71833b2cbf93a023e4ceaf9a748f320))
* **agents:** persist `output_key` when `before_agent_callback` short-circuits LlmAgent ([0e263f1](https://github.com/google/adk-python/commit/0e263f1b5effa374fae5e3609359f1db6c5a960e))
* **agents:** preserve text streamed before tool calls in output_key ([5a0b4af](https://github.com/google/adk-python/commit/5a0b4af5c459fe4b740465e889536a5b080ce80f))
* **agents:** prevent path traversal in AgentTool config_path resolution ([171ae9e](https://github.com/google/adk-python/commit/171ae9e7bef6cee5a39121a9ecd2a3e2298d9c9d))
* **ApplicationIntegrationTool:** implement dynamic mTLS endpoint resolution ([37ca6fb](https://github.com/google/adk-python/commit/37ca6fbeee6b8f206dc206178ed7a5b60ecfc1be))
* apply run_config custom_metadata to user event in node runtime ([066fbce](https://github.com/google/adk-python/commit/066fbce224a8e8166018d719143ec1f45c163b1b))
* **artifacts:** Preserve .text on GcsArtifactService load ([ba51ff2](https://github.com/google/adk-python/commit/ba51ff2e0ee1918c0fd235a8b90708609b901d1b)), closes [#3157](https://github.com/google/adk-python/issues/3157)
* **auth:** allow configuring OAuth prompt parameter ([ac99770](https://github.com/google/adk-python/commit/ac99770646a7112c6f53797ddf5d7f14dadf223b))
* **auth:** strip redirect_uri from credential_key ([ffa1843](https://github.com/google/adk-python/commit/ffa184395136c366bf498324191d43d7afb86df5))
* avoid mutating event validation input ([6b385e4](https://github.com/google/adk-python/commit/6b385e47ffebcd694078d2856fda7a2b8e69e2ce))
* Avoid overwriting existing isolation scope in stamp_event_branch_context ([798207a](https://github.com/google/adk-python/commit/798207aeacaf4f9348c76c35f538b7541b07f849))
* avoid yielding a None function-response event in live mode ([4d88a52](https://github.com/google/adk-python/commit/4d88a5227f7624a2a07bebd7fe23ad86b1d57c10))
* catch RecursionError in safe JSON serialization helpers ([5515800](https://github.com/google/adk-python/commit/551580058dd492c1bcca47c7698da90fea599ccc)), closes [#5411](https://github.com/google/adk-python/issues/5411)
* check if transfer target is a sibling agent ([fa18d26](https://github.com/google/adk-python/commit/fa18d26ae58f9f1309ef7c6a21c2f16feed63172))
* **ci:** Restrict GitHub Actions to main/v1 branches and main repository ([8c4173e](https://github.com/google/adk-python/commit/8c4173ee5c4ddf453b35987aebf0ed2d39a2fc05))
* **cli:** detailed error message on sse stream specifying stacktrack (error type on client side as well) ([56b84e1](https://github.com/google/adk-python/commit/56b84e1e3ee8328b53f059b2ff17a7785c47b455))
* **cli:** enable interspersed option parsing for cloud_run command ([7b049b9](https://github.com/google/adk-python/commit/7b049b9e534d3a2de7237d518ecda07f39f71412))
* **cli:** Ensure ADK compatibility in agent engine requirements ([ea772b9](https://github.com/google/adk-python/commit/ea772b93b9db5b613699bfd03d230749f43332f3)), closes [#5966](https://github.com/google/adk-python/issues/5966)
* **cli:** respect ignore files in adk deploy commands ([ee79e71](https://github.com/google/adk-python/commit/ee79e7129cb9b6295a24405525e929dcf2d98f90))
* **cli:** support flat-module agents in _determine_agent_language ([7a553b7](https://github.com/google/adk-python/commit/7a553b79541739c2911274b486827ae758163e57))
* concatenate list values in deep_merge_dicts during parallel tool call merge ([fda2347](https://github.com/google/adk-python/commit/fda23474bc6803d0a07652f137467e203da44b47)), closes [#5190](https://github.com/google/adk-python/issues/5190)
* concatenate list values in deep_merge_dicts during parallel tool call merge ([1ff84eb](https://github.com/google/adk-python/commit/1ff84ebb83245079dcf9c5f979ccd4f18e8c03f5)), closes [#5190](https://github.com/google/adk-python/issues/5190)
* Constrain artifact references to the caller scope ([f863150](https://github.com/google/adk-python/commit/f8631500c7e46b3ce417fdc47a483cfcf4032c7a)), closes [#6124](https://github.com/google/adk-python/issues/6124) [#6125](https://github.com/google/adk-python/issues/6125)
* correct misleading workflow-agent deprecation messages ([53a8ab1](https://github.com/google/adk-python/commit/53a8ab167fb2eb3fdd0507f08a81498b328a8411))
* Derive sandbox reasoning engine from template or snapshot name ([5afa9db](https://github.com/google/adk-python/commit/5afa9db61d1a989b484fd49441af493b5957d9af))
* drop nonexistent log_query tool from session_state_agent sample ([ade8577](https://github.com/google/adk-python/commit/ade8577745bda23588bc0ac71f93a9d3343ec80a))
* emit standard OTel cloud.resource_id for Agent Engine telemetry ([8fc25f1](https://github.com/google/adk-python/commit/8fc25f1eecb0d1c51f02d5cb621638d2641b2a8d)), closes [#6247](https://github.com/google/adk-python/issues/6247)
* Enable history_config on Vertex AI now that it is supported ([2920145](https://github.com/google/adk-python/commit/292014516b9896ccd0624b4f937ebe246f205652))
* enforce agent-config args denylist when loaded under adk web ([e506fa6](https://github.com/google/adk-python/commit/e506fa6ba03b83f894e2771e6172087e02efad73))
* ensure AgentTool text output when skip_summarization is True ([b983fcf](https://github.com/google/adk-python/commit/b983fcf9033b385e3120bc6e03b6106b332f700d)), closes [#3881](https://github.com/google/adk-python/issues/3881)
* exclude live HTTP clients from trace serialization ([59868ea](https://github.com/google/adk-python/commit/59868ea8e76ba2007655a79e3d2d6060ade63590))
* exclude scripts/ from pre-commit compliance checks ([c91fc75](https://github.com/google/adk-python/commit/c91fc752a5fa2680d41064461f3fb3a5675372da))
* exit connection cleanly on expected GoAway signal in bidi streaming ([4d165ef](https://github.com/google/adk-python/commit/4d165efbfffac2006a58c26aba35e9544a6ed9f5))
* fingerprint cacheable context prefix ([7c7f1e7](https://github.com/google/adk-python/commit/7c7f1e706ab04474c3c992473f21939404c9720a))
* **firestore:** preserve update timestamps in list_sessions ([99ba8ce](https://github.com/google/adk-python/commit/99ba8ce2d976ef93864aa956a6eb0e1ec407cb03))
* Fix branch parsing and unify branch stamping ([9e3b43f](https://github.com/google/adk-python/commit/9e3b43fc9245dbfc927271cb6252b15db6efa3db))
* Fix Code Generation Template Injection via Filenames ([e042b8d](https://github.com/google/adk-python/commit/e042b8df227335cbb8b3b65016779cf4e636df29))
* Fix error swallowing in MCP session context ([ccb8138](https://github.com/google/adk-python/commit/ccb8138eca5ca5776b4a1310207f23838d20989b))
* Fix event loop closed and thread leak errors in unit tests ([2f2e03b](https://github.com/google/adk-python/commit/2f2e03b4acf573ecf25fcd5a906cbe78225bf450))
* Fix instructions_utils matching invalid nested paths ([20ba01c](https://github.com/google/adk-python/commit/20ba01c2caf8e29140d790fa988c3605f309c798))
* Fix MCP debug client factory compatibility with keyword-only factories ([1ad8864](https://github.com/google/adk-python/commit/1ad88641b931656b368f1263aed301cc5609f13b))
* fix polling loop in IAM Connector Credentials Provider when consent is pending ([a614507](https://github.com/google/adk-python/commit/a614507b8eae2786195809ca6fdf357cd3c657b1))
* Fix regression in instructions_utils placeholder matching ([9ecbaed](https://github.com/google/adk-python/commit/9ecbaed5d61513d698fb5a10e04ab2e92bd577e7))
* Fix Vertex AI Live API session replay on reconnect / modality switch ([c007a87](https://github.com/google/adk-python/commit/c007a87468ba3db805d60a2b56460b56870402b0))
* guard against None converter results in RemoteA2aAgent ([23ff66e](https://github.com/google/adk-python/commit/23ff66e213e38226169911237fc6a775ef31af76))
* guard against None converter results in RemoteA2aAgent handlers ([2e3d717](https://github.com/google/adk-python/commit/2e3d717c5d418df0b5de902d69635dc6e3dcaf6f))
* guard user_content assignment against None in EvaluationGenerator ([6bc9c9f](https://github.com/google/adk-python/commit/6bc9c9fb78ae0edeecde02fe24e2879f9a96c676))
* Handle empty message in LiteLLM response ([d3e793f](https://github.com/google/adk-python/commit/d3e793ff924e07e6b4379607a3c7ce1f3d304fb0))
* handle Pydantic models in safe_json_serialize for tool tracing ([25d666a](https://github.com/google/adk-python/commit/25d666a7eb8844d1105f41ba844afe108130a427)), closes [#4629](https://github.com/google/adk-python/issues/4629)
* harden ContainerCodeExecutor sandbox by default ([0a9ce0f](https://github.com/google/adk-python/commit/0a9ce0f691d2ac3960359962453259a5e2ec9f60))
* implement dynamic mtls endpoint resolution for parameter manager ([62b9700](https://github.com/google/adk-python/commit/62b97007378c4da749a1615d0881aba443a32325))
* implement dynamic mtls endpoint resolution for secret manager ([5d4a13f](https://github.com/google/adk-python/commit/5d4a13f1ce4395ed6ee9c1bad39558c5661fddaf))
* import App lazily in _resolve_app to fix legacy Runner NameError ([7481d07](https://github.com/google/adk-python/commit/7481d07e84d1efd5ef757f619fbf4dccad4b6f7f))
* in mcp mtls logic, check for authorization header case insensitively ([3870032](https://github.com/google/adk-python/commit/38700324134f8d392a577f0cda78e4c4400e69d2))
* LiteLLM Claude thinking blocks with display: "omitted" were lost ([7461863](https://github.com/google/adk-python/commit/7461863ee142a6e9b03e212ae4dd7281bd4c52bf))
* Litellm preserve streamed reasoning deltas in LiteLLM adapter ([b9625bf](https://github.com/google/adk-python/commit/b9625bfd709282b96c259f3c8136beb4c79955eb))
* **litellm:** parse DeepSeek-V3 proprietary inline tool-call tokens ([c5b2caa](https://github.com/google/adk-python/commit/c5b2caad2d866ea03093f3303b3e96f569d88cba))
* **LiteLlm:** recognize assistant- prefix as valid OpenAI file ID ([ea325c7](https://github.com/google/adk-python/commit/ea325c7b3c4503a62e4f2d6d44e4f6984e522e6d)), closes [#5664](https://github.com/google/adk-python/issues/5664)
* **LiteLlm:** recognize assistant- prefix as valid OpenAI file ID ([796964a](https://github.com/google/adk-python/commit/796964ac49047838e47dc923852d99cf682f162c))
* **live:** fix the return type hint of handle_function_calls_live ([9865e2b](https://github.com/google/adk-python/commit/9865e2bc9ec6f6356435d50a8658fa347d100186))
* **live:** forward thinking config ([71d8c84](https://github.com/google/adk-python/commit/71d8c8422afee21f25684baf595661eefb7d65f8))
* **live:** keep streaming tool yields from completing turns ([07aa1e0](https://github.com/google/adk-python/commit/07aa1e09e2c2b3aebd9c3457f30e57b9f9b167b7))
* Make EUC request args JSON-serializable ([a181a39](https://github.com/google/adk-python/commit/a181a395f24fbf24366724ea4d3b8d3f5ab11509))
* map A2A Message.role to correct GenAI content role ([fe08a9f](https://github.com/google/adk-python/commit/fe08a9fb5a4dca38d5c7ed606cbce1d6731ce0ac))
* **mcp:** await async MCP header providers ([c01e538](https://github.com/google/adk-python/commit/c01e5380206b55428d4a20ea16a1fa7cfbc8e5db)), closes [#6090](https://github.com/google/adk-python/issues/6090)
* **mcp:** propagate trace context in default streamable HTTP client ([431e3c2](https://github.com/google/adk-python/commit/431e3c2e2033b72950570b023eb45fd08e761cec)), closes [#4768](https://github.com/google/adk-python/issues/4768)
* migrate AgentRegistry base URLs from v1alpha to v1 ([82432a3](https://github.com/google/adk-python/commit/82432a317ac56dea597a6e81b756b70f122f504d))
* **models:** gate Gemini cache creation on cacheable prefix tokens ([1070036](https://github.com/google/adk-python/commit/10700363978c739005690b5055bbdb036f0e3d6e))
* N sized sliding window ([d00ad67](https://github.com/google/adk-python/commit/d00ad67e4055d2747ce0729853ade29279075139))
* preserve Anthropic thinking blocks and signatures in LiteLLM round-trip ([febb250](https://github.com/google/adk-python/commit/febb250bf240dad9b791a0c9ed8f8971e96b30ab))
* preserve JSON-native types in A2A _serialize_value() ([139c700](https://github.com/google/adk-python/commit/139c700de6c79b3764cd578efafe9f3b618ccfb0)), closes [#5183](https://github.com/google/adk-python/issues/5183)
* prevent crash when parsing default values for typing.Any parameters ([e360241](https://github.com/google/adk-python/commit/e360241b8beaaf7112593aa2fe0cf35e2d3a4bfe))
* prevent empty responses after load_skill ([7c79230](https://github.com/google/adk-python/commit/7c79230980cdc941cb222b2c2d7246f5ea1fe0be))
* prevent VertexAiRagRetrieval from blocking the event loop ([5898f37](https://github.com/google/adk-python/commit/5898f37a90a78338a87f3d895d815b12c1c32ef2)), closes [#5033](https://github.com/google/adk-python/issues/5033)
* prevent warning logs when cancelling MCP session runner task ([4aa0fd8](https://github.com/google/adk-python/commit/4aa0fd8df4d93f6b2ab8c79373cde08f2cf3a9f7))
* propagate Gemini grounding metadata from ModelResponse ([c303c62](https://github.com/google/adk-python/commit/c303c623ba5608887ee766baf6bb5e6ad373feac))
* raise ValueError for unsupported MIME types in file_data URI path ([42eceb3](https://github.com/google/adk-python/commit/42eceb3a59628a6beadd53fa6eff217fc383c9d9))
* reconnect on live connection 1011 error ([f36d257](https://github.com/google/adk-python/commit/f36d2573195c172be1062ffb4c079a7cea597a92)), closes [#5525](https://github.com/google/adk-python/issues/5525)
* recurse into JSON-native containers in A2A _serialize_value() ([c08debc](https://github.com/google/adk-python/commit/c08debc93fa540a1c181918da9d19825470d02a3))
* refactor `_redact_file_uri_for_log` to dynamically extract file ID prefixes (`file-`, `assistant-`). This ensures compatibility with both current prefixes and future OpenAI/Azure file ID types. ([ea325c7](https://github.com/google/adk-python/commit/ea325c7b3c4503a62e4f2d6d44e4f6984e522e6d))
* remove unit test with wrong assumption about claude thinking parts ([94fcdbb](https://github.com/google/adk-python/commit/94fcdbb8573940e1a9acec60b4cac9beab51b334))
* remove unused userinfo_endpoint from GoogleApiToolset OIDC config ([1509dcf](https://github.com/google/adk-python/commit/1509dcf3f4b9d8383fe3f596984623ddfb51b2cb))
* restore auth_token initialization for secret and parameter manager clients ([46a2181](https://github.com/google/adk-python/commit/46a2181761ece50ca23ee95509574bf5acd9a6c0))
* Rollback instruction util refactoring as its breaking internal customers ([59fe9b3](https://github.com/google/adk-python/commit/59fe9b3bb83277f23f39ed0e71e392b4306ebe83))
* sandbox nested persona template rendering in evaluation prompts ([30493ba](https://github.com/google/adk-python/commit/30493bae56f62dddb8adde249e9cd0654882bd05))
* scope single-turn node inputs to workflow branch ([8d389e2](https://github.com/google/adk-python/commit/8d389e233b747de9c09192b07f158caa7f9fb908))
* **security:** enable Jinja2 autoescape to prevent XSS in gepa sample ([a721c1e](https://github.com/google/adk-python/commit/a721c1eb3433bd2764bed68733b4f475ff7b7c67))
* send correct field names for sandbox input files ([2b7e08a](https://github.com/google/adk-python/commit/2b7e08a5e190eebc1b82e224eac3632cf5dfe063))
* **sessions:** drop unsupported part_metadata before Vertex appendEvent ([40a0279](https://github.com/google/adk-python/commit/40a02795707d131487c24e2f5321e43505b0a273)), closes [#6014](https://github.com/google/adk-python/issues/6014)
* **sessions:** strip tzinfo for MariaDB in DatabaseSessionService ([2f799d5](https://github.com/google/adk-python/commit/2f799d5196ad04c322f51f5dc084400558f29b41))
* Set persist-credentials to false in release-update-adk-web workflow ([79b8923](https://github.com/google/adk-python/commit/79b8923679524516b15295865636cd469a854dd9))
* strip tzinfo from datetime for MySQL in create_session ([a012bb7](https://github.com/google/adk-python/commit/a012bb7542d481538ad9162993c63ad73259b357))
* surface error for empty STOP model turn in non-streaming mode ([932a9b5](https://github.com/google/adk-python/commit/932a9b5615055672bedc482fbeb1e7f05acc9a9c)), closes [#5631](https://github.com/google/adk-python/issues/5631)
* **telemetry:** always export Agent Engine logs to stdout ([e6df097](https://github.com/google/adk-python/commit/e6df0979da56f1c344d7c213d9522b4c9cca56eb))
* **telemetry:** emit gen_ai.workflow.nested for nested workflows ([20197de](https://github.com/google/adk-python/commit/20197de92931dafa53726c8aef042ba893537826))
* terminate infinite retry loop in RunSkillScriptTool on SCRIPT_NOT_FOUND ([89d9bda](https://github.com/google/adk-python/commit/89d9bda72e412f04730e6836726282c54180a756)), closes [#5684](https://github.com/google/adk-python/issues/5684)
* **tools:** accept dict output_schema in SetModelResponseTool ([#5469](https://github.com/google/adk-python/issues/5469)) ([d69dedd](https://github.com/google/adk-python/commit/d69deddb1302775f812ed044ac6ba8a4a0685b14))
* **tools:** handle tuple schemas in function parsing fallback ([4fa7741](https://github.com/google/adk-python/commit/4fa774192ad0971074d95577368304f0f0ddb655))
* Truncate MCP http debug logs if greater than 1000 chars ([3ebef82](https://github.com/google/adk-python/commit/3ebef82a52f2b650d1ee1f94dbdeeb31fbd0ae10))
* Update custom gemini llm connection logic to be used for all 3_x models, not just 3.1 ([8aff514](https://github.com/google/adk-python/commit/8aff5141e3b22f273d685e2967f57ffa5a5197d1))
* update litellm dependency constraint to &gt;=1.84.0 ([a912306](https://github.com/google/adk-python/commit/a912306ad79fb100646a8b81082bcf9fe21d2e58))
* update mtls_utils import in secret_client.py ([0b79f8d](https://github.com/google/adk-python/commit/0b79f8da4ca7ee06405cfc7ccfec8925b8210e96))
* use branch-scoped events for auth responses ([f706a1e](https://github.com/google/adk-python/commit/f706a1ec7d11baad1620cf819a75f606d2a3c97a))
* use exchanged OAuth credential in ApplicationIntegrationToolset ([e76df3d](https://github.com/google/adk-python/commit/e76df3d4d1991836b78c1666a8f1218683c5d6c2))
* use Modality enum for RunConfig.response_modalities ([5c8c55a](https://github.com/google/adk-python/commit/5c8c55a7632f2388fea7af37cddba54714f84eb1))
* use mTLS endpoint for Google OAuth2 token requests ([ffe41f0](https://github.com/google/adk-python/commit/ffe41f050c147d5bff91b065b61df14c471b3bd6))
* Use RELEASE_PAT for checkout in release-update-adk-web workflow ([28b7721](https://github.com/google/adk-python/commit/28b77212588a018ffd081b995f92776ba1556509))
* validate local eval path segments ([7b87f91](https://github.com/google/adk-python/commit/7b87f910cd69b22d8a7d6ea2a0ec5fcd403fb000))
* Wrap math formulas in `math` blocks in retry config guide ([a40f199](https://github.com/google/adk-python/commit/a40f19930f90cd144a282dc1f5af6b425876bcb3))


### Performance Improvements

* avoid deepcopy of session contents when building LLM requests ([400f512](https://github.com/google/adk-python/commit/400f512d812a0c92ebee5d13b5e7448516a55eae))
* create SQLite session schema once per service instance ([10a2cc5](https://github.com/google/adk-python/commit/10a2cc5d78609c59102c718ca3f162d3e64418d8))
* remove state injection when instruction has no placeholders ([59970b6](https://github.com/google/adk-python/commit/59970b610962ccc9869d1256339163664d526bd1))
* skip event query in DB get_session when num_recent_events is 0 ([7e8191a](https://github.com/google/adk-python/commit/7e8191aec68d4e0512d7d05e2bbe0559111c2832))


### Documentation

* Add manual batch mode trigger for ADK Pull Request Triaging workflow ([dbd4bb0](https://github.com/google/adk-python/commit/dbd4bb07d0cd396f74c1558b6e9459f6e87a4ce9))
* clarify is_final_response() is a public helper ([978be4b](https://github.com/google/adk-python/commit/978be4b13359fc38e8385dcf3bac0cc8156750f2)), closes [#4016](https://github.com/google/adk-python/issues/4016)
* fix typo in per-turn user simulator quality prompt ([9a79fa1](https://github.com/google/adk-python/commit/9a79fa1e3117c6392ad0aa3a33ac57ac3e127c62))
* index missing reference guides in adk-agent-builder SKILL.md ([c922b08](https://github.com/google/adk-python/commit/c922b08212b58e3b67e26cc15aea2e9d1ba2b46d))
* remove trailing whitespace in dynamic_nodes guide ([a7377b4](https://github.com/google/adk-python/commit/a7377b446abc6879f75d27fbd3e9c5293f6a8d06))
* **samples:** Add ManagedAgent code-execution sample ([527e3c1](https://github.com/google/adk-python/commit/527e3c1089ab13ad6f8ef2aee9f05cb823d726e7))
* **samples:** Add ManagedAgent sample using server-side google_search ([969909f](https://github.com/google/adk-python/commit/969909f2ba30c3483feae18f6d585e24e03b2610))
* Sort PRs by update time in list_untriaged_pull_requests ([8679aa8](https://github.com/google/adk-python/commit/8679aa8e955afec20312493357ca3cd379f358dc))
* Streamline open_source_workspace/AGENTS.md ([ea2ea73](https://github.com/google/adk-python/commit/ea2ea7390504970a710743295c09ee45525c0317))
* Update ADK Pull Request Triaging Agent workflow to run periodically ([b3f278a](https://github.com/google/adk-python/commit/b3f278a692b51a0d138d355607bbd6c11ba1fae0))
* update GoogleSearchTool docstring to refer to Gemini models ([8b011f9](https://github.com/google/adk-python/commit/8b011f9ec93d115580f98e48cca2f0f9b7db6b88)), closes [#12345](https://github.com/google/adk-python/issues/12345)
* Update sample-creator skill with agent topology graph rule ([7423101](https://github.com/google/adk-python/commit/7423101f64b82f3d838231898751702ec2e18f9c))
* **workflow:** Add and update workflow developer guides ([e5c7d20](https://github.com/google/adk-python/commit/e5c7d20d5d93fc495d95f162f393c00e0357f8c9))

## [2.3.0](https://github.com/google/adk-python/compare/v2.2.0...v2.3.0) (2026-06-17)


### Features

* Add async and concurrency guidelines to ADK Style Guide ([66e00db](https://github.com/google/adk-python/commit/66e00db095edcc9ac9045d2c88a7a62d8b4537be))
* add create_http_options to ContextCacheConfig for cache creation timeout ([ffc9677](https://github.com/google/adk-python/commit/ffc9677154e37aa51ddc7ff760c3b25929b68aaa)), closes [#4703](https://github.com/google/adk-python/issues/4703)
* add GCS first party toolset to ADK integrations ([fb19e1a](https://github.com/google/adk-python/commit/fb19e1a15537083f34baa798f90a79504de6e95b))
* Add log_level option for adk run CLI ([1ac69a9](https://github.com/google/adk-python/commit/1ac69a9033d470d24a7d801dd035224dc0987cad))
* Add mTLS support in AgentRegistry client ([03671c6](https://github.com/google/adk-python/commit/03671c63f09cc7db6ae71bcfe8e93f3e2babf0f0))
* add request timeout to load_web_page ([792775f](https://github.com/google/adk-python/commit/792775f1378eaa00b02739b30ebe1a2b55481aed))
* **core:** migrate core and CLI to enterprise parameters ([68221f0](https://github.com/google/adk-python/commit/68221f05b14a9a93f8ccb83896d544f338b3e1f2))
* Create GEPARootAgentOptimizer ([654145a](https://github.com/google/adk-python/commit/654145a7e92c57c15728fe394a72e15e8c4889af))
* **eval:** expose user_simulator_config in generate_responses ([e7a673c](https://github.com/google/adk-python/commit/e7a673ccd0d01b35edb6563d109d472f91d8fc63))
* **gemma4:** support Gemma4 in Gemini ([573f043](https://github.com/google/adk-python/commit/573f04344dc943c59de9afe39c698b81de556d7a))
* **integrations:** Add E2BEnvironment for remote sandbox workspaces ([92d608f](https://github.com/google/adk-python/commit/92d608f83e68df7237796f6691de1b3e8751880b))
* **labs:** add experimental Antigravity SDK agent wrapper ([4cb27fd](https://github.com/google/adk-python/commit/4cb27fd42e5cb748d6351b4f061e5bab7c88733c))
* lazily initialize the Vertex AI client in GCPSkillRegistry, and fix the import path for `vertexai` ([65dca53](https://github.com/google/adk-python/commit/65dca53a088d601043d7caa0810e9d1a836ce0b1))
* **live:** Handle input transcription differently for Gemini Live 3.1 models ([048deea](https://github.com/google/adk-python/commit/048deeaeb73d002f75dcaf8c37716542daa4eca1))
* **live:** support Live API translation config in RunConfig ([463040f](https://github.com/google/adk-python/commit/463040fdca4ca9cfe8883f591134ace6e1827eb5))
* Migrate McpToolset to AsyncAuthorizedSession for mTLS support ([fe497a4](https://github.com/google/adk-python/commit/fe497a4f5d3c2176f0b9418e0cc3e658d1a8fd29))
* **plugins:** ADK 2.0 minimum producer cut for the BigQuery Agent Analytics plugin ([e2676fc](https://github.com/google/adk-python/commit/e2676fcbe67c730468e7c2905ca50dd29bf442a4))
* report cached token counts for Anthropic and OpenAI models ([b15c8a0](https://github.com/google/adk-python/commit/b15c8a0fe19ae937d832bb0410a8639da2d86cdf))
* **telemetry:** support per-request OpenTelemetry configuration ([abcaa08](https://github.com/google/adk-python/commit/abcaa08bd69412f2ac9e7a43597947ef71c24e0d))
* Update gcp_auth client UI to support Remote Agents ([57bdecf](https://github.com/google/adk-python/commit/57bdecfcb10df92a738f0652ea5782e5d4e984c7))
* **utils:** add GOOGLE_GENAI_USE_ENTERPRISE env var with deprecation fallback ([4e85e9c](https://github.com/google/adk-python/commit/4e85e9c33511a89b850ca9dea89ca7a8cc929dde))


### Bug Fixes

* **a2a:** Preserve execution metadata in final events ([e90b119](https://github.com/google/adk-python/commit/e90b11958d9ec6eeb1ba58e75646984a99beec12))
* **a2a:** render HITL interrupt when prompt is in a data part ([b9e7fca](https://github.com/google/adk-python/commit/b9e7fcade13ef3f2774ff8bde135e3aa107cf58d))
* **a2a:** set final=True for error TaskStatusUpdateEvent in event_converter ([5efe53d](https://github.com/google/adk-python/commit/5efe53dff40e82e7d2b6eeaa2ba61b36fe98152c))
* **a2a:** suppress part_metadata in Vertex AI mode ([065f4ae](https://github.com/google/adk-python/commit/065f4aed46e65152ee0487f76a60668d855ff3d5))
* add a2a as a required dependency for agent_engine deployment ([d2ebacb](https://github.com/google/adk-python/commit/d2ebacb9d7e0f8597bdcbde845e6f5c536c352b7))
* **adk:** propagate exceptions from run_node in standalone mode ([63841c3](https://github.com/google/adk-python/commit/63841c33331267fb5d38aef52a9e40723d3802be))
* **adk:** propagate isolation_scope to prevent history filtering loops ([f39d75b](https://github.com/google/adk-python/commit/f39d75b99e83a539c29ac4ef81a61ec33c188858))
* **agents:** await cancelled tasks in _merge_agent_run_pre_3_11 to prevent aclose() RuntimeError ([9310ba7](https://github.com/google/adk-python/commit/9310ba75c6cc9660ce0b0c53d6448a52077dedc6))
* api-registry to fetch all services ([81b8067](https://github.com/google/adk-python/commit/81b806715542aaf41e6f254a7798b0b0baef281d)), closes [#5478](https://github.com/google/adk-python/issues/5478)
* **artifacts:** Support nested API names ([b99546b](https://github.com/google/adk-python/commit/b99546bfa359acf800b8f6dab34fe475a924373d))
* **auth:** handle missing client-credentials scopes safely ([a546bcf](https://github.com/google/adk-python/commit/a546bcf743ab8ccd10fbbb893e54bb4d27d2c917)), closes [#5345](https://github.com/google/adk-python/issues/5345)
* avoid UserWarning in _build_response_log when response has funct… ([f022307](https://github.com/google/adk-python/commit/f022307db3e93185063978cd1cecb28a7d4c96fd))
* call to sanitize schema for complex union types ([9808451](https://github.com/google/adk-python/commit/980845103a3e457cf7b76a1b91a6fdfa573f8bb8))
* **ci:** add repository check to prevent workflows from running on forks ([90bd38f](https://github.com/google/adk-python/commit/90bd38fb13476e8111ccf63cff4a2de7cb9ac1e9))
* **ci:** Resolve missing sqlalchemy error in adk_release_analyzer ([107dc38](https://github.com/google/adk-python/commit/107dc384bf017f43fbd3c9a285b717678663a353))
* **cli:** Serialize LiteLlm graph models safely ([c1e852f](https://github.com/google/adk-python/commit/c1e852fd2df3b476d298193a489da27e9271f6ec))
* **conformance:** normalize tool declarations in replay verification ([dd97e76](https://github.com/google/adk-python/commit/dd97e76cb2b54a41d6c6724d0b9bab9b0a6045cf))
* Default subagents to chat mode in build_node ([ad560ce](https://github.com/google/adk-python/commit/ad560ce08f6377738adf92f7058437caa985a63e))
* **deps:** Require otel google-genai instrumentor &gt;=0.7b1 for genai 2.x ([2b8c80c](https://github.com/google/adk-python/commit/2b8c80c1e350edefc76b7d6f2c642e75fe817956))
* **eval:** handle failed inference results without invocations ([9a6cf60](https://github.com/google/adk-python/commit/9a6cf60fa8d54523e95943ebdb49d4f35341aed0))
* **eval:** handle unevaluated final response v2 results ([5cfef01](https://github.com/google/adk-python/commit/5cfef0173d359ee907bc09099fafdde61098299b))
* **eval:** include function-call events in invocation_events when skip_summarization is set ([5b16a86](https://github.com/google/adk-python/commit/5b16a867d06c222e6eacbddfe03894336d5a0bc5))
* **eval:** preserve custom eval metadata ([780b0ab](https://github.com/google/adk-python/commit/780b0ab1595c0c74025aea2b4bd8084bc6c1d19a))
* Extract grounding_metadata from Live API server_content ([8a294af](https://github.com/google/adk-python/commit/8a294af52d3c2884368a059f59ea854090f3b0e5))
* Fix silent dead end when conditional routes are unmatched ([6af4562](https://github.com/google/adk-python/commit/6af456203088d23100a03b8854c6286fb2c39103))
* Fix typing for create_client in mcp_session_manager ([c6546a7](https://github.com/google/adk-python/commit/c6546a75dff7de3556c8364e407feeebfd7fece0))
* fix vertex_ai_session_service crashing when Agent Engine passes full resource names instead of short session IDs ([60c55ad](https://github.com/google/adk-python/commit/60c55ad74570ae73d2ae6aec696a225fdd34519a))
* **flows:** terminate invocation at tool-level EUC ([883ff98](https://github.com/google/adk-python/commit/883ff98aef505e9901218e2c98ce671c068355f3))
* Format files to fix pre-commit failures ([395848a](https://github.com/google/adk-python/commit/395848af51d5b7d1db81ea9bc5ef02c0d3d47dca))
* Format the files ([9670ce2](https://github.com/google/adk-python/commit/9670ce2644f422892997c65940e7330f1a26f799))
* gate pr-triage secrets on same-repository pull_request_target ([0d20b7c](https://github.com/google/adk-python/commit/0d20b7c0a6060c0cd490e33b89ffae44c49722f6))
* handle missing agent name in readonly context ([a890399](https://github.com/google/adk-python/commit/a890399fecb82aab72ff8370f8002f8892a075fa))
* improve error message when beautifulsoup4/lxml not installed for load_web_page ([d9f189c](https://github.com/google/adk-python/commit/d9f189c7a32ff154bae069b6c5649a2cf6268490)), closes [#4852](https://github.com/google/adk-python/issues/4852)
* **live:** history_config rejection on Vertex/Enterprise Live sessions ([8f85260](https://github.com/google/adk-python/commit/8f852603a4cbd2739f7faed73fe153ac9436cf68))
* **live:** propagate output token count in live API usage metadata ([7e8965d](https://github.com/google/adk-python/commit/7e8965d33182f43433a3ab5596e625a3cb824f62))
* log diagnostics for empty or unparseable rubric auto-rater output ([fe56f31](https://github.com/google/adk-python/commit/fe56f31951fe34f4f1d74d0258dc0ebf64a630f1)), closes [#5732](https://github.com/google/adk-python/issues/5732)
* make DatabaseSessionService visible in API docs ([69ecf07](https://github.com/google/adk-python/commit/69ecf079b361b258203cbb1d92db1f3861d8eab8)), closes [#4331](https://github.com/google/adk-python/issues/4331)
* Mock google.auth.default in test_fast_api.py ([a7ceb3f](https://github.com/google/adk-python/commit/a7ceb3fb79dfdeefd787d8f7ee756cd6f4c7d2ed))
* **models:** pass NOT_GIVEN to Anthropic when no system_instruction ([3f505d2](https://github.com/google/adk-python/commit/3f505d2973d83d4a8a3f5897be5b14796d178c3e)), closes [#5318](https://github.com/google/adk-python/issues/5318)
* **models:** surface error when model returns STOP with empty content ([ff95d2f](https://github.com/google/adk-python/commit/ff95d2f712b03617872b04a21e91b0063249f8e3))
* **models:** surface error when model returns STOP with empty content ([423cd28](https://github.com/google/adk-python/commit/423cd28c929738618b8d814f043e83d342e26f8c))
* Move google-cloud-parametermanager to optional dependencies ([0856093](https://github.com/google/adk-python/commit/0856093a4727816ea510be5e44bc707b3ba8a64e))
* Only send grounding_metadata for 3.1 live at the end of each turn ([1f2e59b](https://github.com/google/adk-python/commit/1f2e59b0452209e8fd39513ac23d4da0fe253475))
* **otel:** Handle empty contents in experimental semconv ([d611f11](https://github.com/google/adk-python/commit/d611f1172643c0c85314dea43f08d47a7a39abe8))
* **planners:** allow BuiltInPlanner subclasses to override process_planning_response ([f8e9195](https://github.com/google/adk-python/commit/f8e9195d3d2f71d7d0078e8ffecdc020bbc2e6b7))
* **planners:** keep all leading parallel function calls ([054da5d](https://github.com/google/adk-python/commit/054da5d00e4f2e4e363ec691e568f1f71f4eb29d))
* **plugins:** write BigQuery analytics rows when invocation agent is None ([bc08f46](https://github.com/google/adk-python/commit/bc08f46a8c408c16ed3bbb737158a3294bdcec9a))
* preserve empty GCS text artifacts ([8e2b06d](https://github.com/google/adk-python/commit/8e2b06dd640d004a202b3d79da0d0b0cd24d7a08))
* Preserve event details when output is delegated ([a5a3f2e](https://github.com/google/adk-python/commit/a5a3f2e87863ad1ebef42421f3aa53db4b2645d4))
* preserve function call ids for litellm models ([1ad348d](https://github.com/google/adk-python/commit/1ad348d6f77e77455c3cdcacce9a578073e6ba52)), closes [#2621](https://github.com/google/adk-python/issues/2621)
* prevent compaction from orphaning function responses ([71b936b](https://github.com/google/adk-python/commit/71b936bf48de2c1e66f6a032d132ca9cd70f6726))
* prevent ReDoS in code block extraction ([910e1c1](https://github.com/google/adk-python/commit/910e1c13219f6da03c3553ea3039cbfef790ea49))
* propagate model_version and other metadata in streaming responses ([342b59d](https://github.com/google/adk-python/commit/342b59d55c9b409bd86eb28f78b92901f82ae3b0))
* remove developer notes from transfer_to_agent docstring ([2a0b4e7](https://github.com/google/adk-python/commit/2a0b4e75d4ed88b16200937a04cc5b3bc28435c3))
* remove live event buffering in runner ([4340208](https://github.com/google/adk-python/commit/4340208b172ee90769720a9380c51a61aa66e5b5))
* remove the issue/PR analyze and fix agent workflows ([9127feb](https://github.com/google/adk-python/commit/9127febfd5cb78f6f7e0fec447b4f91e0606dd92))
* remove the issue/PR triage and fix agent workflows ([66730e9](https://github.com/google/adk-python/commit/66730e9d87915a9371b10ecf3ae9a0c37c4aba04))
* Reset retry attempt counter on successful connection ([ca8baf1](https://github.com/google/adk-python/commit/ca8baf193634bb81661ec6f5cd2c171c5b70ff5b))
* restore GitHub-only changes dropped during v2 bring-over ([cb48d01](https://github.com/google/adk-python/commit/cb48d015d8441f78d81d590c1186786617c3063d))
* **sessions:** Further fixes for DatabaseSessionService ([f0ec997](https://github.com/google/adk-python/commit/f0ec997bc01268adbd68c1a4ca824f156548e601))
* **sessions:** honor zero recent events in database service ([d9a672e](https://github.com/google/adk-python/commit/d9a672eccf73b611ca954c0cd5cf56931d33d1bf))
* **sessions:** Prevent MissingGreenlet after append_event with asyncpg ([06959b9](https://github.com/google/adk-python/commit/06959b95ed2c1dfe3fe910b73e9232789b5e6d38))
* Set role='model' for request_input event Content ([0c6974c](https://github.com/google/adk-python/commit/0c6974cbc4752eeab75b067e2bdb368e8a72dd15))
* **skills:** enforce utf-8 encoding when materializing skill files on Windows ([0cb4c81](https://github.com/google/adk-python/commit/0cb4c814928f579bfbac9b9e1f95669e4304e089))
* skip crewai test on ImportError for pytest 9.1 compatibility ([4aaf494](https://github.com/google/adk-python/commit/4aaf4947605b71481e3f2676dbca29742749c0d5))
* Stop interpolating release analyzer workflow inputs into shell commands ([5a129a4](https://github.com/google/adk-python/commit/5a129a450ff6a4f586d8bc887c037c5c3f5f10fe))
* support non-Latin text in InMemoryMemoryService search ([be1425b](https://github.com/google/adk-python/commit/be1425b7551310e9e8e3da8a559a6b481bd1ebee))
* surface MALFORMED_FUNCTION_CALL so on_model_error can recover ([2fffcd9](https://github.com/google/adk-python/commit/2fffcd9a55e3af6abe833ad4f668be2a465ef0be))
* **tests:** skip bash tool tests on Windows ([9371f1b](https://github.com/google/adk-python/commit/9371f1b75522bdfc6753785db3ba4add7affb720))
* **tools:** dereference draft-07 `definitions` in MCP tool schemas ([c11ac7d](https://github.com/google/adk-python/commit/c11ac7d58aa175d3d91710077638c30bf1a68f6f))
* **tools:** handle missing 'request' key in AgentTool.run_async fallb… ([8b09c48](https://github.com/google/adk-python/commit/8b09c48f57ad02c4a47b0d732d822dcf9505c777))
* update model to gemini-3.5-flash in session_state_agent sample ([0aca7bf](https://github.com/google/adk-python/commit/0aca7bf65e77bfe67f42eeee29cfb8c33e233c5b))
* use correct 'content' key in sandbox code executor input files ([6262f94](https://github.com/google/adk-python/commit/6262f9415de48e05c895c5560d5ef4d75e18deb0))
* **utils:** Preserve decorated type for [@experimental](https://github.com/experimental) and [@working](https://github.com/working)_in_progress ([30d1910](https://github.com/google/adk-python/commit/30d1910ea08e46fc3ecf19da19d33d3ae9924503))
* **utils:** Preserve decorated type for [@experimental](https://github.com/experimental) and [@working](https://github.com/working)_in_progress ([1ff0158](https://github.com/google/adk-python/commit/1ff015848ceb7b9d86113e7a33620d5ec55342ff))
* **workflow:** Preserve explicit single-turn contents ([59f7bdf](https://github.com/google/adk-python/commit/59f7bdf8ed1667f950c655bb82c0b36ffa3b3ecf))
* **workflow:** Prevent replay divergence hang in sequence barrier ([d88192c](https://github.com/google/adk-python/commit/d88192c1f1bbc6ccb7987b0d4b39d00cbaeda6c2))
* **workflow:** Prevent Shared InvocationContext branch mutation ([5c46937](https://github.com/google/adk-python/commit/5c4693756724ac49e617828c3ca142a3b16536ad))
* **workflow:** Prevent silent drain of routed nodes in wait_for_output ([ef8a5de](https://github.com/google/adk-python/commit/ef8a5deb125fb0d5fa38e5c0ed2d150de47ad1d0))


### Performance Improvements

* **flows:** skip async-rearrange when no function_responses ([70b314b](https://github.com/google/adk-python/commit/70b314b87c078f639937edcbe9d963a543673a72))
* **test:** Speed up unit test suite via parallelism and dedup ([4e4bf84](https://github.com/google/adk-python/commit/4e4bf84b8794b894136511da11edd94fc49c93b2))


### Code Refactoring

* Add diversion logic based on the auth provider resource name ([d4ba521](https://github.com/google/adk-python/commit/d4ba521327c46eac08afb05ed67a9856574023cf))
* Implement the auth provider using Agent Identity Credentials service ([dc6fbd8](https://github.com/google/adk-python/commit/dc6fbd8faece3157b03f4dbf47047de6bed6f1b2))
* Move the IamConnectorCredential service depedency to a seperate file ([c423fcd](https://github.com/google/adk-python/commit/c423fcd987beb3a6c7a9345528171a8a3a4150eb))
* **otel:** Add pure functions for constructing stable and experimental semconv logs ([23c0826](https://github.com/google/adk-python/commit/23c0826f4a97df53c50fe99b249afc3cf9b6ddac))
* Remove unused imports across src ([b79096a](https://github.com/google/adk-python/commit/b79096ac8694b9c46a1f8c5f53dd22948b48849c))
* Separate PR analysis from triage for automation ([10e5f07](https://github.com/google/adk-python/commit/10e5f07ab649398c7ed724b0c3b251ade9833375))
* **telemetry:** change agent and tool execution duration metrics from milliseconds to seconds ([623c9bd](https://github.com/google/adk-python/commit/623c9bd0da3d4c17a0b6988035a7c8fc032c5b20))


### Documentation

* add beginner explanation for single agent example ([225fafc](https://github.com/google/adk-python/commit/225fafc6d5b3eb3cbbc57a03bdf6d576c4ac1684))
* add PyPI, Python version, downloads, and docs badges to README ([04d278a](https://github.com/google/adk-python/commit/04d278a6c5d455b51a2d2c1f7582321ee4c1444b))
* add unit guides for event.py, request_input.py and update adk-unit-guide skill ([7d74a0a](https://github.com/google/adk-python/commit/7d74a0a0e2ac0d0a0e0a382964f7327d02e2f9d8))
* add unit guides for task mode ([f84a5b5](https://github.com/google/adk-python/commit/f84a5b5e20689be8f3dc63c1c3d72f9279c4e66f))
* Align Python version to 3.10+ and update README badges ([d3c21d7](https://github.com/google/adk-python/commit/d3c21d716ed4b8dea92f273528226885d2c997a8))
* clarify context cache min_tokens gating and 4096-token minimum ([8c92cde](https://github.com/google/adk-python/commit/8c92cdef5013fb5cd81ac09c9c874e2705aec34d))
* Fix ADK release analyzer session db saving error ([991431f](https://github.com/google/adk-python/commit/991431fe2324cf72dc265ab11ed668eaedd00d76))
* fix formatting in multi-agent sample READMEs ([fa82929](https://github.com/google/adk-python/commit/fa829296c0dca38a416360857919d1a951a690be))
* fix triaging agent sample typo ([ef395c7](https://github.com/google/adk-python/commit/ef395c70507e86a2627e36b164d7a185899f52a2))
* **openapi:** improve docs for session model ([7a11b50](https://github.com/google/adk-python/commit/7a11b50cb39e06779ed209ae3e2f4259072cda9f))
* remove stale -b v2 flag from clone command in CONTRIBUTING.md ([2e28e5d](https://github.com/google/adk-python/commit/2e28e5d1e1501c82a390b4ad9b1321f29e1ea05b))
* **skills:** fix broken refs in adk-workflow skill ([24a1b26](https://github.com/google/adk-python/commit/24a1b26a7869b0087b8760fb01f2a88f5962f986))
* update llms.txt and remove build script ([c66dc1d](https://github.com/google/adk-python/commit/c66dc1dec44010811b073067136831bdbfee394a))
* Upgrade ADK release analyzer agent to use gemini-3.1-pro-preview model ([d72bb7d](https://github.com/google/adk-python/commit/d72bb7d90d0b5949eef7d5233313bc71b6beb7a8))

## [2.2.0](https://github.com/google/adk-python/compare/v2.1.0...v2.2.0) (2026-06-04)


### Features

* Add `--trigger_sources` and ADK service options to `cli_deploy_agent_engine` ([ffa057c](https://github.com/google/adk-python/commit/ffa057c11212c0110992ac5525b7b8909de610ed))
* add AutoTracingPlugin for OpenTelemetry auto-instrumentation ([bc3a4fa](https://github.com/google/adk-python/commit/bc3a4fab8096a8086bae7d39d289929b0cd98a20))
* add RubricBasedMultiTurnTrajectoryEvaluator ([cae2337](https://github.com/google/adk-python/commit/cae23371a1cfb0b74de18e8583be9504864bf1aa))
* **agents:** restore 1.x agent config wiring for backward compatibility ([44cd116](https://github.com/google/adk-python/commit/44cd11675e9c3dc2deb5607d20083c10031fa708))
* **api_server:** Abort runs on client drops to avoid leaks ([6a53357](https://github.com/google/adk-python/commit/6a533573dbeee3256a192e73b78eccf237ddafff))
* BigQuery Agent Analytics reliability fixes ([a5fa3da](https://github.com/google/adk-python/commit/a5fa3da0214e0bd027b6fea88e447c78baa1c6d8))
* distinguish input-required vs auth-required in A2A conversion ([9d139ea](https://github.com/google/adk-python/commit/9d139ea2e8fe03d50328192225782b0d0efaf1ec))
* emit OTel gen_ai.client.* metrics natively ([0bb329b](https://github.com/google/adk-python/commit/0bb329ba53ad356a70e73377fff4f429ffa99961))
* forward custom_metadata from run requests into the run config ([460cb8c](https://github.com/google/adk-python/commit/460cb8c7c7dfc12d181e1998a7bcc7ef5de5ca70))
* include thoughts and tool calls in compaction summaries ([bdb5582](https://github.com/google/adk-python/commit/bdb558262489fd3c723166d407981b14ec45a273))
* **interactions:** update ADK to support Google GenAI SDK v2.0.0 ([da1d8f1](https://github.com/google/adk-python/commit/da1d8f15529bf6c741bb32a86c380d5cb3633ed1))
* **models:** Support turn_complete_reason in Live responses to capture safety info ([9126acb](https://github.com/google/adk-python/commit/9126acbace9c6b323041c21aff860916f618a139))
* preserve A2A message metadata field in ADK event ([d4d955d](https://github.com/google/adk-python/commit/d4d955d1503c8950ff2fdf17286f8c3f6bc0ad5a))
* raise explicit error for unsupported LiteLlm file attachments ([8847f23](https://github.com/google/adk-python/commit/8847f2384ab3ed17ae080e5e99b5a3c435b3e29f)), closes [#5546](https://github.com/google/adk-python/issues/5546)
* **sessions:** add get_user_state(app_name, user_id) to BaseSessionService ([d029bce](https://github.com/google/adk-python/commit/d029bce53ecf9e8861e7fa547f2814524f38a544))
* **skills:** Add adk-issue skill to analyze and triage GitHub issues ([be03166](https://github.com/google/adk-python/commit/be03166f533a2c1a14ba0e4268a20323d21064d6))
* **skills:** Add adk-review skill for rigorous change quality control ([cc6f78c](https://github.com/google/adk-python/commit/cc6f78c3dca5b5e70fd5035da09392a457c7f0c6))
* **skills:** Automate PR triage and CLA verification ([ce9011c](https://github.com/google/adk-python/commit/ce9011c10389685b76890f902a31893d5269a193))
* **skills:** Enforce PR assignment gates and stream metadata via stdout ([4006fe4](https://github.com/google/adk-python/commit/4006fe408c583bffd95c23455f00184baa4fad6d))
* Support additional scopes and custom discovery doc in Google API Tools ([dc6e293](https://github.com/google/adk-python/commit/dc6e293503d3d34e6d215e4fb017fa094392bebb))
* **tools:** expose httpx_client_factory on RestApiTool and OpenAPIToolset ([7eb9b3d](https://github.com/google/adk-python/commit/7eb9b3de8aa239608370a50bcb313315dcd9ca1d))
* **tools:** Standardize request_input tool for proactive LLM clarification ([afb0a64](https://github.com/google/adk-python/commit/afb0a64f9647c03c32132e184f40e108dc2a4482))


### Bug Fixes

* **a2a:** Support to_a2a(Workflow) and reject non-agent root nodes ([0478b02](https://github.com/google/adk-python/commit/0478b0262de8334c516e34cc4be8cbfbaa7e8cd2))
* accept Azure assistant file ids ([b73679e](https://github.com/google/adk-python/commit/b73679e58fd4f296d8abc299be55c96829260046)), closes [#5664](https://github.com/google/adk-python/issues/5664)
* add artifacts in each agent's .adk folder ([bae5b1a](https://github.com/google/adk-python/commit/bae5b1a1a40d9b4da1dd0c8d9903825e0ef3ab36))
* add future annotations import and prefix task models logger ([2874874](https://github.com/google/adk-python/commit/2874874af497dcbc432e624e94a592d610003688))
* add missing crop helper to data file helper lib ([b5181cf](https://github.com/google/adk-python/commit/b5181cf1351d16e1133196c6da9396e40ed6e97c)), closes [#4011](https://github.com/google/adk-python/issues/4011)
* add PEP 604 union syntax in function tool parameters ([551445e](https://github.com/google/adk-python/commit/551445e797a7f55670aac2610c33a675c65e5a1d))
* add telemetry metric assertions to the test's own agent ([b7766ce](https://github.com/google/adk-python/commit/b7766ceb2c7f36fd8c98c4f1248c40e61462f8c2))
* **agents:** Improve git hygiene in adk-pr-triage skill ([62bcdd3](https://github.com/google/adk-python/commit/62bcdd343c5ea12583f98fa479c265f3b108a50e))
* **agents:** restore abc.ABC base for BaseAgent and LlmAgent ([020386a](https://github.com/google/adk-python/commit/020386a06cd9a461abbc71d8c4e59a4d83917b42))
* allow internal builder assistant app name ([f6e26cc](https://github.com/google/adk-python/commit/f6e26ccc4f8327e634ed2416f30d1a4c9565c800))
* append trailing newline to runtime-config.json in ADK Web Server ([4baccf6](https://github.com/google/adk-python/commit/4baccf61795d70c26f2557ed21a30a7c2c4aa8c9))
* **auth:** omit scope from OAuth2 token requests ([6ce4b87](https://github.com/google/adk-python/commit/6ce4b87858b1fca8d5f0609bb92f198678555c4a))
* block path traversal in Agent Builder file tools ([1fa7cda](https://github.com/google/adk-python/commit/1fa7cda96a41d8bcadefb7cb7346d4795560d9f6))
* **dependencies:** clarify missing Vertex AI extra ([fde6a2b](https://github.com/google/adk-python/commit/fde6a2b854b1194fa618c4ece22c3dac1e58c085))
* **deps:** bump starlette and fastapi to address CVE-2026-48710 ([81add39](https://github.com/google/adk-python/commit/81add3987ada11c862c24143218d434a6504a57a))
* **eval:** Support include_intermediate_responses_in_final in final_response_match_v2 ([8519602](https://github.com/google/adk-python/commit/8519602116d2217ed4347aed1e3ca546b81d8948)), closes [#5695](https://github.com/google/adk-python/issues/5695)
* Event.message honors subclass field ([5bebfd4](https://github.com/google/adk-python/commit/5bebfd4881332f6619e064b450c8fc7bbd38c9f8))
* exclude temp: state keys from Firestore session writes ([a5db346](https://github.com/google/adk-python/commit/a5db3467c8d556f60150bbf913770df36c38fe89))
* Fix path traversal in GCS skill extraction (Zip Slip) ([2f15c6c](https://github.com/google/adk-python/commit/2f15c6cb507c10a8ad93d1f12346e0fbcc2f94f4))
* **flows:** preserve transparent config on live session reconnect ([5ad1942](https://github.com/google/adk-python/commit/5ad1942cb98c211d64b1cedd74f24492fa662e8f)), closes [#5675](https://github.com/google/adk-python/issues/5675)
* Format the files to fix pre-commit failures ([af8bfe0](https://github.com/google/adk-python/commit/af8bfe08acbcbba6796b0e113197536b599724e0))
* guard peer agent mode access in agent transfer ([bb16958](https://github.com/google/adk-python/commit/bb16958bf8682ce7c7f5fc57201b41e17f365c59)), closes [#5863](https://github.com/google/adk-python/issues/5863)
* **live:** Resolve 1007 error and support Gemini 3.1 Flash Live protocol ([e5af12c](https://github.com/google/adk-python/commit/e5af12c29ccaa07abc4fec118971a9fd44b8384c))
* **mcp:** Prevent initialization hangs and task group leaks ([334ef81](https://github.com/google/adk-python/commit/334ef81568675282956c36a54779f09ca643e2c0)), closes [#5886](https://github.com/google/adk-python/issues/5886)
* **migration:** restrict unpickling of v0 actions blobs ([9db48ce](https://github.com/google/adk-python/commit/9db48ce92e77651e888159b4e9a79904dc3c9cd3))
* **models:** Prevent grounding metadata loss in Gemini 3.1 ([e896c62](https://github.com/google/adk-python/commit/e896c620f6d913f0da2497b077941c8c4a3fdd38))
* parse noncanonical litellm tool call arguments ([31cc5a1](https://github.com/google/adk-python/commit/31cc5a17cc7d3fc04902e9b3de4ddaaa20ff5a28))
* populate user_content in resumed invocations ([660bbd4](https://github.com/google/adk-python/commit/660bbd465212feb6433c2789381798d6f72f0707))
* preserve media blocks in ollama content flattening ([47ceeba](https://github.com/google/adk-python/commit/47ceebac92b89be517cb10ea2b5018cde5def49b)), closes [#4975](https://github.com/google/adk-python/issues/4975)
* **runners:** fall back to root agent when a resumed call author is not in the tree ([a86efa6](https://github.com/google/adk-python/commit/a86efa65f5f7880435c3433a941a7d772dd5b89c))
* **runners:** Preserve state_delta in NodeRunner path ([c56bec8](https://github.com/google/adk-python/commit/c56bec8d6d6d9823744a6032e18a640d4c71cae0))
* **sessions:** guard None event.actions before reading state_delta ([03ef3f6](https://github.com/google/adk-python/commit/03ef3f612b4c136028d16fa9b34e1605c8ecbb4b))
* **streaming:** Ensure final partial=False frame is always yielded ([cd81f7b](https://github.com/google/adk-python/commit/cd81f7bde91df78d6cece539a6f98dda2aa8c9c0)), closes [#3754](https://github.com/google/adk-python/issues/3754)
* Support generalized history config injection for Gemini 3.1 Live on Vertex AI ([61a3933](https://github.com/google/adk-python/commit/61a39330dfafbd365e71e0c11cc0128bbaf2fe89))
* terminate infinite retry loop in LoadSkillResourceTool on RESOURCE_NOT_FOUND ([bc45ee6](https://github.com/google/adk-python/commit/bc45ee67cd34182e75023405320e47f1155f6881))
* tolerate context-likes without user_content or session in record_agent_invocation ([0775da5](https://github.com/google/adk-python/commit/0775da5ae406b6db04d401b779b3ab72e9a0fc9f))
* **tools:** add skill script dir to sys.path ([9296198](https://github.com/google/adk-python/commit/9296198b21a80b211b75f0e9263f618fbe9e8744))
* **tools:** don't close parent's plugins from AgentTool's sub-Runner ([2a68c4e](https://github.com/google/adk-python/commit/2a68c4e7463881397be0e9036e509ce59fa5bf3c))
* **tools:** Prevent broken skill tool references when prefix is set and support tool_filter ([4366cca](https://github.com/google/adk-python/commit/4366ccaf1224ea556da25e506aa99fc4ecd91378))
* **tools:** Shell escape path and range in ReadFileTool command ([e16629b](https://github.com/google/adk-python/commit/e16629b38814ec31ed55dc6412dcc7ec33774749))
* validate session_id and enforce ownership in delete_session ([b2916c7](https://github.com/google/adk-python/commit/b2916c71523f3acecbbde782fe8a799ef83b74d5))
* **workflow:** Prevent incorrect chat agent wiring in graphs ([d7aa7b5](https://github.com/google/adk-python/commit/d7aa7b5720ed6b28104c84009680b3e5a61b5e01)), closes [#5868](https://github.com/google/adk-python/issues/5868)
* **workflow:** Resolve raw Content output crash on rehydration ([4f992b0](https://github.com/google/adk-python/commit/4f992b0c6455fb23f0e25ac78687aa2099af421e))


### Performance Improvements

* **flows:** Resolve agent tool unions in parallel ([ae95a97](https://github.com/google/adk-python/commit/ae95a972280cbf0fcd6a989e19590cad68f3d847))


### Code Refactoring

* **agents:** default model to gemini-3-flash-preview ([ad8b6c7](https://github.com/google/adk-python/commit/ad8b6c769d65c293ca58a078ae447fe499209d15))
* **skills:** Split adk-issue skill to separate issue analysis from implementation ([51b18eb](https://github.com/google/adk-python/commit/51b18ebbbc22b6c6310b9e1ca393663805763a7e))
* **tests:** Consolidate event tests into test_event.py ([77aeadf](https://github.com/google/adk-python/commit/77aeadf131b00133963e5c56a3d510a326cabae7))
* **tools:** Split environment tools into single-class _tool files ([1cc298e](https://github.com/google/adk-python/commit/1cc298edb801f9a4538aa532f3fa1c4d4187dc96))
* update tool and agent retrieval functions to support asynchronous execution ([e623b3b](https://github.com/google/adk-python/commit/e623b3b4db9109d2f53915a7c3e8140db71ca336))


### Documentation

* **agents:** Add issue closing support to PR triage skill ([2748c1b](https://github.com/google/adk-python/commit/2748c1bbbd1f56f16cd61f266a82bcd0ecf21e68))
* **skills:** Add rule to specify GitHub issues in commit messages ([8f2c1e3](https://github.com/google/adk-python/commit/8f2c1e38cbdc1d9c7c91fa942f6287e4801c454c))
* **skills:** Use default model in sample agent templates ([2d465aa](https://github.com/google/adk-python/commit/2d465aa2e1569b27d2a348529f3cb5860a5a9783))

## [2.1.0](https://github.com/google/adk-python/compare/v2.0.0...v2.1.0) (2026-05-23)


### Features

* Add chart generation and artifact loading to data agent ([db06416](https://github.com/google/adk-python/commit/db064160bf634b1c7e644012076f077cde6cfcef))
* Add support for creating sandboxes from templates and snapshots ([cbd14eb](https://github.com/google/adk-python/commit/cbd14ebf99bbff22ed28273f095f1fc05793bed2))
* Add user.id to gen_ai.user.message log records for telemetry ([eb379be](https://github.com/google/adk-python/commit/eb379bea5b87579d5a649698c3fdd7473ac5e5a2))
* Fix error message telemetry for tool calls ([e56c021](https://github.com/google/adk-python/commit/e56c021ef73193b24023494d853ac4fdab9115bb))
* Preserve transcription event order in conversation trajectory ([b3d0759](https://github.com/google/adk-python/commit/b3d0759e42d0def400160e4196a874171579a101))


### Bug Fixes

* **ci:** Add python-dateutil dependency to stale-bot workflow ([84fa984](https://github.com/google/adk-python/commit/84fa984ae087c10b59355f915077d1119969c3f2))
* **ci:** Prevent workflow failures in relocated adk_team samples ([55cbc8c](https://github.com/google/adk-python/commit/55cbc8c9e8b649c48a79c26fb112dbc005386338))
* **ci:** Use absolute path for PYTHONPATH in upload docs workflow ([85223e6](https://github.com/google/adk-python/commit/85223e629e160cad7dd9877483e04faacc151bc2))
* **cli:** Fix --reload_agents for web ([1307f8e](https://github.com/google/adk-python/commit/1307f8eeba4252f43dad057438ba68686e3b7e41))
* **cli:** Inform user to install optional dependency on missing google.cloud ([57d677c](https://github.com/google/adk-python/commit/57d677c5cde6a87a24574042013c0c5382a0a2d3))
* convert Union[Pydantic, Pydantic] tool args at runtime ([104edc8](https://github.com/google/adk-python/commit/104edc83170a5871075285b336d19ac9515c1a90)), closes [#5799](https://github.com/google/adk-python/issues/5799)
* Fix bug where grounding metadata in Gemini 3.1 live was being silently discarded ([b9751eb](https://github.com/google/adk-python/commit/b9751eb9df7868223551b4ce33f2ff360f7d3f3e))
* fix input and output transcription finished events for Gemini v3.1 ([d17a2a3](https://github.com/google/adk-python/commit/d17a2a322156c4d4c617e8d4cbac14f24652e617))
* lazy-import GCS evaluation managers in evals utility ([5f91a9d](https://github.com/google/adk-python/commit/5f91a9db032bb9ffd0b59ba24aad04b680481c98))
* Make google-cloud-storage import lazy in skill utils ([416775d](https://github.com/google/adk-python/commit/416775dcceae8f57badf0cd55c44148f6426b6db))
* resolve circular import caused by llm_request ([7e38fc8](https://github.com/google/adk-python/commit/7e38fc811ed58235aa5c120c48c419e0f10a8de2))
* Resolve circular import in base_tool ([92cf192](https://github.com/google/adk-python/commit/92cf19255e21a6edc08a5cf09a1cfbe936b5690e))
* **tests:** Append trailing newline to JSON test outputs ([3329ced](https://github.com/google/adk-python/commit/3329ced0b9ddb2e681a849d62416f14f837e40dd))
* **tools:** Prevent session drop on MCP tool error ([933653c](https://github.com/google/adk-python/commit/933653c61c5498fa0febe1a984d92b82a899e446))
* update EditFileTool to handle cross-platform line breaks and escape regex characters ([1f24553](https://github.com/google/adk-python/commit/1f245535ff1107b428f4fb0837db985457ddf024))


## [2.0.0](https://github.com/google/adk-python/compare/v2.0.0b1...v2.0.0) (2026-05-19)

### ADK 2.0 General Availability

This release introduces v2.0.0 General Availability (GA) of the Google Agent Development Kit (ADK), establishing production-grade foundations for multi-agent workflows and advanced dynamic agent collaboration.

### Core Architecture Highlights

#### Multi-Agent Workflow Engine
* **Flexible Execution Graphs:** Establishes a model-agnostic engine for orchestrating non-linear, conditional, and cyclical agent execution patterns.
* **Intelligent Task Delegation:** Introduces modular workflow abstractions enabling parallel sub-agent workers, nested hierarchical team structures, and resilient dynamic scheduling across complex task execution steps.

#### Dynamic Agent Collaboration
* **Native Inter-Agent Routing:** Provides seamless orchestration for inter-agent messaging, control state handoffs, and context variable propagation across collaborative multi-agent flows.

## [1.34.0](https://github.com/google/adk-python/compare/v1.33.0...v1.34.0) (2026-05-18)


### Features

* **a2a:** add support for persistent task stores ([cd78d87](https://github.com/google/adk-python/commit/cd78d87b967111d40d429bcf9552a962b7e9614f))
* add general support for Gemini Live API in ADK evaluate ([790c9be](https://github.com/google/adk-python/commit/790c9bef9a336ea000d0cf68e63b025dfead5227))
* Add mTLS support to Google Cloud Telemetry exporter ([cfe8d2c](https://github.com/google/adk-python/commit/cfe8d2cc2b29e392886f997be4d77d4cced9959e))
* add support for A2aAgentExecutor factory in to_a2a() function ([115124c](https://github.com/google/adk-python/commit/115124cdf413859c7f634ce995113e4de6cf5ff7))
* add support for non-ADK produced input-required events ([6e53472](https://github.com/google/adk-python/commit/6e534723dd6be938e6fb1b6f55b06de8ac4d27d8))
* Added config option to include tool calls/responses in conversation history passed to user simulator ([baf7efb](https://github.com/google/adk-python/commit/baf7efbaa92ce9d71152ea9ba7f5d0706277b171))
* **ci:** add Gemini auto review and invoke workflows ([fd8b492](https://github.com/google/adk-python/commit/fd8b49295d628075cf70acabb2c52eedf62dd5bd))
* Implement GCPSkillRegistry in ADK ([88ebd42](https://github.com/google/adk-python/commit/88ebd426beaec9564bec1fe98ad0096bba519e3d))
* Implement Skill Registry in ADK ([380d261](https://github.com/google/adk-python/commit/380d261e59b1955af735bf66e47aba2150f04d9f))
* Make Agent Skill description validation more informative ([9f38973](https://github.com/google/adk-python/commit/9f38973081aacf1999f707dac9778b72b5ce75fd))
* Simplify data retrieved handling of ask_data_agent tool and ask_data_insights tool ([48f1b30](https://github.com/google/adk-python/commit/48f1b302510c3520643db739494ff8ea318b7b8f))
* Support OAuth PKCE in McpToolset ([e7316dc](https://github.com/google/adk-python/commit/e7316dc077d676b4349a8d7779ad4ad73f6b0d24))


### Bug Fixes

* **agents:** fix visibility of output_key state delta in callbacks ([0524797](https://github.com/google/adk-python/commit/0524797ac75ddd13b1c01cac91e507ba2c42cef0))
* **anthropic:** map negative thinking_budget to adaptive thinking ([03b915b](https://github.com/google/adk-python/commit/03b915b1bdf5dcab14ae51d8b8cadf37d649acca))
* **auth:** persist refreshed OAuth2 credentials to store ([218ea76](https://github.com/google/adk-python/commit/218ea76e30ced48898a46ca48a014f7dffd266a7)), closes [#5329](https://github.com/google/adk-python/issues/5329)
* **auth:** remove unneeded OAuth flows ([c35a579](https://github.com/google/adk-python/commit/c35a57969d70cb98356297beb36fdf79ab7c00f6))
* avoid pre-serializing dict values in Interactions API to prevent double-escaping ([85f397d](https://github.com/google/adk-python/commit/85f397d20f8b32cdfd074463ff505a06c8535ddf))
* **cache:** enforce CacheMetadata active-state invariant ([76b9f0b](https://github.com/google/adk-python/commit/76b9f0baa0bcc4e715ee996b4dc894ffc9264583))
* **cache:** handle fingerprint-only metadata in performance analyzer ([9c5de58](https://github.com/google/adk-python/commit/9c5de58cfa55fc2b4aade2018456214c95140c16))
* Catch OSError when importing AnthropicLlm ([91cb5c6](https://github.com/google/adk-python/commit/91cb5c6071cc73da8b97e789557dfbc32026a3e8))
* **evaluation:** handle none config in per_turn_user_simulator_quality ([eed9bd3](https://github.com/google/adk-python/commit/eed9bd319ffc398fae14c2362c93f986ffe25f67)), closes [#5677](https://github.com/google/adk-python/issues/5677)
* fallback to project id if crendetials don't contain quota project ([e377cb5](https://github.com/google/adk-python/commit/e377cb5ec057ed4176f2714f368c45e730053eb0))
* Fix missing dynamically loaded tools in SkillToolset during the same invocation ([f9097cb](https://github.com/google/adk-python/commit/f9097cbf7b64b78da894e482480fc22a9603e429))
* **live:** ensure sub live agent doesn't inherit session resumption handle from parent live agent to avoid interrupting the conversation ([8dd9147](https://github.com/google/adk-python/commit/8dd9147443b1dc4121756ad186090f1f267e83b0))
* **models:** preserve string content in Anthropic tool_result blocks ([9a1e75f](https://github.com/google/adk-python/commit/9a1e75f24256cfe54766c69691247df90dc5558f)), closes [#5358](https://github.com/google/adk-python/issues/5358)
* **models:** preserve tool_use IDs for Anthropic models on session resume ([327c45f](https://github.com/google/adk-python/commit/327c45f9f4c98f7b32feeb8555c166b814ee6684)), closes [#5074](https://github.com/google/adk-python/issues/5074)
* **models:** treat empty GenerateContentResponse without prompt feedback as successful ([0cb9ae9](https://github.com/google/adk-python/commit/0cb9ae94b30ac2cff120b2c4ccab77e6b85cbf45))
* only serialize llm_response to json if it will be included in the trace ([1284493](https://github.com/google/adk-python/commit/12844939f1a89b2a06c592a52bbd3c293860e808))
* Preserve live_session_id in function call handling ([07a9a01](https://github.com/google/adk-python/commit/07a9a01b3c1fb2866cc8bdcd8d8ab0906aa88682))
* Prevent compaction of events involved in Human-in-the-Loop interactions ([bb2efb6](https://github.com/google/adk-python/commit/bb2efb6bd234e3235c47b3245676581f6022b458))
* raise eagerly on importing AgentRegistry if a2a-sdk is missing ([33cf6cb](https://github.com/google/adk-python/commit/33cf6cb61016bdd227749a7eff113045f848b203))
* **small:** Convert events to the A2A format while respecting user vs agent role ([59f7347](https://github.com/google/adk-python/commit/59f7347a635bc56fa8abdd3c7c771ae11bebf9ab))
* **tools:** preserve code_execution_result and executable_code in AgentTool ([7e61b51](https://github.com/google/adk-python/commit/7e61b517027a23c640b7b636a87e04a0a02c392c)), closes [#5481](https://github.com/google/adk-python/issues/5481)
* **tools:** Prevent AnyIO CancelScope task boundary violations during MCP session creation failure ([4309159](https://github.com/google/adk-python/commit/430915970062a4ff926a65e5884cc5bc2912c48c))
* Update model name in hello_world agent ([192f19d](https://github.com/google/adk-python/commit/192f19d82495eb560ee701eb751ce14b90e4b5c7))
* Update model to gemini-3-flash-preview in hello word agent sample ([6d89d21](https://github.com/google/adk-python/commit/6d89d2194a21220801c602248b27b81b9188050c))
* Update model to gemini-3-flash-preview in session state agent sample ([2d423e8](https://github.com/google/adk-python/commit/2d423e835569e0e8e67772a09bf1a76f1bb5324e))
* use tool_responses role for gemma4 models in LiteLLM integration ([3d07960](https://github.com/google/adk-python/commit/3d07960a70031fb7786485f58a964a98dbdb932d)), closes [#5650](https://github.com/google/adk-python/issues/5650)


### Performance Improvements

* lazy-load service registries and split apps.app to cut cold start ~8% ([bd062ec](https://github.com/google/adk-python/commit/bd062ec9eb4b48cc6d4ec45aaf0a1f8f847b6d7b))
* **models:** guard debug log evaluation with isEnabledFor ([57d8fc7](https://github.com/google/adk-python/commit/57d8fc7d818dc3ba2cec56fa8199a11cde30a4c6))
* **utils:** cache find_context_parameter introspection ([ec54bd4](https://github.com/google/adk-python/commit/ec54bd439e31c99a32d773ace04b73cb3a275675))


### Code Refactoring

* Make the "a2a_metadata" string a constant that can be depended on by extension developers ([0821f2d](https://github.com/google/adk-python/commit/0821f2d4dd7cf7aafd369fabf8d78697eedf9d1c))

## [1.33.0](https://github.com/google/adk-python/compare/v1.32.0...v1.33.0) (2026-05-08)


### Features

* add BufferableSessionService ([0bc767e](https://github.com/google/adk-python/commit/0bc767e6892742d6290d3445d028f95925187aed))
* **apigee:** allow injecting credentials into ApigeeLlm ([ce578ff](https://github.com/google/adk-python/commit/ce578fffa0dc02b0033f7f5e705b9422cbd6c252))
* Make ADK environment tools truncation limit configurable ([83ae405](https://github.com/google/adk-python/commit/83ae40525aa734f4a3b365614cce43831612a1ec))
* **models:** add get_function_calls and get_function_responses to LlmResponse ([22fae7e](https://github.com/google/adk-python/commit/22fae7e9a09c581f433f3c51ea9a0ab26e689b92))


### Bug Fixes

* catch genai.ClientError when sandbox is missing ([69fa777](https://github.com/google/adk-python/commit/69fa777881b3cb161e5b3dcb005def9a2ad86904)), closes [#5480](https://github.com/google/adk-python/issues/5480)
* double append bug ([f8b4c59](https://github.com/google/adk-python/commit/f8b4c59350fea3319c9e53e29968c56c93c57c99))
* Filter out video events with inline data from being stored in session ([88421f8](https://github.com/google/adk-python/commit/88421f80a0b008e90f18401abca4ceec3548f6cd))
* fix fork detection, correct offload limits, and add response logging in BigQuery plugin ([9d1bb4b](https://github.com/google/adk-python/commit/9d1bb4b4870233e574f5c06ddd2b62a48272398f))
* hot reload agents for adk web ([740557c](https://github.com/google/adk-python/commit/740557c8965305abc75752082bc3ee63d924742f))
* Only append skills to system instruction if ListSkillsTool isn't available ([01f1fc9](https://github.com/google/adk-python/commit/01f1fc9c912a97ff27bb1332a28324f991eae77d))
* prevent state_delta overwrite on function_response-only events ([fc27203](https://github.com/google/adk-python/commit/fc2720378e8997269d30f5439051f5e43d5fa028), [211e2ce](https://github.com/google/adk-python/commit/211e2ceb70ac6b61400559761d1d6548d906a79b)), closes [#3178](https://github.com/google/adk-python/issues/3178)
* Raise a clear actionable error when CustomAuthScheme lacks a registered AuthProvider ([83f9817](https://github.com/google/adk-python/commit/83f981761b963ca51a286cbd004c043567517a3c))
* should use app_name instead of req.app_name ([8286066](https://github.com/google/adk-python/commit/8286066e71e5c07b5b28979b8327d4b330187ddd))
* **simulation:** Add error message when LlmBackedUserSimulator returns empty response ([fb92aad](https://github.com/google/adk-python/commit/fb92aad9c53bb9f6706fb27751d71fcda2419500))
* Update expressmode api call to include default api key param ([e833995](https://github.com/google/adk-python/commit/e8339953911a8b580cfc2d88c7008234a43beece))
* use asyncio.sleep to avoid blocking event loop ([3a1eadc](https://github.com/google/adk-python/commit/3a1eadce66804db08f6520cc11f9c60e81bb9e30))
* Use project and location instead of API key when deploying to agent engine ([398f28f](https://github.com/google/adk-python/commit/398f28feb47d87ec9c4c03dd3e0e7b87a1699e6e))


### Code Refactoring

* adjust computation of workflow.steps metric and add new unit tests ([03d6208](https://github.com/google/adk-python/commit/03d6208aacac8c19adec45ce0dd837f9e3a7f66f))
* remove input.type and output.type attributes from adk metrics ([9559968](https://github.com/google/adk-python/commit/95599683230dd13e5792133f30ade3fe19358d52))

## [1.32.0](https://github.com/google/adk-python/compare/v1.31.0...v1.32.0) (2026-04-30)


### Features

* Add an option to prevent the SaveFilesAsArtifactsPlugin from attaching reference file parts to the message ([987c809](https://github.com/google/adk-python/commit/987c809bfc816a9804c905bd5c02397e396e72d3))
* add credentials parameter to BigQueryAgentAnalyticsPlugin ([34713fb](https://github.com/google/adk-python/commit/34713fb4cccae9fe066587459862f8d4c4aa166f))
* Add express mode onboarding support to adk deploy cli ([2b04996](https://github.com/google/adk-python/commit/2b04996f7ac342c9e7600e4bb596a666108f8b65))
* add native OpenTelemetry agentic metrics ([6942aac](https://github.com/google/adk-python/commit/6942aac5d7b1f465c20febe2a48bac90da32c4eb))
* Add OpenTelemetry tracing for event compaction ([c65dd55](https://github.com/google/adk-python/commit/c65dd5580f42ed330bf4c57cd040f22748ba1444))
* Add sample agent demonstrating 2LO, 3LO, and API Key auth via GcpAuthProvider ([909a8c2](https://github.com/google/adk-python/commit/909a8c2ad4d06ad485173f40f278c503cd66a063))
* Add support for Anthropic's thinking blocks ([16952bd](https://github.com/google/adk-python/commit/16952bd397f871df3e5a1b035261ded3b7c226a5))
* Add support for excluding predefined functions in ComputerUseToolset ([d760037](https://github.com/google/adk-python/commit/d760037f9500a9187bf835ce62eebf21e818f322))
* Add support for refusal messages in ApigeeLlm ([d6594a1](https://github.com/google/adk-python/commit/d6594a1a2c11fe3f5ac94fd37a9ae4b327fa1a0c))
* Added indication of user message in history event list ([662354a](https://github.com/google/adk-python/commit/662354ae55c244d79955935f2243ba3deba272e9))
* Allow user to define credential_key for McpToolset ([282db87](https://github.com/google/adk-python/commit/282db876fdf8e2f0133cfc386b4b4dd1dc9bdd09)), closes [#5103](https://github.com/google/adk-python/issues/5103)
* **analytics:** add support for logging LLM cache metadata to BigQuery ([02deeb9](https://github.com/google/adk-python/commit/02deeb98a08611733949fa2912f433f2ed55681a))
* **eval:** add evaluate_full_response option to rubric-based evaluation ([#5316](https://github.com/google/adk-python/issues/5316)) ([7623ff1](https://github.com/google/adk-python/commit/7623ff1a27c412ff9b758bb76701e2daff570741))
* **live:** Add save_live_blob query parameter to /run_live endpoint ([36ab8f1](https://github.com/google/adk-python/commit/36ab8f128c0281e44c2120a17de91e081f2232b1))
* **mcp:** gracefully handle tool execution errors and transport crashes ([7744cfe](https://github.com/google/adk-python/commit/7744cfe0f36a74f50abb53ec0d42566c439257b3))


### Bug Fixes

* accumulate list values when merging parallel tool call state_delta ([b0b8b31](https://github.com/google/adk-python/commit/b0b8b310af5cb1184ef3ef57f1bb551e2a9add9a)), closes [#5190](https://github.com/google/adk-python/issues/5190)
* Add support for overriding the API version in GoogleLLM ([1cdd1e7](https://github.com/google/adk-python/commit/1cdd1e74ba3e59e5ef5ebb654184630c1462454e))
* **auth:** isolate resolved credentials in context to prevent race conditions and data leakage ([5578772](https://github.com/google/adk-python/commit/55787721541fe0a9b5df15b980be87623e57eba8))
* avoid double-execution of sync FunctionTools returning None ([78a8851](https://github.com/google/adk-python/commit/78a8851809f2be7b9e20158beee8c39cdd3fe2f8)), closes [#5284](https://github.com/google/adk-python/issues/5284)
* block RCE vulnerability via nested YAML configurations in ADK ([74f235b](https://github.com/google/adk-python/commit/74f235b1195805f2316f90533d4d297038448f0a))
* bump Vertex SDK version ([6380f6a](https://github.com/google/adk-python/commit/6380f6ac767a6e13faf15b7e8ac3bc48acbd5f1b))
* cancel siblings in parallel function calling on failure ([49985c9](https://github.com/google/adk-python/commit/49985c91ca08e36801e72164cb6314aa9190d144))
* Capture and include LLM usage metadata in summarized events ([5ce33b9](https://github.com/google/adk-python/commit/5ce33b9c1e7606cb9b84ab925f8ff47ee0347943)), closes [#4014](https://github.com/google/adk-python/issues/4014)
* catch ValueError in safe-JSON serializers for circular refs ([70a7add](https://github.com/google/adk-python/commit/70a7add2bd8ddca12b5fdd63e2052f291817d5be)), closes [#5412](https://github.com/google/adk-python/issues/5412)
* **deps:** bump litellm cap to >=1.83.7 to admit CVE patches ([6d2ada8](https://github.com/google/adk-python/commit/6d2ada8bbc5a08bee3ca76d3e44628b194562212))
* Disable bound token for mcp_tool ([4c0c6db](https://github.com/google/adk-python/commit/4c0c6db87cd531d932c135a27e69682ed08c6f75))
* fix dataset location handling in BigQueryAgentAnalyticsPlugin ([c263426](https://github.com/google/adk-python/commit/c263426fe1a8620ebebef4b7efaed1eb5b99c03f))
* Fix exception handling and argument order in ReflectRetryToolPlugin ([1deab6d](https://github.com/google/adk-python/commit/1deab6d0bf32a0344ab033a1ae61cc7cddf706fd))
* Fix GcpAuthProvider to return capitalized Bearer scheme ([ad937fe](https://github.com/google/adk-python/commit/ad937fe1b827309787a177a99c42df2679f9286e))
* fix lifecycle issues with credentials in BigQuery Agent Analytics Plugin ([a69f861](https://github.com/google/adk-python/commit/a69f8612fa4b69273b1bb7c90c4efa53b04440e6))
* Fix malformated skill.md ([9a0d2f7](https://github.com/google/adk-python/commit/9a0d2f70ba957b8fc2cae8ed3f4aa1f4885a689c))
* Fix misplaced pytest decorator on helper dataclass in 2LO integration tests ([2343973](https://github.com/google/adk-python/commit/234397353189005b5641df832f8ed45018021ef7))
* Fix RecursionError in ADK framework by adding circular reference detection to schema resolution ([7de5bc5](https://github.com/google/adk-python/commit/7de5bc54e11986f70a48a9dd83ea39be58ebce40))
* fix rewind to preserve initial session state ([af1b00a](https://github.com/google/adk-python/commit/af1b00a12b8dd6eee844cc28df7bcd4838e22c1a)), closes [#4933](https://github.com/google/adk-python/issues/4933)
* Fix SSRF and local-file access in load_web_page ([0447e93](https://github.com/google/adk-python/commit/0447e939483c1c6bc8d6df7f96b372d5f8bee7bb))
* handle None state values in skill_toolset after session rewind ([a977aa3](https://github.com/google/adk-python/commit/a977aa307d56ed1efa89a3ffe4b3d96650a984d6))
* **litellm:** emit input_audio for audio inline_data parts ([4073238](https://github.com/google/adk-python/commit/4073238151ee35488b50a321482db500b705234b)), closes [#5406](https://github.com/google/adk-python/issues/5406)
* **live:** mark all agents' Event as from other agents ([48b7a64](https://github.com/google/adk-python/commit/48b7a64bcf5ff402d10187d269f41e6bd4b8d74a))
* **live:** treat input transcription as user message ([ae1f2e6](https://github.com/google/adk-python/commit/ae1f2e6094935c972af3f6682e5c2f79a5ac70d5))
* **optimization:** handle None metric scores in LocalEvalSampler ([#5415](https://github.com/google/adk-python/issues/5415)) ([684a6e7](https://github.com/google/adk-python/commit/684a6e781adf7e769c8f7f572382ceb61f26a038))
* **otel:** change `gen_ai.tool_definitions` to `gen_ai.tool.definitions` ([029b87d](https://github.com/google/adk-python/commit/029b87d582bdde98be3532f26adb6e1d851c44d6))
* preserve cache fingerprint stability on creation failure ([4d5438c](https://github.com/google/adk-python/commit/4d5438cfc89d69d88ba4c324c292fc23e3047f3d))
* preserve empty-string text parts in A2A converter ([2d61cb6](https://github.com/google/adk-python/commit/2d61cb69704f063f66b5d83b716674f6f94b5903))
* preserve function call IDs for Anthropic models ([f0c787f](https://github.com/google/adk-python/commit/f0c787fbc9c4a66b0d0eccddc6d6d03b844cfd0b))
* Prevent LoopAgent from resetting sub-agent state on pause ([8846be5](https://github.com/google/adk-python/commit/8846be585dd3ac585a75aed03d9c6623a5eaa41b))
* Quote user_id literals in VertexAiSessionService list filters ([bdece00](https://github.com/google/adk-python/commit/bdece003b82959d7d7649cc5c94e26306019299f))
* read_file/write_file path type mismatch in BaseEnvironment and LocalEnvironment ([782796f](https://github.com/google/adk-python/commit/782796f97eb10d09d8dccb51b93868e1c07b475e))
* relax EventActions.state_delta value type to Any ([dbec8e9](https://github.com/google/adk-python/commit/dbec8e937adeb608b01f43409033c1de70a86b92))
* remove exclude_unset=True to correctly serialize pydantic types ([f95ac48](https://github.com/google/adk-python/commit/f95ac48e07daa0934a784c1701a124add0513297))
* **samples:** Upgrade google-adk to 1.28.1 to fix vulnerability ([b848390](https://github.com/google/adk-python/commit/b8483909049d4a9bad94f6cb44cf6a26fd9faa9d))
* Sanitize user_id derived from PubSub subscription and Eventarc source ([0c4f157](https://github.com/google/adk-python/commit/0c4f1570388c8361ce6ab072f5ef19a3d92dbdc2)), closes [#5324](https://github.com/google/adk-python/issues/5324)
* Scope Vertex RAG memory display names ([784350d](https://github.com/google/adk-python/commit/784350dba60245ce02ad96994e7ced2b567a4dec))
* Use correct camelCase functionCallId ([c87ee1e](https://github.com/google/adk-python/commit/c87ee1ee9697b4f5f2b88e45a08eeeabf9a0ad13))
* web oauth flow and trace view ([87cd310](https://github.com/google/adk-python/commit/87cd310bccb33d7faae7d505a4629a2e1d77fadb))
* yield tool_call_parts immediately in live mode to unblock Gemini 3.1 tool calls ([f57b05d](https://github.com/google/adk-python/commit/f57b05dac147eb72f54c9053a4a0ba7023ee55dc))


### Performance Improvements

* lazy-load optional providers and auth chain to cut cold start ~25% ([66bfedc](https://github.com/google/adk-python/commit/66bfedcf8ddc7c5c518c8c7d7a967e1c488e9852))


### Code Refactoring

* move exception handling from metric emission into instrumentation handlers ([62d7ee0](https://github.com/google/adk-python/commit/62d7ee024aa1e50197722d2c5914192a7f322d60))
* **tests:** Refactor tests to explicitly handle JSON_SCHEMA_FOR_FUNC_DECL feature flag ([b580891](https://github.com/google/adk-python/commit/b580891adcc2c7afe110dbef394ffd7b3de67629))
* Use artifact_service.load_artifact during rewind ([c3d50db](https://github.com/google/adk-python/commit/c3d50db9387f7cd76a955299e40a23925dedbc22)), closes [#4932](https://github.com/google/adk-python/issues/4932)


### Documentation

* **gemini:** show subclass pattern for custom Client config ([34c7505](https://github.com/google/adk-python/commit/34c7505cc437578567008c0c8b160de083eae0d1)), closes [#3628](https://github.com/google/adk-python/issues/3628)
* update `output_schema` docstring to reflect support for `tools` and `output_schema` together ([e1e652d](https://github.com/google/adk-python/commit/e1e652d73a3d41f42c517189164f740cb907896d))
* Update README with instructions for installing ADK extensions ([f2a1179](https://github.com/google/adk-python/commit/f2a117972e40dd3d4299f3ff437b4382600d224e))
* use sphinx-click to generate docs for google.adk.cli ([f455974](https://github.com/google/adk-python/commit/f4559743febfa91fdde6e5e2e41acf54e20396fe))

## [1.31.0](https://github.com/google/adk-python/compare/v1.30.0...v1.31.0) (2026-04-16)


### Features

* Add "google-adk" user agent to Parameter Manager and Secret Manager clients ([b8e8f6b](https://github.com/google/adk-python/commit/b8e8f6b90290e48e134f48bbe7e2b800276e7269))
* Add support for memories.ingest_events in VertexAiMemoryBankService ([d69477f](https://github.com/google/adk-python/commit/d69477f6ff348311e1d53e3f2c389dcf037fb049))
* Add Vertex AI Agent Engine Sandbox integration for computer use ([7686848](https://github.com/google/adk-python/commit/76868485519090c5fa2a0287bccca040e438d94e))
* Firestore support ([1a9df8f](https://github.com/google/adk-python/commit/1a9df8f77410a08a85d04744f199d25f20d55ebd))
* **live:** Add live_session_id to LlmResponse ([bf84e2c](https://github.com/google/adk-python/commit/bf84e2cee84f04c886914eb72318875f3c29ea13))


### Bug Fixes

* Bump minimum mcp version from 1.23.0 to 1.24.0 ([494c360](https://github.com/google/adk-python/commit/494c360b2a82af5130f153ff615f84e4c2604a73))
* **cli:** correct console URL path after adk deploy agent_engine ([64ed1a6](https://github.com/google/adk-python/commit/64ed1a68c98e32d61aff43857fa4e756b129b13f)), closes [#5336](https://github.com/google/adk-python/issues/5336)
* execute on_event_callback before append_event to persist plugin modifications ([454188d](https://github.com/google/adk-python/commit/454188de5de0ef44adb7716230eacddcb060dab2)), closes [#3990](https://github.com/google/adk-python/issues/3990)
* make `_EvalMetricResultWithInvocation.expected_invocation` `Optional` for conversation_scenario support ([#5215](https://github.com/google/adk-python/issues/5215)) ([a4c9387](https://github.com/google/adk-python/commit/a4c938775764794f42e00a89e3cb33da5119c38b))
* Pass in auth headers with header provider instead of connection params ([e12b0af](https://github.com/google/adk-python/commit/e12b0af20d9a025e3d75f309de836b139b6d3e88))
* populate required fields in FunctionDeclaration json_schema fallback ([9b9faa4](https://github.com/google/adk-python/commit/9b9faa4ba21d566252e4c25bd55ab9db2658051e))
* Resolve BigQuery plugin issues with A2A transfers, spans, and metadata ([9ca8c38](https://github.com/google/adk-python/commit/9ca8c384324e07e945146359f21010b438eb1bc6))
* upgrade google-genai lower bound ([8bc5728](https://github.com/google/adk-python/commit/8bc57283f3c584a5a6d6d774a316fe63342ed481))


### Code Refactoring

* **live:** Use `send_client_content` to send conversation history ([67dc2eb](https://github.com/google/adk-python/commit/67dc2ebfd42f175f2dd6ea58df51a03c575062c6))
* **live:** Use `send_tool_response` for function responses ([70c5fc8](https://github.com/google/adk-python/commit/70c5fc83a62d1e81d20986223f5c275b086f9822))


### Documentation

* update MCP Toolbox branding, binary version, and asset references ([47fa7b7](https://github.com/google/adk-python/commit/47fa7b743c37e3aa8302e78be552876c2784e6ff))

## [1.30.0](https://github.com/google/adk-python/compare/v1.29.0...v1.30.0) (2026-04-13)


### Features

* Add Auth Provider support to agent registry ([f2c68eb](https://github.com/google/adk-python/commit/f2c68eb1536f1c0018c2cf7ee3f4417ca442080c))
* Add Parameter Manager integration to ADK ([b0715d7](https://github.com/google/adk-python/commit/b0715d77a2a433bb2ed07a2475cc4d1f2d662b6c))
* Add support for Gemma 4 models in ADK ([9d4ecbe](https://github.com/google/adk-python/commit/9d4ecbe9fd1141693e4682cbfe4d542cc62b76ac)), closes [#5156](https://github.com/google/adk-python/issues/5156)
* allow users to include artifacts from artifact_service in A2A events using provided interceptor ([e63d991](https://github.com/google/adk-python/commit/e63d991be84e373fd31be29d4b6b0e32fdbde557))
* emit a `TaskStatusUpdateEvent` for ADK events with no output parts but with event.actions ([dcc485b](https://github.com/google/adk-python/commit/dcc485b23e3509e2e386636d841033b91c9a401c))
* Live avatar support in ADK ([a64a8e4](https://github.com/google/adk-python/commit/a64a8e46480753439b91b9cfd41fd190b4dad493))
* **live:** expose live_session_resumption_update as Event in BaseLlmFlow ([2626ad7](https://github.com/google/adk-python/commit/2626ad7c69fb64a88372225d5583085fc08b1fcd)), closes [#4357](https://github.com/google/adk-python/issues/4357)
* Promote BigQuery tools to Stable ([abcf14c](https://github.com/google/adk-python/commit/abcf14c166baf4f8cc6e919b1eb4c063bf3a92af))
* **samples:** add sample for skill activation via environment tools ([2cbb523](https://github.com/google/adk-python/commit/2cbb52306910fac994fe1d29bdfcfacb258703b4))


### Bug Fixes

* Add "gcloud config unset project" command to express mode flow ([e7d8160](https://github.com/google/adk-python/commit/e7d81604126cbdb4d9ee4624e1d1410b06585750))
* avoid load all agents in adk web server ([cb4dd42](https://github.com/google/adk-python/commit/cb4dd42eff2df6d20c5e53211718ecb023f127fc))
* Change express mode user flow so it's more clear that an express mode project is being created ([0fedb3b](https://github.com/google/adk-python/commit/0fedb3b5eb2074999d8ccdb839e054ea80da486f))
* Custom pickling in McpToolset to exclude unpicklable objects like errlog ([d62558c](https://github.com/google/adk-python/commit/d62558cc2d7d6c0372e43c9f009c8c7a6863ff0a))
* Fix credential leakage vulnerability in Agent Registry ([e3567a6](https://github.com/google/adk-python/commit/e3567a65196bb453cdac4a5ae42f7f079476d748))
* Include a link to the deployed agent ([547766a](https://github.com/google/adk-python/commit/547766a47779915a8a47745237a46882a02dae9a))
* preserve interaction ids for interactions SSE tool calls ([9a19304](https://github.com/google/adk-python/commit/9a1930407a4eff67093ea9f14292f1931631a661)), closes [#5169](https://github.com/google/adk-python/issues/5169)
* validate user_id and session_id against path traversal ([cbcb5e6](https://github.com/google/adk-python/commit/cbcb5e6002b5bae89de5309caf7b9bb02d563cfc)), closes [#5110](https://github.com/google/adk-python/issues/5110)

## [1.29.0](https://github.com/google/adk-python/compare/v1.28.0...v1.29.0) (2026-04-09)


### Features

* Add auth scheme/credential support to MCP toolsets in Agent Registry ([7913a3b](https://github.com/google/adk-python/commit/7913a3b76432caf16953ea7b2a2cf4872baad417))
* add ability to block shell metacharacters in BashTool ([23bd95b](https://github.com/google/adk-python/commit/23bd95bcf23367a8df3342ca4bb9d17f0b3b0d8f))
* add configurable resource limits for subprocesses in BashTool ([1b05842](https://github.com/google/adk-python/commit/1b0584241f6418fd5fe9bd05fa666d03c310b8ae))
* Add configurable view_prefix to BigQueryLoggerConfig ([37973da](https://github.com/google/adk-python/commit/37973daff47d3c67e928a240acd188d4e318f52b))
* Add custom session id functionality to vertex ai session service ([e1913a6](https://github.com/google/adk-python/commit/e1913a6b411aec9e8774ca92ea39531b085c43f0))
* Add Description column to SKILL.md and update terminology ([435f7c7](https://github.com/google/adk-python/commit/435f7c7a9fdf8b1214f4439c6d953b6426d90da1))
* Add Easy GCP support to ADK CLI ([8850916](https://github.com/google/adk-python/commit/8850916e1908ace19a058102f0392eee08349d60))
* Add regional endpoint support to `SecretManagerClient` ([19ac679](https://github.com/google/adk-python/commit/19ac679aeacc045ed78cb9fd48bb295440843288))
* Add support for model endpoints in Agent Registry ([eb4674b](https://github.com/google/adk-python/commit/eb4674b49f017f3947506c55be4075b1ea0369d6))
* **auth:** Add public api to register custom auth provider with credential manager ([a220910](https://github.com/google/adk-python/commit/a22091058dd2ea6e1e0655b5946ce6ed7e72d25e))
* **auth:** Pass consent_nonce to Agent Frontend ([9fec503](https://github.com/google/adk-python/commit/9fec503061846b9903c18921f7848b358a041331))
* **auth:** Support additional HTTP headers in MCP tools ([b3e9962](https://github.com/google/adk-python/commit/b3e99628ee1b87b61badf56e67f8ddee15e6fe54))
* **bigquery:** Add ADK 1P Skills for ADK BQ Toolset ([4030c0d](https://github.com/google/adk-python/commit/4030c0d0167b348cf2e4c941c8610aa6ede28275))
* **environment:** Add EnvironmentToolset for file I/O and command execution ([9082b9e](https://github.com/google/adk-python/commit/9082b9e38eeb3465c399b41633e6441e339c47c3))
* **environment:** Add LocalEnvironment for executing commands and file I/O locally ([f973673](https://github.com/google/adk-python/commit/f97367381e820c75ad16d4ce7ee27c0f9929c81d))
* Implement robust process group management and timeouts in BashTool ([f641b1a](https://github.com/google/adk-python/commit/f641b1a219b041659e6d429c47974bc9e5cfe1af))
* **live:** Added in 1.28.1, support live for `gemini-3.1-flash-live-preview` model ([8082893](https://github.com/google/adk-python/commit/8082893619bb85d4ee0dc53fd2133d12b9434d07))
* Option to use shallow-copy for session in InMemorySessionService ([16a1a18](https://github.com/google/adk-python/commit/16a1a185ab77a904fd01712779fa1bc6417dc628))
* Propagate context to thread pools ([83393ab](https://github.com/google/adk-python/commit/83393ab839d5733568699195683408fccbd1cb6e))
* refresh credentials if token is missing in the common code and samples ([1445ad5](https://github.com/google/adk-python/commit/1445ad5069841e446328e0856553f69a6699f0f4))
* Remove use of raw_event field in vertex ai session service ([642d337](https://github.com/google/adk-python/commit/642d337a9069fae334192d045c9f85922cbcef53))
* **skill:** Standardize skill tools and make script arguments flexible ([9e73ab8](https://github.com/google/adk-python/commit/9e73ab846672065f1fbe1c2642419e8a008efd43))
* Support AgentRegistry association ([6754760](https://github.com/google/adk-python/commit/675476088b9f3c0a488ce48f652b7f3f7ea47230))
* Support loading agents from Visual Builder with BigQuery-powered logging ([2074889](https://github.com/google/adk-python/commit/20748894cdaa5a95d0c4ccb0daf87a34496639dd))
* Support propagating grounding metadata from AgentTool ([d689a04](https://github.com/google/adk-python/commit/d689a04f16846c2aa483dd45dcc65e2decdb419c))
* Support short options and positional arguments in RunSkillScriptTool ([2b49163](https://github.com/google/adk-python/commit/2b49163b399135f0d96b73a99eb4ace764ce87db))
* Use raw_event field in vertex ai session service for append and list events ([6ee0362](https://github.com/google/adk-python/commit/6ee036292e9eefabb032e8ebec3580a2243f3a96))
* Use raw_event to store event data in vertex ai session service ([9da9dee](https://github.com/google/adk-python/commit/9da9dee140a3c8971d2dc267eab7d8d17a22a089))


### Bug Fixes

* Add A2ATransport.http_json to the default supported transports list ([7dd9359](https://github.com/google/adk-python/commit/7dd9359fa1c419f82db84b844195e1b77d8070e7))
* add httpx_client_factory support to SseConnectionParams ([815ebb4](https://github.com/google/adk-python/commit/815ebb441579724e5aa22830b2e6f7c22f94fde6))
* **adk:** redact credentials in BigQuery analytics plugin ([a27ce47](https://github.com/google/adk-python/commit/a27ce4771ff271947a0d94762231da842095836e))
* api client initialization logic to be mutually exclusive between ExpressMode and GCP projects ([4ffe8fb](https://github.com/google/adk-python/commit/4ffe8fb4a6befc9e9d0e838427b7bf4890df4ba3))
* avoid load all agents in adk web server ([ede8a56](https://github.com/google/adk-python/commit/ede8a56a3cd18311ce82e761f0f3da6228fbc0d6))
* Cache BaseToolset.get_tools() for calls within the same invocation ([92cad99](https://github.com/google/adk-python/commit/92cad99724d333760e4ebc6116951d78a9b1cb7a))
* **cli:** fail Agent Engine deploy when config file path is invalid ([bbad9ec](https://github.com/google/adk-python/commit/bbad9ec64ce1617bc45148de97e6246752845b98))
* Disable tool caching for skill toolset ([064f0d2](https://github.com/google/adk-python/commit/064f0d278e55e1e9fd6db1b6ccf3d1cb95cba47b))
* Disallow args on /builder and Add warning about Web UI usage to CLI help ([dcee290](https://github.com/google/adk-python/commit/dcee2902729e178b41086c4039a3828917bbb9f3))
* empty events_iterator assignment ([898c4e5](https://github.com/google/adk-python/commit/898c4e5f78b60c4c4732c7cd19ff2da9a64964a1))
* **environment:** fix package references ([add8e86](https://github.com/google/adk-python/commit/add8e8664bd2ae9257c8b37a5e602d0c7aae7625))
* Fix RemoteA2AAgent deepcopy errors ([6f29775](https://github.com/google/adk-python/commit/6f29775f4bf7172b1378b17856534f95b9d4eeb6))
* Fixes for initializing RemoteA2aAgent - passing in preferred transport, protocol version, and auth headers ([0f3850f](https://github.com/google/adk-python/commit/0f3850f56c857dfb86c7ad8de372bcc7fe495968))
* Generate IDs for FunctionCalls when processing streaming LLM responses ([fe41817](https://github.com/google/adk-python/commit/fe4181718d104843b974417c59203ed8a7b15255)), closes [#4609](https://github.com/google/adk-python/issues/4609)
* Handle merging lists in deep_merge_dicts ([cdb3ff4](https://github.com/google/adk-python/commit/cdb3ff4e1f155c357f8cf720132d09bbc1446075))
* In memory session service to evaluate dictionary keys and value into an isolated snapshot sequence before starting loop ([f75de59](https://github.com/google/adk-python/commit/f75de59362e07c0cce0ead723ceea3102081af4d))
* include intermediate subagent final response events in evaluation intermediate data ([f8a6bd7](https://github.com/google/adk-python/commit/f8a6bd7fc0ca4b37cac4dc93c725c8973a1c9027))
* **live:** Handle live session resumption and GoAway signal ([6b1600f](https://github.com/google/adk-python/commit/6b1600fbf53bcf634c5fe4793f02921bc0b75125)), closes [#4996](https://github.com/google/adk-python/issues/4996)
* move BigQueryAgentAnalyticsPlugin import inside get_runner_async ([6fd0f85](https://github.com/google/adk-python/commit/6fd0f85191dea17b7c6b033473bd39764250265b))
* Safer fix for UI widget merging in ADK ([0e71985](https://github.com/google/adk-python/commit/0e71985501c00682eff0f0c5328a3d429f2bdc68))
* Small fixes for express mode ([3a374ce](https://github.com/google/adk-python/commit/3a374ce0aae73c138cd51d754220d0d7a64677b3))
* sync callbacks with call_llm span ([b2daf83](https://github.com/google/adk-python/commit/b2daf83db406f8844f9db75abc7fee17362433b3))
* **tools:** handle toolset errors gracefully in canonical_tools ([5df03f1](https://github.com/google/adk-python/commit/5df03f1f412e3ab55a5a6ceac892ba6b985a8036)), closes [#3341](https://github.com/google/adk-python/issues/3341)
* truncate error_message in v0 schema to prevent VARCHAR overflow ([62daf4f](https://github.com/google/adk-python/commit/62daf4f61b14aee7bca9d8dec479bfd940bbb955)), closes [#4993](https://github.com/google/adk-python/issues/4993)
* update toolbox-adk and toolbox server versions ([1486925](https://github.com/google/adk-python/commit/14869253d072e901d530fd3b7ee8ef67fbe5ddbc))


### Code Refactoring

* Move SecretManagerClient to google.adk.integrations.secret_manager package ([1104523](https://github.com/google/adk-python/commit/110452375c6ccaa16e4ade7d7fe3438d185d4355))
* Remove the session events dependency from A2aAgentExecutor ([aaa03ac](https://github.com/google/adk-python/commit/aaa03ac30841b2e12e3ddf4bb02fbcbf08ae13e8))


### Documentation

* **adk:** clean up remote triggers README to remove internal references ([ccac461](https://github.com/google/adk-python/commit/ccac461b2ab6291ecd09577ca0553833eaff71b9))
* Update the MCP Toolbox docsite with the new URL ([a60baca](https://github.com/google/adk-python/commit/a60baca3ddfe2541159b32d67b738a836d2395e7))

## [1.28.0](https://github.com/google/adk-python/compare/v1.27.5...v1.28.0) (2026-03-26)


### Features

* **a2a:** add lifespan parameter to to_a2a() ([0f4c807](https://github.com/google/adk-python/commit/0f4c8073e5a180a220f88928d67ee8d521486f03)), closes [#4701](https://github.com/google/adk-python/issues/4701)
* Add a new extension for the new version of ADK-A2A integration ([6f0dcb3](https://github.com/google/adk-python/commit/6f0dcb3e26dd82fed1a8564c17a47eec03b04617))
* Add ability to run individual unit tests to unittests.sh ([b3fcd8a](https://github.com/google/adk-python/commit/b3fcd8a21fe64063cdd8d07121ee4da3adb44c30))
* Add database_role property to SpannerToolSettings and use it in execute_sql to support fine grained access controls ([360e0f7](https://github.com/google/adk-python/commit/360e0f7ebaba7a682f7230c259b474ace7ff6d13))
* Add index to events table and update dependencies ([3153e6d](https://github.com/google/adk-python/commit/3153e6d74f401f39e363a36f6fa0664f245013db)), closes [#4827](https://github.com/google/adk-python/issues/4827)
* Add MultiTurn Task success metric ([9a75c06](https://github.com/google/adk-python/commit/9a75c06873b79fbd206b3712231c0280fb2f87ca))
* Add MultiTurn Task trajectory and tool trajectory metrics ([38bfb44](https://github.com/google/adk-python/commit/38bfb4475406d63af3111775950d9c25acf17ed2))
* Add slack integration to ADK ([6909a16](https://github.com/google/adk-python/commit/6909a167c8d030111bf7118b9d5e78255a299684))
* Add Spanner Admin Toolset ([28618a8](https://github.com/google/adk-python/commit/28618a8dcbee9c4faeec6653a5d978d0330f39bb))
* Add SSE streaming support to conformance tests ([c910961](https://github.com/google/adk-python/commit/c910961501ef559814f54c22aca1609fd3227b80))
* Add support for Anthropic's thinking_blocks format in LiteLLM integration ([fc45fa6](https://github.com/google/adk-python/commit/fc45fa68d75fbf5276bf5951929026285a8bb4af)), closes [#4801](https://github.com/google/adk-python/issues/4801)
* Add support for timeout to UnsafeLocalCodeExecutor ([71d26ef](https://github.com/google/adk-python/commit/71d26ef7b90fe25a5093e4ccdf74b103e64fac67))
* **auth:** Integrate GCP IAM Connectors (Noop implementation) ([78e5a90](https://github.com/google/adk-python/commit/78e5a908dcb4b1a93e156c6f1b282f59ec6b69d4))
* **bigquery:** Migrate 1P BQ Toolset ([08be442](https://github.com/google/adk-python/commit/08be44295de614f30e686113897af7fe9c228751)) ([7aa1f52](https://github.com/google/adk-python/commit/7aa1f5252c15caaf40fde73ac4283fa0a48d8a96)) ([d112131](https://github.com/google/adk-python/commit/d1121317ef4e1ac559f4ae13855ac1af28eef8f6)) ([166ff99](https://github.com/google/adk-python/commit/166ff99b9266cd3bb0e86070c58a67d937216297))
* enable suppressing A2A experimental warnings ([fdc2b43](https://github.com/google/adk-python/commit/fdc2b4355b5a73b8f32d3fa32a092339d963ce67))
* Enhance AgentEngineSandboxCodeExecutor sample to automatically provision an Agent Engine if neither agent_engine_resource_name nor sandbox_resource_name is provided ([6c34694](https://github.com/google/adk-python/commit/6c34694da64968bc766a7e5e860c0ed9acbc69c2))
* Extract and merge EventActions from A2A metadata ([4b677e7](https://github.com/google/adk-python/commit/4b677e73b939f5a13269abd9ba9fe65e4b78d7f6)), closes [#3968](https://github.com/google/adk-python/issues/3968)
* **mcp:** add sampling callback support for MCP sessions ([8f82697](https://github.com/google/adk-python/commit/8f826972cc06ef250c1f020e34b9d1cdbd0788c4))
* Optional GCP project and credential for GCS access ([2f90c1a](https://github.com/google/adk-python/commit/2f90c1ac09638517b08cd96a17d595f0968f0bf6))
* Support new embedding model in files retrieval ([faafac9](https://github.com/google/adk-python/commit/faafac9bb33b45174f04746055fc655b12d3e7f7))


### Bug Fixes

* add agent name validation to prevent arbitrary module imports ([116f75d](https://github.com/google/adk-python/commit/116f75d))
* add protection for arbitrary module imports ([995cd1c](https://github.com/google/adk-python/commit/995cd1c)), closes [#4947](https://github.com/google/adk-python/issues/4947)
* Add read-only session support in DatabaseSessionService ([f6ea58b](https://github.com/google/adk-python/commit/f6ea58b5939b33afad5a2d2f8fb395150120ae07)), closes [#4771](https://github.com/google/adk-python/issues/4771)
* Allow snake case for skill name ([b157276](https://github.com/google/adk-python/commit/b157276cbb3c4f7f7b97e338e9d9df63d9c949cd))
* **bigquery:** use valid dataplex OAuth scope ([4010716](https://github.com/google/adk-python/commit/4010716470fc83918dc367c5971342ff551401c8))
* Default to ClusterIP so GKE deployment isn't publicly exposed by default ([f7359e3](https://github.com/google/adk-python/commit/f7359e3fd40eae3b8ef50c7bc88f1075ffb9b7de))
* **deps:** bump google-genai minimum to &gt;=1.64.0 for gemini-embedding-2-preview ([f8270c8](https://github.com/google/adk-python/commit/f8270c826bc807da99b4126e98ee1c505f4ed7c3))
* enforce allowed file extensions for GET requests in the builder API ([96e845e](https://github.com/google/adk-python/commit/96e845ef8cf66b288d937e293a88cdb28b09417c))
* error when event does not contain long_running_tool_ids ([1f9f0fe](https://github.com/google/adk-python/commit/1f9f0fe9d349c06f48063b856242c67654786dbc))
* Exclude compromised LiteLLM versions from dependencies pin to 1.82.6 ([77f1c41](https://github.com/google/adk-python/commit/77f1c41be61eed017b008d7ab311923e30b46643))
* Fix IDE hangs by moving test venv and cache to /tmp ([6f6fd95](https://github.com/google/adk-python/commit/6f6fd955f6dab50c98859294328a98f32181dc27))
* Fix imports for environment simulation files ([dcccfca](https://github.com/google/adk-python/commit/dcccfca1d1dd1b3b9c273278e9f9c883f0148eba))
* gate builder endpoints behind web flag ([6c24ccc](https://github.com/google/adk-python/commit/6c24ccc9ec7d0f942e1dd436a823f48ae1a0c695))
* Handle concurrent creation of app/user state rows in DatabaseSessionService ([d78422a](https://github.com/google/adk-python/commit/d78422a4051bba383202f3f13325e65b8be3ccd3)), closes [#4954](https://github.com/google/adk-python/issues/4954)
* **live:** convert response_modalities to Modality enum before assigning to LiveConnectConfig ([47aaf66](https://github.com/google/adk-python/commit/47aaf66efb3e3825f06fd44578d592924fb7542b)), closes [#4869](https://github.com/google/adk-python/issues/4869)
* **models:** handle arbitrary dict responses in part_to_message_block ([c26d359](https://github.com/google/adk-python/commit/c26d35916e1b6cd12a412516381c6fcbf867bcee))
* **models:** update 429 docs link for Gemini ([a231c72](https://github.com/google/adk-python/commit/a231c729e6526a2035b4630796f3dc8a658bb203))
* populate `required` for Pydantic `BaseModel` parameters in `FunctionTool` ([c5d809e](https://github.com/google/adk-python/commit/c5d809e10eeaadfcbd12874d0976b5259f327adf)), closes [#4777](https://github.com/google/adk-python/issues/4777)
* Prevent compaction of events with pending function calls ([991c411](https://github.com/google/adk-python/commit/991c4111e31ffe97acc73c2ddf5cacea0955d39f)), closes [#4740](https://github.com/google/adk-python/issues/4740)
* Prevent uv.lock modifications in unittests.sh ([e6476c9](https://github.com/google/adk-python/commit/e6476c9790eaa8f3a6ae8165351f8fe38bf9bd1e))
* Refactor blocking subprocess call to use asyncio in bash_tool ([58c4536](https://github.com/google/adk-python/commit/58c453688fea921707a07c21d0669174ea1a3b5f))
* Refactor LiteLlm check to avoid ImportError ([7b94a76](https://github.com/google/adk-python/commit/7b94a767337e0d642e808734608f07a70e077c62))
* Reject appends to stale sessions in DatabaseSessionService ([b8e7647](https://github.com/google/adk-python/commit/b8e764715cb1cc7c8bc1de9aa94ca5f5271bb627)), closes [#4751](https://github.com/google/adk-python/issues/4751)
* Remove redundant client_id from fetch_token call ([50d6f35](https://github.com/google/adk-python/commit/50d6f35139b56aa5b9fb06ee53b911269c222ffe)), closes [#4782](https://github.com/google/adk-python/issues/4782)
* returns '&lt;No stdout/stderr captured&gt;' instead of empty strings for clearer agent feedback and correct typing ([3e00e95](https://github.com/google/adk-python/commit/3e00e955519730503e73155723f27b2bc8d5779b))
* Store and retrieve usage_metadata in Vertex AI custom_metadata ([b318eee](https://github.com/google/adk-python/commit/b318eee979b1625d3d23ad98825c88f54016a12f))
* Support resolving string annotations for `find_context_parameter` ([22fc332](https://github.com/google/adk-python/commit/22fc332c95b7deca95240b33406513bcc95c6e03))
* **telemetry:** Rolling back change to fix issue affecting LlmAgent creation due to missing version field ([0e18f81](https://github.com/google/adk-python/commit/0e18f81a5cd0d0392ded653b1a63a236449a2685))
* **tools:** disable default httpx 5s timeout in OpenAPI tool _request ([4c9c01f](https://github.com/google/adk-python/commit/4c9c01fd4b1c716950700fd56a1a8789795cb7b1)), closes [#4431](https://github.com/google/adk-python/issues/4431)
* **tools:** support regional Discovery Engine endpoints ([30b904e](https://github.com/google/adk-python/commit/30b904e596b0bcea8498a9b47d669585a6c481d3))
* **tools:** support structured datastores in DiscoveryEngineSearchTool ([f35c3a6](https://github.com/google/adk-python/commit/f35c3a66da7c66967d06d0f5f058f9417abf1f8d)), closes [#3406](https://github.com/google/adk-python/issues/3406)
* Update Agent Registry to use the full agent card if available ([031f581](https://github.com/google/adk-python/commit/031f581ac6e0fb06cc1175217a26bdd0c7382da8))
* Update eval extras to Vertex SDK package version with constrained LiteLLM upperbound ([27cc98d](https://github.com/google/adk-python/commit/27cc98db5fbc15de27713a5814d5c68e9c835d0f))
* Update import and version for k8s-agent-sandbox ([1ee0623](https://github.com/google/adk-python/commit/1ee062312813e9564fdff693f883f57987e18c6a)), closes [#4883](https://github.com/google/adk-python/issues/4883)
* Update list_agents to only list directories, not validate agent definitions ([5020954](https://github.com/google/adk-python/commit/50209549206256abe5d1c5d84ab2b14dfdf80d66))


### Code Refactoring
* rename agent simulator to environment simulation. Also add tracing into environment simulation ([99a31bf](https://github.com/google/adk-python/commit/99a31bf77ea6fb2c53c313094734611dcb87b1e2))


### Documentation

* Feat/Issue Monitoring Agent ([780093f](https://github.com/google/adk-python/commit/780093f389bfbffce965c89ca888d49f992219c1))
* Use a dedicated API key for docs agents ([51c19cb](https://github.com/google/adk-python/commit/51c19cbc13c422dffd764ed0d7c664deed9e58b3))


## [1.27.4](https://github.com/google/adk-python/compare/v1.27.3...v1.27.4) (2026-03-24)
### Bug Fixes

* Exclude compromised LiteLLM versions from dependencies pin to 1.82.6 ([fa5e707](https://github.com/google/adk-python/commit/fa5e707c11ad748e7db2f653b526d9bdc4b7d405))
* gate builder endpoints behind web flag ([44b3f72](https://github.com/google/adk-python/commit/44b3f72d8f4ee09461d0acd8816149e801260b84))

## [1.27.3](https://github.com/google/adk-python/compare/v1.27.2...v1.27.3) (2026-03-23)
### Bug Fixes
  * add protection for arbitrary module imports ([276adfb](https://github.com/google/adk-python/commit/276adfb7ad552213c0201a3c95efbc9876bf3b66))

## [1.27.2](https://github.com/google/adk-python/compare/v1.27.1...v1.27.2) (2026-03-17)
### Bug Fixes
  * Use valid dataplex OAuth scope for BigQueryToolset ([4010716](https://github.com/google/adk-python/commit/4010716470fc83918dc367c5971342ff551401c8))
  * Store and retrieve usage_metadata in Vertex AI custom_metadata ([b318eee](https://github.com/google/adk-python/commit/b318eee979b1625d3d23ad98825c88f54016a12f))

## [1.27.1](https://github.com/google/adk-python/compare/v1.27.0...v1.27.1) (2026-03-13)
### Bug Fixes
  * Rolling back change to fix issue affecting LlmAgent creation due to missing version field ([0e18f81](https://github.com/google/adk-python/commit/0e18f81a5cd0d0392ded653b1a63a236449a2685))


## [1.27.0](https://github.com/google/adk-python/compare/v1.26.0...v1.27.0) (2026-03-12)

### Features
* **[Core]**
  * Introduce A2A request interceptors in RemoteA2aAgent ([6f772d2](https://github.com/google/adk-python/commit/6f772d2b0841446bc168ccf405b59eb17c1d671a))
  * Add UiWidget to EventActions for supporting new experimental UI Widgets feature ([530ff06](https://github.com/google/adk-python/commit/530ff06ece61a93855a53235e85af18b46b2a6a0))
  * **auth:** Add pluggable support for auth integrations using AuthProviderRegistry within CredentialManager ([d004074](https://github.com/google/adk-python/commit/d004074c90525442a69cebe226440bb318abad29))
  * Support all `types.SchemaUnion` as output_schema in LLM Agent ([63f450e](https://github.com/google/adk-python/commit/63f450e0231f237ee1af37f17420d37b15426d48))
  * durable runtime support ([07fdd23](https://github.com/google/adk-python/commit/07fdd23c9c3f5046aa668fb480840f67f13bf271))
  * **runners:** pass GetSessionConfig through Runner to session service ([eff724a](https://github.com/google/adk-python/commit/eff724ac9aef2a203607f772c473703f21c09a72))

* **[Models]**
  * Add support for PDF documents in Anthropic LLM ([4c8ba74](https://github.com/google/adk-python/commit/4c8ba74fcb07014db187ef8db8246ff966379aa9))
  * Add streaming support for Anthropic models ([5770cd3](https://github.com/google/adk-python/commit/5770cd3776c8805086ece34d747e589e36916a34)), closes [#3250](https://github.com/google/adk-python/issues/3250)
  * Enable output schema with tools for LiteLlm models ([89df5fc](https://github.com/google/adk-python/commit/89df5fcf883b599cf7bfe40bde35b8d86ab0146b)), closes [#3969](https://github.com/google/adk-python/issues/3969)
  * Preserve thought_signature in LiteLLM tool calls ([ae565be](https://github.com/google/adk-python/commit/ae565be30e64249b2913ad647911061a8b170e21)), closes [#4650](https://github.com/google/adk-python/issues/4650)

* **[Web]**
  * Updated human in the loop: developers now can respond to long running functions directly in chat
  * Render artifacts when resuming
  * Fix some light mode styles
  * Fix token level streaming not working properly ([22799c0](https://github.com/google/adk-python/commit/22799c0833569753021078f7bd8dcd11ece562fe))

* **[Observability]**
  * **telemetry:** add new gen_ai.agent.version span attribute ([ffe97ec](https://github.com/google/adk-python/commit/ffe97ec5ad7229c0b4ba573f33eb0edb8bb2877a))
  * **otel:** add `gen_ai.tool.definitions` to experimental semconv ([4dd4d5e](https://github.com/google/adk-python/commit/4dd4d5ecb6a1dadbc41389dac208616f6d21bc6e))
  * **otel:** add experimental semantic convention and emit `gen_ai.client.inference.operation.details` event ([19718e9](https://github.com/google/adk-python/commit/19718e9c174af7b1287b627e6b23a609db1ee5e2))
  * add missing token usage span attributes during model usage ([77bf325](https://github.com/google/adk-python/commit/77bf325d2bf556621c3276f74ee2816fce2a7085))
  * capture tool execution error code in OpenTelemetry spans ([e0a6c6d](https://github.com/google/adk-python/commit/e0a6c6db6f8e2db161f8b86b9f11030f0cec807a))

* **[Tools]**
  * Warn when accessing DEFAULT_SKILL_SYSTEM_INSTRUCTION ([35366f4](https://github.com/google/adk-python/commit/35366f4e2a0575090fe12cd85f51e8116a1cd0d3))
  * add preserve_property_names option to OpenAPIToolset ([078b516](https://github.com/google/adk-python/commit/078b5163ff47acec69b1c8e105f62eb7b74f5548))
  * Add gcs filesystem support for Skills. It supports skills in text and pdf format, also has some sample agents ([6edcb97](https://github.com/google/adk-python/commit/6edcb975827dbd543a40ae3a402d2389327df603))
  * Add list_skills_in_dir to skills utils ([327b3af](https://github.com/google/adk-python/commit/327b3affd2d0a192f5a072b90fdb4aae7575be90))
  * Add support for MCP App UI widgets in MCPTool ([86db35c](https://github.com/google/adk-python/commit/86db35c338adaafb41e156311465e71e17edf35e))
  * add Dataplex Catalog search tool to BigQuery ADK ([82c2eef](https://github.com/google/adk-python/commit/82c2eefb27313c5b11b9e9382f626f543c53a29e))
  * Add RunSkillScriptTool to SkillToolset ([636f68f](https://github.com/google/adk-python/commit/636f68fbee700aa47f01e2cfd746859353b3333d))
  * Add support for ADK tools in SkillToolset ([44a5e6b](https://github.com/google/adk-python/commit/44a5e6bdb8e8f02891e72b65ef883f108c506f6a))
  * limit number of user-provided BigQuery job labels and reserve internal prefixes ([8c4ff74](https://github.com/google/adk-python/commit/8c4ff74e7d70cf940f54f6d7735f001495ce75d5))
  * Add param support to Bigtable execute_sql ([5702a4b](https://github.com/google/adk-python/commit/5702a4b1f59b17fd8b290fc125c349240b0953d7))
  * **bigtable:** add Bigtable cluster metadata tools ([34c560e](https://github.com/google/adk-python/commit/34c560e66e7ad379f586bbcd45a9460dc059bee2))
  * execute-type param addition in GkeCodeExecutor ([9c45166](https://github.com/google/adk-python/commit/9c451662819a6c7de71be71d12ea715b2fe74135))
  * **skill:** Add BashTool ([8a31612](https://github.com/google/adk-python/commit/8a3161202e4bac0bb8e8801b100f4403c1c75646))
  * Add support for toolsets to additional_tools field of SkillToolset ([066fcec](https://github.com/google/adk-python/commit/066fcec3e8e669d1c5360e1556afce3f7e068072))


* **[Optimization]**
  * Add `adk optimize` command ([b18d7a1](https://github.com/google/adk-python/commit/b18d7a140f8e18e03255b07e6d89948427790095))
  * Add interface between optimization infra and LocalEvalService ([7b7ddda](https://github.com/google/adk-python/commit/7b7ddda46ca701952f002b2807b89dbef5322414))
  * Add GEPA root agent prompt optimizer ([4e3e2cb](https://github.com/google/adk-python/commit/4e3e2cb58858e08a79bc6119ad49b6c049dbc0d0))

* **[Integrations]**
  * Enhance BigQuery plugin schema upgrades and error reporting ([bcf38fa](https://github.com/google/adk-python/commit/bcf38fa2bac2f0d1ab74e07e01eb5160bad1d6dc))
  * Enhance BQ plugin with fork safety, auto views, and trace continuity ([80c5a24](https://github.com/google/adk-python/commit/80c5a245557cd75870e72bff0ecfaafbd37fdbc7))
  * Handle Conflict Errors in BigQuery Agent Analytics Plugin ([372c76b](https://github.com/google/adk-python/commit/372c76b857daa1102e76d755c0758f1515d6f180))
  * Added tracking headers for ADK CLI command to Agent Engine ([3117446](https://github.com/google/adk-python/commit/3117446293d30039c2f21f3d17a64a456c42c47d))

* **[A2A]**
  * New implementation of A2aAgentExecutor and A2A-ADK conversion ([87ffc55](https://github.com/google/adk-python/commit/87ffc55640dea1185cf67e6f9b78f70b30867bcc))
  * New implementation of RemoteA2aAgent and A2A-ADK conversion ([6770e41](https://github.com/google/adk-python/commit/6770e419f5e200f4c7ad26587e1f769693ef4da0))

### Bug Fixes

* Allow artifact services to accept dictionary representations of types.Part ([b004da5](https://github.com/google/adk-python/commit/b004da50270475adc9e1d7afe4064ca1d10c560a)), closes [#2886](https://github.com/google/adk-python/issues/2886)
* Decode image data from ComputerUse tool response into image blobs ([d7cfd8f](https://github.com/google/adk-python/commit/d7cfd8fe4def2198c113ff1993ef39cd519908a1))
* Expand LiteLLM reasoning extraction to include 'reasoning' field ([9468487](https://github.com/google/adk-python/commit/94684874e436c2959cfc90ec346010a6f4fddc49)), closes [#3694](https://github.com/google/adk-python/issues/3694)
* Filter non-agent directories from list_agents() ([3b5937f](https://github.com/google/adk-python/commit/3b5937f022adf9286dc41e01e3618071a23eb992))
* Fix Type Error by initializing user_content as a Content object ([2addf6b](https://github.com/google/adk-python/commit/2addf6b9dacfe87344aeec0101df98d99c23bdb1))
* Handle length finish reason in LiteLLM responses ([4c6096b](https://github.com/google/adk-python/commit/4c6096baa1b0bed8533397287a5c11a0c4cb9101)), closes [#4482](https://github.com/google/adk-python/issues/4482)
* In SaveFilesAsArtifactsPlugin, write the artifact delta to state then event actions so that the plugin works with ADK Web UI's artifacts panel ([d6f31be](https://github.com/google/adk-python/commit/d6f31be554d9b7ee15fd9c95ae655b2265fb1f32))
* Make invocation_context optional in convert_event_to_a2a_message ([8e79a12](https://github.com/google/adk-python/commit/8e79a12d6bcde43cc33247b7ee6cc9e929fa6288))
* Optimize row-level locking in append_event ([d61846f](https://github.com/google/adk-python/commit/d61846f6c6dd5e357abb0e30eaf61fe27896ae6a)), closes [#4655](https://github.com/google/adk-python/issues/4655)
* Preserve thought_signature in FunctionCall conversions between GenAI and A2A ([f9c104f](https://github.com/google/adk-python/commit/f9c104faf73e2a002bb3092b50fb88f4eed78163))
* Prevent splitting of SSE events with artifactDelta for function resume requests ([6a929af](https://github.com/google/adk-python/commit/6a929af718fa77199d1eecc62b16c54beb1c8d84)), closes [#4487](https://github.com/google/adk-python/issues/4487)
* Propagate file names during A2A to/from Genai Part conversion ([f324fa2](https://github.com/google/adk-python/commit/f324fa2d62442301ebb2e7974eb97ea870471410))
* Propagate thought from A2A TextPart metadata to GenAI Part ([e59929e](https://github.com/google/adk-python/commit/e59929e11a56aaee7bb0c45cd4c9d9fef689548c))
* Re-export DEFAULT_SKILL_SYSTEM_INSTRUCTION to skills and skill/prompt.py to avoid breaking current users ([de4dee8](https://github.com/google/adk-python/commit/de4dee899cd777a01ba15906f8496a72e717ea98))
* Refactor type string update in Anthropic tool param conversion ([ab4b736](https://github.com/google/adk-python/commit/ab4b736807dabee65659486a68135d9f1530834c))
* **simulation:** handle NoneType generated_content ([9d15517](https://github.com/google/adk-python/commit/9d155177b956f690d4c99560f582e3e90e111f71))
* Store and retrieve EventCompaction via custom_metadata in Vertex AISessionService ([2e434ca](https://github.com/google/adk-python/commit/2e434ca7be765d45426fde9d52b131921bd9fa30)), closes [#3465](https://github.com/google/adk-python/issues/3465)
* Support before_tool_callback and after_tool_callback in Live mode ([c36a708](https://github.com/google/adk-python/commit/c36a708058163ade061cd3d2f9957231a505a62d)), closes [#4704](https://github.com/google/adk-python/issues/4704)
* temp-scoped state now visible to subsequent agents in same invocation ([2780ae2](https://github.com/google/adk-python/commit/2780ae2892adfbebc7580c843d2eaad29f86c335))
* **tools:** Handle JSON Schema boolean schemas in Gemini schema conversion ([3256a67](https://github.com/google/adk-python/commit/3256a679da3e0fb6f18b26057e87f5284680cb58))
* typo in A2A EXPERIMENTAL warning ([eb55eb7](https://github.com/google/adk-python/commit/eb55eb7e7f0fa647d762205225c333dcd8a08dd0))
* Update agent_engine_sandbox_code_executor in ADK ([dff4c44](https://github.com/google/adk-python/commit/dff4c4404051b711c8be437ba0ae26ca2763df7d))
* update Bigtable query tools to async functions ([72f3e7e](https://github.com/google/adk-python/commit/72f3e7e1e00d93c632883027bf6d31a9095cd6c2))
* Update expected UsageMetadataChunk in LiteLLM tests ([dd0851a](https://github.com/google/adk-python/commit/dd0851ac74d358bc030def5adf242d875ab18265)), closes [#4680](https://github.com/google/adk-python/issues/4680)
* update toolbox server and SDK package versions ([2e370ea](https://github.com/google/adk-python/commit/2e370ea688033f0663501171d0babfb0d74de4b2))
* Validate session before streaming instead of eagerly advancing the runner generator ([ebbc114](https://github.com/google/adk-python/commit/ebbc1147863956e85931f8d46abb0632e3d1cf67))


### Code Refactoring

* extract reusable functions from hitl and auth preprocessor ([c59afc2](https://github.com/google/adk-python/commit/c59afc21cbed27d1328872cdc2b0e182ab2ca6c8))
* Rename base classes and TypeVars in optimization data types ([9154ef5](https://github.com/google/adk-python/commit/9154ef59d29eb37538914e9967c4392cc2a24237))


## [1.26.0](https://github.com/google/adk-python/compare/v1.25.1...v1.26.0) (2026-02-26)


### Features

* **[Core]**
  * Add intra-invocation compaction and token compaction pre-request ([485fcb8](https://github.com/google/adk-python/commit/485fcb84e3ca351f83416c012edcafcec479c1db))
  * Use `--memory_service_uri` in ADK CLI run command ([a7b5097](https://github.com/google/adk-python/commit/a7b509763c1732f0363e90952bb4c2672572d542))

* **[Models]**
  * Add `/chat/completions` integration to `ApigeeLlm` ([9c4c445](https://github.com/google/adk-python/commit/9c4c44536904f5cf3301a5abb910a5666344a8c5))
  * Add `/chat/completions` streaming support to Apigee LLM ([121d277](https://github.com/google/adk-python/commit/121d27741684685c564e484704ae949c5f0807b1))
  * Expand LiteLlm supported models and add registry tests ([d5332f4](https://github.com/google/adk-python/commit/d5332f44347f44d60360e14205a2342a0c990d66))

* **[Tools]**
  * Add `load_skill_from_dir()` method ([9f7d5b3](https://github.com/google/adk-python/commit/9f7d5b3f1476234e552b783415527cc4bac55b39))
  * Agent Skills spec compliance — validation, aliases, scripts, and auto-injection ([223d9a7](https://github.com/google/adk-python/commit/223d9a7ff52d8da702f1f436bd22e94ad78bd5da))
  * BigQuery ADK support for search catalog tool ([bef3f11](https://github.com/google/adk-python/commit/bef3f117b4842ce62760328304484cd26a1ec30a))
  * Make skill instruction optimizable and can adapt to user tasks ([21be6ad](https://github.com/google/adk-python/commit/21be6adcb86722a585b26f600c45c85e593b4ee0))
  * Pass trace context in MCP tool call's `_meta` field with OpenTelemetry propagator ([bcbfeba](https://github.com/google/adk-python/commit/bcbfeba953d46fca731b11542a00103cef374e57))

* **[Evals]**
  * Introduce User Personas to the ADK evaluation framework ([6a808c6](https://github.com/google/adk-python/commit/6a808c60b38ad7140ddeb222887c6accc63edce9))

* **[Services]**
  * Add generate/create modes for Vertex AI Memory Bank writes ([811e50a](https://github.com/google/adk-python/commit/811e50a0cbb181d502b9837711431ef78fca3f34))
  * Add support for memory consolidation via Vertex AI Memory Bank ([4a88804](https://github.com/google/adk-python/commit/4a88804ec7d17fb4031b238c362f27d240df0a13))

* **[A2A]**
  * Add interceptor framework to `A2aAgentExecutor` ([87fcd77](https://github.com/google/adk-python/commit/87fcd77caa9672f219c12e5a0e2ff65cbbaaf6f3))

* **[Auth]**
  * Add native support for `id_token` in OAuth2 credentials ([33f7d11](https://github.com/google/adk-python/commit/33f7d118b377b60f998c92944d2673679fddbc6e))
  * Support ID token exchange in `ServiceAccountCredentialExchanger` ([7be90db](https://github.com/google/adk-python/commit/7be90db24b41f1830e39ca3d7e15bf4dbfa5a304)), closes [#4458](https://github.com/google/adk-python/issues/4458)

* **[Integrations]**
  * Agent Registry in ADK ([abaa929](https://github.com/google/adk-python/commit/abaa92944c4cd43d206e2986d405d4ee07d45afe))
  * Add schema auto-upgrade, tool provenance, HITL tracing, and span hierarchy fix to BigQuery Agent Analytics plugin ([4260ef0](https://github.com/google/adk-python/commit/4260ef0c7c37ecdfea295fb0e1a933bb0df78bea))
  * Change default BigQuery table ID and update docstring ([7557a92](https://github.com/google/adk-python/commit/7557a929398ec2a1f946500d906cef5a4f86b5d1))
  * Update Agent Registry to create AgentCard from info in get agents endpoint ([c33d614](https://github.com/google/adk-python/commit/c33d614004a47d1a74951dd13628fd2300aeb9ef))

* **[Web]**
  * Enable dependency injection for agent loader in FastAPI app gen ([34da2d5](https://github.com/google/adk-python/commit/34da2d5b26e82f96f1951334fe974a0444843720))


### Bug Fixes

* Add OpenAI strict JSON schema enforcement in LiteLLM ([2dbd1f2](https://github.com/google/adk-python/commit/2dbd1f25bdb1d88a6873d824b81b3dd5243332a4)), closes [#4573](https://github.com/google/adk-python/issues/4573)
* Add push notification config store to agent_to_a2a ([4ca904f](https://github.com/google/adk-python/commit/4ca904f11113c4faa3e17bb4a9662dca1f936e2e)), closes [#4126](https://github.com/google/adk-python/issues/4126)
* Add support for injecting a custom google.genai.Client into Gemini models ([48105b4](https://github.com/google/adk-python/commit/48105b49c5ab8e4719a66e7219f731b2cd293b00)), closes [#2560](https://github.com/google/adk-python/issues/2560)
* Add support for injecting a custom google.genai.Client into Gemini models ([c615757](https://github.com/google/adk-python/commit/c615757ba12093ba4a2ba19bee3f498fef91584c)), closes [#2560](https://github.com/google/adk-python/issues/2560)
* Check both `input_stream` parameter name and its annotation to decide whether it's a streaming tool that accept input stream ([d56cb41](https://github.com/google/adk-python/commit/d56cb4142c5040b6e7d13beb09123b8a59341384))
* **deps:** Increase pydantic lower version to 2.7.0 ([dbd6420](https://github.com/google/adk-python/commit/dbd64207aebea8c5af19830a9a02d4c05d1d9469))
* edit copybara and BUILD config for new adk/integrations folder (added with Agent Registry) ([37d52b4](https://github.com/google/adk-python/commit/37d52b4caf6738437e62fe804103efe4bde363a1))
* Expand add_memory to accept MemoryEntry ([f27a9cf](https://github.com/google/adk-python/commit/f27a9cfb87caecb8d52967c50637ed5ad541cd07))
* Fix pickling lock errors in McpSessionManager ([4e2d615](https://github.com/google/adk-python/commit/4e2d6159ae3552954aaae295fef3e09118502898))
* fix typo in PlanReActPlanner instruction ([6d53d80](https://github.com/google/adk-python/commit/6d53d800d5f6dc5d4a3a75300e34d5a9b0f006f5))
* handle UnicodeDecodeError when loading skills in ADK ([3fbc27f](https://github.com/google/adk-python/commit/3fbc27fa4ddb58b2b69ee1bea1e3a7b2514bd725))
* Improve BigQuery Agent Analytics plugin reliability and code quality ([ea03487](https://github.com/google/adk-python/commit/ea034877ec15eef1be8f9a4be9fcd95446a3dc21))
* Include list of skills in every message and remove list_skills tool from system instruction ([4285f85](https://github.com/google/adk-python/commit/4285f852d54670390b19302ed38306bccc0a7cee))
* Invoke on_tool_error_callback for missing tools in live mode ([e6b601a](https://github.com/google/adk-python/commit/e6b601a2ab71b7e2df0240fd55550dca1eba8397))
* Keep query params embedded in OpenAPI paths when using httpx ([ffbcc0a](https://github.com/google/adk-python/commit/ffbcc0a626deb24fe38eab402b3d6ace484115df)), closes [#4555](https://github.com/google/adk-python/issues/4555)
* Only relay the LiveRequest after tools is invoked ([b53bc55](https://github.com/google/adk-python/commit/b53bc555cceaa11dc53b42c9ca1d650592fb4365))
* Parallelize tool resolution in LlmAgent.canonical_tools() ([7478bda](https://github.com/google/adk-python/commit/7478bdaa9817b0285b4119e8c739d7520373f719))
* race condition in table creation for `DatabaseSessionService` ([fbe9ecc](https://github.com/google/adk-python/commit/fbe9eccd05e628daa67059ba2e6a0d03966b240d))
* Re-export DEFAULT_SKILL_SYSTEM_INSTRUCTION to skills and skill/prompt.py to avoid breaking current users ([40ec134](https://github.com/google/adk-python/commit/40ec1343c2708e1cf0d39cd8b8a96f3729f843de))
* Refactor LiteLLM streaming response parsing for compatibility with LiteLLM 1.81+ ([e8019b1](https://github.com/google/adk-python/commit/e8019b1b1b0b43dcc5fa23075942b31db502ffdd)), closes [#4225](https://github.com/google/adk-python/issues/4225)
* remove duplicate session GET when using API server, unbreak auto_session_create when using API server ([445dc18](https://github.com/google/adk-python/commit/445dc189e915ce5198e822ad7fadd6bb0880a95e))
* Remove experimental decorators from user persona data models ([eccdf6d](https://github.com/google/adk-python/commit/eccdf6d01e70c37a1e5aa47c40d74469580365d2))
* Replace the global DEFAULT_USER_PERSONA_REGISTRY with a function call to get_default_persona_registry ([2703613](https://github.com/google/adk-python/commit/2703613572a38bf4f9e25569be2ee678dc91b5b5))
* **skill:** coloate default skill SI with skilltoolset ([fc1f1db](https://github.com/google/adk-python/commit/fc1f1db00562a79cd6c742cfd00f6267295c29a8))
* Update agent_engine_sandbox_code_executor in ADK ([ee8d956](https://github.com/google/adk-python/commit/ee8d956413473d1bbbb025a470ad882c1487d8b8))
* Update agent_engine_sandbox_code_executor in ADK ([dab80e4](https://github.com/google/adk-python/commit/dab80e4a8f3c5476f731335724bff5df3e6f3650))
* Update sample skills agent to use weather-skill instead of weather_skill ([8f54281](https://github.com/google/adk-python/commit/8f5428150d18ed732b66379c0acb806a9121c3cb))
* update Spanner query tools to async functions ([1dbcecc](https://github.com/google/adk-python/commit/1dbceccf36c28d693b0982b531a99877a3e75169))
* use correct msg_out/msg_err keys for Agent Engine sandbox output ([b1e33a9](https://github.com/google/adk-python/commit/b1e33a90b4ba716d717e0488b84892b8a7f42aac))
* Validate session before streaming instead of eagerly advancing the runner generator ([ab32f33](https://github.com/google/adk-python/commit/ab32f33e7418d452e65cf6f5b6cbfe1371600323))
* **web:** allow session resume without new message ([30b2ed3](https://github.com/google/adk-python/commit/30b2ed3ef8ee6d3633743c0db00533683d3342d8))


### Code Refactoring

* Extract reusable function for building agent transfer instructions ([e1e0d63](https://github.com/google/adk-python/commit/e1e0d6361675e7b9a2c9b2523e3a72e2e5e7ce05))
* Extract reusable private methods ([976a238](https://github.com/google/adk-python/commit/976a238544330528b4f9f4bea6c4e75ec13b33e1))
* Extract reusable private methods ([42eeaef](https://github.com/google/adk-python/commit/42eeaef2b34c860f126c79c552435458614255ad))
* Extract reusable private methods ([706f9fe](https://github.com/google/adk-python/commit/706f9fe74db0197e19790ca542d372ce46d0ae87))


### Documentation

* add `thinking_config` in `generate_content_config` in example agent ([c6b1c74](https://github.com/google/adk-python/commit/c6b1c74321faf62cc52d2518eb9ea0dcef050cde))

## [1.25.1](https://github.com/google/adk-python/compare/v1.25.0...v1.25.1) (2026-02-18)

### Bug Fixes

* Fix pickling lock errors in McpSessionManager ([4e2d615](https://github.com/google/adk-python/commit/4e2d6159ae3552954aaae295fef3e09118502898))

## [1.25.0](https://github.com/google/adk-python/compare/v1.24.1...v1.25.0) (2026-02-11)

### Features

* **[Core]**
  * Add a demo for the simple prompt optimizer for the optimization interface ([0abf4cd](https://github.com/google/adk-python/commit/0abf4cd2c7103a071506c9398455a3bd66fe5da5))
  * Add `--auto_create_session` flag to `adk api_server` CLI ([40c15d0](https://github.com/google/adk-python/commit/40c15d059599472b40f48272a464eb3cb7345fc6))
  * Add `add_events_to_memory` facade for event-delta ([59e8897](https://github.com/google/adk-python/commit/59e88972ae4f10274444593db0607f40cfcc597e))
  * Add post-invocation token-threshold compaction with event retention ([a88e864](https://github.com/google/adk-python/commit/a88e8647558a9b9d0bfdf38d2d8de058e3ba0596))
  * Add report generation to `adk conformance test` command ([43c437e](https://github.com/google/adk-python/commit/43c437e38b9109b68a81de886d1901e4d8f87a01))

* **[Models]**
  * Add base_url option to Gemini LLM class ([781f605](https://github.com/google/adk-python/commit/781f605a1e5de6d77b69d7e7b9835ec6fc8de4bf))

* **[Tools]**
  * Enhance google credentials config to support externally passed access token ([3cf43e3](https://github.com/google/adk-python/commit/3cf43e3842d9987499ea70d6f63d6e1c4d4a07db))
  * Update agent simulator by improving prompts and add environment data ([7af1858](https://github.com/google/adk-python/commit/7af1858f46b66fa4471c5ba7943385f2d23d08d3))
  * Add a load MCP resource tool ([e25227d](https://github.com/google/adk-python/commit/e25227da5e91a8c1192af709f8e8bb2a471ded92))
  * Add SkillToolset to adk ([8d02792](https://github.com/google/adk-python/commit/8d0279251ce4fad6f0c84bd7777eb5a74f7ba07a))

* **[Web]**
  * Add `/health` and `/version` endpoints to ADK web server ([25ec2c6](https://github.com/google/adk-python/commit/25ec2c6b614cf8d185ff6dbdac5697a210be68da))

### Bug Fixes

* Use async iteration for VertexAiSessionService.list_sessions pagination ([758d337](https://github.com/google/adk-python/commit/758d337c76d877e3174c35f06551cc9beb1def06))
* Fix event loop closed bug in McpSessionManager ([4aa4751](https://github.com/google/adk-python/commit/4aa475145f196fb35fe97290dd9f928548bc737f))
* Preserve thought_signature in function call conversions for interactions API integration ([2010569](https://github.com/google/adk-python/commit/20105690100d9c2f69c061ac08be5e94c50dc39c))
* Propagate grounding and citation metadata in streaming responses ([e6da417](https://github.com/google/adk-python/commit/e6da4172924ecc36ffc2535199c450a2a51c7bcc))
* Add endpoints to get/list artifact version metadata ([e0b9712](https://github.com/google/adk-python/commit/e0b9712a492bf84ac17679095b333642a79b8ee6))
* Support escaped curly braces in instruction templates ([7c7d25a](https://github.com/google/adk-python/commit/7c7d25a4a6e4389e23037e70b8efdcd5341f44ea))
* Strip timezone for PostgreSQL timestamps in DatabaseSessionService ([19b6076](https://github.com/google/adk-python/commit/19b607684f15ce2b6ffd60382211ba5600705743))
* Prompt token may be None in streaming mode ([32ee07d](https://github.com/google/adk-python/commit/32ee07df01f10dbee0e98ca9d412440a7fe9163d))
* Pass invocation_id from `/run` endpoint to `Runner.run_async` ([d2dba27](https://github.com/google/adk-python/commit/d2dba27134f833e5d929fdf363ada9364cc852f9))
* Conditionally preserve function call IDs in LLM requests ([663cb75](https://github.com/google/adk-python/commit/663cb75b3288d8d0649412e1009329502b21cbbc))
* Migrate VertexAiMemoryBankService to use the async Vertex AI client ([64a44c2](https://github.com/google/adk-python/commit/64a44c28974de77cf8934f9c3d1bc03691b90e7b))
* Handle list values in Gemini schema sanitization ([fd8a9e3](https://github.com/google/adk-python/commit/fd8a9e3962cca4f422beb7316cbe732edf726d51))
* Used logger to log instead of print in MCP ([6bc70a6](https://github.com/google/adk-python/commit/6bc70a6bab79b679a4b18ad146b3450fb9014475))

### Improvements

* Replace check of instance for LlmAgent with hasAttribute check ([7110336](https://github.com/google/adk-python/commit/7110336788662abb8c9bbbb0a53a50cc09130d5e))
* Log exception details before re-raising in MCP session execution ([de79bf1](https://github.com/google/adk-python/commit/de79bf12b564a4eefc7e6a2568dbe0f08bb6efeb))

## [1.24.1](https://github.com/google/adk-python/compare/v1.24.0...v1.24.1) (2026-02-06)

### Bug Fixes

* Add back deprecated eval endpoint for web until we migrate([ae993e8](https://github.com/google/adk-python/commit/ae993e884f44db276a4116ebb7a11a2fb586dbfe))
* Update eval dialog colors, and fix a2ui component types ([3686a3a](https://github.com/google/adk-python/commit/3686a3a98f46738549cd7a999f3773b7a6fd1182))

## [1.24.0](https://github.com/google/adk-python/compare/v1.23.0...v1.24.0) (2026-02-04)

### ⚠ BREAKING CHANGES

* Breaking: Make credential manager accept `tool_context` instead of `callback_context` ([fe82f3c](https://github.com/google/adk-python/commit/fe82f3cde854e49be13d90b4c02d786d82f8a202))

### Highlights

* **[Web]**
  * **Consolidated Event View**: Replaced the Event tab with a more intuitive "click-to-expand" interaction on message rows, enabling faster debugging within the chat context
  * **Enhanced Accessibility**: Added full support for arrow-key navigation for a more seamless, keyboard-centric experience
  * **Rich Developer Tooling**: Introduced detailed tooltips for function calls, providing instant visibility into arguments, responses, and state changes
  * **A2UI Integration**: Integrated the **A2UI v0.8** standard catalog to automatically render spec-compliant ADK parts as native UI components directly in the chat

### Features

* **[Core]**
  * Allow passthrough of `GOOGLE_CLOUD_LOCATION` for Agent Engine deployments ([004e15c](https://github.com/google/adk-python/commit/004e15ccb7c7f683623f8e7d2e77a9d12558c545))
  * Add interface for agent optimizers ([4ee125a](https://github.com/google/adk-python/commit/4ee125a03856fdb9ed28245bf7f5917c2d9038db))
  * Pass event ID as metadata when converted into a message ([85434e2](https://github.com/google/adk-python/commit/85434e293f7bd1e3711f190f84d5a36804e4462b))
  * Restructure the bug report template as per the intake process ([324796b](https://github.com/google/adk-python/commit/324796b4fe05bec3379bfef67071a29552ef355a))

* **[Models]**
  * Mark Vertex calls made from non-Gemini models ([7d58e0d](https://github.com/google/adk-python/commit/7d58e0d2f375bc80bdfac9cffea2926fd2344b8a))

* **[Evals]**
  * Allow Vertex AI Client initialization with API Key ([43d6075](https://github.com/google/adk-python/commit/43d6075ea7aa49ddb358732f2219ca9598dd286f))
  * Remove overall evaluation status calculation from `_CustomMetricEvaluator` and add threshold to custom metric function expected signature ([553e376](https://github.com/google/adk-python/commit/553e376718ceb3d7fb1403231bb720836d71f42c))

* **[Tools]**
  * Make OpenAPI tool asynchronous ([9290b96](https://github.com/google/adk-python/commit/9290b966267dc02569786f95aab2a3cb78c7004f))
  * Implement toolset authentication for `McpToolset`, `OpenAPIToolset`, and other toolsets ([798f65d](https://github.com/google/adk-python/commit/798f65df86b1bbe33d864e30c5b1f9e155e89810))
  * Add framework support for toolset authentication before `get_tools` calls ([ee873ca](https://github.com/google/adk-python/commit/ee873cae2e2df960910d264a4340ce6c0489eb7a))
  * Support dynamic configuration for `VertexAiSearchTool` ([585ebfd](https://github.com/google/adk-python/commit/585ebfdac7f1b8007b4e4a7e4258ec5de72c78b1))
  * Add `get_auth_config` method to toolset to expose authentication requirements ([381d44c](https://github.com/google/adk-python/commit/381d44cab437cac027af181ae627e7b260b7561e))
  * Add methods in `McpToolset` for users to access MCP resources ([8f7d965](https://github.com/google/adk-python/commit/8f7d9659cfc19034af29952fbca765d012169b38))
  * Improve error message when failing to get tools from MCP ([3480b3b](https://github.com/google/adk-python/commit/3480b3b82d89de69f77637d7ad034827434df45a))

* **[Services]**
  * Improve `asyncio` loop handling and test cleanup ([00aba2d](https://github.com/google/adk-python/commit/00aba2d884d24fb5244d1de84f8dba9cbc3c07e8))

* **[Live]**
  * Support running tools in separate threads for live mode ([714c3ad](https://github.com/google/adk-python/commit/714c3ad0477e775fba6696a919a366a293197268))

* **[Observability]**
  * Add extra attributes to spans generated with `opentelemetry-instrumentation-google-genai` ([e87a843](https://github.com/google/adk-python/commit/e87a8437fb430e0d4c42c73948e3ba1872040a15))

### Bug Fixes

* Ignore `session_db_kwargs` for SQLite session services ([ce07cd8](https://github.com/google/adk-python/commit/ce07cd8144c8498434f68e61ebeb519bf329f778))
* Resolve `MutualTLSChannelError` by adding `pyopenssl` dependency ([125bc85](https://github.com/google/adk-python/commit/125bc85ac5e1400bc38f7c681f76fa82626c9911))
* Add `update_timestamp_tz` property to `StorageSession` ([666cebe](https://github.com/google/adk-python/commit/666cebe3693d2981fd5fea6e9e4c65e56dcd3f2b))
* Do not treat Function Calls and Function Responses as invisible when marked as thoughts ([853a3b0](https://github.com/google/adk-python/commit/853a3b0e143ce27516f0de51e0e0df2af6ecf465))
* Add pre-deployment validation for agent module imports (credit to @ppgranger, [2ac468e](https://github.com/google/adk-python/commit/2ac468ea7e30ef30c1324ffc86f67dbf32ab7ede))
* Fix cases where `execution_result_delimiters` have `None` type element ([a16e3cc](https://github.com/google/adk-python/commit/a16e3cc67e1cb391228ba78662547672404ae550))
* Disable `save_input_blobs_as_artifacts` deprecation warning message for users not setting it ([c34615e](https://github.com/google/adk-python/commit/c34615ecf3c7bbe0f4275f72543774f258c565b4))
* Fix agent config path handling in generated deployment script ([8012339](https://github.com/google/adk-python/commit/801233902bbd6c0cca63b6fc8c1b0b2531f3f11e))
* Add `pypika>=0.50.0` to `project.toml` to support `crewai` on Python 3.12+ ([e8f7aa3](https://github.com/google/adk-python/commit/e8f7aa3140d2585ac38ebfe31c5b650383499a20))
* Update OpenTelemetry dependency versions to relax version constraints for `opentelemetry-api` and `opentelemetry-sdk` ([706a6dd](https://github.com/google/adk-python/commit/706a6dda8144da147bd9fa42ef85bbfa58fec5d3))
* Enable `pool_pre_ping` by default for non-SQLite database engines ([da73e71](https://github.com/google/adk-python/commit/da73e718efa9557ed33e2fb579de68fcbcf4c7f0))
* Ensure database sessions are always rolled back on errors ([63a8eba](https://github.com/google/adk-python/commit/63a8eba53f2cb07625eb7cd111ff767e8e0030fa))
* Reload stale session in `DatabaseSessionService` when storage update time is later than the in-memory session object ([1063fa5](https://github.com/google/adk-python/commit/1063fa532cad59d8e9f7421ce2f523724d49d541))
* Make credential key generation stable and prevent cross-user credential leaks ([33012e6](https://github.com/google/adk-python/commit/33012e6dda9ef20c7a1dae66a84717de5d782097))
* Change MCP `read_resource` to return original contents ([ecce7e5](https://github.com/google/adk-python/commit/ecce7e54a688a915a1b9d742c39e4684186729be))
* Recognize function responses as non-empty parts in LiteLLM ([d0102ec](https://github.com/google/adk-python/commit/d0102ecea331e062190dbb7578a4ef7f4044306e))
* Handle HTTP/HTTPS URLs for media files in LiteLLM content conversion ([47221cd](https://github.com/google/adk-python/commit/47221cd5c1e778cd4b92ed8d382c639435f5728c))
* Fix Pydantic schema generation error for `ClientSession` ([131fbd3](https://github.com/google/adk-python/commit/131fbd39482980572487a30fea13236d2badd543))
* Fix Click’s Wrapping in `adk eval` help message ([3bcd8f7](https://github.com/google/adk-python/commit/3bcd8f7f7a0683f838005bc209f7d39dc93f850b))
* Stream errors as simple JSON objects in ADK web server SSE endpoint ([798d005](https://github.com/google/adk-python/commit/798d0053c832e7ed52e2e104f8a14f789ba8b17f))
* Remove print debugging artifact ([0d38a36](https://github.com/google/adk-python/commit/0d38a3683f13bc12dc5d181164b6cd5d72fc260c))

### Improvements

* Check `will_continue` for streaming function calls ([2220d88](https://github.com/google/adk-python/commit/2220d885cda875144b52338b5becf6e5546f3f51))
* Update ADK web, rework events, and add A2UI capabilities ([37e6507](https://github.com/google/adk-python/commit/37e6507ce4d8750100d914eb1a62014350ef1795))
* Improve error handling for LiteLLM import in `gemma_llm.py` ([574ec43](https://github.com/google/adk-python/commit/574ec43a175e3bf3a05e73114e8db7196fae7040))
* Replace proxy methods with utils implementation ([6ff10b2](https://github.com/google/adk-python/commit/6ff10b23be01c1f7dd79d13ac8c679c079140f76), [f82ceb0](https://github.com/google/adk-python/commit/f82ceb0ce75d3efed7c046835ddac76c28210013))
* Replace print statements with logging in ADK evaluation components ([dd8cd27](https://github.com/google/adk-python/commit/dd8cd27b2ce505ecca50cdfbb1469db01c82b0af))
* Add sample agent that requires OAuth flow during MCP tool listing, and convert `MCPToolset` to `McpToolset` in unit tests ([2770012](https://github.com/google/adk-python/commit/2770012cecdfc71628a818a75b21faabe828b4e5), [4341839](https://github.com/google/adk-python/commit/43418394202c2d01b0d37f6424bd601148077e27))
* Ensure `BigQueryAgentAnalyticsPlugin` is shut down after each test ([c0c98d9](https://github.com/google/adk-python/commit/c0c98d94b3161d6bf9fff731e0abfc985b53e653))
* Add ADK logger in `RestApiTool` ([288c2c4](https://github.com/google/adk-python/commit/288c2c448d77c574dafadf7851a49e6ff59fa7f4))
* Add GitHub Action check to run `mypy` ([32f9f92](https://github.com/google/adk-python/commit/32f9f92042ab530220ac9d159045c91d311affa7))
* Add `unittests.sh` script and update `CONTRIBUTING.md` ([025b42c](https://github.com/google/adk-python/commit/025b42c8361ad2078593e3e7fc5301df88a532c7))
* Extract helper function for LLM request building and response processing ([753084f](https://github.com/google/adk-python/commit/753084fd46c9637488f33b0a05b4d270f6e03a39))

## [1.23.0](https://github.com/google/adk-python/compare/v1.22.1...v1.23.0) (2026-01-22)

### ⚠ BREAKING CHANGES

* Breaking: Use OpenTelemetry for BigQuery plugin tracing, replacing custom `ContextVar` implementation ([ab89d12](https://github.com/google/adk-python/commit/ab89d1283430041afb303834749869e9ee331721))

### Features

* **[Core]**
  * Add support to automatically create a session if one does not exist ([8e69a58](https://github.com/google/adk-python/commit/8e69a58df4eadeccbb100b7264bb518a46b61fd7))
  * Remove `@experimental` decorator from `AgentEngineSandboxCodeExecutor` ([135f763](https://github.com/google/adk-python/commit/135f7633253f6a415302142abc3579b664601d5b))
  * Add `--disable_features` CLI option to override default feature enable state ([53b67ce](https://github.com/google/adk-python/commit/53b67ce6340f3f3f8c3d732f9f7811e445c76359))
  * Add `otel_to_cloud` flag to `adk deploy agent_engine` command ([21f63f6](https://github.com/google/adk-python/commit/21f63f66ee424501d9a70806277463ef718ae843))
  * Add `is_computer_use` field to agent information in `adk-web` server ([5923da7](https://github.com/google/adk-python/commit/5923da786eb1aaef6f0bcbc6adc906cbc8bf9b36))
  * Allow `thinking_config` in `generate_content_config` ([e162bb8](https://github.com/google/adk-python/commit/e162bb8832a806e2380048e39165bf837455f88c))
  * Convert A2UI messages between A2A `DataPart` metadata and ADK events ([1133ce2](https://github.com/google/adk-python/commit/1133ce219c5a7a9a85222b03e348ba6b13830c8f))
  * Add `--enable_features` CLI option to override default feature enable state ([79fcddb](https://github.com/google/adk-python/commit/79fcddb39f71a4c1342e63b4d67832b3eccb2652))

* **[Tools]**
  * Add flush mechanism to `BigQueryAgentAnalyticsPlugin` to ensure pending log events are written to BigQuery ([9579bea](https://github.com/google/adk-python/commit/9579bea05d946b3d8b4bfec35e510725dd371224))
  * Allow Google Search tool to set a different model ([b57a3d4](https://github.com/google/adk-python/commit/b57a3d43e4656f5a3c5db53addff02b67d1fde26))
  * Support authentication for MCP tool listing ([e3d542a](https://github.com/google/adk-python/commit/e3d542a5ba3d357407f8cd29cfdd722f583c8564) [19315fe](https://github.com/google/adk-python/commit/19315fe557039fa8bf446525a4830b1c9f40cba9))
  * Use JSON schema for `base_retrieval_tool`, `load_artifacts_tool`, and `load_memory_tool` declarations when the feature is enabled ([69ad605](https://github.com/google/adk-python/commit/69ad605bc4bbe9a4f018127fd3625169ee70488e))
  * Use JSON schema for `IntegrationConnectorTool` declaration when the feature is enabled ([2ed6865](https://github.com/google/adk-python/commit/2ed686527ac75ff64128ce7d9b1a3befc2b37c64))
  * Start and close `ClientSession` in a single task in `McpSessionManager` ([cce430d](https://github.com/google/adk-python/commit/cce430da799766686e65f6cae02ba64e916d5c8a))
  * Use JSON schema for `RestApiTool` declaration when the feature is enabled ([a5f0d33](https://github.com/google/adk-python/commit/a5f0d333d7f26f2966ed511d5d9def7a1933f0c2))

* **[Evals]**
  * Update `adk eval` CLI to consume custom metrics by adding `CustomMetricEvaluator` ([ea0934b](https://github.com/google/adk-python/commit/ea0934b9934c1fefd129a1026d6af369f126870e))
  * Update `EvalConfig` and `EvalMetric` data models to support custom metrics ([6d2f33a](https://github.com/google/adk-python/commit/6d2f33a59cfba358dd758378290125fc2701c411))

* **[Observability]**
  * Add minimal `generate_content {model.name}` spans and logs for non-Gemini inference and when `opentelemetry-inference-google-genai` dependency is missing ([935c279](https://github.com/google/adk-python/commit/935c279f8281bde99224f03d936b8abe51cbabfc))

* **[Integrations]**
  * Enhance `TraceManager` asynchronous safety, enrich BigQuery plugin logging, and fix serialization ([a4116a6](https://github.com/google/adk-python/commit/a4116a6cbfadc161982af5dabd55a711d79348b7))

* **[Live]**
  * Persist user input content to session in live mode ([a04828d](https://github.com/google/adk-python/commit/a04828dd8a848482acbd48acc7da432d0d2cb0aa))

### Bug Fixes

* Recursively extract input/output schema for AgentTool ([bf2b56d](https://github.com/google/adk-python/commit/bf2b56de6d0052e40b6d871b2d22c56e9225e145))
* Yield buffered `function_call` and `function_response` events during live streaming ([7b25b8f](https://github.com/google/adk-python/commit/7b25b8fb1daf54d7694bf405d545d46d2c012d2b))
* Update `authlib` and `mcp` dependency versions ([7955177](https://github.com/google/adk-python/commit/7955177fb28b8e5dc19aae8be94015a7b5d9882a))
* Set `LITELLM_MODE` to `PRODUCTION` before importing LiteLLM to prevent implicit `.env` file loading ([215c2f5](https://github.com/google/adk-python/commit/215c2f506e21a3d8c39551b80f6356943ecae320))
* Redact sensitive information from URIs in logs ([5257869](https://github.com/google/adk-python/commit/5257869d91a77ebd1381538a85e7fdc3a600da90))
* Handle asynchronous driver URLs in the migration tool ([4b29d15](https://github.com/google/adk-python/commit/4b29d15b3e5df65f3503daffa6bc7af85159507b))
* Remove custom metadata from A2A response events ([81eaeb5](https://github.com/google/adk-python/commit/81eaeb5eba6d40cde0cf6147d96921ed1bf7bb31))
* Handle `None` inferences in eval results ([7d4326c](https://github.com/google/adk-python/commit/7d4326c3606a7ff2ba3c0fdef08d4f6af52ee71e))
* Mark all parts of a thought event as thought ([f92d4e3](https://github.com/google/adk-python/commit/f92d4e397f37445fe9032a95ce26646a3a69300b))
* Use `json.dumps` for error messages in SSE events ([6ad18cc](https://github.com/google/adk-python/commit/6ad18cc2fc3a3315a0fc240cb51b3283b53116b4))
* Use the correct path for config-based agents when deploying to AgentEngine ([83d7bb6](https://github.com/google/adk-python/commit/83d7bb6ef0d952ad04c5d9a61aaf202672c7e17d))
* Support Generator and Async Generator tool declarations in JSON schema ([19555e7](https://github.com/google/adk-python/commit/19555e7dce6d60c3b960ca0bc2f928c138ac3cc0) [7c28297](https://github.com/google/adk-python/commit/7c282973ea193841fee79f90b8a91c5e02627ccc))
* Prevent stopping event processing on events with `None` content ([ed2c3eb](https://github.com/google/adk-python/commit/ed2c3ebde9cafbb5e2bf375f44db1e77cee9fb24))
* Fix `'NoneType'` object is not iterable error ([7db3ce9](https://github.com/google/adk-python/commit/7db3ce9613b1c2c97e6ca3cd8115736516dc1556))
* Use canonical tools to find streaming tools and register them by `tool.name` ([ec6abf4](https://github.com/google/adk-python/commit/ec6abf401019c39e8e1a8d1b2c7d5cf5e8c7ac56))
* Initialize `self._auth_config` inside `BaseAuthenticatedTool` to access authentication headers in `McpTool` ([d4da1bb](https://github.com/google/adk-python/commit/d4da1bb7330cdb87c1dcbe0b9023148357a6bd07))
* Only filter out audio content when sending history ([712b5a3](https://github.com/google/adk-python/commit/712b5a393d44e7b5ce35fc459da98361bae4bb16))
* Add finish reason mapping and remove custom file URI handling in LiteLLM ([89bed43](https://github.com/google/adk-python/commit/89bed43f5e0c5ad12dd31c716d372145b7e33e78))
* Convert unsupported inline artifact MIME types to text in `LoadArtifactsTool` ([fdc98d5](https://github.com/google/adk-python/commit/fdc98d5c927bfef021e87cf72103892e4c2ac12a))
* Pass `log_level` to `uvicorn` in `web` and `api_server` commands ([38d52b2](https://github.com/google/adk-python/commit/38d52b247600fb45a2beeb041c4698e90c00d705))
* Use the agent name as the author of the audio event ([ab62b1b](https://github.com/google/adk-python/commit/ab62b1bffd7ad2df5809d430ad1823872b8bd67a))
* Handle `NOT_FOUND` error when fetching Vertex AI sessions ([75231a3](https://github.com/google/adk-python/commit/75231a30f1857d930804769caf88bcc20839dd08))
* Fix `httpx` client closure during event pagination ([b725045](https://github.com/google/adk-python/commit/b725045e5a1192bc9fd5190cbd2758ab6ff02590))

### Improvements

* Add new conversational analytics API toolset ([82fa10b](https://github.com/google/adk-python/commit/82fa10b71e037b565cb407c82e9e908432dab0ff))
* Filter out `adk_request_input` event from content list ([295b345](https://github.com/google/adk-python/commit/295b34558774d1f64022009980e3edd8eb79527b))
* Always skip executing partial function calls ([d62f9c8](https://github.com/google/adk-python/commit/d62f9c896c301aba3a781e868735e16f946a8862))
* Update comments of request confirmation preprocessor ([1699b09](https://github.com/google/adk-python/commit/1699b090edc9e5b13c34f461c8e664187157c5c0))
* Fix various typos ([a8f2ddd](https://github.com/google/adk-python/commit/a8f2ddd943301bbf53f49b3a23300ece45803cc0))
* Update sample live streaming tools agent to use latest live models ([3dd7e3f](https://github.com/google/adk-python/commit/3dd7e3f1b9be05c28adb061864d84c4202a2d922))
* Make the regex to catch CLI reference strict by adding word boundary anchor ([c222a45](https://github.com/google/adk-python/commit/c222a45ef74f7b55c48dc151ba98cd8c30a15c57))
* Migrate `ToolboxToolset` to use `toolbox-adk` and align validation ([7dc6adf](https://github.com/google/adk-python/commit/7dc6adf4e563330a09e4cf28d2b1994c24b007d1) [277084e](https://github.com/google/adk-python/commit/277084e31368302e6338b69d456affd35d5fedfe))
* Always log API backend when connecting to live model ([7b035aa](https://github.com/google/adk-python/commit/7b035aa9fc43a43489aeffea8f877cd7eaa09f35))
* Add a sample BigQuery agent using BigQuery MCP tools ([672b57f](https://github.com/google/adk-python/commit/672b57f1b76580023d1f348de76227291a9c1012))
* Add a `DebugLoggingPlugin` to record human-readable debugging logs ([8973618](https://github.com/google/adk-python/commit/8973618b0b0e90c513873e22af272c147efb4904))
* Upgrade the sample BigQuery agent model version to `gemini-2.5-flash` ([fd2c0f5](https://github.com/google/adk-python/commit/fd2c0f556b786417a9f6add744827b07e7a06b7d))
* Import `migration_runner` lazily within the migrate command ([905604f](https://github.com/google/adk-python/commit/905604faac82aca8ae0935eebea288f82985e9c5))



## [1.22.1](https://github.com/google/adk-python/compare/v1.22.0...v1.22.1) (2026-01-09)

### Bug Fixes
* Add back `adk migrate session` CLI ([8fb2be2](https://github.com/google/adk-python/commit/8fb2be216f11dabe7fa361a0402e5e6316878ad8)).
* Escape database reserved keyword ([94d48fc](https://github.com/google/adk-python/commit/94d48fce32a1f07cef967d50e82f2b1975b4abd9)).


## [1.22.0](https://github.com/google/adk-python/compare/v1.21.0...v1.22.0) (2026-01-08)

### Features

* **[Core]**
  * Make `LlmAgent.model` optional with a default fallback ([b287215](https://github.com/google/adk-python/commit/b28721508a41bf6bcfef52bbc042fb6193a32dfa)).
  * Support regex for allowed origins ([2ea6e51](https://github.com/google/adk-python/commit/2ea6e513cff61d3f330274725c66f82fce4ba259)).
  * Enable PROGRESSIVE_SSE_STREAMING feature by default ([0b1cff2](https://github.com/google/adk-python/commit/0b1cff2976d1c04acf3863f76107b05d1cec448f)).

* **[Evals]**
  * Add custom instructions support to LlmBackedUserSimulator ([a364388](https://github.com/google/adk-python/commit/a364388d9744969760fd87ed24d60793146c162a)).
  * Introduce a post-hoc, per-turn evaluator for user simulations ([e515e0f](https://github.com/google/adk-python/commit/e515e0f321a259016c5e5f6b388ecf02ae343ba7)).

* **[Tools]**
  * Expose mcps streamable http custom httpx factory parameter ([bfed19c](https://github.com/google/adk-python/commit/bfed19cd78298fc9f896da8ed82a756004e92094)).
  * Add a handwritten tool for Cloud Pub/Sub ([b6f6dcb](https://github.com/google/adk-python/commit/b6f6dcbeb465a775b9c38ace7a324ee2155d366f)).
  * Add `token_endpoint_auth_method` support to OAuth2 credentials ([8782a69](https://github.com/google/adk-python/commit/8782a695036aa0c1528027673868159143f925f0)).

* **[Services]**
  * Introduce new JSON-based database schema for DatabaseSessionService, which will be used for newly-created databases. A migration command and script are provided.([7e6ef71](https://github.com/google/adk-python/commit/7e6ef71eec8be2e804286cc4140d0cbdf84f1206) [ba91fea](https://github.com/google/adk-python/commit/ba91fea54136ab60f37c10b899c3648d0b0fa721) [ce64787](https://github.com/google/adk-python/commit/ce64787c3e1130d1678e408aa31011fc88590e15)).
  * Set log level when deploying to Agent Engine ([1f546df](https://github.com/google/adk-python/commit/1f546df35a1c18aeb3d2fc7a2ac66edf386027c5)).

* **[A2A]**
  * Update event_converter used in A2ARemote agent to use a2a_task.status.message only if parts are non-empty ([e4ee9d7](https://github.com/google/adk-python/commit/e4ee9d7c46b57eed8493539d8f539c042bdfae60)).

### Bug Fixes

* Add checks for event content and parts before accessing ([5912835](https://github.com/google/adk-python/commit/5912835c975673c8fc2fb315150f5ec29d685eac)).
* Validate app name in `adk create` command ([742c926](https://github.com/google/adk-python/commit/742c9265a260a9c598a1f65e0996d926b4b9c022)).
* Prevent .env files from overriding existing environment variables ([0827d12](https://github.com/google/adk-python/commit/0827d12ccd74feb24758f64f2884c9493001b4ca)).
* Prevent ContextFilterPlugin from creating orphaned function responses ([e32f017](https://github.com/google/adk-python/commit/e32f017979e26a94b998311cafcde753fd29e44e)).
* Update empty event check to include executable code and execution results ([688f48f](https://github.com/google/adk-python/commit/688f48fffb9df6ef18a692cd2ccaa7628f4c82a7)).
* Make the BigQuery analytics plugin work with agents that don't have instructions such as the LoopAgent ([8bed01c](https://github.com/google/adk-python/commit/8bed01cbdc5961c0d219fd6389f492f1a4235de5)).
* Label response as thought if task is immediately returned as working ([4f3b733](https://github.com/google/adk-python/commit/4f3b733074c867e68ca5d38720ccb1f3e0b0d960)).
* Move and enhance the deprecation warning for the plugins argument in "_validate_runner_params" to the beginning of the function ([43270bc](https://github.com/google/adk-python/commit/43270bcb6197526ba5765f83d7e4fb88f213b8d3)).
* Oauth refresh not triggered on token expiry ([69997cd](https://github.com/google/adk-python/commit/69997cd5ef44ee881a974bb36dc100e17ed6de2e)).
* Fix double JSON encoding when saving eval set results ([fc4e3d6](https://github.com/google/adk-python/commit/fc4e3d6f607032259e68e91bcb1ad0815a03164e)).
* Allow string values for ToolTrajectoryCriterion.match_type ([93d6e4c](https://github.com/google/adk-python/commit/93d6e4c888d5a2181e3c22da049d8be0d6ead70c)).
* Fix inconsistent method signatures for evaluate_invocations ([0918b64](https://github.com/google/adk-python/commit/0918b647df6f88b95974d486a3161121a6514901)).
* Honor the modalities parameter in adk api server for live API ([19de45b](https://github.com/google/adk-python/commit/19de45b3250d09b9ec16c45788e7d472b3e588c2)).
* Filter out thought parts in lite_llm._get_content ([1ace8fc](https://github.com/google/adk-python/commit/1ace8fc6780bc25e2ef4222c73bc2558082b0a00)).
* Rehydration of EventActions in StorageEvent.to_event ([838530e](https://github.com/google/adk-python/commit/838530ebe053e5193d4329c5a203ca3d096ff7be)).
* Heal missing tool results before LiteLLM requests ([6b7386b](https://github.com/google/adk-python/commit/6b7386b7620bbc51cda8c1c6d9914549536640e6)).
* Refine Ollama content flattening and provider checks ([c6f389d](https://github.com/google/adk-python/commit/c6f389d4bc4d2b91795003a3bd87ed1f1b854493)).
* Add MIME type inference and default for file URIs in LiteLLM ([5c4bae7](https://github.com/google/adk-python/commit/5c4bae7ff2085c05b7f002f5fa368e9b48a752b1)).
* Use mode='json' in model_dump to serialize bytes correctly when using telemetry ([96c5db5](https://github.com/google/adk-python/commit/96c5db5a07f7f851751ccd68f176dad1634885cb)).
* Avoid local .adk storage in Cloud Run/GKE ([b30c2f4](https://github.com/google/adk-python/commit/b30c2f4e139e0d4410c5f8dd61acee2056ad06ea)).
* Remove fallback to cached exchanged credential in _load_existing_credential ([1ae0e16](https://github.com/google/adk-python/commit/1ae0e16b2c1a3139b9c2b1c4a3e725833a6240be)).
* Handle overriding of requirements when deploying to agent engine ([38a30a4](https://github.com/google/adk-python/commit/38a30a44d222fade8616f9d63410b1c2b6f84e1b)).
* Built-in agents (names starting with "__") now use in-memory session storage instead of creating .adk folders in the agents directory ([e3bac1a](https://github.com/google/adk-python/commit/e3bac1ab8c724454fb433cc7e78416b61efe33ee)).
* Change error_message column type to TEXT in DatabaseSessionService ([8335f35](https://github.com/google/adk-python/commit/8335f35015c7d4349bc4ac47dedbe99663b78e62)).
* Add schema type sanitization to OpenAPI spec parser ([6dce7f8](https://github.com/google/adk-python/commit/6dce7f8a8f28de275b1119fc03219f1468bb883b)).
* Prevent retry_on_errors from retrying asyncio.CancelledError ([30d3411](https://github.com/google/adk-python/commit/30d3411d603f12ca5bcdd2d71773d087f3191dba)).
* Include back-ticks around the BQ asset names in the tools examples ([8789ad8](https://github.com/google/adk-python/commit/8789ad8f16dfa250fab607946250a2857a25d5ef)).
* Fix issue with MCP tools throwing an error ([26e77e1](https://github.com/google/adk-python/commit/26e77e16947aed1abcfdd7f526532a708f1f073b)).
* Exclude thought parts when merging agent output ([07bb164](https://github.com/google/adk-python/commit/07bb1647588a781e701257c4c379736537029ea0)).
* Prepend "https://" to the MCP server url only if it doesn't already have a scheme ([71b3289](https://github.com/google/adk-python/commit/71b32890f5ab279e2bed1fd28c0f4693cba3f45e)).
* Split SSE events with both content and artifactDelta in ADK Web Server ([084fcfa](https://github.com/google/adk-python/commit/084fcfaba52c4a6075397221dbe7aba2f2acd2d7)).
* Propagate RunConfig custom metadata to all events ([e3db2d0](https://github.com/google/adk-python/commit/e3db2d0d8301748c63bad826f24692448dbd1c2c)).
* Harden YAML builder tmp save/cleanup([6f259f0](https://github.com/google/adk-python/commit/6f259f08b3c45ad6050b8a93c9bd85913451ece6)).
* Ignore adk-bot administrative actions in stale agent ([3ec7ae3](https://github.com/google/adk-python/commit/3ec7ae3b8d532ed4b60786201a78e980dfc56cf3)).
* Only prepend "https://" to the MCP server url if it doesn't already have a scheme ([71b3289](https://github.com/google/adk-python/commit/71b32890f5ab279e2bed1fd28c0f4693cba3f45e)).
* Check all content parts for emptiness in _contains_empty_content ([f35d129](https://github.com/google/adk-python/commit/f35d129b4c59d381e95418725d6eaa072ca7720a)).

### Improvements

* Remove unnecessary event loop creation in LiveRequstQueue constructor ([ecc9f18](https://github.com/google/adk-python/commit/ecc9f182e3bd25ee8eda8920d665e967517ca59a)).
* Close database engines to avoid aiosqlite pytest hangs ([4ddb2cb](https://github.com/google/adk-python/commit/4ddb2cb2a8d1d026a43418b2dd698e6ea199594e)).
* Add `override_feature_enabled` to override the default feature enable states ([a088506](https://github.com/google/adk-python/commit/a0885064b0cbef3b25484025da0748dc64320d4a)).
* Move SQLite migration script to migration/ folder ([e8ab7da](https://github.com/google/adk-python/commit/e8ab7dafa96d5890a4fff919b9fa180993ef5830)).
* Update latest Live Model names for sample agent ([f1eb1c0](https://github.com/google/adk-python/commit/f1eb1c0254802ef3aa64c76512e3104376291ec0)).
* Update google-genai and google-cloud-aiplatform versions ([d58ea58](https://github.com/google/adk-python/commit/d58ea589ade822894f1482fd505a33d842755d9c)).
* Introduce MetricInfoProvider interface, and refactor metric evaluators to use this interface to provide MetricInfo ([5b7c8c0](https://github.com/google/adk-python/commit/5b7c8c04d6e4a688c76fa517922488e3d96353a3)).
* Update _flatten_ollama_content return type and add tests ([fcea86f](https://github.com/google/adk-python/commit/fcea86f58c95894bc9c1fb7ed12e36ddedaaa88a)).
* Add disambiguation message to enterprise_search_tool ([8329fec](https://github.com/google/adk-python/commit/8329fec0fc6b6130ffd1f53a8a2e2ccc6e8f43ed)).
* Add x-goog-user-project header to http calls in API Registry ([0088b0f](https://github.com/google/adk-python/commit/0088b0f3adb963dded692929c314d94709dcc211)).
* Set the default response modality to AUDIO only ([a4b914b](https://github.com/google/adk-python/commit/a4b914b09fbab76834050a8c8f0eb335b12cfc34)).


## [1.21.0](https://github.com/google/adk-python/compare/v1.20.0...v1.21.0) (2025-12-11)

### Features
* **[Interactions API Support]**
  * The newly released Gemini [Interactions API](https://ai.google.dev/gemini-api/docs/interactions) is supported in ADK now. To use it:
  ```Python
  Agent(
    model=Gemini(
        model="gemini-3-pro-preview",
        use_interactions_api=True,
    ),
    name="...",
    description="...",
    instruction="...",
  )
  ```
  see [samples](https://github.com/google/adk-python/tree/main/contributing/samples/interactions_api) for details


* **[Services]**
  * Add `add_session_to_memory` to `CallbackContext` and `ToolContext` to explicitly save the current session to memory ([7b356dd](https://github.com/google/adk-python/commit/7b356ddc1b1694d2c8a9eee538f3a41cf5518e42))

* **[Plugins]**
  * Add location for table in agent events in plugin BigQueryAgentAnalytics ([507424a](https://github.com/google/adk-python/commit/507424acb9aabc697fc64ef2e9a57875f25f0a21))
  * Upgrade BigQueryAgentAnalyticsPlugin to v2.0 with improved performance, multimodal support, and reliability ([7b2fe14](https://github.com/google/adk-python/commit/7b2fe14dab96440ee25b66dae9e66eadba629a56))


* **[A2A]**
  * Adds ADK EventActions to A2A response ([32e87f6](https://github.com/google/adk-python/commit/32e87f6381ff8905a06a9a43a0207d758a74299d))

* **[Tools]**
  * Add `header_provider` to `OpenAPIToolset` and `RestApiTool` ([e1a7593](https://github.com/google/adk-python/commit/e1a7593ae8455d51cdde46f5165410217400d3c9))
  * Allow overriding connection template ([cde7f7c](https://github.com/google/adk-python/commit/cde7f7c243a7cdc8c7b886f68be55fd59b1f6d5a))
  * Add SSL certificate verification configuration to OpenAPI tools using the `verify` parameter ([9d2388a](https://github.com/google/adk-python/commit/9d2388a46f7a481ea1ec522f33641a06c64394ed))
  * Use json schema for function tool declaration when feature enabled ([cb3244b](https://github.com/google/adk-python/commit/cb3244bb58904ab508f77069b436f85b442d3299))

* **[Models]**
  * Add Gemma3Ollama model integration and a sample ([e9182e5](https://github.com/google/adk-python/commit/e9182e5eb4a37fb5219fc607cd8f06d7e6982e83))


### Bug Fixes

* Install dependencies for py 3.10 ([9cccab4](https://github.com/google/adk-python/commit/9cccab453706138826f313c47118812133e099c4))
* Refactor LiteLLM response schema formatting for different models ([894d8c6](https://github.com/google/adk-python/commit/894d8c6c2652492324c428e8dae68a8646b17485))
* Resolve project and credentials before creating Spanner client ([99f893a](https://github.com/google/adk-python/commit/99f893ae282a04c67cce5f80e87d3bfadd3943e6))
* Avoid false positive "App name mismatch" warnings in Runner ([6388ba3](https://github.com/google/adk-python/commit/6388ba3b2054e60d218eae6ec8abc621ed0a1139))
* Update the code to work with either 1 event or more than 1 events ([4f54660](https://github.com/google/adk-python/commit/4f54660d6de54ddde0fec6e09fdd68890ce657ca))
* OpenAPI schema generation by skipping JSON schema for judge_model_config ([56775af](https://github.com/google/adk-python/commit/56775afc48ee54e9cbea441a6e0fa6c8a12891b9))
* Add tool_name_prefix support to OpenAPIToolset ([82e6623](https://github.com/google/adk-python/commit/82e6623fa97fb9cbc6893b44e228f4da098498da))
* Pass context to client interceptors ([143ad44](https://github.com/google/adk-python/commit/143ad44f8c5d1c56fc92dd691589aaa0b788e485))
* Yield event with error code when agent run raised A2AClientHTTPError ([b7ce5e1](https://github.com/google/adk-python/commit/b7ce5e17b6653074c5b41d08b2027b5e9970a671))
* Handle string function responses in LiteLLM conversion ([2b64715](https://github.com/google/adk-python/commit/2b6471550591ee7fc5f70f79e66a6e4080df442b))
* ApigeeLLM support for Built-in tools like GoogleSearch, BuiltInCodeExecutor when calling Gemini models through Apigee ([a9b853f](https://github.com/google/adk-python/commit/a9b853fe364d08703b37914a89cf02293b5c553b))
* Extract and propagate task_id in RemoteA2aAgent ([82bd4f3](https://github.com/google/adk-python/commit/82bd4f380bd8b4822191ea16e6140fe2613023ad))
* Update FastAPI and Starlette to fix CVE-2025-62727 (ReDoS vulnerability) ([c557b0a](https://github.com/google/adk-python/commit/c557b0a1f2aac9f0ef7f1e0f65e3884007407e30))
* Add client id to token exchange ([f273517](https://github.com/google/adk-python/commit/f2735177f195b8d7745dba6360688ddfebfed31a))

### Improvements

* Normalize multipart content for LiteLLM's ollama_chat provider ([055dfc7](https://github.com/google/adk-python/commit/055dfc79747aa365db8441908d4994f795e94a68))
* Update adk web, fixes image not rendering, state not updating, update drop down box width and trace icons ([df86847](https://github.com/google/adk-python/commit/df8684734bbfd5a8afe3b4362574fe93dcb43048))
* Add sample agent for interaction api integration ([68d7048](https://github.com/google/adk-python/commit/68d70488b9340251a9d37e8ae3a9166870f26aa1))
* Update genAI SDK version ([f0bdcab](https://github.com/google/adk-python/commit/f0bdcaba449f21bd8c27cde7dbedc03bf5ec5349))
* Introduce `build_function_declaration_with_json_schema` to use pydantic to generate json schema for FunctionTool ([51a638b](https://github.com/google/adk-python/commit/51a638b6b85943d4aaec4ee37c95a55386ebac90))
* Update component definition for triaging agent ([ee743bd](https://github.com/google/adk-python/commit/ee743bd19a8134129111fc4769ec24e40a611982))
* Migrate Google tools to use the new feature decorator ([bab5729](https://github.com/google/adk-python/commit/bab57296d553cb211106ece9ee2c226c64a60c57))
* Migrate computer to use the new feature decorator ([1ae944b](https://github.com/google/adk-python/commit/1ae944b39d9cf263e15b36c76480975fe4291d22))
* Add Spanner execute sql query result mode using list of dictionaries ([f22bac0](https://github.com/google/adk-python/commit/f22bac0b202cd8f273bf2dee9fff57be1b40730d))
* Improve error message for missing `invocation_id` and `new_message` in `run_async` ([de841a4](https://github.com/google/adk-python/commit/de841a4a0982d98ade4478f10481c817a923faa2))

## [1.20.0](https://github.com/google/adk-python/compare/v1.19.0...v1.20.0) (2025-12-01)


### Features
* **[Core]**
  * Add enum constraint to `agent_name` for `transfer_to_agent` ([4a42d0d](https://github.com/google/adk-python/commit/4a42d0d9d81b7aab98371427f70a7707dbfb8bc4))
  * Add validation for unique sub-agent names ([#3557](https://github.com/google/adk-python/issues/3557)) ([2247a45](https://github.com/google/adk-python/commit/2247a45922afdf0a733239b619f45601d9b325ec))
  * Support streaming function call arguments in progressive SSE streaming feature ([786aaed](https://github.com/google/adk-python/commit/786aaed335e1ce64b7e92dff2f4af8316b2ef593))

* **[Models]**
  * Enable multi-provider support for Claude and LiteLLM ([d29261a](https://github.com/google/adk-python/commit/d29261a3dc9c5a603feef27ea657c4a03bb8a089))

* **[Tools]**
  * Create APIRegistryToolset to add tools from Cloud API registry to agent ([ec4ccd7](https://github.com/google/adk-python/commit/ec4ccd718feeadeb6b2b59fcc0e9ff29a4fd0bac))
  * Add an option to disallow propagating runner plugins to AgentTool runner ([777dba3](https://github.com/google/adk-python/commit/777dba3033a9a14667fb009ba017f648177be41d))

* **[Web]**
  * Added an endpoint to list apps with details ([b57fe5f](https://github.com/google/adk-python/commit/b57fe5f4598925ec7592917bb32c7f0d6eca287a))


### Bug Fixes

* Allow image parts in user messages for Anthropic Claude ([5453b5b](https://github.com/google/adk-python/commit/5453b5bfdedc91d9d668c9eac39e3bb009a7bbbf))
* Mark the Content as non-empty if its first part contains text or inline_data or file_data or func call/response ([631b583](https://github.com/google/adk-python/commit/631b58336d36bfd93e190582be34069613d38559))
* Fixes double response processing issue in `base_llm_flow.py` where, in Bidi-streaming (live) mode, the multi-agent structure causes duplicated responses after tool calling. ([cf21ca3](https://github.com/google/adk-python/commit/cf21ca358478919207049695ba6b31dc6e0b2673))
* Fix out of bounds error in _run_async_impl ([8fc6128](https://github.com/google/adk-python/commit/8fc6128b62ba576480d196d4a2597564fd0a7006))
* Fix paths for public docs ([cd54f48](https://github.com/google/adk-python/commit/cd54f48fed0c87b54fb19743c9c75e790c5d9135))
* Ensure request bodies without explicit names are named 'body' ([084c2de](https://github.com/google/adk-python/commit/084c2de0dac84697906e2b4beebf008bbd9ae8e1)), closes [#2213](https://github.com/google/adk-python/issues/2213)
* Optimize Stale Agent with GraphQL and Search API to resolve 429 Quota errors ([cb19d07](https://github.com/google/adk-python/commit/cb19d0714c90cd578551753680f39d8d6076c79b))
* Update AgentTool to use Agent's description when input_schema is provided in FunctionDeclaration ([52674e7](https://github.com/google/adk-python/commit/52674e7fac6b7689f0e3871d41c4523e13471a7e))
* Update LiteLLM system instruction role from "developer" to "system" ([2e1f730](https://github.com/google/adk-python/commit/2e1f730c3bc0eb454b76d7f36b7b9f1da7304cfe)), closes [#3657](https://github.com/google/adk-python/issues/3657)
* Update session last update time when appending events ([a3e4ad3](https://github.com/google/adk-python/commit/a3e4ad3cd130714affcaa880f696aeb498cd93af)), closes [#2721](https://github.com/google/adk-python/issues/2721)
* Update the retry_on_closed_resource decorator to retry on all errors ([a3aa077](https://github.com/google/adk-python/commit/a3aa07722a7de3e08807e86fd10f28938f0b267d))
* Windows Path Handling and Normalize Cross-Platform Path Resolution in AgentLoader ([a1c09b7](https://github.com/google/adk-python/commit/a1c09b724bb37513eaabaff9643eeaa68014f14d))


### Documentation

* Add Code Wiki badge to README ([caf23ac](https://github.com/google/adk-python/commit/caf23ac49fe08bc7f625c61eed4635c26852c3ba))


## [1.19.0](https://github.com/google/adk-python/compare/v1.18.0...v1.19.0) (2025-11-19)

### Features

* **[Core]**
  * Add `id` and `custom_metadata` fields to `MemoryEntry` ([4dd28a3](https://github.com/google/adk-python/commit/4dd28a3970d0f76c571caf80b3e1bea1b79e9dde))
  * Add progressive SSE streaming feature ([a5ac1d5](https://github.com/google/adk-python/commit/a5ac1d5e14f5ce7cd875d81a494a773710669dc1))
  * Add a2a_request_meta_provider to RemoteAgent init ([d12468e](https://github.com/google/adk-python/commit/d12468ee5a2b906b6699ccdb94c6a5a4c2822465))
  * Add feature decorator for the feature registry system ([871da73](https://github.com/google/adk-python/commit/871da731f1c09c6a62d51b137d9d2e7c9fb3897a))
  * Breaking: Raise minimum Python version to 3_10 ([8402832](https://github.com/google/adk-python/commit/840283228ee77fb3dbd737cfe7eb8736d9be5ec8))
  * Refactor and rename BigQuery agent analytics plugin ([6b14f88](https://github.com/google/adk-python/commit/6b14f887262722ccb85dcd6cef9c0e9b103cfa6e))
  * Pass custom_metadata through forwarding artifact service ([c642f13](https://github.com/google/adk-python/commit/c642f13f216fb64bc93ac46c1c57702c8a2add8c))
  * Update save_files_as_artifacts_plugin to never keep inline data ([857de04](https://github.com/google/adk-python/commit/857de04debdeba421075c2283c9bd8518d586624))

* **[Evals]**
  * Add support for InOrder and AnyOrder match in ToolTrajectoryAvgScore Metric ([e2d3b2d](https://github.com/google/adk-python/commit/e2d3b2d862f7fc93807d16089307d4df25367a24))

* **[Integrations]**
  * Enhance BQ Plugin Schema, Error Handling, and Logging ([5ac5129](https://github.com/google/adk-python/commit/5ac5129fb01913516d6f5348a825ca83d024d33a))
  * Schema Enhancements with Descriptions, Partitioning, and Truncation Indicator ([7c993b0](https://github.com/google/adk-python/commit/7c993b01d1b9d582b4e2348f73c0591d47bf2f3a))

* **[Services]**
  * Add file-backed artifact service ([99ca6aa](https://github.com/google/adk-python/commit/99ca6aa6e6b4027f37d091d9c93da6486def20d7))
  * Add service factory for configurable session and artifact backends ([a12ae81](https://github.com/google/adk-python/commit/a12ae812d367d2d00ab246f85a73ed679dd3828a))
  * Add SqliteSessionService and a migration script to migrate existing DB using DatabaseSessionService to SqliteSessionService ([e218254](https://github.com/google/adk-python/commit/e2182544952c0174d1a8307fbba319456dca748b))
  * Add transcription fields to session events ([3ad30a5](https://github.com/google/adk-python/commit/3ad30a58f95b8729f369d00db799546069d7b23a))
  * Full async implementation of DatabaseSessionService ([7495941](https://github.com/google/adk-python/commit/74959414d8ded733d584875a49fb4638a12d3ce5))

* **[Models]**
  * Add experimental feature to use `parameters_json_schema` and `response_json_schema` for McpTool ([1dd97f5](https://github.com/google/adk-python/commit/1dd97f5b45226c25e4c51455c78ebf3ff56ab46a))
  * Add support for parsing inline JSON tool calls in LiteLLM responses ([22eb7e5](https://github.com/google/adk-python/commit/22eb7e5b06c9e048da5bb34fe7ae9135d00acb4e))
  * Expose artifact URLs to the model when available ([e3caf79](https://github.com/google/adk-python/commit/e3caf791395ce3cc0b10410a852be6e7b0d8d3b1))

* **[Tools]**
  * Add BigQuery related label handling ([ffbab4c](https://github.com/google/adk-python/commit/ffbab4cf4ed6ceb313241c345751214d3c0e11ce))
  * Allow setting max_billed_bytes in BigQuery tools config ([ffbb0b3](https://github.com/google/adk-python/commit/ffbb0b37e128de50ebf57d76cba8b743a8b970d5))
  * Propagate `application_name` set for the BigQuery Tools as BigQuery job labels ([f13a11e](https://github.com/google/adk-python/commit/f13a11e1dc27c5aa46345154fbe0eecfe1690cbb))
  * Set per-tool user agent in BQ calls and tool label in BQ jobs ([c0be1df](https://github.com/google/adk-python/commit/c0be1df0521cfd4b84585f404d4385b80d08ba59))

* **[Observability]**
  * Migrate BigQuery logging to Storage Write API ([a2ce34a](https://github.com/google/adk-python/commit/a2ce34a0b9a8403f830ff637d0e2094e82dee8e7))

### Bug Fixes

* Add `jsonschema` dependency for Agent Builder config validation ([0fa7e46](https://github.com/google/adk-python/commit/0fa7e4619d589dc834f7508a18bc2a3b93ec7fd9))
* Add None check for `event` in `remote_a2a_agent.py` ([744f94f](https://github.com/google/adk-python/commit/744f94f0c8736087724205bbbad501640b365270))
* Add vertexai initialization for code being deployed to AgentEngine ([b8e4aed](https://github.com/google/adk-python/commit/b8e4aedfbf0eb55b34599ee24e163b41072a699c))
* Change LiteLLM content and tool parameter handling ([a19be12](https://github.com/google/adk-python/commit/a19be12c1f04bb62a8387da686499857c24b45c0))
* Change name for builder agent ([131d39c](https://github.com/google/adk-python/commit/131d39c3db1ae25e3911fa7f72afbe05e24a1c37))
* Ensure event compaction completes by awaiting task ([b5f5df9](https://github.com/google/adk-python/commit/b5f5df9fa8f616b855c186fcef45bade00653c77))
* Fix deploy to cloud run on Windows ([29fea7e](https://github.com/google/adk-python/commit/29fea7ec1fb27989f07c90494b2d6acbe76c03d8))
* Fix error handling when MCP server is unreachable ([ee8106b](https://github.com/google/adk-python/commit/ee8106be77f253e3687e72ae0e236687d254965c))
* Fix error when query job destination is None ([0ccc43c](https://github.com/google/adk-python/commit/0ccc43cf49dc0882dc896455d6603a602d8a28e7))
* Fix Improve logic for checking if a MCP session is disconnected ([a754c96](https://github.com/google/adk-python/commit/a754c96d3c4fd00f9c2cd924fc428b68cc5115fb))
* Fix McpToolset crashing with anyio.BrokenResourceError ([8e0648d](https://github.com/google/adk-python/commit/8e0648df23d0694afd3e245ec4a3c41aa935120a))
* Fix Safely handle `FunctionDeclaration` without a `required` attribute ([93aad61](https://github.com/google/adk-python/commit/93aad611983dc1daf415d3a73105db45bbdd1988))
* Fix status code in error message in RestApiTool ([9b75456](https://github.com/google/adk-python/commit/9b754564b3cc5a06ad0c6ae2cd2d83082f9f5943))
* Fix Use `async for` to loop through event iterator to get all events in vertex_ai_session_service ([9211f4c](https://github.com/google/adk-python/commit/9211f4ce8cc6d918df314d6a2ff13da2e0ef35fa))
* Fix: Fixes DeprecationWarning when using send method ([2882995](https://github.com/google/adk-python/commit/28829952890c39dbdb4463b2b67ff241d0e9ef6d))
* Improve logic for checking if a MCP session is disconnected ([a48a1a9](https://github.com/google/adk-python/commit/a48a1a9e889d4126e6f30b56c93718dfbacef624))
* Improve handling of partial and complete transcriptions in live calls ([1819ecb](https://github.com/google/adk-python/commit/1819ecb4b8c009d02581c2d060fae49cd7fdf653))
* Keep vertex session event after the session update time ([0ec0195](https://github.com/google/adk-python/commit/0ec01956e86df6ae8e6553c70e410f1f8238ba88))
* Let part converters also return multiple parts so they can support more usecases ([824ab07](https://github.com/google/adk-python/commit/824ab072124e037cc373c493f43de38f8b61b534))
* Load agent/app before creating session ([236f562](https://github.com/google/adk-python/commit/236f562cd275f84837be46f7dfb0065f85425169))
* Remove app name from FileArtifactService directory structure ([12db84f](https://github.com/google/adk-python/commit/12db84f5cd6d8b6e06142f6f6411f6b78ff3f177))
* Remove hardcoded `google-cloud-aiplatform` version in agent engine requirements ([e15e19d](https://github.com/google/adk-python/commit/e15e19da05ee1b763228467e83f6f73e0eced4b5))
* Stop updating write mode in the global settings during tool execution ([5adbf95](https://github.com/google/adk-python/commit/5adbf95a0ab0657dd7df5c4a6bac109d424d436e))
* Update description for `load_artifacts` tool ([c485889](https://github.com/google/adk-python/commit/c4858896ff085bedcfbc42b2010af8bd78febdd0))

### Improvements

* Add BigQuery related label handling ([ffbab4c](https://github.com/google/adk-python/commit/ffbab4cf4ed6ceb313241c345751214d3c0e11ce))
* Add demo for rewind ([8eb1bdb](https://github.com/google/adk-python/commit/8eb1bdbc58dc709006988f5b6eec5fda25bd0c89))
* Add debug logging for live connection ([5d5708b](https://github.com/google/adk-python/commit/5d5708b2ab26cb714556311c490b4d6f0a1f9666))
* Add debug logging for missing function call events ([f3d6fcf](https://github.com/google/adk-python/commit/f3d6fcf44411d07169c14ae12189543f44f96c27))
* Add default retry options as fall back to llm_request that are made during evals ([696852a](https://github.com/google/adk-python/commit/696852a28095a024cbe76413ee7617356e19a9e3))
* Add plugin for returning GenAI Parts from tools into the model request ([116b26c](https://github.com/google/adk-python/commit/116b26c33e166bf1a22964e2b67013907fbfcb80))
* Add support for abstract types in AFC ([2efc184](https://github.com/google/adk-python/commit/2efc184a46173529bdfc622db0d6f3866e7ee778))
* Add support for structured output schemas in LiteLLM models ([7ea4aed](https://github.com/google/adk-python/commit/7ea4aed35ba70ec5a38dc1b3b0a9808183c2bab1))
* Add tests for `max_query_result_rows` in BigQuery tool config ([fd33610](https://github.com/google/adk-python/commit/fd33610e967ad814bc02422f5d14dae046bee833))
* Add type hints in `cleanup_unused_files.py` ([2dea573](https://github.com/google/adk-python/commit/2dea5733b759a7a07d74f36a4d6da7b081afc732))
* Add util to build our llms.txt and llms-full.txt files
* ADK changes ([f1f4467](https://github.com/google/adk-python/commit/f1f44675e4a86b75e72cfd838efd8a0399f23e24))
* Defer import of `google.cloud.storage` in `GCSArtifactService` ([999af55](https://github.com/google/adk-python/commit/999af5588005e7b29451bdbf9252265187ca992d))
* Defer import of `live`, `Client` and `_transformers` in `google.genai` ([22c6dbe](https://github.com/google/adk-python/commit/22c6dbe83cd1a8900d0ac6fd23d2092f095189fa))
* Enhance the messaging with possible fixes for RESOURCE_EXHAUSTED errors from Gemini ([b2c45f8](https://github.com/google/adk-python/commit/b2c45f8d910eb7bca4805c567279e65aff72b58a))
* Improve gepa tau-bench colab for external use ([e02f177](https://github.com/google/adk-python/commit/e02f177790d9772dd253c9102b80df1a9418aa7f))
* Improve gepa voter agent demo colab ([d118479](https://github.com/google/adk-python/commit/d118479ccf3a970ce9b24ac834b4b6764edb5de4))
* Lazy import DatabaseSessionService in the adk/sessions/ module ([5f05749](https://github.com/google/adk-python/commit/5f057498a274d3b3db0be0866f04d5225334f54a))
* Move adk_agent_builder_assistant to built_in_agents ([b2b7f2d](https://github.com/google/adk-python/commit/b2b7f2d6aa5b919a00a92abaf2543993746e939e))
* Plumb memory service from LocalEvalService to EvaluationGenerator ([dc3f60c](https://github.com/google/adk-python/commit/dc3f60cc939335da49399a69c0b4abc0e7f25ea4))
* Removes the unrealistic todo comment of visibility management ([e511eb1](https://github.com/google/adk-python/commit/e511eb1f70f2a3fccc9464ddaf54d0165db22feb))
* Returns agent state regardless if ctx.is_resumable ([d6b928b](https://github.com/google/adk-python/commit/d6b928bdf7cdbf8f1925d4c5227c7d580093348e))
* Stop logging the full content of LLM blobs ([0826755](https://github.com/google/adk-python/commit/082675546f501a70f4bc8969b9431a2e4808bd13))
* Update ADK web to match main branch ([14e3802](https://github.com/google/adk-python/commit/14e3802643a2d8ce436d030734fafd163080a1ad))
* Update agent instructions and retry limit in `plugin_reflect_tool_retry` sample ([01bac62](https://github.com/google/adk-python/commit/01bac62f0c14cce5d454a389b64a9f44a03a3673))
* Update conformance test CLI to handle long-running tool calls ([dd706bd](https://github.com/google/adk-python/commit/dd706bdc4563a2a815459482237190a63994cb6f))
* Update Gemini Live model names in live bidi streaming sample ([aa77834](https://github.com/google/adk-python/commit/aa77834e2ecd4b77dfb4e689ef37549b3ebd6134))


## [1.18.0](https://github.com/google/adk-python/compare/v1.17.0...v1.18.0) (2025-11-05)

### Features

* **[ADK Visual Agent Builder]**
  * Core Features
    * Visual workflow designer for agent creation
    * Support for multiple agent types (LLM, Sequential, Parallel, Loop, Workflow)
    * Agent tool support with nested agent tools
    * Built-in and custom tool integration
    * Callback management for all ADK callback types (before/after agent, model, tool)
    * Assistant to help you build your agents with natural language
    * Assistant proposes and writes agent configuration yaml files for you
    * Save to test with chat interfaces as normal
    * Build and debug at the same time in adk web!

* **[Core]**
  * Add support for extracting cache-related token counts from LiteLLM usage ([4f85e86](https://github.com/google/adk-python/commit/4f85e86fc3915f0e67312a39fe22451968d4f1b1))
  * Expose the Python code run by the code interpreter in the logs ([a2c6a8a](https://github.com/google/adk-python/commit/a2c6a8a85cf4f556e9dacfe46cf384d13d964208))
  * Add run_debug() helper method for quick agent experimentation ([0487eea](https://github.com/google/adk-python/commit/0487eea2abcd05d7efd123962d17b8c6c9a9d975))
  * Allow injecting a custom Runner into `agent_to_a2a` ([156d235](https://github.com/google/adk-python/commit/156d23547915e8f7f5c6ba55e0362f4b133c3968))
  * Support MCP prompts via the McpInstructionProvider class ([88032cf](https://github.com/google/adk-python/commit/88032cf5c56bb2d81842353605f9f5ab4b2206ff))

* **[Models]**
  * Add model tracking to LiteLlm and introduce a LiteLLM with fallbacks demo ([d4c63fc](https://github.com/google/adk-python/commit/d4c63fc5629e7d70ad8b8185be09243a01e3428f))
  * Add ApigeeLlm as a model that lets ADK Agent developers to connect with an Apigee proxy ([87dcb3f](https://github.com/google/adk-python/commit/87dcb3f7ba344a2ba7d9edfc4817c9e792d90bfc))

* **[Integrations]**
  * Add example and fix for loading and upgrading old ADK session databases ([338c3c8](https://github.com/google/adk-python/commit/338c3c89c6bce7f3406f729013cedcd78b809a56))
  * Add support for specifying logging level for adk eval cli command ([b1ff85f](https://github.com/google/adk-python/commit/b1ff85fb2347e3402eedd42e3673be7093a99548))
  * Propagate LiteLLM finish_reason to LlmResponse for use in callbacks ([71aa564](https://github.com/google/adk-python/commit/71aa5645f6c3d91fd0e0ddb1ed564188c6727080))
  * Allow LLM request to override the model used in the generate content async method in LiteLLM ([ce8f674](https://github.com/google/adk-python/commit/ce8f674a287368439ba11be3285902671e9bc75a))
  * Add api key argument to Vertex Session and Memory services for Express Mode support ([9014a84](https://github.com/google/adk-python/commit/9014a849eab9f77b82db4a7f2053fb2a96282f03))
  * Added support for enums as arguments for function tools ([240ef5b](https://github.com/google/adk-python/commit/240ef5beea9389911e8c03a6039b353befc716ac))
  * Implement artifact_version related methods in GcsArtifactService ([e194ebb](https://github.com/google/adk-python/commit/e194ebb33c62bc40403ea852a88f77a9511b61a4))

* **[Services]**
  * Add support for Vertex AI Express Mode when deploying to Agent Engine ([d4b2a8b](https://github.com/google/adk-python/commit/d4b2a8b49f98a9991cb44ac7ec6e538b81a08664))
  * Remove custom polling logic for Vertex AI Session Service since LRO polling is supported in express mode ([546c2a6](https://github.com/google/adk-python/commit/546c2a68165f54e694664d5b6b6740566301782b))
  * Make VertexAiSessionService fully asynchronous ([f7e2a7a](https://github.com/google/adk-python/commit/f7e2a7a40ef248dd6fbba9669503b0828a12f0cc))

* **[Tools]**
  * Add Bigquery detect_anomalies tool ([9851340](https://github.com/google/adk-python/commit/9851340ad1df86d6f5c21e8984199573f239bb2b))
  * Extend Bigquery detect_anomalies tool to support future data anomaly detection ([38ea749](https://github.com/google/adk-python/commit/38ea749c9cec8e65f5e768f49fd2de79b5545571))
  * Add get_job_info tool to BigQuery toolset ([6429457](https://github.com/google/adk-python/commit/64294572c1c93590aa3c221015a5cb9b440ee948))

* **[Evals]**
  * Add "final_session_state" to the EvalCase data model ([2274c4f](https://github.com/google/adk-python/commit/2274c4f3040b20da3690aa03272155776ca330c1))
  * Marked expected_invocation as optional field on evaluator interface ([b17c8f1](https://github.com/google/adk-python/commit/b17c8f19e5fc67180d1bdc621f84cd43e357571c))
  * Adds LLM-backed user simulator ([54c4ecc](https://github.com/google/adk-python/commit/54c4ecc73381cffa51cff01c7fb8a2ac59308c53))

* **[Observability]**
  * Add BigQueryLoggingPlugin for event logging to BigQuery ([b7dbfed](https://github.com/google/adk-python/commit/b7dbfed4a3d4a0165e2c6e51594d1f547bec89d3))

* **[Live]**
  * Add token usage to live events for bidi streaming ([6e5c0eb](https://github.com/google/adk-python/commit/6e5c0eb6e0474f5b908eb9df20328e7da85ebed9))

### Bug Fixes

* Reduce logging spam for MCP tools without authentication ([11571c3](https://github.com/google/adk-python/commit/11571c37ab948d43cbaa3a1d82522256dfe4d467))
* Fix typo in several files ([d2888a3](https://github.com/google/adk-python/commit/d2888a3766b87df2baaaa1a67a2235b1b80f138f))
* Disable SetModelResponseTool workaround for Vertex AI Gemini 2+ models ([6a94af2](https://github.com/google/adk-python/commit/6a94af24bf3367c05a5d405b7e7b79810a1fac4e))
* Bug when callback_context_invocation_context is missing in GlobalInstructionPlugin ([f81ebdb](https://github.com/google/adk-python/commit/f81ebdb622211031945eb06c3f00ff5208d94f9b))
* Support models slash prefix in model name extraction ([8dff850](https://github.com/google/adk-python/commit/8dff85099d67623dd6f4a707fb932ea55b8aaf9b))
* Do not consider events with state delta and no content as final response ([1ee93c8](https://github.com/google/adk-python/commit/1ee93c8bcb7ccd6f33658dc76b2095dd7e58aac9))
* Parameter filtering for CrewAI functions with **kwargs ([74a3500](https://github.com/google/adk-python/commit/74a3500fc5d4b07e80f914d83a0d91face28086c))
* Do not treat FinishReason.STOP as error case for LLM responses containing candidates with empty contents ([2f72ceb](https://github.com/google/adk-python/commit/2f72ceb49b452c5a1f257bce6adb004fa5d54472))
* Fixes null check for reflect_retry plugin sample ([86f0155](https://github.com/google/adk-python/commit/86f01550bd1b52d6d160e8bc54cecc6c4fe8611c))
* Creates evalset directory on evalset create ([6c3882f](https://github.com/google/adk-python/commit/6c3882f2d66f169d393171be280b6e6218b52a7c))
* Add ADK_DISABLE_LOAD_DOTENV environment variable that disables automatic loading of .env when running ADK cli, if set to true or 1 ([15afbcd](https://github.com/google/adk-python/commit/15afbcd1587d4102a4dc5c07c0c493917df9d6ea))
* Allow tenacity 9.0.0 ([ee8acc5](https://github.com/google/adk-python/commit/ee8acc58be7421a3e8eab07b051c45f9319f80dc))
* Output file uploading to artifact service should handle both base64 encoded and raw bytes ([496f8cd](https://github.com/google/adk-python/commit/496f8cd6bb36d3ba333d7ab1e94e7796d2960300))
* Correct message part ordering in A2A history ([5eca72f](https://github.com/google/adk-python/commit/5eca72f9bfd05c7c28a3d738391138a59a31167d))
* Change instruction insertion to respect tool call/response pairs ([1e6a9da](https://github.com/google/adk-python/commit/1e6a9daa63050936ab421f1f684935927aebc63e))
* DynamicPickleType to support MySQL dialect ([fc15c9a](https://github.com/google/adk-python/commit/fc15c9a0c3c043c0a61dce625b8cd1ee121b4baf))
* Enable usage metadata in LiteLLM streaming ([f9569bb](https://github.com/google/adk-python/commit/f9569bbb1afbc7f0e8b6e68599590471fd112b9f))
* Fix issue with MCP tools throwing an error ([1a4261a](https://github.com/google/adk-python/commit/1a4261ad4b66cdeb39d39110a086bd6112b17516))
* Remove redundant `format` field from LiteLLM content objects ([489c39d](https://github.com/google/adk-python/commit/489c39db01465e38ecbc2c7f32781c349b8cddc9))
* Update the contribution analysis tool to use original write mode ([54db3d4](https://github.com/google/adk-python/commit/54db3d4434e0706b83a589fa2499d11d439a6e4e))
* Fix agent evaluations detailed output rows wrapping issue([4284c61](https://github.com/google/adk-python/commit/4284c619010b8246c1ecaa011f14b6cc9de512dd))
* Update dependency version constraints to be based on PyPI versions([0b1784e](https://github.com/google/adk-python/commit/0b1784e0e493a0e2df1edfe37e5ed5f4247e7d9d))

### Improvements

* Add Community Repo section to README ([432d30a](https://github.com/google/adk-python/commit/432d30af486329aa83f89c5d5752749a85c0b843))
* Undo adding MCP tools output schema to FunctionDeclaration ([92a7d19](https://github.com/google/adk-python/commit/92a7d1957367d498de773761edd142d8c108d751))
* Refactor ADK README for clarity and consistency ([b0017ae](https://github.com/google/adk-python/commit/b0017aed4472c73c3b07e71f1d65ae97a5293547))
* Add support for reversed proxy in adk web ([a0df75b](https://github.com/google/adk-python/commit/a0df75b6fa35d837086decb8802dbf1c0a6637ad))
* Avoid rendering empty columns as part of detailed results rendering of eval results ([5cb35db](https://github.com/google/adk-python/commit/5cb35db921bf86b5ad0012046bd19fa7cc1e6abb))
* Clear the behavior of disallow_transfer_to_parent ([48ddd07](https://github.com/google/adk-python/commit/48ddd078941f9240b10f052b6de171c310bc2bc6))
* Disable the scheduled execution for issue triage workflow ([a02f321](https://github.com/google/adk-python/commit/a02f321f1bdb8be9ad1873db804e0e8393268dc3))
* Include delimiter when matching events from parent nodes in content processor ([b8a2b6c](https://github.com/google/adk-python/commit/b8a2b6c57080ae29d7a02df7d9fcc2f961d422d2))
* Improve Tau-bench ADK colab stability ([04dbc42](https://github.com/google/adk-python/commit/04dbc42e50ce40ef3924d1c259e425215e12c2e7))
* Implement ADK-based agent factory for Tau-bench ([c0c67c8](https://github.com/google/adk-python/commit/c0c67c8698d70ddb9ed958416661f232ef9a5ed8))
* Add util to run ADK LLM Agent with simulation environment ([87f415a](https://github.com/google/adk-python/commit/87f415a7c36a1f3b6ab84d1fe939726c6ef7f34e))
* Demonstrate CodeExecutor customization for environment setup ([8eeff35](https://github.com/google/adk-python/commit/8eeff35b35d7e1538a5c9662cc8369f6ff7962f8))
* Add sample agent for VertexAiCodeExecutor ([edfe553](https://github.com/google/adk-python/commit/edfe5539421d196ca4da14d3a37fac7b598f8c8d))
* Adds a new sample agent that demonstrates how to integrate PostgreSQL databases using the Model Context Protocol (MCP) ([45a2168](https://github.com/google/adk-python/commit/45a2168e0e6773e595ecfb825d7e4ab0a38c3a38))
* Add example for using ADK with Fast MCP sampling ([d3796f9](https://github.com/google/adk-python/commit/d3796f9b33251d28d05e6701f11e80f02a2a49e1))
* Refactor gepa sample code and clean-up user demo colab([63353b2](https://github.com/google/adk-python/commit/63353b2b74e23e97385892415c5a3f2a59c3504f))

## [1.17.0](https://github.com/google/adk-python/compare/v1.16.0...v1.17.0) (2025-10-22)

### Features

* **[Core]**
  * Add a service registry to provide a generic way to register custom service implementations to be used in FastAPI server. See [short instruction](https://github.com/google/adk-python/discussions/3175#discussioncomment-14745120). ([391628f](https://github.com/google/adk-python/commit/391628fcdc7b950c6835f64ae3ccab197163c990))
  * Add the ability to rewind a session to before a previous invocation ([9dce06f](https://github.com/google/adk-python/commit/9dce06f9b00259ec42241df4f6638955e783a9d1))
  * Support resuming a parallel agent with multiple branches paused on tool confirmation requests ([9939e0b](https://github.com/google/adk-python/commit/9939e0b087094038b90d86c2fd35c26dd63f1157))
  * Support content union as static instruction ([cc24d61](https://github.com/google/adk-python/commit/cc24d616f80c0eba2b09239b621cf3d176f144ea))

* **[Evals]**
  * ADK cli allows developers to create an eval set and add an eval case ([ae139bb](https://github.com/google/adk-python/commit/ae139bb461c2e7c6be154b04f3f2c80919808d31))

* **[Integrations]**
  * Allow custom request and event converters in A2aAgentExecutor ([a17f3b2](https://github.com/google/adk-python/commit/a17f3b2e6d2d48c433b42e27763f3d6df80243ca))

* **[Observability]**
  * Env variable for disabling llm_request and llm_response in spans ([e50f05a](https://github.com/google/adk-python/commit/e50f05a9fc94834796876f7f112f344f788f202e))

* **[Services]**
  * Allow passing extra kwargs to create_session of VertexAiSessionService ([6a5eac0](https://github.com/google/adk-python/commit/6a5eac0bdc9adc6907a28f65a3d4d7234e863049))
  * Implement new methods in in-memory artifact service to support custom metadata, artifact versions, etc. ([5a543c0](https://github.com/google/adk-python/commit/5a543c00df2f7a66018df8a67efcf4ce44d4e0e4))
  * Add create_time and mime_type to ArtifactVersion ([2c7a342](https://github.com/google/adk-python/commit/2c7a34259395b1294319118d0f3d1b3b867b44d6))
  * Support returning all sessions when user id is none ([141318f](https://github.com/google/adk-python/commit/141318f77554ae4eb5a360bea524e98eff4a086c))

* **[Tools]**
  * Support additional headers for Google API toolset ([ed37e34](https://github.com/google/adk-python/commit/ed37e343f0c997d3ee5dc98888c5e0dbd7f2a2b6))
  * Introduces a new AgentEngineSandboxCodeExecutor class that supports executing agent-generated code using the Vertex AI Code Execution Sandbox API ([ee39a89](https://github.com/google/adk-python/commit/ee39a891106316b790621795b5cc529e89815a98))
  * Support dynamic per-request headers in MCPToolset ([6dcbb5a](https://github.com/google/adk-python/commit/6dcbb5aca642290112a7c81162b455526c15cd14))
  * Add `bypass_multi_tools_limit` option to GoogleSearchTool and VertexAiSearchTool ([9a6b850](https://github.com/google/adk-python/commit/9a6b8507f06d8367488aac653efecf665619516c), [6da7274](https://github.com/google/adk-python/commit/6da727485898137948d72906d86d78b6db6331ac))
  * Extend `ReflectAndRetryToolPlugin` to support hallucinating function calls ([f51380f](https://github.com/google/adk-python/commit/f51380f9ea4534591eda76bef27407c0aa7c3fae))
  * Add require_confirmation param for MCP tool/toolset ([78e74b5](https://github.com/google/adk-python/commit/78e74b5bf2d895d72025a44dbcf589f543514a50))

* **[UI]**
  * Granular per agent speech configuration ([409df13](https://github.com/google/adk-python/commit/409df1378f36b436139aa909fc90a9e9a0776b3a))

### Bug Fixes

* Returns dict as result from McpTool to comply with BaseTool expectations ([4df9263](https://github.com/google/adk-python/commit/4df926388b6e9ebcf517fbacf2f5532fd73b0f71))
* Fixes the identity prompt to be one line ([7d5c6b9](https://github.com/google/adk-python/commit/7d5c6b9acf0721dd230f08df919c7409eed2b7d0))
* Fix the broken langchain importing caused by their 1.0.0 release ([c850da3](https://github.com/google/adk-python/commit/c850da3a07ec1441037ced1b654d8aacacd277ab))
* Fix BuiltInCodeExecutor to support visualizations ([ce3418a](https://github.com/google/adk-python/commit/ce3418a69de56570847d45f56ffe7139ab0a47aa))
* Relax runner app-name enforcement and improve agent origin inference ([dc4975d](https://github.com/google/adk-python/commit/dc4975dea9fb79ad887460659f8f397a537ee38f))
* Improve error message when adk web is run in wrong directory ([4a842c5](https://github.com/google/adk-python/commit/4a842c5a1334c3ee01406f796651299589fe12ab))
* Handle App objects in eval and graph endpoints ([0b73a69](https://github.com/google/adk-python/commit/0b73a6937bd84a41f79a9ada3fc782dca1d6fb11))
* Exclude `additionalProperties` from Gemini schemas ([307896a](https://github.com/google/adk-python/commit/307896aeceeb97efed352bc0217bae10423e5da6))
* Overall eval status should be NOT_EVALUATED if no invocations were evaluated ([9fbed0b](https://github.com/google/adk-python/commit/9fbed0b15afb94ec8c0c7ab60221bbc97e481b06))
* Create context cache only when prefix matches with previous request ([9e0b1fb](https://github.com/google/adk-python/commit/9e0b1fb62b06de7ecb79bf77d54a999167d001e1))
* Handle `App` instances returned by `agent_loader.load_agent` ([847df16](https://github.com/google/adk-python/commit/847df1638cbf1686aa43e8e094121d4e23e40245))
* Add support for file URIs in LiteLLM content conversion ([85ed500](https://github.com/google/adk-python/commit/85ed500871ff55c74d16e809ddae0d4db66cbc3a))
* Only exclude scores that are None ([998264a](https://github.com/google/adk-python/commit/998264a5b1b98ac660fcc1359fb2d25c84fa0d87))
* Better handling the A2A streaming tasks ([bddc70b](https://github.com/google/adk-python/commit/bddc70b5d004ba5304fe05bcbf6e08210f0e6131))
* Correctly populate context_id in remote_a2a_agent library ([2158b3c](https://github.com/google/adk-python/commit/2158b3c91531e9125761f211f125d9ab41a55e10))
* Remove unnecessary Aclosing ([2f4f561](https://github.com/google/adk-python/commit/2f4f5611bdb30bd5eb2fdb3a70f43d748371392f))
* Fix pickle data was truncated error in database session using MySql ([36c96ec](https://github.com/google/adk-python/commit/36c96ec5b356109b7c874c85d8bb24f0bf6c050d))

### Improvements

* Improve hint message in agent loader ([fe1fc75](https://github.com/google/adk-python/commit/fe1fc75c15a7983829bbe0b023f4b612b1e5c018))
* Fixes MCPToolset --> McpToolset in various places ([d4dc645](https://github.com/google/adk-python/commit/d4dc6454783f747120d407d0dc2cb78f53598d83))
* Add span for context caching handling and new cache creation ([a2d9f13](https://github.com/google/adk-python/commit/a2d9f13fa1d31e00ba9493fba321ca151cdd9366))
* Checks gemini version for `2 and above` for gemini-builtin tools ([0df6759](https://github.com/google/adk-python/commit/0df67599c0eb54a9a5df51af06483b40058953bf))
* Refactor and fix state management in the session service ([8b3ed05](https://github.com/google/adk-python/commit/8b3ed059c24903e8aca0a09d9d503b48af7df850))
* Update agent builder instructions and remove run command details ([89344da](https://github.com/google/adk-python/commit/89344da81364d921f778c8bbea93e1df6ad1097e))
* Clarify how to use adk built-in tool in instruction ([d22b8bf](https://github.com/google/adk-python/commit/d22b8bf8907e723f618dfd18e90dd0a5dbc9518c))
* Delegate the agent state reset logic to LoopAgent ([bb1ea74](https://github.com/google/adk-python/commit/bb1ea74924127d65d763a45b869da3d4ff4d5c5a))
* Adjust the instruction about default model ([214986e](https://github.com/google/adk-python/commit/214986ebeb53b2ef34c8aa37cd6403106de82c1b))
* Migrate invocation_context to callback_context ([e2072af](https://github.com/google/adk-python/commit/e2072af69f40474431b6749b7b9dc22fbcbc7730))
* Correct the callback signatures ([fa84bcb](https://github.com/google/adk-python/commit/fa84bcb5756773eadff486b99c9bd416b4faa9c6))
* Set default for `bypass_multi_tools_limit` to False for GoogleSearchTool and VertexAiSearchTool ([6da7274](https://github.com/google/adk-python/commit/6da727485898137948d72906d86d78b6db6331ac))
* Add more clear instruction to the doc updater agent about one PR for each recommended change ([b21d0a5](https://github.com/google/adk-python/commit/b21d0a50d610407be2f10b73a91274840ffdfe18))
* Add a guideline to avoid content deletion ([16b030b](https://github.com/google/adk-python/commit/16b030b2b25a9b0b489e47b4b148fc4d39aeffcb))
* Add a sample agent for the `ReflectAndRetryToolPlugin` ([9b8a4aa](https://github.com/google/adk-python/commit/9b8a4aad6fe65ef37885e5c3368d2799a2666534))
* Improve error message when adk web is run in wrong directory ([4a842c5](https://github.com/google/adk-python/commit/4a842c5a1334c3ee01406f796651299589fe12ab))
* Add span for context caching handling and new cache creation ([a2d9f13](https://github.com/google/adk-python/commit/a2d9f13fa1d31e00ba9493fba321ca151cdd9366))
* Disable the scheduled execution for issue triage workflow ([bae2102](https://github.com/google/adk-python/commit/bae21027d9bd7f811bed638ecce692262cb33fe5))
* Correct the callback signatures ([fa84bcb](https://github.com/google/adk-python/commit/fa84bcb5756773eadff486b99c9bd416b4faa9c6))

### Documentation

* Format README.md for samples ([0bdba30](https://github.com/google/adk-python/commit/0bdba3026345872fb907aedd1ed75e4135e58a30))
* Bump models in llms and llms-full to Gemini 2.5 ([ce46386](https://github.com/google/adk-python/commit/ce4638651f376fb6579993d8468ae57198134729))
* Update gemini_llm_connection.py - typo spelling correction ([e6e2767](https://github.com/google/adk-python/commit/e6e2767c3901a14187f5527540f318317dd6c8e3))
* Announce the first ADK Community Call in the README ([731bb90](https://github.com/google/adk-python/commit/731bb9078d01359ae770719a8f5c003680ed9f3e))

## [1.16.0](https://github.com/google/adk-python/compare/v1.15.1...v1.16.0) (2025-10-08)

### Features

* **[Core]**
  * Implementation of LLM context compaction ([e0dd06f](https://github.com/google/adk-python/commit/e0dd06ff04f9d3c2f022873ce145aaae2de02f45))
  * Support pause and resume an invocation in ADK ([ce9c39f](https://github.com/google/adk-python/commit/ce9c39f5a85ed12c22009693b5e6bc65f4641633),
    [2f1040f](https://github.com/google/adk-python/commit/2f1040f296db365080b62d6372474d90196ce0d6),
    [1ee01cc](https://github.com/google/adk-python/commit/1ee01cc05add44ce460d2cfd3726dceb0c76dceb),
    [f005414](https://github.com/google/adk-python/commit/f005414895a57befe880fd58c0d778e499a20d8e),
    [fbf7576](https://github.com/google/adk-python/commit/fbf75761bb8d89a70b32c43bbd3fa2f48b81d67c))
* **[Models]**
  * Add `citation_metadata` to `LlmResponse` ([3f28e30](https://github.com/google/adk-python/commit/3f28e30c6da192e90a8100f270274cb9a55a5348))
  * Add support for gemma model via gemini api ([2b5acb9](https://github.com/google/adk-python/commit/2b5acb98f577f5349e788bcf9910c8d7107e63b3))
* **[Tools]**
  * Add `dry_run` functionality to BigQuery `execute_sql` tool ([960eda3](https://github.com/google/adk-python/commit/960eda3d1f2f46dc93a365eb3de03dc3483fe9bb))
  * Add BigQuery analyze_contribution tool ([4bb089d](https://github.com/google/adk-python/commit/4bb089d386d4e8133e9aadbba5c42d31ff281cf6))
  * Spanner ADK toolset supports customizable template SQL and parameterized SQL ([da62700](https://github.com/google/adk-python/commit/da62700d739cb505149554962a8bcfb30f9428cc))
  * Support OAuth2 client credentials grant type ([5c6cdcd](https://github.com/google/adk-python/commit/5c6cdcd197a6780fc86d9183fa208f78c8a975d9))
  * Add `ReflectRetryToolPlugin` to reflect from errors and retry with different arguments when tool errors ([e55b894](https://github.com/google/adk-python/commit/e55b8946d6a2e01aaf018d6a79d11d13c5286152))
  * Support using `VertexAiSearchTool` built-in tool with other tools in the same agent ([4485379](https://github.com/google/adk-python/commit/4485379a049a5c84583a43c85d444ea1f1ba6f12))
  * Support using google search built-in tool with other tools in the same agent ([d3148da](https://github.com/google/adk-python/commit/d3148dacc97f0a9a39b6d7a9640f7b7b0d6f9a6c))
* **[Evals]**
  * Add HallucinationsV1 evaluation metric ([8c73d29](https://github.com/google/adk-python/commit/8c73d29c7557a75d64917ac503da519361d1d762))
  * Add Rubric based tool use metric ([c984b9e](https://github.com/google/adk-python/commit/c984b9e5529b48fff64865a8b805e7e93942ea53))
* **[UI]**
  * Adds `adk web` options for custom logo ([822efe0](https://github.com/google/adk-python/commit/822efe00659607bad2d19ec9a2d14c649fca2d8d))
* **[Observability]**
  * **otel:** Switch CloudTraceSpanExporter to telemetry.googleapis.com ([bd76b46](https://github.com/google/adk-python/commit/bd76b46ce296409d929ae69c5c43347c73e7b365))

### Bug Fixes

* Adapt to new computer use tool name in genai sdk 1.41.0 ([c6dd444](https://github.com/google/adk-python/commit/c6dd444fc947571d089b784fde3a81e17b10cf28))
* Add AuthConfig json serialization in vertex ai session service ([636def3](https://github.com/google/adk-python/commit/636def3687a85e274e3ab44d906f6d92d49e84c0))
* Added more agent instructions for doc content changes ([7459962](https://github.com/google/adk-python/commit/745996212db156878554386be34f58658482e687))
* Convert argument to pydantic model when tool declares it accepts pydantic model as argument ([571c802](https://github.com/google/adk-python/commit/571c802fbaa80b3e65f9ce2db772b9db5a13dbc4))
* Do not re-create `App` object when loader returns an `App` ([d5c46e4](https://github.com/google/adk-python/commit/d5c46e496009eb55d78637f47162df7fcaf3a7ac))
* Fix compaction logic ([3f2b457](https://github.com/google/adk-python/commit/3f2b457efd27ed47160811705e30efa6dd09d7c0))
* Fix the instruction in workflow_triage example agent ([8f3ca03](https://github.com/google/adk-python/commit/8f3ca0359e5b1306c1395770759a74aa48a52347))
* Fixes a bug that causes intermittent `pydantic` validation errors when uploading files ([e680063](https://github.com/google/adk-python/commit/e68006386fdd0da98feb9c3dce9322e44a9c914d))
* Handle A2A Task Status Update Event when streaming in remote_a2a_agent ([a5cf80b](https://github.com/google/adk-python/commit/a5cf80b952887c07bb1d56b7bdec28808edcc4a9))
* Make compactor optional in Events Compaction Config and add a default ([3f4bd67](https://github.com/google/adk-python/commit/3f4bd67b49cd60e6a2e43ccd5192efe450a6e009))
* Rename SlidingWindowCompactor to LlmEventSummarizer and refine its docstring ([f1abdb1](https://github.com/google/adk-python/commit/f1abdb1938e474564a3a76279a1a0a511f74a750))
* Rollback compaction handling from _get_contents ([84f2f41](https://github.com/google/adk-python/commit/84f2f417f77ead3748c5bbeac7f144164b9a9416))
* Set `max_output_tokens` for the agent builder ([2e2d61b](https://github.com/google/adk-python/commit/2e2d61b6fecb90cd474d6f51255678ff74b67a9b))
* Set default response modality to AUDIO in run_session ([68402bd](https://github.com/google/adk-python/commit/68402bda49083f2d56f8e8488fe13aa58b3bc18c))
* Update remote_a2a_agent to better handle streaming events and avoid duplicate responses ([8e5f361](https://github.com/google/adk-python/commit/8e5f36126498f751171bb2639c7f5a9e7dca2558))
* Update the load_artifacts tool so that the model can reliably call it for follow-up questions about the same artifact ([238472d](https://github.com/google/adk-python/commit/238472d083b5aa67551bde733fc47826ff062679))
* Fix VertexAiSessionService base_url override to preserve initialized http_options ([8110e41](https://github.com/google/adk-python/commit/8110e41b36cceddb8b92ba17cffaacf701706b36), [c51ea0b](https://github.com/google/adk-python/commit/c51ea0b52e63de8e43d3dccb24f9d20987784aa5))
* Handle `App` instances returned by `agent_loader.load_agent` ([847df16](https://github.com/google/adk-python/commit/847df1638cbf1686aa43e8e094121d4e23e40245))

### Improvements

* Migrate VertexAiSessionService to use Agent Engine SDK ([90d4c19](https://github.com/google/adk-python/commit/90d4c19c5115c7af361effa8e12c248225ccf6ab))
* Migrate VertexAiMemoryBankService to use Agent Engine SDK ([d1efc84](https://github.com/google/adk-python/commit/d1efc8461e82fc31df940b701f1d1b5422214296), [97b950b](https://github.com/google/adk-python/commit/97b950b36b9c16467f0f42216b2dc8395346d7fe), [83fd045](https://github.com/google/adk-python/commit/83fd0457188decdabeae58b4e8be25daa89f2943))
* Add support for resolving $ref and $defs in OpenAPI schemas ([a239716](https://github.com/google/adk-python/commit/a239716930c72a0dbd2ccabeea69be46110ca48d))

### Documentation

* Update BigQuery samples README ([3021266](https://github.com/google/adk-python/commit/30212669ff61f3cbd6603c3dceadfbcc4cec42f8))

## [1.15.1](https://github.com/google/adk-python/compare/v1.15.0...v1.15.1) (2025-09-26)

### Bug Fixes

* Fix the deployment failure for Agent Engine ([e172811](https://github.com/google/adk-python/commit/e172811bc7173b9004572f2a2afc7024145d7713))

## [1.15.0](https://github.com/google/adk-python/compare/v1.14.1...v1.15.0) (2025-09-24)

### Features

* **[Core]**
  * Adding the ContextFilterPlugin ([a06bf27](https://github.com/google/adk-python/commit/a06bf278cbc89f521c187ed51b032d82ffdafe2d))
  * Adds plugin to save artifacts for issue [#2176](https://github.com/google/adk-python/issues/2176) ([657369c](https://github.com/google/adk-python/commit/657369cffe142ef3745cd5950d0d24a49f42f7fd))
  * Expose log probs of candidates in LlmResponse ([f7bd3c1](https://github.com/google/adk-python/commit/f7bd3c111c211e880d7c1954dd4508b952704c68))
* **[Context Caching]**
  * Support context caching ([c66245a](https://github.com/google/adk-python/commit/c66245a3b80192c16cb67ee3194f82c9a7c901e5))
    - Support explicit context caching auto creation and lifecycle management.

      Usage: `App(root_agent=..., plugins=..., context_cache_config=...)`
  * Support non-text content in static instruction ([61213ce](https://github.com/google/adk-python/commit/61213ce4d4c10f7ecaf6ddb521672059cee27942))
  * Support static instructions ([9be9cc2](https://github.com/google/adk-python/commit/9be9cc2feee92241fd2fbf9dea3a42de5a78e9ce))
    - Support static instruction that won't change, put at the beginning of
      the instruction.
      Static instruction support inline_data and file_data as contents.
      Dynamic instruction moved to the end of LlmRequest, increasing prefix
      caching matching size.

      Usage:
      `LlmAgent(model=...,static_instruction =types.Content(parts=...), ... )`
* **[Observability]**
  * Add --otel_to_cloud experimental support ([1ae0b82](https://github.com/google/adk-python/commit/1ae0b82f5602a57ad1ca975ca0b7c85003d1a28a), [b131268](https://github.com/google/adk-python/commit/b1312680f4ea9f21c3246a1d24392619643d71f5), [7870480](https://github.com/google/adk-python/commit/7870480c63bb4fc08cfb3cabc0e1f0458f0e85bd))
  * Add GenAI Instrumentation if --otel_to_cloud is enabled ([cee365a](https://github.com/google/adk-python/commit/cee365a13d0d1b1f2be046c1cc29e24a8d1fdbcc))
  * Support standard OTel env variables for exporter endpoints ([f157b2e](https://github.com/google/adk-python/commit/f157b2ee4caf4055e78f4657254e45913895f5de))
  * Temporarily disable Cloud Monitoring integration in --otel_to_cloud ([3b80337](https://github.com/google/adk-python/commit/3b80337faf427460e4743e25dbb92578f823513f))
* **[Services]**
  * Add endpoint to generate memory from session ([2595824](https://github.com/google/adk-python/commit/25958242db890b4d2aac8612f7f7cfbb561727fa))
* **[Tools]**
  * Add Google Maps Grounding Tool to ADK ([6b49391](https://github.com/google/adk-python/commit/6b493915469ecb42068e24818ab547b0856e4709))
  * **MCP:** Initialize tool_name_prefix in MCPToolset ([86dea5b](https://github.com/google/adk-python/commit/86dea5b53ac305367283b7e353b60d0f4515be3b))
* **[Evals]**
  * Data model for storing App Details and data model for steps ([01923a9](https://github.com/google/adk-python/commit/01923a9227895906ca8ae32712d65b178e2cd7d5))
  * Adds Rubric based final response evaluator ([5a485b0](https://github.com/google/adk-python/commit/5a485b01cd64cb49735e13ebd5e7fa3da02cd85f))
  * Populate AppDetails to each Invocation ([d486795](https://github.com/google/adk-python/commit/d48679582de91050ca9c5106402319be9a8ae7e8))
* **[Samples]**
  * Make the bigquery sample agent run with ADC out-of-the-box ([10cf377](https://github.com/google/adk-python/commit/10cf37749417856e394e62896231e41b13420f18))

### Bug Fixes

* Close runners after running eval ([86ee6e3](https://github.com/google/adk-python/commit/86ee6e3fa3690148d60358fc3dacb0e0ab40942b))
* Filter out thought parts when saving agent output to state ([632bf8b](https://github.com/google/adk-python/commit/632bf8b0bcf18ff4e4505e4e5f4c626510f366a2))
* Ignore empty function chunk in LiteLlm streaming response ([8a92fd1](https://github.com/google/adk-python/commit/8a92fd18b600da596c22fd80c6148511a136dfd0))
* Introduces a `raw_mcp_tool` method in `McpTool` to provide direct access to the underlying MCP tool ([6158075](https://github.com/google/adk-python/commit/6158075a657f8fe0835679e509face6191905403))
* Make a copy of the `columns` instead of modifying it in place ([aef1ee9](https://github.com/google/adk-python/commit/aef1ee97a55a310f3959d475b8d7d6bc3915ae48))
* Prevent escaping of Latin characters in LLM response ([c9ea80a](https://github.com/google/adk-python/commit/c9ea80af28e586c9cc1f643b365cdba82f80c700))
* Retain the consumers and transport registry when recreating the ClientFactory in remote_a2a_agent.py ([6bd33e1](https://github.com/google/adk-python/commit/6bd33e1be36f741a6ed0514197550f9f336262ed))
* Remove unsupported 'type': 'unknown' in test_common.py for fastapi 0.117.1 ([3745221](https://github.com/google/adk-python/commit/374522197fa6843f786bfd12d17ce0fc20461dfd))

### Documentation

* Correct the documentation of `after_agent_callback` ([b9735b2](https://github.com/google/adk-python/commit/b9735b2193267645781b268231d63c23c6fec654))

## [1.14.1](https://github.com/google/adk-python/compare/v1.14.0...v1.14.1) (2025-09-12)

### Bug Fixes

* Fix logging issues with RemoteA2aAgent [0c1f1fa](https://github.com/google/adk-python/commit/0c1f1fadeb5a6357af9cad0eff5d5e7103fc88b0)

## [1.14.0](https://github.com/google/adk-python/compare/v1.13.0...v1.14.0) (2025-09-10)

### Features

* **[A2A]**
  * Allow users to pass their own agent card to to_a2a method [a1679da](https://github.com/google/adk-python/commit/a1679dae3fef70f1231afba3e97d45b59c314ae3)
  * Allow custom part converters in A2A classes [b05fef9](https://github.com/google/adk-python/commit/b05fef9ba71f95ab2658eb4eb5608c141d49f82f)
* **[Tools]**
  * Allow setting agent/application name and compute project for BigQuery tools [11a2ffe](https://github.com/google/adk-python/commit/11a2ffe35adbae977b49ceccf0e76e20c6dc90b6)
  * Add BigQuery forecast tool [0935a40](https://github.com/google/adk-python/commit/0935a40011a3276ee7f7fa3b91678b4d63f22ba5)
  * Add GkeCodeExecutor for sandboxed code execution on GKE [72ff9c6](https://github.com/google/adk-python/commit/72ff9c64a291aebb50b07446378f375e58882c4e)
  * Add a tool confirmation flow that can guard tool execution with explicit confirmation and custom input [a17bcbb](https://github.com/google/adk-python/commit/a17bcbb2aa0f5c6aca460db96ed1cb7dd86fef84)
  * Add audience and prompt as configurable for OAuth flows [edda922](https://github.com/google/adk-python/commit/edda922791f15ac37830ed95ebf76b9f836d9db4)
  * Allow user specify embedding model for file retrieval [67f23df](https://github.com/google/adk-python/commit/67f23df25ad47aff3cb36d0fc9ce2c9b97bde09b)
* **[Core]**
  * Allow all possible values for `agent_class` field in all Agent Configs [3bc2d77](https://github.com/google/adk-python/commit/3bc2d77b4d180e9c42b30d4d1ce580aa75abe501)
  * Allow agent loader to load built-in agents from special directories in adk folder [578fad7](https://github.com/google/adk-python/commit/578fad7034a7b369a490ad0afa4dd2820463c22d)
  * Upgrade ADK runner to use App in addition to root_agent [4df79dd](https://github.com/google/adk-python/commit/4df79dd5c92d96096d031b26470458d0bca79a79)
  * Allow inject artifact into instructions [bb4cfde](https://github.com/google/adk-python/commit/bb4cfdec12370955d4038d6d8c86e04691f2308e)
* **[Misc]** Create an initial ADK release analyzer agent to find the doc updates needed between releases [e3422c6](https://github.com/google/adk-python/commit/e3422c616d18ec3850454ee83f2ef286198543ec)

### Bug Fixes

* Add a NOTE to agent transfer instructions listing available agents [43eec82](https://github.com/google/adk-python/commit/43eec82f8444c19455089655ee288200ec966577)
* Fix pagination of list_sessions in VertexAiSessionService [e63fe0c](https://github.com/google/adk-python/commit/e63fe0c0eb73ac6e22d975387dd2df3d2ba3f521)
* Fix AttributeError and indentation in parameter processing of LiteLlm [1e23652](https://github.com/google/adk-python/commit/1e23652968164c5fdfa5564e966e78799237d94b)
* Allow AgentTool to inherit/use plugins from its invocation context when running [1979dcf](https://github.com/google/adk-python/commit/1979dcf496be3fb75fa2063fc96f480bedeb5de2)
* Enforce foreign key constraint for SQLite DB [0c87907](https://github.com/google/adk-python/commit/0c87907bcb2e5687a4ad08bab450fc888a5b5233)
* Add back installing requirements.txt to Dockerfile template for cloud run [8e43f0d](https://github.com/google/adk-python/commit/8e43f0dd8321ea31d6ad970ad4402feb48cdbd3d)
* Only process the auth responses in the last event with content (if applicable i.e. it's authored by user) [3b922a2](https://github.com/google/adk-python/commit/3b922a2f6da373b0de78b022db5d5bcb5453379f)
* Extract a utility for aggregating partial streaming responses and emitting LlmResponses for them as needed [7975e8e](https://github.com/google/adk-python/commit/7975e8e1961c8e375e2af3506ea546580ff7e45d)
* Support saving text artifacts in GCS artifact service [cecf7e8](https://github.com/google/adk-python/commit/cecf7e805d19d20e940319a6e16bfc9015ead202)
* Fixes `thought` handling in contents.py and refactors its unit tests [a30851e](https://github.com/google/adk-python/commit/a30851ee16114103dca7b9736e79cb31e82ee4d8)
* Fixes the `thought` field handling in _planning.py [fe8b37b](https://github.com/google/adk-python/commit/fe8b37b0d3046a9c0dd90e8ddca2940c28d1a93f)
* Pass state_delta to runner in /run endpoint [a3410fa](https://github.com/google/adk-python/commit/a3410fab7b25cc0e9c5908e23a087b501466df76)
* Fix discussion answering github action workflow to escape the quote in the discussion content JSON [43c9681](https://github.com/google/adk-python/commit/43c96811da891a5b0c9cf1be525665e65f346a13)
* Send full MIME types for image/video/pdf in get_content [e45c3be](https://github.com/google/adk-python/commit/e45c3be23895b5ec68908ad9ee19bd622dcbd003)
* Fix flaky unit tests: tests/unittests/flows/llm_flows/test_functions_simple.py [b92b288](https://github.com/google/adk-python/commit/b92b288c978a9b3d1a76c8bcb96cc8f439ce610b)
* Make UT of a2a consistent about how tests should be skipped when python version < 3.10 [98b0426](https://github.com/google/adk-python/commit/98b0426cd2dc5e28014ead22b22dbf50d42d0a9a)

### Improvements

* Update contribution guide [8174a29](https://github.com/google/adk-python/commit/8174a29c6db9fd22a5a563f3088bd538b90e9a50)
* Skip PR triage for already triaged or Google-contributor PRs [78eea1a](https://github.com/google/adk-python/commit/78eea1aa550790097a1005237acaec56309cd61e)
* Avoid mutable default arguments in `local_eval_service` and `runners` [64f11a6](https://github.com/google/adk-python/commit/64f11a6a67e7042768270c5587e87528c358bd06)
* Avoid mutable default arguments in `local_eval_service` and `runners` [5b465fd](https://github.com/google/adk-python/commit/5b465fd71b601a2a1ab95a74f7c9ddafe09085e5)
* Reorder dependencies in `pyproject.toml` [ca5f7f1](https://github.com/google/adk-python/commit/ca5f7f1ff0afb2b3c2457fb9efdf029dcf7494b7)
* Follow pydantic convention to make field_validator a public method [1448406](https://github.com/google/adk-python/commit/14484065c64396cebc4a1dde84d6b8b51439b990)
* Update comment to clarify `after_run` callbacks [7720616](https://github.com/google/adk-python/commit/7720616c5f1dc302f019c348a6dfa70d1cf0b135)
* Tune instructions to not ask root directory if it's already provided in the context [25df6c2](https://github.com/google/adk-python/commit/25df6c22d5942ead3a329f90ed2c10b374051ae6)
* Load discussion data from event content to avoid additional GraphQL API call [a503a0c](https://github.com/google/adk-python/commit/a503a0c807e50ec9dde7d5095f8e020861d1375d)
* Refactor discussion answering agent to merge answer_discussions.py into main.py [408d3df](https://github.com/google/adk-python/commit/408d3dfeb1475da343a15ae13e9b128985460a5d)
* Add community repo dependency group to pyproject toml [7b077ac](https://github.com/google/adk-python/commit/7b077ac3517f2b88d1bc4b732815ca766c791168)
* Add warning for using Gemini models via LiteLLM [9291daa](https://github.com/google/adk-python/commit/9291daaa8e399ca052f5a52dbb600d719dcc9fa8)

### Documentation

* Update root_agent description for clarity [467df1a](https://github.com/google/adk-python/commit/467df1a36f3ded1a0e324defcd94c557871c9190)
* Update the ask_data_insights docstring [aad1533](https://github.com/google/adk-python/commit/aad153322e54cc39c97e3e0bc71cbed72bcab477)
* Add contributing Spanner tools RAG agent sample [fcd748e](https://github.com/google/adk-python/commit/fcd748e17f4e0e7a3146716816c579f2ee973e6b)

### Tests

* Add functional telemetry tests [bc6b546](https://github.com/google/adk-python/commit/bc6b5462a76ee1cd718c75360daac94373d7c071)
* Add unit tests for the `App` class and improve `Runner` initialization tests [fc90ce9](https://github.com/google/adk-python/commit/fc90ce968f114f84b14829f8117797a4c256d710)

### Chores

* Use lazy % formatting in logging functions to fix pylint warnings [b431072](https://github.com/google/adk-python/commit/b4310727d90421a81a8afc47e3c344646ee7aee8)
* Update release cadence in README [decc19b](https://github.com/google/adk-python/commit/decc19b188fbf097995824f9ad7b7be1263b6338)
* Add `custom_metadata` to DatabaseSessionService [fb009d8](https://github.com/google/adk-python/commit/fb009d8ea672bbbef4753e4cd25229dbebd0ff8d)
* Update create_session endpoint to use Request message as post body [219815d](https://github.com/google/adk-python/commit/219815d2d7f45ac0cff28265f23fbf4f4e77163f)

## 1.13.0 (2025-08-27)

### Features

* [Tools] Add the ask_data_insights tool for natural language queries on BigQuery data [47b88d2](https://github.com/google/adk-python/commit/47b88d2b06d247a698915ebf74564dbb5d81153e)

### Bug Fixes

* Add the missing `from_config` class method in BaseToolset [2dd432c](https://github.com/google/adk-python/commit/2dd432cc1fe265a79986a28e2afb59ee2c83abb3)
* Change LlmResponse to use Content for transcriptions [3b997a0](https://github.com/google/adk-python/commit/3b997a0a07d1a2915bc64d64355f4dbabb7e0ba0)
* AgentTool returns last content, instead of the content in the last event [bcf0dda](https://github.com/google/adk-python/commit/bcf0dda8bcc221974098f3077007c9e84c63021a)
* Fix adk deploy docker file permission [ad81aa5](https://github.com/google/adk-python/commit/ad81aa54de1f38df580915b7f47834ea8e5f1004)
* Updating BaseAgent.clone() and LlmAgent.clone() to properly clone fields that are lists [29bb75f](https://github.com/google/adk-python/commit/29bb75f975fe0c9c9d9a7e534a9c20158e1cbe1e)
* Make tool description for bigquery `execute_sql` for various write modes self-contained [167182b](https://github.com/google/adk-python/commit/167182be0163117f814c70f453d5b2e19bf474df)
* Set invocation_id and branch for event generated when both output_schema and tools are used [3f3aa7b](https://github.com/google/adk-python/commit/3f3aa7b32d63cae5750d71bc586c088427c979ea)
* Rework parallel_agent.py to always aclose async generators [826f554](https://github.com/google/adk-python/commit/826f5547890dc02e707be33a3d6a58b527dac223)
* Add table metadata info into Spanner tool `get_table_schema` and fix the key usage info [81a53b5](https://github.com/google/adk-python/commit/81a53b53d6336011187a50ae8f1544de9b2764a8)
* Fix Spanner DatabaseSessionService support [54ed079](https://github.com/google/adk-python/commit/54ed0791005350542708eb2c38f32ce8b92356bc)
* Add support for required params [c144b53](https://github.com/google/adk-python/commit/c144b5347cc459496d4fd41e0c63715ffffb4952)
* Replaced hard coded value for user_id to the value from the tool context from parent agent. [0b89f18](https://github.com/google/adk-python/commit/0b89f1882dccc1acd0ee109832053edecec04850)

### Improvements

* Allow user to specify protocol for A2A RPC URL in to_a2a utility [157f731](https://github.com/google/adk-python/commit/157f73181d123b0fddc34205dc74434fcbc43b2a)
* Passthrough extra args for `adk deploy cloud_run` as Cloud Run args [6806dea](https://github.com/google/adk-python/commit/6806deaf8811eb7f02ed958648886323aba16adb)
* Renames MCPTool and MCPToolset to McpTool and McpToolset [4c70606](https://github.com/google/adk-python/commit/4c7060612967253dae824a14c5c3f853a547469b)
* Ignore hidden files in autoformat.sh [0eb65c0](https://github.com/google/adk-python/commit/0eb65c07d52f71cf555f0c32dc34b2e4ac8cf2a2)

### Documentation

* Clean up docs in sample [a360bc2](https://github.com/google/adk-python/commit/a360bc25429bf4bef6a80da59afe30d6933a844b)
* Fixes root_agent.yaml in tool_mcp_stdio_notion_config for Agent Config sample and adds README.md [2c088ac](https://github.com/google/adk-python/commit/2c088acc9b34f030537b02b45a4afd458445d15b)
* Add What's new section to README.md [ccab076](https://github.com/google/adk-python/commit/ccab076aceff917591eb3a3cc89a9f85226b832a)

## 1.12.0 (2025-08-21)

### Features

**[Agent Config]** 🌟 **NEW FEATURE**: Support using config file (YAML) to author agents in addition to python code. See the [documentation](https://google.github.io/adk-docs/agents/config/) for details.
* [Agent Config] Support deploying config agent to Agent Engine in CLI ([b3b7003](https://github.com/google/adk-python/commit/b3b70035c432670a5f0b5cdd1e9467f43b80495c))
* [Tools] Add a dedicated Bigtable toolset to provide an easier, integrated way to interact
with Bigtable for building AI Agent applications(experimental feature) ([a953807](https://github.com/google/adk-python/commit/a953807cce341425ba23e3f0a85eae58d6b0630f))
* [Tools] Support custom tool_name_prefix in auto-generated GoogleApiToolset ([a2832d5](https://github.com/google/adk-python/commit/a2832d5ac7ba5264ee91f6d5a6a0058cfe4c9e8a)) See [oauth_calendar_agent](https://github.com/google/adk-python/tree/main/contributing/samples/oauth_calendar_agent) as an example.
* [CLI] Add `build_image` option for `adk deploy cloud_run` CLI ([c843503](https://github.com/google/adk-python/commit/c84350345af0ea6a232e0818b20c4262b228b103))
* [Services] Add setdefault method to the ADK State object ([77ed1f5](https://github.com/google/adk-python/commit/77ed1f5f15ed3f009547ed0e20f86d949de12ec2))


### Bug Fixes

* Lazy load VertexAiCodeExecutor and ContainerCodeExecutor ([018db79](https://github.com/google/adk-python/commit/018db79d1354f93b8328abb8416f63070b25f9f1))
* Fix the path for agent card in A2A demo ([fa64545](https://github.com/google/adk-python/commit/fa64545a9de216312a69f93126cfd37f1016c14b))
* Fix the path for agent card in A2A demo ([a117cf0](https://github.com/google/adk-python/commit/a117cf0af335c5e316ae9d61336a433052316462))
* litellm-test due to breaking change in dep library of extension extra ([004a0a0](https://github.com/google/adk-python/commit/004a0a0f2d9a4f7ae6bff42a7cad96c11a99acaf))
* Using base event's invocation id when merge multiple function response event ([279e4fe](https://github.com/google/adk-python/commit/279e4fedd0b1c0d1499c0f9a4454357af7da490e))
* Avoid crash when there is no candidates_token_count, which is Optional ([22f34e9](https://github.com/google/adk-python/commit/22f34e9d2c552fbcfa15a672ef6ff0c36fa32619))
* Fix the packaging version comparison logic in adk cli ([a2b7909](https://github.com/google/adk-python/commit/a2b7909fc36e7786a721f28e2bf75a1e86ad230d))
* Add Spanner admin scope to Spanner tool default OAuth scopes ([b66054d](https://github.com/google/adk-python/commit/b66054dd0d8c5b3d6f6ad58ac1fbd8128d1da614))
* Fixes SequentialAgent.config_type type hint ([8a9a271](https://github.com/google/adk-python/commit/8a9a271141678996c9b84b8c55d4b539d011391c))
* Fixes the host in the ansi bracket of adk web ([cd357bf](https://github.com/google/adk-python/commit/cd357bf5aeb01f1a6ae2a72349a73700ca9f1ed2))
* Add spanner tool name prefix ([a27927d](https://github.com/google/adk-python/commit/a27927dc8197c391c80acb8b2c23d610fba2f887))

### Improvements

* Support `ADK_SUPPRESS_EXPERIMENTAL_FEATURE_WARNINGS` as environment variable to suppress experimental warnings ([4afc9b2](https://github.com/google/adk-python/commit/4afc9b2f33d63381583cea328f97c02213611529))
* Uses pydantic `Field` for Agent configs, so that the generated AgentConfig.json json schema can carry field description ([5b999ed](https://github.com/google/adk-python/commit/5b999ed6fd23a0fc1da56ccff4c09621f433846b))
* Update `openai` dependency version, based on correct OPENAI release ([bb8ebd1](https://github.com/google/adk-python/commit/bb8ebd15f90768b518cd0e21a59b269e30d6d944))
* Add the missing license header for core_callback_config init file ([f8fd6a4](https://github.com/google/adk-python/commit/f8fd6a4f09ab520b8ecdbd8f9fe48228dbff7ebe))
* Creates yaml_utils.py in utils to allow adk dump yaml in the same style ([1fd58cb](https://github.com/google/adk-python/commit/1fd58cb3633992cd88fa7e09ca6eda0f9b34236f))
* Return explicit None type for DELETE endpoints ([f03f167](https://github.com/google/adk-python/commit/f03f1677790c0a9e59b6ba6f46010d0b7b64be50))
* Add _config suffix to all yaml-based agent examples ([43f302c](https://github.com/google/adk-python/commit/43f302ce1ab53077ee8f1486d5294540678921e6))
* Rename run related method and request to align with the conventions ([ecaa7b4](https://github.com/google/adk-python/commit/ecaa7b4c9847b478c7cdc37185b1525f733bb403))
* Update models in samples/ folder to be gemini 2.0+ ([6c217ba](https://github.com/google/adk-python/commit/6c217bad828edf62b41ec06b168f8a6cb7ece2ed))
* Remove the "one commit" requirement from the contributing guide ([c32cb6e](https://github.com/google/adk-python/commit/c32cb6eef9ce320ea5a1f3845fc57b83762c237e))
* Bump version to 1.11.0 ([8005270](https://github.com/google/adk-python/commit/80052700f6cee947322080ae6c415d3a428b6c91))

### Documentation

* Add contributing bigtable sample ([fef5318](https://github.com/google/adk-python/commit/fef5318a22f3dcaadb7ecb858725eb61a0350140))
* Fix core_callback example ([ba6e85e](https://github.com/google/adk-python/commit/ba6e85eb3fb06f58ce9077574eac193298e18bea))
* Adds a minimal sample to demo how to use Agent Config to create a multi-agent setup ([1328e6e](https://github.com/google/adk-python/commit/1328e6ef62e9e6260048c0078579edb85a0440bc))


## [1.11.0](https://github.com/google/adk-python/compare/v1.10.0...v1.11.0) (2025-08-14)

### Features

* [Tools] Support adding prefix to tool names returned by toolset ([ebd726f](https://github.com/google/adk-python/commit/ebd726f1f5e0a76f383192cace4a80a83204325b))
* [Eval] Expose `print_detailed_results` param to `AgentEvaluator.evaluate` ([7e08808](https://github.com/google/adk-python/commit/7e0880869b340e9a5e0d68d6936219e64ab41212))
* [Tools] Add Spanner toolset (breaking change to BigQueryTool, consolidating into generic GoogleTool) ([1fc8d20](https://github.com/google/adk-python/commit/1fc8d20ae88451b7ed764aa86c17c3cdfaffa1cf))
* [Core] Support both output_schema and tools at the same time in LlmAgent([sample](https://github.com/google/adk-python/tree/main/contributing/samples/output_schema_with_tools)) ([af63567](https://github.com/google/adk-python/commit/af635674b5d3c128cf21737056e091646283aeb7))

### Bug Fixes

* A2A RPC URL got overridden by host and port param of adk api server ([52284b1](https://github.com/google/adk-python/commit/52284b1bae561e0d6c93c9d3240a09f210551b97))
* Aclose all async generators to fix OTel tracing context ([a30c63c](https://github.com/google/adk-python/commit/a30c63c5933a770b960b08a6e2f8bf13eece8a22))
* Use PreciseTimestamp for create and update time in database session service to improve precision ([585141e](https://github.com/google/adk-python/commit/585141e0b7dda20abb024c7164073862c8eea7ae))
* Ignore AsyncGenerator return types in function declarations ([e2518dc](https://github.com/google/adk-python/commit/e2518dc371fe77d7b30328d8d6f5f864176edeac))
* Make all subclass of BaseToolset to call parent constructor ([8c65967](https://github.com/google/adk-python/commit/8c65967cdc2dc79fa925ff49a2a8d67c2a248fa9))
* Path parameter extraction for complex Google API endpoints ([54680ed](https://github.com/google/adk-python/commit/54680edf3cac7477c281680ec988c0a207c0915d))
* Docstring concatenation in 3.13 ([88f759a](https://github.com/google/adk-python/commit/88f759a941c95beef0571f36f8e7a34f27971ba8))
* Lazy load retrieval tools and prompt users to install extensions if import failed ([9478a31](https://github.com/google/adk-python/commit/9478a31bf2257f0b668ae7eb91a10863e87c7bed))
* Incorrect logic in LlmRequest.append_tools and make BaseTool to call it ([b4ce3b1](https://github.com/google/adk-python/commit/b4ce3b12d109dd0386f4985fc4b27d5b93787532))
* Creates an InMemoryMemoryService within the EvaluationGenerator ([e4d54b6](https://github.com/google/adk-python/commit/e4d54b66b38ed334ca92c3bb1a83aca01b19e490))
* Uncomment OTel tracing in base_llm_flow.py ([9cfe433](https://github.com/google/adk-python/commit/9cfe43334ae50f814fed663cca7cbe330e663b8c))

### Improvements

* Added upper version bounds to dependencies in "pyproject.toml" ([a74d334](https://github.com/google/adk-python/commit/a74d3344bc19e587c5e9f55f3c90fa9d22c478d8))
* Update python-version in .github/workflows/python-unit-tests.yml to \["3.9", "3.10", "3.11", "3.12", "3.13"] ([ddf2e21](https://github.com/google/adk-python/commit/ddf2e2194b49667c8e91b4a6afde694474674250))
* Update comment to reference "Streamable HTTP Client" ([c52f956](https://github.com/google/adk-python/commit/c52f9564330f0c00d82338cc58df28cb22400b6f))
* Remove logging that contains full event data from DatabaseSessionService ([bb3735c](https://github.com/google/adk-python/commit/bb3735c9cab1baa1af2cc22981af3b3984ddfe15))
* Add the missing env variables in discussion_answering.yml ([a09a5e6](https://github.com/google/adk-python/commit/a09a5e67aa95cf71b51732ab445232dc4815d83d))
* Add Gemini API docs as a new datastore for the ADK Answering Agent ([5fba196](https://github.com/google/adk-python/commit/5fba1963c31eec512558325c480812ccb919a7bb))
* Add the missing license header for some sample agents' files ([7d2cb65](https://github.com/google/adk-python/commit/7d2cb654f0d64728741b5de733e572c44c8a5b04))
* Add docstring to clarify the behavior of preload memory tool ([88114d7](https://github.com/google/adk-python/commit/88114d7c739ca6a1b9bd19d40ed7160e53054a89))
* Add experimental messages for a2a related API ([d0b3b5d](https://github.com/google/adk-python/commit/d0b3b5d857d8105c689bd64204e367102a67eded))
* Fixes generate_image sample ([d674178](https://github.com/google/adk-python/commit/d674178a0535be3769edbf6af5a3d8cd3d47fcd2))
* Make all FastAPI endpoints async ([7f12387](https://github.com/google/adk-python/commit/7f12387eb19b9335a64b80df00609c3c765480e7))
* Group FastAPI endpoints with tags ([c323de5](https://github.com/google/adk-python/commit/c323de5c692223e55372c3797e62d4752835774d))
* Allow implementations to skip defining a close method on Toolset ([944e39e](https://github.com/google/adk-python/commit/944e39ec2a7c9ad7f20c08fd66bf544de94a23d7))
* Add sample agent to test support of output_schema and tools at the same time for gemini model ([f2005a2](https://github.com/google/adk-python/commit/f2005a20267e1ee8581cb79c37aa55dc8e18c0ea))
* Add GitHub workflow config for uploading ADK docs to knowledge store ([5900273](https://github.com/google/adk-python/commit/59002734559d49a46940db9822b9c5f490220a8c))
* Update ADK Answering agent to reference doc site instead of adk-docs repo ([b5a8bad](https://github.com/google/adk-python/commit/b5a8bad170e271b475385dac440c7983ed207df8))

### Documentation

* Fixes tool_functions, which is a config-based sample for using tools ([c5af44c](https://github.com/google/adk-python/commit/c5af44cfc0224e2f07ddc7a649a8561e7141fcdc))
* Add workflow_triage sample for multi-agent request orchestration ([e295feb](https://github.com/google/adk-python/commit/e295feb4c67cbe8ac4425d9ae230210840378b2e))
* Add examples for config agents ([d87feb8](https://github.com/google/adk-python/commit/d87feb8ddb6a5e402c63bd3c35625160eb94e132))
* Adds pypi badge to README.md ([dc26aad](https://github.com/google/adk-python/commit/dc26aad663b6ae72223cfec9b91eaf73a636402d))
* Update StreamableHTTPConnectionParams docstring to remove SSE references ([8f937b5](https://github.com/google/adk-python/commit/8f937b517548a1ce0569f9698ea55c0a130ef221))

## [1.10.0](https://github.com/google/adk-python/compare/v1.9.0...v1.10.0) (2025-08-07)

### Features

* [Live] Implement Live Session Resumption ([71fbc92](https://github.com/google/adk-python/commit/71fbc9275b3d74700ec410cb4155ba0cb18580b7))
* [Tool] Support parallel execution of parallel function calls ([57cd41f](https://github.com/google/adk-python/commit/57cd41f424b469fb834bb8f2777b5f7be9aa6cdf))
* [Models] Allow max tokens to be customizable in Claude ([7556ebc](https://github.com/google/adk-python/commit/7556ebc76abd3c776922c2803aed831661cf7f82))
* [Tool] Create enterprise_web_search_tool as a tool instance ([0e28d64](https://github.com/google/adk-python/commit/0e28d64712e481cfd3b964be0166f529657024f6))

### Bug Fixes

* Fix shared default plugin manager and cost manager instances among multiple invocations ([423542a](https://github.com/google/adk-python/commit/423542a43fb8316195e9f79d97f87593751bebd3))
* Correct the type annotation in anthropic_llm implementation ([97318bc](https://github.com/google/adk-python/commit/97318bcd199acdacadfe8664da3fbfc3c806cdd2))
* Fix adk deploy cloud_run cli, which was broken in v1.9.0 ([e41dbcc](https://github.com/google/adk-python/commit/e41dbccf7f610e249108f9321f60f71fe2cc10f4))
* Remove thoughts from contents in llm requests from history contents ([d620bcb](https://github.com/google/adk-python/commit/d620bcb384d3068228ea2059fb70274e68e69682))
* Annotate response type as None for transfer_to_agent tool ([86a4487](https://github.com/google/adk-python/commit/86a44873e9b2dfc7e62fa31a9ac3be57c0bbff7b))
* Fix incompatible a2a sdk changes ([faadef1](https://github.com/google/adk-python/commit/faadef167ee8e4dd1faf4da5685a577c3155556e))
* Fix adk cli options and method parameters mismatching ([8ef2177](https://github.com/google/adk-python/commit/8ef2177658fbfc74b1a74b0c3ea8150bae866796))

### Improvements

* Add GitHub workflow config for the ADK Answering agent ([8dc0c94](https://github.com/google/adk-python/commit/8dc0c949afb9024738ff7ac1b2c19282175c3200))
* Import AGENT_CARD_WELL_KNOWN_PATH from adk instead of from a2a directly ([37dae9b](https://github.com/google/adk-python/commit/37dae9b631db5060770b66fce0e25cf0ffb56948))
* Make `LlmRequest.LiveConnectConfig` field default to a factory ([74589a1](https://github.com/google/adk-python/commit/74589a1db7df65e319d1ad2f0676ee0cf5d6ec1d))
* Update the prompt to make the ADK Answering Agent more objective ([2833030](https://github.com/google/adk-python/commit/283303032a174d51b8d72f14df83c794d66cb605))
* Add sample agent for testing parallel functions execution ([90b9193](https://github.com/google/adk-python/commit/90b9193a20499b8dd7f57d119cda4c534fcfda10))
* Hide the ask_data_insights tool until the API is publicly available ([bead607](https://github.com/google/adk-python/commit/bead607364be7ac8109357c9d3076d9b345e9e8a))
* Change `LlmRequest.config`'s default value to be `types.GenerateContentConfig()` ([041f04e](https://github.com/google/adk-python/commit/041f04e89cee30532facccce4900d10f1b8c69ce))
* Prevent triggering of _load_from_yaml_config in AgentLoader ([db975df](https://github.com/google/adk-python/commit/db975dfe2a09a6d056d02bc03c1247ac10f6da7d))

### Documentation

* Fix typos ([16a15c8](https://github.com/google/adk-python/commit/16a15c8709b47c9bebe7cffe888e8e7e48ec605a))


## [1.9.0](https://github.com/google/adk-python/compare/v1.8.0...v1.9.0) (2025-07-31)


### Features

* [CLI] Add `-v`, `--verbose` flag to enable DEBUG logging as a shortcut for `--log_level DEBUG` ([3be0882](https://github.com/google/adk-python/commit/3be0882c63bf9b185c34bcd17e03769b39f0e1c5))
* [CLI] Add a CLI option to update an agent engine instance ([206a132](https://github.com/google/adk-python/commit/206a13271e5f1bb0bb8114b3bb82f6ec3f030cd7))
* [CLI] Modularize fast_api.py to allow simpler construction of API Server ([bfc203a](https://github.com/google/adk-python/commit/bfc203a92fdfbc4abaf776e76dca50e7ca59127b), [dfc25c1](https://github.com/google/adk-python/commit/dfc25c17a98aaad81e1e2f140db83d17cd78f393), [e176f03](https://github.com/google/adk-python/commit/e176f03e8fe13049187abd0f14e63afca9ccff01))
* [CLI] Refactor AgentLoader into base class and add InMemory impl alongside existing filesystem impl ([bda3df2](https://github.com/google/adk-python/commit/bda3df24802d0456711a5cd05544aea54a13398d))
* [CLI] Respect the .ae_ignore file when deploying to agent engine ([f29ab5d](https://github.com/google/adk-python/commit/f29ab5db0563a343d6b8b437a12557c89b7fc98b))
* [Core] Add new callbacks to handle tool and model errors ([00afaaf](https://github.com/google/adk-python/commit/00afaaf2fc18fba85709754fb1037bb47f647243))
* [Core] Add sample plugin for logging ([20537e8](https://github.com/google/adk-python/commit/20537e8bfa31220d07662dad731b4432799e1802))
* [Core] Expose Gemini RetryOptions to client ([1639298](https://github.com/google/adk-python/commit/16392984c51b02999200bd4f1d6781d5ec9054de))
* [Evals] Added an Fast API new endpoint to serve eval metric info ([c69dcf8](https://github.com/google/adk-python/commit/c69dcf87795c4fa2ad280b804c9b0bd3fa9bf06f))
* [Evals] Refactored AgentEvaluator and updated it to use LocalEvalService ([1355bd6](https://github.com/google/adk-python/commit/1355bd643ba8f7fd63bcd6a7284cc48e325d138e))


### Bug Fixes

* Add absolutize_imports option when deploying to agent engine ([fbe6a7b](https://github.com/google/adk-python/commit/fbe6a7b8d3a431a1d1400702fa534c3180741eb3))
* Add space to allow adk deploy cloud_run --a2a ([70c4616](https://github.com/google/adk-python/commit/70c461686ec2c60fcbaa384a3f1ea2528646abba))
* Copy the original function call args before passing it to callback or tools to avoid being modified ([3432b22](https://github.com/google/adk-python/commit/3432b221727b52af2682d5bf3534d533a50325ef))
* Eval module not found exception string ([7206e0a](https://github.com/google/adk-python/commit/7206e0a0eb546a66d47fb411f3fa813301c56f42))
* Fix incorrect token count mapping in telemetry ([c8f8b4a](https://github.com/google/adk-python/commit/c8f8b4a20a886a17ce29abd1cfac2858858f907d))
* Import cli's artifact dependencies directly ([282d67f](https://github.com/google/adk-python/commit/282d67f253935af56fae32428124a385f812c67d))
* Keep existing header values while merging tracking headers for `llm_request.config.http_options` in `Gemini.generate_content_async` ([6191412](https://github.com/google/adk-python/commit/6191412b07c3b5b5a58cf7714e475f63e89be847))
* Merge tracking headers even when `llm_request.config.http_options` is not set in `Gemini.generate_content_async` ([ec8dd57](https://github.com/google/adk-python/commit/ec8dd5721aa151cfc033cc3aad4733df002ae9cb))
* Restore bigquery sample agent to runnable form ([16e8419](https://github.com/google/adk-python/commit/16e8419e32b54298f782ba56827e5139effd8780))
* Return session state in list_session API endpoint ([314d6a4](https://github.com/google/adk-python/commit/314d6a4f95c6d37c7da3afbc7253570564623322))
* Runner was expecting Event object instead of Content object when using early exist feature ([bf72426](https://github.com/google/adk-python/commit/bf72426af2bfd5c2e21c410005842e48b773deb3))
* Unable to acquire impersonated credentials ([9db5d9a](https://github.com/google/adk-python/commit/9db5d9a3e87d363c1bac0f3d8e45e42bd5380d3e))
* Update `agent_card_builder` to follow grammar rules ([9c0721b](https://github.com/google/adk-python/commit/9c0721beaa526a4437671e6cc70915073be835e3)), closes [#2223](https://github.com/google/adk-python/issues/2223)
* Use correct type for actions parameter in ApplicationIntegrationToolset ([ce7253f](https://github.com/google/adk-python/commit/ce7253f63ff8e78bccc7805bd84831f08990b881))


### Documentation

* Update documents about the information of vibe coding ([0c85587](https://github.com/google/adk-python/commit/0c855877c57775ad5dad930594f9f071164676da))


## [1.8.0](https://github.com/google/adk-python/compare/v1.7.0...v1.8.0) (2025-07-23)

### Features

* [Core]Add agent card builder ([18f5bea](https://github.com/google/adk-python/commit/18f5bea411b3b76474ff31bfb2f62742825b45e5))
* [Core]Add a to_a2a util to convert adk agent to A2A ASGI application ([a77d689](https://github.com/google/adk-python/commit/a77d68964a1c6b7659d6117d57fa59e43399e0c2))
* [Core]Add camel case converter for agents ([0e173d7](https://github.com/google/adk-python/commit/0e173d736334f8c6c171b3144ac6ee5b7125c846))
* [Evals]Use LocalEvalService to run all evals in cli and web ([d1f182e](https://github.com/google/adk-python/commit/d1f182e8e68c4a5a4141592f3f6d2ceeada78887))
* [Evals]Enable FinalResponseMatchV2 metric as an experiment ([36e45cd](https://github.com/google/adk-python/commit/36e45cdab3bbfb653eee3f9ed875b59bcd525ea1))
* [Models]Add support for `model-optimizer-*` family of models in vertex ([ffe2bdb](https://github.com/google/adk-python/commit/ffe2bdbe4c2ea86cc7924eb36e8e3bb5528c0016))
* [Services]Added a sample for History Management ([67284fc](https://github.com/google/adk-python/commit/67284fc46667b8c2946762bc9234a8453d48a43c))
* [Services]Support passing fully qualified agent engine resource name when constructing session service and memory service ([2e77804](https://github.com/google/adk-python/commit/2e778049d0a675e458f4e35fe4104ca1298dbfcf))
* [Tools]Add ComputerUseToolset ([083dcb4](https://github.com/google/adk-python/commit/083dcb44650eb0e6b70219ede731f2fa78ea7d28))
* [Tools]Allow toolset to process llm_request before tools returned by it ([3643b4a](https://github.com/google/adk-python/commit/3643b4ae196fd9e38e52d5dc9d1cd43ea0733d36))
* [Tools]Support input/output schema by fully-qualified code reference ([dfee06a](https://github.com/google/adk-python/commit/dfee06ac067ea909251d6fb016f8331065d430e9))
* [Tools]Enhance LangchainTool to accept more forms of functions ([0ec69d0](https://github.com/google/adk-python/commit/0ec69d05a4016adb72abf9c94f2e9ff4bdd1848c))

### Bug Fixes

* **Attention**: Logging level for some API requests and responses was moved from `INFO` to `DEBUG` ([ff31f57](https://github.com/google/adk-python/commit/ff31f57dc95149f8f309f83f2ec983ef40f1122c))
  * Please set `--log_level=DEBUG`, if you are interested in having those API request and responses in logs.
* Add buffer to the write file option ([f2caf2e](https://github.com/google/adk-python/commit/f2caf2eecaf0336495fb42a2166b1b79e57d82d8))
* Allow current sub-agent to finish execution before exiting the loop agent due to a sub-agent's escalation. ([2aab1cf](https://github.com/google/adk-python/commit/2aab1cf98e1d0e8454764b549fac21475a633409))
* Check that `mean_score` is a valid float value ([65cb6d6](https://github.com/google/adk-python/commit/65cb6d6bf3278e6c3529938a7b932e3ef6d6c2ae))
* Handle non-json-serializable values in the `execute_sql` tool ([13ff009](https://github.com/google/adk-python/commit/13ff009d34836a80f107cb43a632df15f7c215e4))
* Raise `NotFoundError` in `list_eval_sets` function when app_name doesn't exist ([b17d8b6](https://github.com/google/adk-python/commit/b17d8b6e362a5b2a1b6a2dd0cff5e27a71c27925))
* Fixed serialization of tools with nested schema ([53df35e](https://github.com/google/adk-python/commit/53df35ee58599e9816bd4b9c42ff48457505e599))
* Set response schema for function tools that returns `None` ([33ac838](https://github.com/google/adk-python/commit/33ac8380adfff46ed8a7d518ae6f27345027c074))
* Support path level parameters for open_api_spec_parser ([6f01660](https://github.com/google/adk-python/commit/6f016609e889bb0947877f478de0c5729cfcd0c3))
* Use correct type for actions parameter in ApplicationIntegrationToolset ([ce7253f](https://github.com/google/adk-python/commit/ce7253f63ff8e78bccc7805bd84831f08990b881))
* Use the same word extractor for query and event contents in InMemoryMemoryService ([1c4c887](https://github.com/google/adk-python/commit/1c4c887bec9326aad2593f016540160d95d03f33))

### Documentation

* Fix missing toolbox-core dependency and improve installation guide ([2486349](https://github.com/google/adk-python/commit/24863492689f36e3c7370be40486555801858bac))


## 1.7.0 (2025-07-16)

### Features

* Add ability to send state change with message [3f9f773](https://github.com/google/adk-python/commit/3f9f773d9b5fcca343e32f76f6d5677b7cf4c327)
* [Eval] Support for persisting eval run results [bab3be2](https://github.com/google/adk-python/commit/bab3be2cf31dc9afd00bcce70103bdaa5460f1a3)
* Introduce [Plugin]: Plugin is simply a class that packages these individual callback functions together for a broader purpose[162228d](https://github.com/google/adk-python/commit/162228d208dca39550a75221030edf9876bf8e3a)

### Bug Fixes

* Create correct object for image and video content in litellm [bf7745f](https://github.com/google/adk-python/commit/bf7745f42811de3c9c80ec0998001ae50960dafc)
*  Support project-based gemini model path for BuiltInCodeExecutor and all built-in tools [a5d6f1e](https://github.com/google/adk-python/commit/a5d6f1e52ee36d84f94693086f74e4ca2d0bed65)
*  Add instruction in long running tool description to avoid being invoked again by model [62a6119](https://github.com/google/adk-python/commit/62a611956f8907e0580955adb23dfb6d7799bf4f)
*  [A2A] Import A2A well known path from A2A sdk [a6716a5](https://github.com/google/adk-python/commit/a6716a55140f63834ae4e3507b38786da9fdbee2)
*  Fix the long running function response event merge logic [134ec0d](https://github.com/google/adk-python/commit/134ec0d71e8de4cf9bcbe370c7e739e7ada123f3)
*  [A2A] Return final task result in task artifact instead of status message [a8fcc1b](https://github.com/google/adk-python/commit/a8fcc1b8ab0d47eccf6612a6eb8be021bff5ed3a)
* Make InMemoryMemoryService thread-safe [10197db](https://github.com/google/adk-python/commit/10197db0d752defc5976d1f276c7b5405a94c75b)

### Improvements

* Improve partial event handling and streaming aggregation [584c8c6](https://github.com/google/adk-python/commit/584c8c6d91308e62285c94629f020f2746e88f6f)

### Documentation

* Update agent transfer related doc string and comments [b1fa383](https://github.com/google/adk-python/commit/b1fa383e739d923399b3a23ca10435c0fba3460b)
* Update doc string for GcsArtifactService [498ce90](https://github.com/google/adk-python/commit/498ce906dd9b323b6277bc8118e1bcc68c38c1b5)

## [1.6.1](https://github.com/google/adk-python/compare/v1.5.0...v1.6.1) (2025-07-09)

### Features

* Add A2A support as experimental features [f0183a9](https://github.com/google/adk-python/commit/f0183a9b98b0bcf8aab4f948f467cef204ddc9d6)
  * Install google-adk with a2a extra: pip install google-adk[a2a]
  * Users can serve agents as A2A agent with `--a2a` option for `adk web` and
    `adk api_server`
  * Users can run a remote A2A agent with `RemoteA2AAgent` class
  * Three A2A agent samples are added:
    * contributing/samples/a2a_basic
    * contributing/samples/a2a_auth
    * contributing/samples/a2a_human_in_loop

* Support agent hot reload.[e545e5a](https://github.com/google/adk-python/commit/e545e5a570c1331d2ed8fda31c7244b5e0f71584)
  Users can add `--reload_agents` flag to `adk web` and `adk api_server` command
  to reload agents automatically when new changes are detected.

* Eval features
  * Implement auto rater-based evaluator for responses [75699fb](https://github.com/google/adk-python/commit/75699fbeca06f99c6f2415938da73bb423ec9b9b)
  * Add Safety evaluator metric [0bd05df](https://github.com/google/adk-python/commit/0bd05df471a440159a44b5864be4740b0f1565f9)
  * Add BaseEvalService declaration and surrounding data models [b0d88bf](https://github.com/google/adk-python/commit/b0d88bf17242e738bcd409b3d106deed8ce4d407)

* Minor features
  * Add `custom_metadata` to VertexAiSessionService when adding events [a021222](https://github.com/google/adk-python/commit/a02122207734cabb26f7c23e84d2336c4b8b0375)
  * Support protected write in BigQuery `execute_sql` tool [dc43d51](https://github.com/google/adk-python/commit/dc43d518c90b44932b3fdedd33fca9e6c87704e2)
  * Added clone() method to BaseAgent to allow users to create copies of an agent [d263afd] (https://github.com/google/adk-python/commit/d263afd91ba4a3444e5321c0e1801c499dec4c68)

### Bug Fixes

* Support project-based gemini model path to use enterprise_web_search_tool [e33161b](https://github.com/google/adk-python/commit/e33161b4f8650e8bcb36c650c4e2d1fe79ae2526)
* Use inspect.signature() instead of typing.get_type_hints for examining function signatures[4ca77bc](https://github.com/google/adk-python/commit/4ca77bc056daa575621a80d3c8d5014b78209233)
* Replace Event ID generation with UUID4 to prevent SQLite integrity constraint failures [e437c7a](https://github.com/google/adk-python/commit/e437c7aac650ac6a53fcfa71bd740e3e5ec0f230)
* Remove duplicate options from `adk deploy` [3fa2ea7](https://github.com/google/adk-python/commit/3fa2ea7cb923c9f8606d98b45a23bd58a7027436)
* Fix scenario where a user can access another users events given the same session id [362fb3f](https://github.com/google/adk-python/commit/362fb3f2b7ac4ad15852d00ce4f3935249d097f6)
* Handle unexpected 'parameters' argument in FunctionTool.run_async [0959b06](https://github.com/google/adk-python/commit/0959b06dbdf3037fe4121f12b6d25edca8fb9afc)
* Make sure each partial event has different timestamp [17d6042](https://github.com/google/adk-python/commit/17d604299505c448fcb55268f0cbaeb6c4fa314a)
* Avoid pydantic.ValidationError when the model stream returns empty final chunk [9b75e24](https://github.com/google/adk-python/commit/9b75e24d8c01878c153fec26ccfea4490417d23b)
* Fix google_search_tool.py to support updated Gemini LIVE model naming [77b869f](https://github.com/google/adk-python/commit/77b869f5e35a66682cba35563824fd23a9028d7c)
* Adding detailed information on each metric evaluation [04de3e1](https://github.com/google/adk-python/commit/04de3e197d7a57935488eb7bfa647c7ab62cd9d9)
* Converts litellm generate config err [3901fad](https://github.com/google/adk-python/commit/3901fade71486a1e9677fe74a120c3f08efe9d9e)
* Save output in state via output_key only when the event is authored by current agent [20279d9](https://github.com/google/adk-python/commit/20279d9a50ac051359d791dea77865c17c0bbf9e)
* Treat SQLite database update time as UTC for session's last update time [3f621ae](https://github.com/google/adk-python/commit/3f621ae6f2a5fac7f992d3d833a5311b4d4e7091)
* Raise ValueError when sessionId and userId are incorrect combination(#1653) [4e765ae](https://github.com/google/adk-python/commit/4e765ae2f3821318e581c26a52e11d392aaf72a4)
* Support API-Key for MCP Tool authentication [045aea9](https://github.com/google/adk-python/commit/045aea9b15ad0190a960f064d6e1e1fc7f964c69)
* Lock LangGraph version to <= 0.4.10 [9029b8a](https://github.com/google/adk-python/commit/9029b8a66e9d5e0d29d9a6df0e5590cc7c0e9038)
* Update the retry logic of create session polling [3d2f13c](https://github.com/google/adk-python/commit/3d2f13cecd3fef5adfa1c98bf23d7b68ff355f4d)

### Chores

* Extract mcp client creation logic to a separate method [45d60a1](https://github.com/google/adk-python/commit/45d60a1906bfe7c43df376a829377e2112ea3d17)
* Add tests for live streaming configs [bf39c00](https://github.com/google/adk-python/commit/bf39c006102ef3f01e762e7bb744596a4589f171)
* Update ResponseEvaluator to use newer version of Eval SDK [62c4a85](https://github.com/google/adk-python/commit/62c4a8591780a9a3fdb03a0de11092d84118a1b9)
* Add util to build our llms.txt and llms-full.txt files [a903c54](https://github.com/google/adk-python/commit/a903c54bacfcb150dc315bec9c67bf7ce9551c07)
* Create an example for multi agent live streaming [a58cc3d](https://github.com/google/adk-python/commit/a58cc3d882e59358553e8ea16d166b1ab6d3aa71)
* Refactor the ADK Triaging Agent to make the code easier to read [b6c7b5b](https://github.com/google/adk-python/commit/b6c7b5b64fcd2e83ed43f7b96ea43791733955d8)


### Documentation

* Update the a2a example link in README.md [d0fdfb8](https://github.com/google/adk-python/commit/d0fdfb8c8e2e32801999c81de8d8ed0be3f88e76)
* Adds AGENTS.md to provide relevant project context for the Gemini CLI [37108be](https://github.com/google/adk-python/commit/37108be8557e011f321de76683835448213f8515)
* Update CONTRIBUTING.md [ffa9b36](https://github.com/google/adk-python/commit/ffa9b361db615ae365ba62c09a8f4226fb761551)
* Add adk project overview and architecture [28d0ea8](https://github.com/google/adk-python/commit/28d0ea876f2f8de952f1eccbc788e98e39f50cf5)
* Add docstring to clarify that inmemory service are not suitable for production [dc414cb](https://github.com/google/adk-python/commit/dc414cb5078326b8c582b3b9072cbda748766286)
* Update agents.md to include versioning strategy [6a39c85](https://github.com/google/adk-python/commit/6a39c854e032bda3bc15f0e4fe159b41cf2f474b)
* Add tenacity into project.toml [df141db](https://github.com/google/adk-python/commit/df141db60c1137a6bcddd6d46aad3dc506868543)
* Updating CONTRIBUTING.md with missing extra [e153d07](https://github.com/google/adk-python/commit/e153d075939fb628a7dc42b12e1b3461842db541)

## [1.5.0](https://github.com/google/adk-python/compare/v1.4.2...v1.5.0) (2025-06-25)


### Features

* Add a new option `eval_storage_uri` in adk web & adk eval to specify GCS bucket to store eval data ([fa025d7](https://github.com/google/adk-python/commit/fa025d755978e1506fa0da1fecc49775bebc1045))
* Add ADK examples for litellm with add_function_to_prompt ([f33e090](https://github.com/google/adk-python/commit/f33e0903b21b752168db3006dd034d7d43f7e84d))
* Add implementation of VertexAiMemoryBankService and support in FastAPI endpoint ([abc89d2](https://github.com/google/adk-python/commit/abc89d2c811ba00805f81b27a3a07d56bdf55a0b))
* Add rouge_score library to ADK eval dependencies, and implement RougeEvaluator that is computes ROUGE-1 for "response_match_score" metric ([9597a44](https://github.com/google/adk-python/commit/9597a446fdec63ad9e4c2692d6966b14f80ff8e2))
* Add usage span attributes to telemetry ([#356](https://github.com/google/adk-python/issues/356)) ([ea69c90](https://github.com/google/adk-python/commit/ea69c9093a16489afdf72657136c96f61c69cafd))
* Add Vertex Express mode compatibility for VertexAiSessionService ([00cc8cd](https://github.com/google/adk-python/commit/00cc8cd6433fc45ecfc2dbaa04dbbc1a81213b4d))


### Bug Fixes

* Include current turn context when include_contents='none' ([9e473e0](https://github.com/google/adk-python/commit/9e473e0abdded24e710fd857782356c15d04b515))
* Make LiteLLM streaming truly asynchronous ([bd67e84](https://github.com/google/adk-python/commit/bd67e8480f6e8b4b0f8c22b94f15a8cda1336339))
* Make raw_auth_credential and exchanged_auth_credential optional given their default value is None ([acbdca0](https://github.com/google/adk-python/commit/acbdca0d8400e292ba5525931175e0d6feab15f1))
* Minor typo fix in the agent instruction ([ef3c745](https://github.com/google/adk-python/commit/ef3c745d655538ebd1ed735671be615f842341a8))
* Typo fix in sample agent instruction ([ef3c745](https://github.com/google/adk-python/commit/ef3c745d655538ebd1ed735671be615f842341a8))
* Update contributing links ([a1e1441](https://github.com/google/adk-python/commit/a1e14411159fd9f3e114e15b39b4949d0fd6ecb1))
* Use starred tuple unpacking on GCS artifact blob names ([3b1d9a8](https://github.com/google/adk-python/commit/3b1d9a8a3e631ca2d86d30f09640497f1728986c))


### Chore

* Do not send api request when session does not have events ([88a4402](https://github.com/google/adk-python/commit/88a4402d142672171d0a8ceae74671f47fa14289))
* Leverage official uv action for install([09f1269](https://github.com/google/adk-python/commit/09f1269bf7fa46ab4b9324e7f92b4f70ffc923e5))
* Update google-genai package and related deps to latest([ed7a21e](https://github.com/google/adk-python/commit/ed7a21e1890466fcdf04f7025775305dc71f603d))
* Add credential service backed by session state([29cd183](https://github.com/google/adk-python/commit/29cd183aa1b47dc4f5d8afe22f410f8546634abc))
* Clarify the behavior of Event.invocation_id([f033e40](https://github.com/google/adk-python/commit/f033e405c10ff8d86550d1419a9d63c0099182f9))
* Send user message to the agent that returned a corresponding function call if user message is a function response([7c670f6](https://github.com/google/adk-python/commit/7c670f638bc17374ceb08740bdd057e55c9c2e12))
* Add request converter to convert a2a request to ADK request([fb13963](https://github.com/google/adk-python/commit/fb13963deda0ff0650ac27771711ea0411474bf5))
* Support allow_origins in cloud_run deployment ([2fd8feb](https://github.com/google/adk-python/commit/2fd8feb65d6ae59732fb3ec0652d5650f47132cc))

## [1.4.2](https://github.com/google/adk-python/compare/v1.4.1...v1.4.2) (2025-06-20)


### Bug Fixes

* Add type checking to handle different response type of genai API client ([4d72d31](https://github.com/google/adk-python/commit/4d72d31b13f352245baa72b78502206dcbe25406))
  * This fixes the broken VertexAiSessionService
* Allow more credentials types for BigQuery tools ([2f716ad](https://github.com/google/adk-python/commit/2f716ada7fbcf8e03ff5ae16ce26a80ca6fd7bf6))

## [1.4.1](https://github.com/google/adk-python/compare/v1.3.0...v1.4.1) (2025-06-18)


### Features

* Add Authenticated Tool (Experimental) ([dcea776](https://github.com/google/adk-python/commit/dcea7767c67c7edfb694304df32dca10b74c9a71))
* Add enable_affective_dialog and proactivity to run_config and llm_request ([fe1d5aa](https://github.com/google/adk-python/commit/fe1d5aa439cc56b89d248a52556c0a9b4cbd15e4))
* Add import session API in the fast API ([233fd20](https://github.com/google/adk-python/commit/233fd2024346abd7f89a16c444de0cf26da5c1a1))
* Add integration tests for litellm with and without turning on add_function_to_prompt ([8e28587](https://github.com/google/adk-python/commit/8e285874da7f5188ea228eb4d7262dbb33b1ae6f))
* Allow data_store_specs pass into ADK VAIS built-in tool ([675faef](https://github.com/google/adk-python/commit/675faefc670b5cd41991939fe0fc604df331111a))
* Enable MCP Tool Auth (Experimental) ([157d9be](https://github.com/google/adk-python/commit/157d9be88d92f22320604832e5a334a6eb81e4af))
* Implement GcsEvalSetResultsManager to handle storage of eval sets on GCS, and refactor eval set results manager ([0a5cf45](https://github.com/google/adk-python/commit/0a5cf45a75aca7b0322136b65ca5504a0c3c7362))
* Re-factor some eval sets manager logic, and implement GcsEvalSetsManager to handle storage of eval sets on GCS ([1551bd4](https://github.com/google/adk-python/commit/1551bd4f4d7042fffb497d9308b05f92d45d818f))
* Support real time input config ([d22920b](https://github.com/google/adk-python/commit/d22920bd7f827461afd649601326b0c58aea6716))
* Support refresh access token automatically for rest_api_tool ([1779801](https://github.com/google/adk-python/commit/177980106b2f7be9a8c0a02f395ff0f85faa0c5a))

### Bug Fixes

* Fix Agent generate config err ([#1305](https://github.com/google/adk-python/issues/1305)) ([badbcbd](https://github.com/google/adk-python/commit/badbcbd7a464e6b323cf3164d2bcd4e27cbc057f))
* Fix Agent generate config error ([#1450](https://github.com/google/adk-python/issues/1450)) ([694b712](https://github.com/google/adk-python/commit/694b71256c631d44bb4c4488279ea91d82f43e26))
* Fix liteLLM test failures ([fef8778](https://github.com/google/adk-python/commit/fef87784297b806914de307f48c51d83f977298f))
* Fix tracing for live ([58e07ca](https://github.com/google/adk-python/commit/58e07cae83048d5213d822be5197a96be9ce2950))
* Merge custom http options with adk specific http options in model api request ([4ccda99](https://github.com/google/adk-python/commit/4ccda99e8ec7aa715399b4b83c3f101c299a95e8))
* Remove unnecessary double quote on Claude docstring ([bbceb4f](https://github.com/google/adk-python/commit/bbceb4f2e89f720533b99cf356c532024a120dc4))
* Set explicit project in the BigQuery client ([6d174eb](https://github.com/google/adk-python/commit/6d174eba305a51fcf2122c0fd481378752d690ef))
* Support streaming in litellm + adk and add corresponding integration tests ([aafa80b](https://github.com/google/adk-python/commit/aafa80bd85a49fb1c1a255ac797587cffd3fa567))
* Support project-based gemini model path to use google_search_tool ([b2fc774](https://github.com/google/adk-python/commit/b2fc7740b363a4e33ec99c7377f396f5cee40b5a))
* Update conversion between Celsius and Fahrenheit ([1ae176a](https://github.com/google/adk-python/commit/1ae176ad2fa2b691714ac979aec21f1cf7d35e45))

### Chores

* Set `agent_engine_id` in the VertexAiSessionService constructor, also use the `agent_engine_id` field instead of overriding `app_name` in FastAPI endpoint ([fc65873](https://github.com/google/adk-python/commit/fc65873d7c31be607f6cd6690f142a031631582a))



## [1.3.0](https://github.com/google/adk-python/compare/v1.2.1...v1.3.0) (2025-06-11)


### Features

* Add memory_service option to CLI ([416dc6f](https://github.com/google/adk-python/commit/416dc6feed26e55586d28f8c5132b31413834c88))
* Add support for display_name and description when deploying to agent engine ([aaf1f9b](https://github.com/google/adk-python/commit/aaf1f9b930d12657bfc9b9d0abd8e2248c1fc469))
* Dev UI: Trace View
  * New trace tab which contains all traces grouped by user messages
  * Click each row will open corresponding event details
  * Hover each row will highlight the corresponding message in dialog
* Dev UI: Evaluation
  * Evaluation Configuration: users can now configure custom threshold for the metrics used for each eval run ([d1b0587](https://github.com/google/adk-python/commit/d1b058707eed72fd4987d8ec8f3b47941a9f7d64))
  * Each eval case added can now be viewed and edited. Right now we only support edit of text.
  * Show the used metric in evaluation history ([6ed6351](https://github.com/google/adk-python/commit/6ed635190c86d5b2ba0409064cf7bcd797fd08da))
* Tool enhancements:
  * Add url_context_tool ([fe1de7b](https://github.com/google/adk-python/commit/fe1de7b10326a38e0d5943d7002ac7889c161826))
  * Support to customize timeout for mcpstdio connections ([54367dc](https://github.com/google/adk-python/commit/54367dcc567a2b00e80368ea753a4fc0550e5b57))
  * Introduce write protected mode to BigQuery tools ([6c999ca](https://github.com/google/adk-python/commit/6c999caa41dca3a6ec146ea42b0a794b14238ec2))



### Bug Fixes

* Agent Engine deployment:
  * Correct help text formatting for `adk deploy agent_engine` ([13f98c3](https://github.com/google/adk-python/commit/13f98c396a2fa21747e455bb5eed503a553b5b22))
  * Handle project and location in the .env properly when deploying to Agent Engine ([0c40542](https://github.com/google/adk-python/commit/0c4054200fd50041f0dce4b1c8e56292b99a8ea8))
* Fix broken agent graphs ([3b1f2ae](https://github.com/google/adk-python/commit/3b1f2ae9bfdb632b52e6460fc5b7c9e04748bd50))
* Forward `__annotations__` to the fake func for FunctionTool inspection ([9abb841](https://github.com/google/adk-python/commit/9abb8414da1055ab2f130194b986803779cd5cc5))
* Handle the case when agent loading error doesn't have msg attribute in agent loader ([c224626](https://github.com/google/adk-python/commit/c224626ae189d02e5c410959b3631f6bd4d4d5c1))
* Prevent agent_graph.py throwing when workflow agent is root agent ([4b1c218](https://github.com/google/adk-python/commit/4b1c218cbe69f7fb309b5a223aa2487b7c196038))
* Remove display_name for non-Vertex file uploads ([cf5d701](https://github.com/google/adk-python/commit/cf5d7016a0a6ccf2b522df6f2d608774803b6be4))


### Documentation

* Add DeepWiki badge to README ([f38c08b](https://github.com/google/adk-python/commit/f38c08b3057b081859178d44fa2832bed46561a9))
* Update code example in tool declaration to reflect BigQuery artifact description ([3ae6ce1](https://github.com/google/adk-python/commit/3ae6ce10bc5a120c48d84045328c5d78f6eb85d4))


## [1.2.1](https://github.com/google/adk-python/compare/v1.2.0...v1.2.1) (2025-06-04)


### Bug Fixes

* Import deprecated from typing_extensions ([068df04](https://github.com/google/adk-python/commit/068df04bcef694725dd36e09f4476b5e67f1b456))


## [1.2.0](https://github.com/google/adk-python/compare/v1.1.1...v1.2.0) (2025-06-04)


### Features

* Add agent engine as a deployment option to the ADK CLI ([2409c3e](https://github.com/google/adk-python/commit/2409c3ef192262c80f5328121f6dc4f34265f5cf))
* Add an option to use gcs artifact service in adk web. ([8d36dbd](https://github.com/google/adk-python/commit/8d36dbda520b1c0dec148e1e1d84e36ddcb9cb95))
* Add index tracking to handle parallel tool call using litellm ([05f4834](https://github.com/google/adk-python/commit/05f4834759c9b1f0c0af9d89adb7b81ea67d82c8))
* Add sortByColumn functionality to List Operation ([af95dd2](https://github.com/google/adk-python/commit/af95dd29325865ec30a1945b98e65e457760e003))
* Add implementation for  `get_eval_case`, `update_eval_case` and `delete_eval_case` for the local eval sets manager. ([a7575e0](https://github.com/google/adk-python/commit/a7575e078a564af6db3f42f650e94ebc4f338918))
* Expose more config of VertexAiSearchTool from latest Google GenAI SDK ([2b5c89b](https://github.com/google/adk-python/commit/2b5c89b3a94e82ea4a40363ea8de33d9473d7cf0))
* New Agent Visualization ([da4bc0e](https://github.com/google/adk-python/commit/da4bc0efc0dd96096724559008205854e97c3fd1))
* Set the max width and height of view image dialog to be 90% ([98a635a](https://github.com/google/adk-python/commit/98a635afee399f64e0a813d681cd8521fbb49500))
* Support Langchain StructuredTool for Langchain tool ([7e637d3](https://github.com/google/adk-python/commit/7e637d3fa05ca3e43a937e7158008d2b146b1b81))
* Support Langchain tools that has run_manager in _run args and don't have args_schema populated ([3616bb5](https://github.com/google/adk-python/commit/3616bb5fc4da90e79eb89039fb5e302d6a0a14ec))
* Update for anthropic models ([16f7d98](https://github.com/google/adk-python/commit/16f7d98acf039f21ec8a99f19eabf0ef4cb5268c))
* Use bigquery scope by default in bigquery credentials. ([ba5b80d](https://github.com/google/adk-python/commit/ba5b80d5d774ff5fdb61bd43b7849057da2b4edf))
* Add jira_agent adk samples code which connect Jira cloud ([8759a25](https://github.com/google/adk-python/commit/8759a2525170edb2f4be44236fa646a93ba863e6))
* Render HTML artifact in chat window ([5c2ad32](https://github.com/google/adk-python/commit/5c2ad327bf4262257c3bc91010c3f8c303d3a5f5))
* Add export to json button in the chat window ([fc3e374](https://github.com/google/adk-python/commit/fc3e374c86c4de87b4935ee9c56b6259f00e8ea2))
* Add tooltip to the export session button ([2735942](https://github.com/google/adk-python/commit/273594215efe9dbed44d4ef85e6234bd7ba7b7ae))


### Bug Fixes

* Add adk icon for UI ([2623c71](https://github.com/google/adk-python/commit/2623c710868d832b6d5119f38e22d82adb3de66b))
* Add cache_ok option to remove sa warning. ([841e10a](https://github.com/google/adk-python/commit/841e10ae353e0b1b3d020a26d6cac6f37981550e))
* Add support for running python main function in UnsafeLocalCodeExecutor when the code has an if __name__ == "__main__" statement. ([95e33ba](https://github.com/google/adk-python/commit/95e33baf57e9c267a758e08108cde76adf8af69b))
* Adk web not working on some env for windows, fixes https://github.com/google/adk-web/issues/34 ([daac8ce](https://github.com/google/adk-python/commit/daac8cedfe6d894f77ea52784f0a6d19003b2c00))
* Assign empty inputSchema to MCP tool when converting an ADK tool that wraps a function which takes no parameters. ([2a65c41](https://github.com/google/adk-python/commit/2a65c4118bb2aa97f2a13064db884bd63c14a5f7))
* Call all tools in parallel calls during partial authentication ([0e72efb](https://github.com/google/adk-python/commit/0e72efb4398ce6a5d782bcdcb770b2473eb5af2e))
* Continue fetching events if there are multiple pages. ([6506302](https://github.com/google/adk-python/commit/65063023a5a7cb6cd5db43db14a411213dc8acf5))
* Do not convert "false" value to dict ([60ceea7](https://github.com/google/adk-python/commit/60ceea72bde2143eb102c60cf33b365e1ab07d8f))
* Enhance agent loader exception handler and expose precise error information ([7b51ae9](https://github.com/google/adk-python/commit/7b51ae97245f6990c089183734aad41fe59b3330))
* Ensure function description is copied when ignoring parameters ([7fdc6b4](https://github.com/google/adk-python/commit/7fdc6b4417e5cf0fbc72d3117531914353d3984a))
* Filter memory by app_name and user_id. ([db4bc98](https://github.com/google/adk-python/commit/db4bc9809c7bb6b0d261973ca7cfd87b392694be))
* Fix filtering by user_id for vertex ai session service listing ([9d4ca4e](https://github.com/google/adk-python/commit/9d4ca4ed44cf10bc87f577873faa49af469acc25))
* fix parameter schema generation for gemini ([5a67a94](https://github.com/google/adk-python/commit/5a67a946d2168b80dd6eba008218468c2db2e74e))
* Handle non-indexed function call chunks with incremental fallback index ([b181cbc](https://github.com/google/adk-python/commit/b181cbc8bc629d1c9bfd50054e47a0a1b04f7410))
* Handles function tool parsing corner case where type hints are stored as strings. ([a8a2074](https://github.com/google/adk-python/commit/a8a20743f92cd63c3d287a3d503c1913dd5ad5ae))
* Introduce PreciseTimestamp to fix mysql datetime precision issue. ([841e10a](https://github.com/google/adk-python/commit/841e10ae353e0b1b3d020a26d6cac6f37981550e))
* match arg case in errors ([b226a06](https://github.com/google/adk-python/commit/b226a06c0bf798f85a53c591ad12ee582703af6d))
* ParallelAgent should only append to its immediate sub-agent, not transitive descendants ([ec8bc73](https://github.com/google/adk-python/commit/ec8bc7387c84c3f261c44cedfe76eb1f702e7b17))
* Relax openapi spec to gemini schema conversion to tolerate more cases ([b1a74d0](https://github.com/google/adk-python/commit/b1a74d099fae44d41750b79e58455282d919dd78))
* Remove labels from config when using API key from Google AI Studio to call model ([5d29716](https://github.com/google/adk-python/commit/5d297169d08a2d0ea1a07641da2ac39fa46b68a4))
* **sample:** Correct text artifact saving in artifact_save_text sample ([5c6001d](https://github.com/google/adk-python/commit/5c6001d90fe6e1d15a2db6b30ecf9e7b6c26eee4))
* Separate thinking from text parts in streaming mode ([795605a](https://github.com/google/adk-python/commit/795605a37e1141e37d86c9b3fa484a3a03e7e9a6))
* Simplify content for ollama provider ([eaee49b](https://github.com/google/adk-python/commit/eaee49bc897c20231ecacde6855cccfa5e80d849))
* Timeout issues for mcpstdio server when mcp tools are incorrect. ([45ef668](https://github.com/google/adk-python/commit/45ef6684352e3c8082958bece8610df60048f4a3))
* **transfer_to_agent:** update docstring for clarity and accuracy ([854a544](https://github.com/google/adk-python/commit/854a5440614590c2a3466cf652688ba57d637205))
* Update unit test code for test_connection ([b0403b2](https://github.com/google/adk-python/commit/b0403b2d98b2776d15475f6b525409670e2841fc))
* Use inspect.cleandoc on function docstrings in generate_function_declaration. ([f7cb666](https://github.com/google/adk-python/commit/f7cb66620be843b8d9f3d197d6e8988e9ee0dfca))
* Restore errors path ([32c5ffa](https://github.com/google/adk-python/commit/32c5ffa8ca5e037f41ff345f9eecf5b26f926ea1))
* Unused import for deprecated ([ccd05e0](https://github.com/google/adk-python/commit/ccd05e0b00d0327186e3b1156f1b0216293efe21))
* Prevent JSON parsing errors and preserve non-ascii characters in telemetry ([d587270](https://github.com/google/adk-python/commit/d587270327a8de9f33b3268de5811ac756959850))
* Raise HTTPException when running evals in fast_api if google-adk[eval] is not installed ([1de5c34](https://github.com/google/adk-python/commit/1de5c340d8da1cedee223f6f5a8c90070a9f0298))
* Fix typos in README for sample bigquery_agent and oauth_calendar_agent ([9bdd813](https://github.com/google/adk-python/commit/9bdd813be15935af5c5d2a6982a2391a640cab23))
* Make tool_call one span for telemetry and renamed to execute_tool ([999a7fe](https://github.com/google/adk-python/commit/999a7fe69d511b1401b295d23ab3c2f40bccdc6f))
* Use media type in chat window. Remove isArtifactImage and isArtifactAudio reference ([1452dac](https://github.com/google/adk-python/commit/1452dacfeb6b9970284e1ddeee6c4f3cb56781f8))
* Set output_schema correctly for LiteLlm ([6157db7](https://github.com/google/adk-python/commit/6157db77f2fba4a44d075b51c83bff844027a147))
* Update pending event dialog style ([1db601c](https://github.com/google/adk-python/commit/1db601c4bd90467b97a2f26fe9d90d665eb3c740))
* Remove the gap between event holder and image ([63822c3](https://github.com/google/adk-python/commit/63822c3fa8b0bdce2527bd0d909c038e2b66dd98))


### Documentation

* Adds a sample agent to illustrate state usage via `callbacks`. ([18fbe3c](https://github.com/google/adk-python/commit/18fbe3cbfc9f2af97e4b744ec0a7552331b1d8e3))
* Fix typos in documentation ([7aaf811](https://github.com/google/adk-python/commit/7aaf8116169c210ceda35c649b5b49fb65bbb740))
* Change eval_dataset to eval_dataset_file_path_or_dir ([62d7bf5](https://github.com/google/adk-python/commit/62d7bf58bb1c874caaf3c56a614500ae3b52f215))
* Fix broken link to A2A example ([0d66a78](https://github.com/google/adk-python/commit/0d66a7888b68380241b92f7de394a06df5a0cc06))
* Fix typo in envs.py ([bd588bc](https://github.com/google/adk-python/commit/bd588bce50ccd0e70b96c7291db035a327ad4d24))
* Updates CONTRIBUTING.md to refine setup process using uv. ([04e07b4](https://github.com/google/adk-python/commit/04e07b4a1451123272641a256c6af1528ea6523e))
* Create and update project documentation including README.md and CONTRIBUTING.md ([f180331](https://github.com/google/adk-python/commit/f1803312c6a046f94c23cfeaed3e8656afccf7c3))
* Rename the root agent in the example to match the example name ([94c0aca](https://github.com/google/adk-python/commit/94c0aca685f1dfa4edb44caaedc2de25cc0caa41))
* ADK: add section comment ([349a414](https://github.com/google/adk-python/commit/349a414120fbff0937966af95864bd683f063d08))


### Chore

* Miscellaneous changes ([0724a83](https://github.com/google/adk-python/commit/0724a83aa9cda00c1b228ed47a5baa7527bb4a0a), [a9dcc58](https://github.com/google/adk-python/commit/a9dcc588ad63013d063dbe37095c0d2e870142c3), [ac52eab](https://github.com/google/adk-python/commit/ac52eab88eccafa451be7584e24aea93ff15f3f3), [a0714b8](https://github.com/google/adk-python/commit/a0714b8afc55461f315ede8451b17aad18d698dd))
* Enable release-please workflow ([57d99aa](https://github.com/google/adk-python/commit/57d99aa7897fb229f41c2a08034606df1e1e6064))
* Added unit test coverage for local_eval_sets_manager.py ([174afb3](https://github.com/google/adk-python/commit/174afb3975bdc7e5f10c26f3eebb17d2efa0dd59))
* Extract common options for `adk web` and `adk api_server` ([01965bd](https://github.com/google/adk-python/commit/01965bdd74a9dbdb0ce91a924db8dee5961478b8))

## 1.1.1

### Features
* Add [BigQuery first-party tools](https://github.com/google/adk-python/commit/d6c6bb4b2489a8b7a4713e4747c30d6df0c07961).


## 1.1.0

### Features

* Extract agent loading logic from fast_api.py to a separate AgentLoader class and support more agent definition folder/file structure.
* Added audio play in web UI.
* Added input transcription support for live/streaming.
* Added support for storing eval run history locally in adk eval cli.
* Image artifacts can now be clicked directly in chat message to view.
* Left side panel can now be resized.

### Bug Fixes

* Avoid duplicating log in stderr.
* Align event filtering and ordering logic.
* Add handling for None param.annotation.
* Fixed several minor bugs regarding eval tab in web UI.

### Miscellaneous Chores

* Updates mypy config in pyproject.toml.
* Add google search agent in samples.
* Update filtered schema parameters for Gemini API.
* Adds autoformat.sh for formatting codebase.

## 1.0.0

### ⚠ BREAKING CHANGES

* Evaluation dataset schema is finalized with strong-type pydantic models.
  (previously saved eval file needs re-generation, for both adk eval cli and
  the eval tab in adk web UI).
* `BuiltInCodeExecutor` (in code_executors package) replaces
  `BuiltInCodeExecutionTool` (previously in tools package).
* All methods in services are now async, including session service, artifact
  service and memory service.
  * `list_events` and `close_session` methods are removed from session service.
* agent.py file structure with MCP tools are now easier and simpler ([now](https://github.com/google/adk-python/blob/3b5232c14f48e1d5b170f3698d91639b079722c8/contributing/samples/mcp_stdio_server_agent/agent.py#L33) vs [before](https://github.com/google/adk-python/blob/a4adb739c0d86b9ae4587547d2653d568f6567f2/contributing/samples/mcp_agent/agent.py#L41)).
  Old format is not working anymore.
* `Memory` schema and `MemoryService` is redesigned.
* Mark various class attributes as private in the classes in the `tools` package.
* Disabled session state injection if instruction provider is used.
  (so that you can have `{var_name}` in the instruction, which is required for code snippets)
* Toolbox integration is revamped: tools/toolbox_tool.py → tools/toolbox_toolset.py.
* Removes the experimental `remote_agent.py`. We'll redesign it and bring it back.

### Features

* Dev UI:
  * A brand new trace view for overall agent invocation.
  * A revamped evaluation tab and comparison view for checking eval results.
* Introduced `BaseToolset` to allow dynamically add/remove tools for agents.
  * Revamped MCPToolset with the new BaseToolset interface.
  * Revamped GoogleApiTool, GoogleApiToolset and ApplicationIntegrationToolset with the new BaseToolset interface.
  * Resigned agent.py file structure when needing MCPToolset.
  * Added ToolboxToolset.
* Redesigned strong-typed agent evaluation schema.
  * Allows users to create more cohesive eval sets.
  * Allows evals to be extended for non-text modality.
  * Allows for a structured interaction with the uber eval system.
* Redesigned Memory schema and MemoryService interfaces.
* Added token usage to LlmResponse.
* Allowed specifying `--adk_version` in `adk deploy cloud_run` cli. Default is the current version.

### Bug Fixes

* Fixed `adk deploy cloud_run` failing bug.
* Fixed logs not being printed due to `google-auth` library.

### Miscellaneous Chores

* Display full help text when adk cli receives invalid arguments.
* `adk web` now binds `127.0.0.1` by default, instead of 0.0.0.0.
* `InMemoryRunner` now takes `BaseAgent` in constructor.
* Various docstring improvements.
* Various UI tweaks.
* Various bug fixes.
* Update various contributing/samples for contributors to validate the implementation.


## 0.5.0

### ⚠ BREAKING CHANGES

* Updated artifact and memory service interface to be async. Agents that
  interact with these services through callbacks or tools will now need to
  adjust their invocation methods to be async (using await), or ensure calls
  are wrapped in an asynchronous executor like asyncio.run(). Any service that
  extends the base interface must also be updated.

### Features

* Introduced the ability to chain model callbacks.
* Added support for async agent and model callbacks.
* Added input transcription support for live/streaming.
* Captured all agent code error and display on UI.
* Set param required tag to False by default in openapi_tool.
* Updated evaluation functions to be asynchronous.

### Bug Fixes

* Ensured a unique ID is generated for every event.
* Fixed the issue when openapi_specparser has parameter.required as None.
* Updated the 'type' value on the items/properties nested structures for Anthropic models to adhere to JSON schema.
* Fix litellm error issues.

### Miscellaneous Chores

* Regenerated API docs.
* Created a `developer` folder and added samples.
* Updated the contributing guide.
* Docstring improvements, typo fixings, GitHub action to enforce code styles on formatting and imports, etc.

## 0.4.0

### ⚠ BREAKING CHANGES
* Set the max size of strings in database columns. MySQL mandates that all VARCHAR-type fields must specify their lengths.
* Extract content encode/decode logic to a shared util, resolve issues with JSON serialization, and update key length for DB table to avoid key too long issue in mysql.
* Enhance `FunctionTool` to verify if the model is providing all the mandatory arguments.

### Features
* Update ADK setup guide to improve onboarding experience.
* feat: add ordering to recent events in database session service.
* feat(llm_flows): support async before/after tool callbacks.
* feat: Added --replay and --resume options to adk run cli. Check adk run --help for more details.
* Created a new Integration Connector Tool (underlying of the ApplicationIntegrationToolSet) so that we do not force LLM to provide default value.

### Bug Fixes

* Don't send content with empty text to LLM.
* Fix google search reading undefined for `renderedContent`.

### Miscellaneous Chores
* Docstring improvements, typo fixings, github action to enforce code styles on formatting and imports, etc.

## 0.3.0

### ⚠ BREAKING CHANGES

* Auth: expose `access_token` and `refresh_token` at top level of auth
  credentials, instead of a `dict`
  ([commit](https://github.com/google/adk-python/commit/956fb912e8851b139668b1ccb8db10fd252a6990)).

### Features

* Added support for running agents with MCPToolset easily on `adk web`.
* Added `custom_metadata` field to `LlmResponse`, which can be used to tag
  LlmResponse via `after_model_callback`.
* Added `--session_db_url` to `adk deploy cloud_run` option.
* Many Dev UI improvements:
  * Better google search result rendering.
  * Show websocket close reason in Dev UI.
  * Better error message showing for audio/video.

### Bug Fixes

* Fixed MCP tool json schema parsing issue.
* Fixed issues in DatabaseSessionService that leads to crash.
* Fixed functions.py.
* Fixed `skip_summarization` behavior in `AgentTool`.

### Miscellaneous Chores

* README.md improvements.
* Various code improvements.
* Various typo fixes.
* Bump min version of google-genai to 1.11.0.

## 0.2.0

### ⚠ BREAKING CHANGES

* Fix typo in method name in `Event`: has_trailing_code_execution_result --> has_trailing_code_execution_result.

### Features

* `adk` CLI:
  * Introduce `adk create` cli tool to help creating agents.
  * Adds `--verbosity` option to `adk deploy cloud_run` to show detailed cloud
    run deploy logging.
* Improve the initialization error message for `DatabaseSessionService`.
* Lazy loading for Google 1P tools to minimize the initial latency.
* Support emitting state-change-only events from planners.
* Lots of Dev UI updates, including:
  * Show planner thoughts and actions in the Dev UI.
  * Support MCP tools in Dev UI.
    (NOTE: `agent.py` interface is temp solution and is subject to change)
  * Auto-select the only app if only one app is available.
  * Show grounding links generated by Google Search Tool.
* `.env` file is reloaded on every agent run.

### Bug Fixes

* `LiteLlm`: arg parsing error and python 3.9 compatibility.
* `DatabaseSessionService`: adds the missing fields; fixes event with empty
  content not being persisted.
* Google API Discovery response parsing issue.
* `load_memory_tool` rendering issue in Dev UI.
* Markdown text overflows in Dev UI.

### Miscellaneous Chores

* Adds unit tests in GitHub action.
* Improves test coverage.
* Various typo fixes.

## 0.1.0

### Features

* Initial release of the Agent Development Kit (ADK).
* Multi-agent, agent-as-workflow, and custom agent support
* Tool authentication support
* Rich tool support, e.g. built-in tools, google-cloud tools, third-party tools, and MCP tools
* Rich callback support
* Built-in code execution capability
* Asynchronous runtime and execution
* Session, and memory support
* Built-in evaluation support
* Development UI that makes local development easy
* Deploy to Google Cloud Run, Agent Engine
* (Experimental) Live(Bidi) audio/video agent support and Compositional Function Calling(CFC) support
