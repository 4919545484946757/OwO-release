# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio

from google.adk.agents.llm_agent import LlmAgent
from google.adk.agents.readonly_context import ReadonlyContext
from google.adk.tools.mcp_tool.mcp_session_manager import StreamableHTTPConnectionParams
from google.adk.tools.mcp_tool.mcp_toolset import McpToolset
from google.adk.utils import _mtls_utils
import google.auth
import google.auth.transport.requests

BIGQUERY_AGENT_NAME = "adk_sample_bigquery_mcp_agent"
BIGQUERY_MCP_ENDPOINT = _mtls_utils.get_api_endpoint(
    location="",
    default_template="https://bigquery.googleapis.com/mcp",
    mtls_template="https://bigquery.mtls.googleapis.com/mcp",
)
BIGQUERY_SCOPE = "https://www.googleapis.com/auth/bigquery"

# Initialize the tools to use the application default credentials.
# https://cloud.google.com/docs/authentication/provide-credentials-adc
credentials, project_id = google.auth.default(scopes=[BIGQUERY_SCOPE])
credentials.refresh(google.auth.transport.requests.Request())
oauth_token = credentials.token


async def _auth_headers(ctx: ReadonlyContext) -> dict[str, str]:
  """Returns the auth header, refreshing the access token when it expires.

  Access tokens are valid for about an hour, so a token fetched once at import
  would stop working in a long-running ``adk web`` or ``adk api_server``
  process.
  """
  if not credentials.valid:
    await asyncio.to_thread(
        credentials.refresh, google.auth.transport.requests.Request()
    )
  return {"Authorization": f"Bearer {credentials.token}"}


bigquery_mcp_toolset = McpToolset(
    connection_params=StreamableHTTPConnectionParams(
        url=BIGQUERY_MCP_ENDPOINT,
        headers={"Authorization": f"Bearer {oauth_token}"},
    ),
    header_provider=_auth_headers,
)

# The variable name `root_agent` determines what your root agent is for the
# debug CLI
root_agent = LlmAgent(
    name=BIGQUERY_AGENT_NAME,
    description=(
        "Agent to answer questions about BigQuery data and models and execute"
        " SQL queries using MCP."
    ),
    instruction="""\
        You are a data science agent with access to several BigQuery tools provided via MCP.
        Make use of those tools to answer the user's questions.
    """,
    tools=[bigquery_mcp_toolset],
)
