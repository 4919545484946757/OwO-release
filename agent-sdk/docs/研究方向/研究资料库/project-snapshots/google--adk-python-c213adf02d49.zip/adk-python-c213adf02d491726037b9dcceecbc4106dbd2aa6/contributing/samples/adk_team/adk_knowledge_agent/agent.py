# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import os
from typing import Optional

from google.adk.agents import LlmAgent
from google.adk.agents.context import Context
from google.adk.models import LlmResponse
from google.adk.tools.vertex_ai_search_tool import VertexAiSearchTool
from google.genai import types

VERTEXAI_DATASTORE_ID = os.environ.get("VERTEXAI_DATASTORE_ID")
if not VERTEXAI_DATASTORE_ID:
  raise ValueError(
      "VERTEXAI_DATASTORE_ID environment variable not set. Set it to the"
      " full resource name of your own Vertex AI Search data store, as"
      " projects/.../locations/.../collections/.../dataStores/... ."
  )


def citation_retrieval_after_model_callback(
    callback_context: Context,
    llm_response: LlmResponse,
) -> Optional[LlmResponse]:
  """Callback function to retrieve citations after model response is generated."""
  grounding_metadata = llm_response.grounding_metadata
  if not grounding_metadata:
    return None

  content = llm_response.content
  if not llm_response.content:
    return None

  parts = content.parts
  if not parts:
    return None

  # Collect the citations as JSON objects. `grounding_chunks` is optional, and
  # is absent when the metadata only carries e.g. search queries.
  citations = []
  for grounding_chunk in grounding_metadata.grounding_chunks or []:
    retrieved_context = grounding_chunk.retrieved_context
    if not retrieved_context:
      continue

    citation = {
        "title": retrieved_context.title,
        "uri": retrieved_context.uri,
        "snippet": retrieved_context.text,
    }
    citations.append(types.Part(text=json.dumps(citation)))

  if not citations:
    return None

  # Copy the response so the rest of it (role, grounding and usage metadata,
  # finish reason, ...) survives, instead of building a bare one. A content
  # without a role is treated as empty and dropped from the conversation
  # history.
  new_content = types.Content(
      role=content.role or "model",
      parts=[*parts, types.Part(text="References:\n"), *citations],
  )
  return llm_response.model_copy(update={"content": new_content})


root_agent = LlmAgent(
    name="adk_knowledge_agent",
    description=(
        "Agent for performing Vertex AI Search to find ADK knowledge and"
        " documentation"
    ),
    instruction="""You are a specialized search agent for an ADK knowledge base.

      You can use the VertexAiSearchTool to search for ADK examples and documentation in the document store.
      """,
    tools=[VertexAiSearchTool(data_store_id=VERTEXAI_DATASTORE_ID)],
    after_model_callback=citation_retrieval_after_model_callback,
)
