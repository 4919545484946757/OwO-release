# @restatedev/restate-sdk-tunnel

## 1.17.3

### Patch Changes

- Release 1.17.3

## 1.17.2

### Patch Changes

- - Allow to provide description and metadata in the new iface API

## 1.17.1

### Patch Changes

- Minor bug fixes

## 1.17.0

### Minor Changes

- Ported restate.iface to define service interfaces without depending on the SDK

## 1.16.9

### Patch Changes

- Fix HTTP/1 attempt abort timing

## 1.16.8

### Patch Changes

- Improved retry logic in ingress clients

## 1.16.7

### Patch Changes

- Improve retry logic using the new x-restate-error-source header in restate 1.7.4

## 1.16.6

### Patch Changes

- Bump shared core to 7.0.3

## 1.16.5

### Patch Changes

- Update shared core to 7.0.2

## 1.16.4

### Patch Changes

- Few minor improvements

## 1.16.3

### Patch Changes

- Add retry support to workflows

## 1.16.2

### Patch Changes

- Added scope() client to the gen sdk

## 1.16.1

### Patch Changes

- Update shared core to 7.0.1, including fix for panics on out of bound durations

## 1.16.0

### Minor Changes

- 1e3027a: Align retry-policy terminology and expose scoped virtual-object clients.
  - **restate-sdk-tunnel** (⚠️ breaking): the reconnect backoff options
    `reconnectInitialMs` / `reconnectMaxMs` / `reconnectFactor` are replaced by a
    nested `reconnectRetryPolicy: { initialInterval, maxInterval, exponentiationFactor }`,
    matching the field names used by the invocation and ingress retry policies. The
    `initialInterval` / `maxInterval` fields accept a `Duration` or a number of
    milliseconds.
  - **restate-sdk-gen** (`run` retry): added `exponentiationFactor`; the previous
    `intervalFactor` is deprecated but still honored as a fallback.
  - **restate-sdk** and **restate-sdk-clients**: scoped requests now expose
    `objectClient` / `objectSendClient` for virtual objects, so
    `ctx.scope(...)` / `ingress.scope(...)` can route calls and sends to a virtual
    object (the object key is part of the scoped identity).

## 1.15.1

### Patch Changes

- Bug fixes

## 1.15.0

### Minor Changes

- ffadd88: Bump to 1.15.0 rc.6
- 62cd16b: New package: `@restatedev/restate-sdk-tunnel` — serve a Restate SDK deployment over an **outbound** connection to Restate Cloud's tunnel, with no inbound HTTP listener. `connectTunnel({ region | tunnelServers, environmentId, authToken, signingPublicKey, tunnelName, services })` dials the tunnel server (TLS with ALPN `h2`, the same offer the standalone Rust client makes; requires a tunnel server that advertises it — standard-h2 control traffic), role-flips so Restate Cloud drives HTTP/2 as the client while the deployment serves, completes the `/_/start-tunnel` credentials/trailers handshake, and dispatches each forwarded invocation into the SDK's own endpoint handler (full-duplex `BIDI_STREAM`) after stripping the tunnel's destination path prefix.

  Request identity is enforced by delegation to the SDK: `signingPublicKey` (required) is passed to the endpoint handler, so every forwarded request's `x-restate-jwt-v1` is verified against the service-relative path your environment signed. Reconnects use jittered exponential backoff that resets only after a stable connection; authorization failures (`unauthorized`, `bad-tunnel-name`, tunnel-name mismatch) are fatal and surface on `connection.error` / `connection.ready` rather than retry-looping. Graceful drain is supported and advertised by default (`supportsDrain`): on `/_/drain-tunnel` the engine immediately dials a replacement connection while the old one keeps serving its in-flight invocations (bounded by `drainGraceMs`, default 120s) — zero dropped requests across cloud rollovers. The returned `TunnelConnection` exposes `ready`, `close()`, `connectionCount`, the handshake-learned `tunnelName` / `proxyUrl` / `tunnelUrl`, and a ready-made `deploymentUrl` — `<proxyUrl>/http/in-process/9080/` — to register with `restate dep register`. `tunnelName` is the deployment's identity: the tunnel server routes and load-balances purely by `<environment>/<tunnelName>`, so it must be unique per deployment and shared across that deployment's replicas; the `/http/in-process/9080/` destination segment is a constant that is never dialed for an in-process tunnel. Multi-homed like the standalone client: one connection per resolved tunnel server (SRV discovery — via `region` or a raw `tunnelServersSrv` name — expands every target to all of its addresses; explicit `tunnelServers` get one connection per entry), each with an independent reconnect loop, with the server set re-resolved every `resolveIntervalMs` (30s default) — servers that appear get connections, servers that vanish are torn down, and resolver blips (transport errors) keep existing connections serving rather than tearing them down.

  Configuration falls back to `RESTATE_INPROC_*` environment variables when options are omitted (option > environment > throw): `tunnelName` ← `RESTATE_INPROC_TUNNEL_NAME`, `environmentId` ← `RESTATE_INPROC_ENVIRONMENT_ID`, `region` ← `RESTATE_INPROC_CLOUD_REGION`, `signingPublicKey` ← `RESTATE_INPROC_SIGNING_PUBLIC_KEY`, and `authToken` ← the file named by `RESTATE_INPROC_AUTH_TOKEN_FILE`, which is re-read on every reconnect so rotated Secrets are picked up without a restart. These form the contract with the restate-operator's `tunnelMode: in-process`, which injects the identity variables per revision and auto-registers the matching tunnel URL — there, `connectTunnel({ services })` plus a token-file Secret mount (named by `RESTATE_INPROC_AUTH_TOKEN_FILE`) is a complete configuration.

- Bump to 1.15.0
- 59868ef: Bump to 1.15.0-rc.5

### Patch Changes

- 24b5263: 1.15.0-rc.7
- 1f850e1:

## 1.15.0-rc.7

### Patch Changes

- 1.15.0-rc.7

## 1.15.0-rc.6

### Minor Changes

- Bump to 1.15.0 rc.6

## 1.15.0-rc.5

### Minor Changes

- Bump to 1.15.0-rc.5

## 1.15.0-rc.4

### Patch Changes

-

## 1.15.0-rc.3
