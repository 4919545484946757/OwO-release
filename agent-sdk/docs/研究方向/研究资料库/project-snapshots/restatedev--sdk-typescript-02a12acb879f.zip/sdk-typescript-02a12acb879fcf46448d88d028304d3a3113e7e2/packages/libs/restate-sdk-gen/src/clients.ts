/*
 * Copyright (c) 2023-2026 - Restate Software, Inc., Restate GmbH
 *
 * This file is part of the Restate SDK for Node.js/TypeScript,
 * which is released under the MIT license.
 *
 * You can find a copy of the license in file LICENSE in the root
 * directory of this repository or package, or at
 * https://github.com/restatedev/sdk-typescript/blob/main/LICENSE
 */

import * as restate from "@restatedev/restate-sdk";
import type { Future } from "./future.js";
import type { InvocationReference } from "./invocation-reference.js";
import type { HandlerDescriptor, Descriptor } from "./define.js";
import {
  ClientCallOptions,
  ClientSendOptions,
  Opts,
  SendOpts,
} from "@restatedev/restate-sdk";

/**
 * A Future<O> that also carries an `invocation` field — a Future<InvocationReference<O>>
 * for accessing the invocationId, attach, cancel, and signal of the underlying call.
 */
export type ClientFuture<O> = Future<O> & {
  invocation: Future<InvocationReference<O>>;
};

/** Client type returned by client() — each method returns ClientFuture<O> */
export type GenClient<H extends Record<string, HandlerDescriptor>> = {
  readonly [K in keyof H]: H[K] extends HandlerDescriptor<infer I, infer O>
    ? [I] extends [void]
      ? (opts?: Opts<I, O>) => ClientFuture<O>
      : (input: I, opts?: Opts<I, O>) => ClientFuture<O>
    : never;
};

/** Client type returned by sendClient() — each method returns Future<InvocationReference<O>> */
export type GenSendClient<H extends Record<string, HandlerDescriptor>> = {
  readonly [K in keyof H]: H[K] extends HandlerDescriptor<infer I, infer O>
    ? [I] extends [void]
      ? (opts?: SendOpts<I>) => Future<InvocationReference<O>>
      : (input: I, opts?: SendOpts<I>) => Future<InvocationReference<O>>
    : never;
};

// =============================================================================
// makeClient / makeSendClient — proxy factories used by RestateOperations
// =============================================================================

/* eslint-disable @typescript-eslint/no-explicit-any */

export function makeClient<H extends Record<string, HandlerDescriptor>>(
  def: Descriptor<string, H, any>,
  key: string | undefined,
  call: (opts: restate.GenericCall<unknown, unknown>) => ClientFuture<unknown>,
  scope?: string
): GenClient<H> {
  return new Proxy({} as any, {
    get(_target, methodName: string) {
      return (...args: unknown[]) => {
        const { parameter, opts } = optsFromArgs(args);
        const callOpts = opts as ClientCallOptions<unknown, unknown>;
        const desc = def._handlers[methodName];
        const outputSerde = callOpts?.output ?? desc?._outputSerde;
        return call({
          service: def.name,
          key,
          method: String(methodName),
          parameter,
          inputSerde: (callOpts?.input ??
            desc?._inputSerde ??
            restate.serde.json) as restate.Serde<unknown>,
          outputSerde: (outputSerde ??
            restate.serde.json) as restate.Serde<unknown>,
          idempotencyKey: callOpts?.idempotencyKey,
          limitKey: callOpts?.limitKey,
          scope,
          headers: callOpts?.headers,
          name: callOpts?.name,
        });
      };
    },
  }) as GenClient<H>;
}

export function makeSendClient<H extends Record<string, HandlerDescriptor>>(
  def: Descriptor<string, H, any>,
  key: string | undefined,
  send: (
    opts: restate.GenericSend<unknown>,
    outputSerde?: restate.Serde<unknown>
  ) => Future<InvocationReference<unknown>>,
  scope?: string
): GenSendClient<H> {
  return new Proxy({} as any, {
    get(_target, methodName: string) {
      return (...args: unknown[]) => {
        const { parameter, opts } = optsFromArgs(args);
        const sendOpts = opts as ClientSendOptions<unknown>;
        const desc = def._handlers[methodName];
        return send(
          {
            service: def.name,
            key,
            method: String(methodName),
            parameter,
            inputSerde: (sendOpts?.input ??
              desc?._inputSerde ??
              restate.serde.json) as restate.Serde<unknown>,
            delay: sendOpts?.delay,
            idempotencyKey: sendOpts?.idempotencyKey,
            limitKey: sendOpts?.limitKey,
            scope,
            headers: sendOpts?.headers,
            name: sendOpts?.name,
          },
          desc?._outputSerde as restate.Serde<unknown> | undefined
        );
      };
    },
  }) as GenSendClient<H>;
}

function optsFromArgs(args: unknown[]): {
  parameter?: unknown;
  opts?:
    | ClientCallOptions<unknown, unknown>
    | ClientSendOptions<unknown>
    | undefined;
} {
  let parameter: unknown;
  let opts:
    | ClientCallOptions<unknown, unknown>
    | ClientSendOptions<unknown>
    | undefined;
  switch (args.length) {
    case 0: {
      break;
    }
    case 1: {
      if (args[0] instanceof Opts) {
        opts = args[0].getOpts();
      } else if (args[0] instanceof SendOpts) {
        opts = args[0].getOpts();
      } else {
        parameter = args[0];
      }
      break;
    }
    case 2: {
      parameter = args[0];
      if (args[1] instanceof Opts) {
        opts = args[1].getOpts();
      } else if (args[1] instanceof SendOpts) {
        opts = args[1].getOpts();
      } else {
        throw new TypeError(
          "The second argument must be either Opts or SendOpts"
        );
      }
      break;
    }
    default: {
      throw new TypeError("unexpected number of arguments");
    }
  }
  return {
    parameter,
    opts,
  };
}
