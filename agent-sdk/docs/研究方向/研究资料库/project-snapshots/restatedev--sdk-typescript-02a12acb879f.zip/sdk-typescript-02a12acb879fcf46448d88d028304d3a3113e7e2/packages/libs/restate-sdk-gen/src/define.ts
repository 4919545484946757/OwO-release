/*
 * Copyright (c) 2023-2026 - Restate Software, Inc., Restate GmbH
 *
 * This file is part of the Restate SDK for Node.js/TypeScript,
 * which is released under the MIT license.
 *
 * You can find a copy of the license in file LICENSE in the root
 * directory of this repository or package, or at
 * https://github.com/restatedev/sdk-typescript/blob/main/LICENSE
 */
/* eslint-disable @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access, @typescript-eslint/no-unsafe-argument, @typescript-eslint/no-unsafe-return, @typescript-eslint/no-unnecessary-type-assertion */

import * as restate from "@restatedev/restate-sdk";
import type { StandardSchemaV1 } from "@restatedev/restate-sdk-core";
import {
  type HandlerDescriptor,
  type Descriptor,
  type ServiceDescriptor,
  type ObjectDescriptor,
  type WorkflowDescriptor,
  type ImplementedServiceDefinition,
  type ImplementedObjectDefinition,
  type ImplementedWorkflowDefinition,
  type ImplementedDefinition,
  makeHandlerDescriptor,
  serde,
} from "@restatedev/restate-sdk-core";
import { execute } from "./restate-operations.js";
import { type Operation } from "./operation.js";
import { ServiceHandlerOpts } from "@restatedev/restate-sdk";

// =============================================================================
// Shared interface/descriptor layer — moved to @restatedev/restate-sdk-core and
// re-exported here so this package's public API is unchanged.
// =============================================================================
export type {
  HandlerDescriptor,
  Descriptor,
  ServiceDescriptor,
  ObjectDescriptor,
  WorkflowDescriptor,
  ImplementedServiceDefinition,
  ImplementedObjectDefinition,
  ImplementedWorkflowDefinition,
  ImplementedDefinition,
};

// =============================================================================
// HandlerDef — result of serdes()
// =============================================================================

/** @internal
 * @internal - Wraps a generator function with optional serde. Produced by typed().
 * Discriminated by _genFn for runtime detection (distinct from bare gen fns,
 * which are plain functions rather than objects).
 */
export type HandlerDef<I = any, O = any> = {
  readonly _genFn: (input: I) => Operation<O>;
} & HandlerDescriptor<I, O>;

/** @internal */
export type EntryToDescriptor<E> =
  E extends HandlerDef<infer I, infer O>
    ? HandlerDescriptor<I, O>
    : E extends () => Operation<infer O>
      ? HandlerDescriptor<void, O> // no-arg generator → void input
      : E extends (input: infer I) => Operation<infer O>
        ? HandlerDescriptor<I, O>
        : HandlerDescriptor;

/** Map a full handler map type to the corresponding descriptor map type */
export type HandlerDescriptors<
  H extends Record<string, HandlerOrHandlerDescriptor>,
> = {
  [K in keyof H]: EntryToDescriptor<H[K]>;
};

// =============================================================================
// Per-handler options
// =============================================================================

/** Options valid for all handler types. To set input and output serde, check {@link serdes()} */
export type GenHandlerOpts = Omit<
  ServiceHandlerOpts<unknown, unknown>,
  "input" | "output"
>;

/** Handler options for virtual object handlers */
export type GenObjectHandlerOpts = GenHandlerOpts & {
  /**
   * When true, the handler will be marked as shared.
   * Shared object handlers can only read state, not write it.
   */
  shared?: boolean;

  /**
   * When set to `true`, lazy state will be enabled for all invocations to this handler.
   *
   * *NOTE:* You can set this field only if you register this endpoint against restate-server >= 1.4,
   * otherwise the service discovery will fail.
   */
  enableLazyState?: boolean;
};

/** Handler options for workflow handlers (shared is implicit from name) */
export type GenWorkflowHandlerOpts = {
  /**
   * When set to `true`, lazy state will be enabled for all invocations to this handler.
   *
   * *NOTE:* You can set this field only if you register this endpoint against restate-server >= 1.4,
   * otherwise the service discovery will fail.
   */
  enableLazyState?: boolean;
};

// =============================================================================
// Handler entry types
// =============================================================================

/** @internal */
export type AnyGenFn = (input: any) => Operation<any>;

/** A handler entry: either a bare generator fn or the result of {@link serdes()} */
export type HandlerOrHandlerDescriptor = AnyGenFn | HandlerDef<any, any>;

// =============================================================================
// Helpers
// =============================================================================

/** HandlerDef has _genFn as an object property; bare gen fns are plain functions */
function isHandlerDef(
  entry: HandlerOrHandlerDescriptor
): entry is HandlerDef<any, any> {
  return (
    typeof entry === "object" &&
    entry !== null &&
    typeof (entry as any)._genFn === "function"
  );
}

function extractEntry(entry: HandlerOrHandlerDescriptor): {
  genFn: AnyGenFn;
  inputSerde: restate.Serde<any> | undefined;
  outputSerde: restate.Serde<any> | undefined;
} {
  if (isHandlerDef(entry)) {
    return {
      genFn: entry._genFn as AnyGenFn,
      inputSerde: entry._inputSerde,
      outputSerde: entry._outputSerde,
    };
  }
  return {
    genFn: entry as AnyGenFn,
    inputSerde: undefined,
    outputSerde: undefined,
  };
}

// =============================================================================
// Handler definition helpers — produce HandlerDef for use in service/object/workflow
// =============================================================================

/** serdes(opts, fn) — explicit Serde per field */
export function serdes<I, O>(
  opts: { input: restate.Serde<I>; output: restate.Serde<O> },
  fn: (input: I) => Operation<O>
): HandlerDef<I, O> {
  return {
    _genFn: fn as AnyGenFn,
    _inputSerde: opts.input,
    _outputSerde: opts.output,
  };
}

/** schemas(opts, fn) — Standard Schema (Zod, TypeBox, Valibot, …) per field */
export function schemas<
  SI extends StandardSchemaV1<any>,
  SO extends StandardSchemaV1<any>,
>(
  opts: { input: SI; output: SO },
  fn: (
    input: StandardSchemaV1.InferOutput<SI>
  ) => Operation<StandardSchemaV1.InferOutput<SO>>
): HandlerDef<
  StandardSchemaV1.InferOutput<SI>,
  StandardSchemaV1.InferOutput<SO>
> {
  return {
    _genFn: fn as AnyGenFn,
    _inputSerde: serde.schema(opts.input),
    _outputSerde: serde.schema(opts.output),
  };
}

// =============================================================================
// service() factory
// =============================================================================

export function service<
  P extends string,
  H extends Record<string, HandlerOrHandlerDescriptor>,
>(config: {
  name: P;
  description?: string;
  metadata?: Record<string, string>;
  handlers: H;
  options?: restate.ServiceOptions & {
    handlers?: Partial<Record<keyof H, GenHandlerOpts>>;
  };
}): ImplementedServiceDefinition<P, HandlerDescriptors<H>> {
  const { name, description, metadata, handlers, options } = config;
  const { handlers: perHandlerOpts, ...serviceOpts } = options ?? {};

  const coreHandlers: Record<string, any> = {};
  const descriptors: Record<string, HandlerDescriptor> = {};

  for (const [handlerName, entry] of Object.entries(handlers)) {
    const { genFn, inputSerde, outputSerde } = extractEntry(entry);
    const handlerOpts =
      ((perHandlerOpts as any)?.[handlerName] as GenHandlerOpts) ?? {};

    coreHandlers[handlerName] = restate.handlers.handler(
      { input: inputSerde, output: outputSerde, ...handlerOpts } as any,
      async (ctx: restate.Context, input: any) => execute(ctx, genFn(input))
    );

    descriptors[handlerName] = makeHandlerDescriptor(inputSerde, outputSerde);
  }

  const coreDef = restate.service({
    name,
    handlers: coreHandlers as any,
    description,
    metadata,
    options: serviceOpts,
  });

  return Object.assign(coreDef, {
    _kind: "service" as const,
    _handlers: descriptors,
  }) as unknown as ImplementedServiceDefinition<P, HandlerDescriptors<H>>;
}

// =============================================================================
// object() factory
// =============================================================================

export function object<
  P extends string,
  H extends Record<string, HandlerOrHandlerDescriptor>,
>(config: {
  name: P;
  description?: string;
  metadata?: Record<string, string>;
  handlers: H;
  options?: restate.ObjectOptions & {
    handlers?: Partial<Record<keyof H, GenObjectHandlerOpts>>;
  };
}): ImplementedObjectDefinition<P, HandlerDescriptors<H>> {
  const { name, description, metadata, handlers, options } = config;
  const { handlers: perHandlerOpts, ...objectOpts } = options ?? {};

  const coreHandlers: Record<string, any> = {};
  const descriptors: Record<string, HandlerDescriptor> = {};

  for (const [handlerName, entry] of Object.entries(handlers)) {
    const { genFn, inputSerde, outputSerde } = extractEntry(entry);
    const handlerOpts: GenObjectHandlerOpts =
      ((perHandlerOpts as any)?.[handlerName] as GenObjectHandlerOpts) ?? {};
    const { shared, ...restOpts } = handlerOpts;

    const sdkOpts = {
      input: inputSerde,
      output: outputSerde,
      ...restOpts,
    } as any;
    const fn = async (
      ctx: restate.ObjectContext | restate.ObjectSharedContext,
      input: any
    ) => execute(ctx as restate.Context, genFn(input));

    coreHandlers[handlerName] = shared
      ? restate.handlers.object.shared(sdkOpts, fn as any)
      : restate.handlers.object.exclusive(sdkOpts, fn as any);

    descriptors[handlerName] = makeHandlerDescriptor(inputSerde, outputSerde);
  }

  const coreDef = restate.object({
    name,
    handlers: coreHandlers as any,
    description,
    metadata,
    options: objectOpts,
  });

  return Object.assign(coreDef, {
    _kind: "object" as const,
    _handlers: descriptors,
  }) as unknown as ImplementedObjectDefinition<P, HandlerDescriptors<H>>;
}

// =============================================================================
// workflow() factory
// =============================================================================

export function workflow<
  P extends string,
  H extends Record<string, HandlerOrHandlerDescriptor>,
>(config: {
  name: P;
  description?: string;
  metadata?: Record<string, string>;
  handlers: H;
  options?: restate.WorkflowOptions & {
    handlers?: Partial<Record<keyof H, GenWorkflowHandlerOpts>>;
  };
}): ImplementedWorkflowDefinition<P, HandlerDescriptors<H>> {
  const { name, description, metadata, handlers, options } = config;
  const { handlers: perHandlerOpts, ...workflowOpts } = options ?? {};

  const coreHandlers: Record<string, any> = {};
  const descriptors: Record<string, HandlerDescriptor> = {};

  for (const [handlerName, entry] of Object.entries(handlers)) {
    const { genFn, inputSerde, outputSerde } = extractEntry(entry);
    const handlerOpts =
      ((perHandlerOpts as any)?.[handlerName] as GenWorkflowHandlerOpts) ?? {};

    const sdkOpts = {
      input: inputSerde,
      output: outputSerde,
      ...handlerOpts,
    } as any;
    const fn = async (
      ctx: restate.WorkflowContext | restate.WorkflowSharedContext,
      input: any
    ) => execute(ctx as restate.Context, genFn(input));

    coreHandlers[handlerName] =
      handlerName === "run"
        ? restate.handlers.workflow.workflow(sdkOpts, fn as any)
        : restate.handlers.workflow.shared(sdkOpts, fn as any);

    descriptors[handlerName] = makeHandlerDescriptor(inputSerde, outputSerde);
  }

  const coreDef = restate.workflow({
    name,
    handlers: coreHandlers as any,
    description,
    metadata,
    options: workflowOpts,
  });

  return Object.assign(coreDef, {
    _kind: "workflow" as const,
    _handlers: descriptors,
  }) as unknown as ImplementedWorkflowDefinition<P, HandlerDescriptors<H>>;
}
