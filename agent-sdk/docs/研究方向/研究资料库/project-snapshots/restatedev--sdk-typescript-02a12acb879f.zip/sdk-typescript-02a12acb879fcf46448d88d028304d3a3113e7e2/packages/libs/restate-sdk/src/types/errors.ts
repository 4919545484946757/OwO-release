/*
 * Copyright (c) 2023-2024 - Restate Software, Inc., Restate GmbH
 *
 * This file is part of the Restate SDK for Node.js/TypeScript,
 * which is released under the MIT license.
 *
 * You can find a copy of the license in file LICENSE in the root
 * directory of this repository or package, or at
 * https://github.com/restatedev/sdk-typescript/blob/main/LICENSE
 */

/* eslint-disable @typescript-eslint/no-explicit-any */

import type { Duration } from "@restatedev/restate-sdk-core";

export const INTERNAL_ERROR_CODE = 500;
export const TIMEOUT_ERROR_CODE = 408;
export const CANCEL_ERROR_CODE = 409;
export const UNKNOWN_ERROR_CODE = 500;

// From shared core!
export const CLOSED_ERROR_CODE = 598;
export const SUSPENDED_ERROR_CODE = 599;

export function ensureError(
  e: unknown,
  asTerminalError?: (error: any) => TerminalError | undefined
): Error {
  if (e instanceof TerminalError) {
    return e;
  }
  // Try convert to terminal error
  const maybeTerminalError = asTerminalError ? asTerminalError(e) : undefined;
  if (maybeTerminalError) {
    return maybeTerminalError;
  }

  if (e instanceof Error) {
    return e;
  }
  if (typeof e === "object" && e !== null && "code" in e && "message" in e) {
    // This is an error from the VM
    return new RestateError(e.message as string, {
      errorCode: e.code as number,
    });
  }

  // None of the types we know
  let msg;
  try {
    msg = JSON.stringify(e);
  } catch {
    msg = "(no JSON representation)";
  }

  return new Error("Non-Error value: " + msg);
}

export function logError(log: Console, e: unknown) {
  if (e instanceof RestateError) {
    if (e.code === SUSPENDED_ERROR_CODE) {
      log.info("Invocation suspended");
      return;
    } else if (e.code === CLOSED_ERROR_CODE) {
      log.error(
        "DANGER! The invocation is closed, but some related operation is still running. \n" +
          "This might indicate that a RestatePromise is being awaited on an asynchronous task, outside the handler, or you're awaiting a RestatePromise inside a ctx.run.\n" +
          "This is dangerous, and can lead the service to deadlock. Please fix the issue.\n" +
          "Diagnostic: ",
        e
      );
      return;
    }
  }
  log.warn("Error when processing a Restate context operation.\n", e);
}

export class RestateError extends Error {
  public readonly code: number;
  public override name = "RestateError";

  constructor(message: string, options?: { errorCode?: number; cause?: any }) {
    super(message, { cause: options?.cause });
    this.code = options?.errorCode ?? INTERNAL_ERROR_CODE;
  }
}

/**
 * Does not lead to Restate retries.
 *
 * Leads to an output message with a failure defined.
 */
export class TerminalError extends RestateError {
  public override name = "TerminalError";
  public readonly metadata?: Record<string, string>;

  constructor(
    message: string,
    options?: {
      /**
       * Error code. This should be an HTTP status code, and in case the service was invoked from the ingress, this will be propagated back to the caller.
       */
      errorCode?: number;
      /**
       * Metadata key-value pairs to attach to the terminal error.
       * These will be recorded together with error message and code.
       *
       * **Note **: requires Restate 1.6+.
       */
      metadata?: Record<string, string>;
    }
  ) {
    super(message, options);
    this.metadata = options?.metadata ?? {};
  }
}

/**
 * Returned by `RestatePromise.withTimeout` when the timeout is reached.
 */
export class TimeoutError extends TerminalError {
  public override name = "TimeoutError";

  constructor() {
    super("Timeout occurred", { errorCode: TIMEOUT_ERROR_CODE });
  }
}

/**
 * Returned when the invocation was cancelled.
 */
export class CancelledError extends TerminalError {
  public override name = "CancelledError";

  constructor() {
    super("Cancelled", { errorCode: CANCEL_ERROR_CODE });
  }
}

export interface RetryableErrorOptions {
  /**
   * In how long it should retry.
   */
  retryAfter?: Duration | number;
}

/**
 * Error that Restate will retry. By using this error type within a `ctx.run` closure,
 * you can dynamically provide the retry delay specified in {@link RetryableErrorOptions}.
 *
 * You can wrap another error using {@link from}.
 */
export class RetryableError extends RestateError {
  public override name = "RetryableError";

  readonly retryAfter?: Duration | number;

  constructor(
    message: string,
    options?: RetryableErrorOptions & {
      errorCode?: number;
      cause?: any;
    }
  ) {
    super(message, {
      errorCode: options?.errorCode,
      // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
      cause: options?.cause,
    });
    this.retryAfter = options?.retryAfter;
  }

  /**
   * Create a `RetryableError` from the given cause.
   */
  static from(cause: any, options?: RetryableErrorOptions): RetryableError {
    const error = ensureError(cause);
    return new RetryableError(error.message, {
      errorCode: error["errorCode" as keyof typeof error] as number,
      cause: cause,
      ...options,
    });
  }
}

/**
 * When thrown, Restate will pause the execution of the current invocation.
 * This error type MUST be used only within a `ctx.run` closure. If thrown outside a `ctx.run` closure, pause will be ignored.
 *
 * You can wrap another error using {@link from}.
 */
export class PauseError extends RestateError {
  public override name = "PauseError";

  constructor(
    message: string,
    options?: {
      errorCode?: number;
      cause?: any;
    }
  ) {
    super(message, {
      errorCode: options?.errorCode,
      // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
      cause: options?.cause,
    });
  }

  /**
   * Create a `PauseError` from the given cause.
   */
  static from(cause: any): PauseError {
    const error = ensureError(cause);
    return new PauseError(error.message, {
      errorCode: error["errorCode" as keyof typeof error] as number,
      // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
      cause: cause,
    });
  }
}

/**
 * Returns true if the error indicates the current attempt is ending without
 * a failure — e.g. the runtime suspended the invocation (waiting for
 * `ctx.sleep()` or `ctx.call()`), or the connection was dropped (kill).
 *
 * Use this in handler interceptor catch blocks to distinguish attempt-ending
 * signals from real errors (e.g. to avoid logging it as a failure or to set
 * a neutral span status).
 */
export function isSuspendedError(e: unknown): boolean {
  return e instanceof RestateError && e.code === SUSPENDED_ERROR_CODE;
}
