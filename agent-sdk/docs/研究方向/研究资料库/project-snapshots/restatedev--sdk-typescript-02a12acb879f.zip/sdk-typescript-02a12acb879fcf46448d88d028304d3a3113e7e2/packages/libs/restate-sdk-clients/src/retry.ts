/*
 * Copyright (c) 2023-2026 - Restate Software, Inc., Restate GmbH
 *
 * This file is part of the Restate SDK for Node.js/TypeScript,
 * which is released under the MIT license.
 *
 * You can find a copy of the license in file LICENSE in the root
 * directory of this repository or package, or at
 * https://github.com/restatedev/sdk-typescript/blob/main/LICENSE
 */

import { millisOrDurationToMillis } from "@restatedev/restate-sdk-core";
import type { RetryFailure, RetryPolicy } from "./api.js";

/** Fully resolved retry policy, with all defaults applied. */
export interface ResolvedRetryPolicy {
  /**
   * `Infinity` means retries are not bounded by attempt count (the user passed
   * `maxAttempts: false`).
   */
  maxAttempts: number;
  initialInterval: number;
  maxInterval: number;
  exponentiationFactor: number;
  respectRetryAfter: boolean;
  /**
   * In milliseconds. `Infinity` means retries are not bounded by duration (the
   * user passed `maxDuration: false`).
   */
  maxDuration: number;
  shouldRetry?: (failure: RetryFailure, attempt: number) => boolean;
}

const DEFAULT_RETRY_POLICY: ResolvedRetryPolicy = {
  maxAttempts: 6,
  initialInterval: 250,
  maxInterval: 3000,
  exponentiationFactor: 2,
  respectRetryAfter: true,
  maxDuration: 60_000,
};

/**
 * Resolve a user supplied retry policy into a fully populated one.
 *
 * Retries are opt-in: returns `undefined` (disabled) when `retry` is omitted or
 * `false`. `true` enables the built-in policy; an object enables it with the
 * provided overrides.
 */
export function resolveRetryPolicy(
  retry: RetryPolicy | boolean | undefined
): ResolvedRetryPolicy | undefined {
  if (retry === undefined || retry === false) {
    return undefined;
  }
  if (retry === true) {
    return DEFAULT_RETRY_POLICY;
  }
  return {
    // `false` disables the bound (Infinity); otherwise the override or default.
    maxAttempts:
      retry.maxAttempts === false
        ? Infinity
        : (retry.maxAttempts ?? DEFAULT_RETRY_POLICY.maxAttempts),
    initialInterval:
      retry.initialInterval !== undefined
        ? millisOrDurationToMillis(retry.initialInterval)
        : DEFAULT_RETRY_POLICY.initialInterval,
    maxInterval:
      retry.maxInterval !== undefined
        ? millisOrDurationToMillis(retry.maxInterval)
        : DEFAULT_RETRY_POLICY.maxInterval,
    exponentiationFactor:
      retry.exponentiationFactor ?? DEFAULT_RETRY_POLICY.exponentiationFactor,
    respectRetryAfter:
      retry.respectRetryAfter ?? DEFAULT_RETRY_POLICY.respectRetryAfter,
    // Defaults to 60s; `false` disables the duration bound (Infinity), relying
    // on maxAttempts alone.
    maxDuration:
      retry.maxDuration === false
        ? Infinity
        : retry.maxDuration !== undefined
          ? millisOrDurationToMillis(retry.maxDuration)
          : DEFAULT_RETRY_POLICY.maxDuration,
    shouldRetry: retry.shouldRetry,
  };
}

/**
 * Whether an HTTP response status is a transient ingress condition that
 * warrants a retry: `408`, `425`, `429`, or any `5xx`.
 */
export function isRetryableStatus(status: number): boolean {
  return (
    status === 408 ||
    status === 425 ||
    status === 429 ||
    (status >= 500 && status <= 599)
  );
}

/**
 * The built-in retry decision. Retries network errors and responses with a
 * transient status (`408`, `425`, `429`, or `5xx`) — except errors restate
 * attributes to the invocation itself, which are terminal outcomes of the
 * durable execution and are never retried whatever their status code.
 *
 * restate-server discloses the origin via the `x-restate-error-source` header
 * (`"invocation"` or `"ingress"`); when it is absent — a proxy stripped it, or
 * an older server — the status alone drives the decision. See
 * https://github.com/restatedev/restate/pull/5173.
 *
 * Exported so a custom {@link RetryPolicy.shouldRetry} can compose with it
 * rather than reimplement it.
 */
export function defaultShouldRetry(failure: RetryFailure): boolean {
  if (failure.kind === "network") {
    return true;
  }
  // An invocation-sourced error is the terminal result of the durable
  // execution; retrying it re-runs nothing and never changes the outcome.
  if (failure.headers.get("x-restate-error-source") === "invocation") {
    return false;
  }
  return isRetryableStatus(failure.status);
}

/**
 * Compute the backoff for the given (zero based) attempt index using
 * exponential backoff with ±20% jitter. The exponential base is capped at
 * `maxInterval`; jitter is then applied on top, so the returned delay can sit
 * up to 20% above `maxInterval`.
 */
export function backoffDelay(
  policy: ResolvedRetryPolicy,
  attempt: number
): number {
  const exp =
    policy.initialInterval * Math.pow(policy.exponentiationFactor, attempt);
  const base = Math.min(exp, policy.maxInterval);
  // ±20% jitter keeps clients from retrying in lockstep after a shared blip.
  return base * (0.8 + Math.random() * 0.4);
}

/**
 * Parse a `Retry-After` header value into milliseconds.
 *
 * Supports both the delay-seconds form (`"120"`) and the HTTP-date form
 * (`"Wed, 21 Oct 2015 07:28:00 GMT"`). Returns `undefined` when absent or
 * unparseable.
 */
export function parseRetryAfter(
  headers: Headers,
  now: number = Date.now()
): number | undefined {
  const value = headers.get("retry-after");
  if (!value) {
    return undefined;
  }
  const seconds = Number(value);
  if (Number.isFinite(seconds)) {
    return Math.max(0, seconds * 1000);
  }
  const dateMs = Date.parse(value);
  if (Number.isNaN(dateMs)) {
    return undefined;
  }
  return Math.max(0, dateMs - now);
}

/**
 * Sleep for `ms`, rejecting early if `signal` aborts in the meantime.
 */
export function abortableSleep(
  ms: number,
  signal?: AbortSignal
): Promise<void> {
  const abortError = (): Error => {
    const reason: unknown = signal?.reason;
    return reason instanceof Error
      ? reason
      : new Error("The operation was aborted");
  };
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(abortError());
      return;
    }
    const onAbort = () => {
      clearTimeout(timer);
      reject(abortError());
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}
