/*
 * Copyright (c) 2023-2024 - Restate Software, Inc., Restate GmbH
 *
 * This file is part of the Restate SDK for Node.js/TypeScript,
 * which is released under the MIT license.
 *
 * You can find a copy of the license in file LICENSE in the root
 * directory of this repository or package, or at
 * https://github.com/restatedev/sdk-typescript/blob/main/LICENSE
 */

import { RestatePromise } from "./context.js";

export type {
  Context,
  ObjectContext,
  ObjectSharedContext,
  WorkflowContext,
  WorkflowSharedContext,
  Rand,
  GenericCall,
  GenericSend,
  InvocationId,
  InvocationHandle,
  InvocationPromise,
  TypedState,
  UntypedState,
  ContextDate,
  RunAction,
  RunOptions,
  KeyValueStore,
  DurablePromise,
  Request,
  ScopedContext,
  Target,
  InvocationReference,
  SignalReference,
} from "./context.js";
export { InvocationIdParser, RestatePromise } from "./context.js";
export { isRestatePromise } from "./promises.js";

/**
 * @deprecated Use {@link RestatePromise}
 */
export const CombineablePromise = RestatePromise;

/**
 * @deprecated Use {@link RestatePromise}
 */
export type CombineablePromise<T> = RestatePromise<T>;

export type {
  Serde,
  RestateContext,
  ServiceDefinitionFrom,
  Service,
  VirtualObjectDefinitionFrom,
  VirtualObject,
  WorkflowDefinitionFrom,
  Workflow,
  RestateObjectContext,
  RestateObjectSharedContext,
  RestateWorkflowSharedContext,
  RestateWorkflowContext,
  ServiceHandler,
  ObjectHandler,
  WorkflowHandler,
  WorkflowSharedHandler,
  Duration,
  JournalValueCodec,
} from "@restatedev/restate-sdk-core";
export { serde } from "@restatedev/restate-sdk-core";

export type {
  Client,
  SendClient,
  ClientFromDescriptors,
  SendClientFromDescriptors,
  ClientCallOptions,
  ClientSendOptions,
  RemoveVoidArgument,
  InferArg,
  ServiceHandlerOpts,
  WorkflowHandlerOpts,
  ObjectHandlerOpts,
  ServiceOpts,
  ObjectOpts,
  WorkflowOpts,
  ServiceOptions,
  ObjectOptions,
  WorkflowOptions,
  RetryPolicy,
} from "./types/rpc.js";
export {
  service,
  object,
  workflow,
  handlers,
  Opts,
  SendOpts,
} from "./types/rpc.js";

export { rpc } from "./types/rpc.js";

export type {
  ServiceDefinition,
  VirtualObjectDefinition,
  WorkflowDefinition,
} from "@restatedev/restate-sdk-core";

export { iface } from "@restatedev/restate-sdk-core";
export type {
  ServiceInterface,
  DescriptorOpts,
  HandlerDescriptor,
  Descriptor,
  ServiceDescriptor,
  ObjectDescriptor,
  WorkflowDescriptor,
  ImplementedServiceDefinition,
  ImplementedObjectDefinition,
  ImplementedWorkflowDefinition,
  ImplementedDefinition,
  InferInput,
  InferOutput,
} from "@restatedev/restate-sdk-core";
export { implement } from "./types/interface.js";
export type {
  /** @internal */
  FnOf,
  /** @internal */
  ServiceImplHandlers,
  /** @internal */
  ObjectImplHandlers,
  /** @internal */
  WorkflowImplHandlers,
  /** @internal */
  ServicePerHandlerOpts,
  /** @internal */
  ObjectPerHandlerOpts,
  /** @internal */
  WorkflowPerHandlerOpts,
} from "./types/interface.js";

export type {
  RestateEndpoint,
  RestateEndpointBase,
  DefaultServiceOptions,
} from "./endpoint.js";

export {
  /**
   * @deprecated YOU MUST NOT USE THIS TYPE
   */
  RestateError,
  TerminalError,
  TimeoutError,
  RetryableError,
  PauseError,
  CancelledError,
  type RetryableErrorOptions,
} from "./types/errors.js";
export type {
  LoggerTransport,
  LogMetadata,
  RestateLogLevel,
  LoggerContext,
  LogSource,
} from "./logging/logger_transport.js";
export type { EndpointOptions } from "./endpoint/types.js";
export type { Hooks, HooksProvider, Interceptor } from "./hooks.js";

// re-exporting createHandler shortcuts

import { handlers } from "./types/rpc.js";

export const createServiceHandler = handlers.handler;
export const createObjectHandler = handlers.object.exclusive;
export const createObjectSharedHandler = handlers.object.shared;
export const createWorkflowHandler = handlers.workflow.workflow;
export const createWorkflowSharedHandler = handlers.workflow.shared;

// Internal APIs
export * as internal from "./internal.js";
