/*
 * Copyright (c) 2023-2024 - Restate Software, Inc., Restate GmbH
 *
 * This file is part of the Restate SDK for Node.js/TypeScript,
 * which is released under the MIT license.
 *
 * You can find a copy of the license in file LICENSE in the root
 * directory of this repository or package, or at
 * https://github.com/restatedev/sdk-typescript/blob/main/LICENSE
 */

import {
  RestateContainer,
  RestateTestEnvironment,
} from "@restatedev/restate-sdk-testcontainers";
import { counter } from "../src/object.js";
import * as clients from "@restatedev/restate-sdk-clients";
import * as core from "@restatedev/restate-sdk-core";
import {
  object,
  service,
  type ObjectContext,
  type Context,
} from "@restatedev/restate-sdk";
import { describe, it, beforeAll, afterAll, expect } from "vitest";

const TESTCONTAINERS_START_TIMEOUT = 120_000;

// Non-deterministic handler: sets state to a random value then sleeps.
// On replay, Math.random() produces a different value, causing a journal mismatch.
// With alwaysReplay, this is caught. Without it, the handler completes in one shot.
const nonDeterministic = object({
  name: "nonDeterministic",
  handlers: {
    run: async (ctx: ObjectContext) => {
      ctx.set("value", Math.random());
      await ctx.sleep(100);
      return "completed";
    },
  },
});

// Fails on first attempt, succeeds on retry. With retries disabled, the
// invocation fails. With retries enabled, it succeeds on the second attempt.
let failOnceAttempts = 0;
const failOnceService = service({
  name: "failOnce",
  handlers: {
    run: async (_ctx: Context): Promise<string> => {
      failOnceAttempts++;
      if (failOnceAttempts === 1) {
        throw new Error("first attempt fails");
      }
      return "success";
    },
  },
});

describe("ExampleObject", () => {
  let restateTestEnvironment: RestateTestEnvironment;
  let rs: clients.Ingress;

  const serviceKey = "foo";

  // Deploy Restate and the Service endpoint once for all the tests in this suite
  beforeAll(async () => {
    restateTestEnvironment = await RestateTestEnvironment.start({
      services: [counter],
    });
    rs = clients.connect({ url: restateTestEnvironment.baseUrl() });
  }, TESTCONTAINERS_START_TIMEOUT);

  // Stop Restate and the Service endpoint
  afterAll(async () => {
    if (restateTestEnvironment !== undefined) {
      await restateTestEnvironment.stop();
    }
  });

  it("Can read state", async () => {
    const state = restateTestEnvironment.stateOf(counter, serviceKey);

    // State reading
    expect(await state.getAll()).toStrictEqual({});
    expect(await state.get("count")).toBeNull();
  });

  it("Can call methods", async () => {
    const client = rs.objectClient(counter, serviceKey);

    const count = await client.add(1);

    expect(count).toBe(1);
  });

  it("Can write state", async () => {
    const state = restateTestEnvironment.stateOf(counter, serviceKey);

    await state.setAll({
      count: 123,
    });
    expect(await state.getAll()).toStrictEqual({ count: 123 });

    await state.set("count", 321);
    expect(await state.get<number>("count")).toStrictEqual(321);
  });

  it("Can operate on state with non-JSON serde", async () => {
    const state = restateTestEnvironment.stateOf(counter, serviceKey);

    // State operations with non-JSON serde
    await state.setAll(
      {
        count: new Uint8Array([49, 50]), // 12
      },
      core.serde.binary
    );
    expect(
      await state.getAll<{ count: Uint8Array }>(core.serde.binary)
    ).toStrictEqual({
      count: new Uint8Array([49, 50]),
    });

    await state.set(
      "count",
      new Uint8Array([49, 52]), // 14
      core.serde.binary
    );
    expect(
      await state.get<Uint8Array>("count", core.serde.binary)
    ).toStrictEqual(new Uint8Array([49, 52]));
  });

  it("Can operate on typed state", async () => {
    // Typed state
    const state = restateTestEnvironment.stateOf<{
      count: number;
    }>(counter, serviceKey);

    await state.setAll({ count: 1 });
    // wont compile:
    // state.setAll({ count: "a" });
    // state.setAll({ foo: 1 });

    expect(await state.getAll()).toStrictEqual({ count: 1 });
    // wont compile:
    // (await state.getAll()) satisfies { count: string };
    // (await state.getAll()) satisfies { foo: number };

    await state.set("count", 2);
    // wont compile:
    // state.set("count", "a");
    // state.set("foo", 2);

    expect(await state.get("count")).toStrictEqual(2);
    // wont compile:
    // await state.get("foo");
    // (await state.get("count")) satisfies string;
  });
});

describe("Always replay", () => {
  let restateTestEnvironment: RestateTestEnvironment;
  let rs: clients.Ingress;

  beforeAll(async () => {
    restateTestEnvironment = await RestateTestEnvironment.start({
      services: [nonDeterministic],
      alwaysReplay: true,
      disableRetries: true,
    });
    rs = clients.connect({ url: restateTestEnvironment.baseUrl() });
  }, TESTCONTAINERS_START_TIMEOUT);

  afterAll(async () => {
    if (restateTestEnvironment !== undefined) {
      await restateTestEnvironment.stop();
    }
  });

  it("Catches non-deterministic behavior on replay", async () => {
    const client = rs.objectClient(nonDeterministic, "test-key");
    // The handler sets state to Math.random() then sleeps.
    // With alwaysReplay, the sleep causes a replay where Math.random()
    // produces a different value, triggering a journal mismatch error.
    await expect(client.run()).rejects.toThrow();
  }, 15_000);
});

describe("Disable retries", () => {
  let restateTestEnvironment: RestateTestEnvironment;
  let rs: clients.Ingress;

  beforeAll(async () => {
    restateTestEnvironment = await RestateTestEnvironment.start({
      services: [failOnceService],
      disableRetries: true,
    });
    rs = clients.connect({ url: restateTestEnvironment.baseUrl() });
  }, TESTCONTAINERS_START_TIMEOUT);

  afterAll(async () => {
    if (restateTestEnvironment !== undefined) {
      await restateTestEnvironment.stop();
    }
  });

  it("Fails instead of retrying", async () => {
    const client = rs.serviceClient(failOnceService);
    // Handler fails on first attempt, succeeds on retry.
    // With retries disabled, the invocation fails immediately.
    // If retries were enabled, the retry would succeed and this assertion would fail.
    await expect(client.run()).rejects.toThrow();
  }, 10_000);
});

describe("Custom testcontainer config", () => {
  let restateTestEnvironment: RestateTestEnvironment;

  // Deploy Restate and the Service endpoint once for all the tests in this suite
  beforeAll(async () => {
    restateTestEnvironment = await RestateTestEnvironment.start(
      { services: [counter] },
      () =>
        new RestateContainer()
          .withEnvironment({ RESTATE_LOG_FORMAT: "json" })
          .withLogConsumer((stream) => {
            // eslint-disable-next-line no-console
            stream.on("data", (line) => console.info(line));
            // eslint-disable-next-line no-console
            stream.on("err", (line) => console.error(line));
          })
    );
  }, TESTCONTAINERS_START_TIMEOUT);

  // Stop Restate and the Service endpoint
  afterAll(async () => {
    if (restateTestEnvironment !== undefined) {
      await restateTestEnvironment.stop();
    }
  });

  it("Works", () => {});
});

describe("Testcontainers host networking with disk storage", () => {
  let restateTestEnvironment: RestateTestEnvironment;
  let rs: clients.Ingress;

  beforeAll(async () => {
    restateTestEnvironment = await RestateTestEnvironment.start({
      services: [counter],
      serviceEndpointAccess: "testcontainers",
      storage: "disk",
    });
    rs = clients.connect({ url: restateTestEnvironment.baseUrl() });
  }, TESTCONTAINERS_START_TIMEOUT);

  afterAll(async () => {
    if (restateTestEnvironment !== undefined) {
      await restateTestEnvironment.stop();
    }
  });

  it("Can call a service", async () => {
    const client = rs.objectClient(counter, "testcontainers-disk");

    expect(await client.add(1)).toBe(1);
  });
});
