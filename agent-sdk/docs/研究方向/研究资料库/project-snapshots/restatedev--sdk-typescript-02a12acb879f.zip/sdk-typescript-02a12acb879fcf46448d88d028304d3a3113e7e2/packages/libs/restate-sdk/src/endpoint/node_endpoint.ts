/*
 * Copyright (c) 2023-2024 - Restate Software, Inc., Restate GmbH
 *
 * This file is part of the Restate SDK for Node.js/TypeScript,
 * which is released under the MIT license.
 *
 * You can find a copy of the license in file LICENSE in the root
 * directory of this repository or package, or at
 * https://github.com/restatedev/sdk-typescript/blob/main/LICENSE
 */

import type { RestateEndpoint } from "../index.js";
import type {
  JournalValueCodec,
  ServiceDefinition,
  VirtualObjectDefinition,
  WorkflowDefinition,
} from "@restatedev/restate-sdk-core";
import { IncomingMessage, ServerResponse } from "node:http";
import { Http2ServerRequest, Http2ServerResponse } from "node:http2";
import * as http2 from "node:http2";
import type { Endpoint } from "./endpoint.js";
import { EndpointBuilder } from "./endpoint.js";
import { createRestateHandler } from "./handlers/generic.js";
import { ensureError } from "../types/errors.js";
import type { LoggerTransport } from "../logging/logger_transport.js";
import type { DefaultServiceOptions } from "../endpoint.js";
import { tryCreateContextualLogger } from "./handlers/utils.js";
import type { InputReader, OutputWriter } from "./handlers/types.js";
import type { ProtocolMode } from "./discovery.js";

export class NodeEndpoint implements RestateEndpoint {
  private builder: EndpointBuilder = new EndpointBuilder();

  public bind<P extends string, M>(
    definition:
      | ServiceDefinition<P, M>
      | VirtualObjectDefinition<P, M>
      | WorkflowDefinition<P, M>
  ): RestateEndpoint {
    this.builder.bind(definition);
    return this;
  }

  public withIdentityV1(...keys: string[]): RestateEndpoint {
    this.builder.addIdentityKeys(...keys);
    return this;
  }

  public defaultServiceOptions(
    options: DefaultServiceOptions
  ): RestateEndpoint {
    this.builder.setDefaultServiceOptions(options);
    return this;
  }

  public setLogger(logger: LoggerTransport): RestateEndpoint {
    this.builder.setLogger(logger);
    return this;
  }

  public journalValueCodecProvider(
    codecProvider: () => Promise<JournalValueCodec>
  ): RestateEndpoint {
    this.builder.setJournalValueCodecProvider(codecProvider);
    return this;
  }

  http2Handler(options?: {
    bidirectional?: boolean;
  }): (request: Http2ServerRequest, response: Http2ServerResponse) => void {
    return nodeHttp2Handler(
      this.builder.build(),
      options?.bidirectional === false ? "REQUEST_RESPONSE" : "BIDI_STREAM"
    );
  }

  http1Handler(options?: {
    bidirectional?: boolean;
  }): (request: IncomingMessage, response: ServerResponse) => void {
    return nodeHttp1Handler(
      this.builder.build(),
      options?.bidirectional ? "BIDI_STREAM" : "REQUEST_RESPONSE"
    );
  }

  handler(options?: { bidirectional?: boolean }): {
    (request: IncomingMessage, response: ServerResponse): void;
    (request: Http2ServerRequest, response: Http2ServerResponse): void;
  } {
    const endpoint = this.builder.build();
    const h2Handler = nodeHttp2Handler(
      endpoint,
      options?.bidirectional === false ? "REQUEST_RESPONSE" : "BIDI_STREAM"
    );
    const h1Handler = nodeHttp1Handler(
      endpoint,
      options?.bidirectional ? "BIDI_STREAM" : "REQUEST_RESPONSE"
    );

    return ((
      request: IncomingMessage | Http2ServerRequest,
      response: ServerResponse | Http2ServerResponse
    ) => {
      if (request.httpVersionMajor >= 2) {
        h2Handler(
          request as Http2ServerRequest,
          response as Http2ServerResponse
        );
      } else {
        h1Handler(request as IncomingMessage, response as ServerResponse);
      }
    }) as {
      (request: IncomingMessage, response: ServerResponse): void;
      (request: Http2ServerRequest, response: Http2ServerResponse): void;
    };
  }

  listen(port?: number): Promise<number> {
    const endpoint = this.builder.build();

    const actualPort = port ?? parseInt(process.env.PORT ?? "9080");
    endpoint.rlog.info(`Restate SDK started listening on ${actualPort}...`);

    const server = http2.createServer(
      nodeHttp2Handler(endpoint, "BIDI_STREAM")
    );

    return new Promise((resolve, reject) => {
      let failed = false;
      server.once("error", (e: Error) => {
        failed = true;
        reject(e);
      });
      server.listen(actualPort, () => {
        if (failed) {
          return;
        }
        const address = server.address();
        if (address === null || typeof address === "string") {
          reject(
            new TypeError(
              "endpoint.listen() currently supports only binding to a PORT"
            )
          );
        } else {
          resolve(address.port);
        }
      });
    });
  }
}

function nodeHttp1Handler(
  endpoint: Endpoint,
  protocolMode: ProtocolMode
): (request: IncomingMessage, response: ServerResponse) => void {
  return nodeHandlerImpl(endpoint, protocolMode);
}

function nodeHttp2Handler(
  endpoint: Endpoint,
  protocolMode: ProtocolMode
): (request: Http2ServerRequest, response: Http2ServerResponse) => void {
  return nodeHandlerImpl(endpoint, protocolMode);
}

function nodeHandlerImpl(
  endpoint: Endpoint,
  protocolMode: ProtocolMode
): (
  request: Http2ServerRequest | IncomingMessage,
  response: Http2ServerResponse | ServerResponse
) => void {
  const handler = createRestateHandler(endpoint, protocolMode, {});

  return (httpRequest, httpResponse) => {
    const url = httpRequest.url!;
    const inputReader = inputReaderAdapter(httpRequest);
    const outputWriter = outputWriterAdapter(httpResponse);
    const res = httpResponse as NodeWritableResponse;

    // Abort controller used to clean up resources at the end of this attempt.
    const abortController = new AbortController();
    const abort = () => abortController.abort();

    // WARNING: DON'T TOUCH THIS UNLESS YOU REALLY KNOW WHAT YOU'RE DOING
    //
    // HTTP/1 has separate request and response lifecycles:
    // request body ends -> request closes -> handler finishes -> response closes.
    // The request can therefore close while the attempt is still running. The
    // response closes when the response completes or the connection is lost.
    //
    // In HTTP/2, the request and response share one stream:
    // request body ends -> handler finishes -> stream closes -> request closes.
    // Request close therefore covers both stream completion and reset.
    if (httpRequest.httpVersionMajor >= 2) {
      httpRequest.once("close", abort);
    } else {
      httpResponse.once("close", abort);
    }

    const writeHead = res.writeHead.bind(res);

    // handle should never throw
    const restateResponse = handler.handle({
      url,
      headers: httpRequest.headers,
      extraArgs: [],
    });

    restateResponse
      .process({
        inputReader,
        outputWriter,
        writeHead,
        abortSignal: abortController.signal,
      })
      .catch((e) => {
        // Responses handle their own errors before rejecting; anything
        // reaching here is an unexpected failure — just log.
        const error = ensureError(e);
        const logger =
          tryCreateContextualLogger(
            endpoint.loggerTransport,
            url,
            httpRequest.headers
          ) ?? endpoint.rlog;
        logger.error("Unexpected error: " + (error.stack ?? error.message));
      });
  };
}

// Both ServerResponse and Http2ServerResponse satisfy this interface.
// We use it to avoid TS union overload incompatibilities.
interface NodeWritableResponse {
  writeHead(statusCode: number, headers: Record<string, string>): void;
  write(chunk: Uint8Array, callback: (err?: Error | null) => void): boolean;
  end(callback: () => void): void;
}

function inputReaderAdapter(
  request: Http2ServerRequest | IncomingMessage
): InputReader {
  return (request as AsyncIterable<Uint8Array>)[Symbol.asyncIterator]();
}

function outputWriterAdapter(
  response: Http2ServerResponse | ServerResponse
): OutputWriter {
  const res = response as NodeWritableResponse;
  return {
    write: function (value: Uint8Array): Promise<void> {
      return new Promise((resolve, reject) => {
        res.write(value, (err) => (err ? reject(err) : resolve()));
      });
    },
    close: function (): Promise<void> {
      return new Promise((resolve) => {
        res.end(() => resolve());
      });
    },
  };
}
