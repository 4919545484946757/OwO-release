use js_sys::Uint8Array;
use restate_sdk_shared_core::tracing_pretty::{Pretty, PrettyFields};
use restate_sdk_shared_core::{
    AwaitResponse, AwakeableHandle, CallHandle, CommandRelationship, CommandType, CoreVM, Error,
    Header, HeaderMap, IdentityVerifier, ImplicitCancellationOption, Input,
    JournalMismatchRetryBehavior, NonDeterministicChecksOption, NonEmptyValue, OnMaxAttempts,
    ResponseHead, RetryPolicy, RunExitResult, RunHandle, SendHandle, Target, TerminalFailure,
    UnresolvedFuture, VMOptions, Value, CANCEL_NOTIFICATION_HANDLE, VM,
};
use serde::{Deserialize, Serialize};
use std::alloc::{GlobalAlloc, Layout, System};
use std::cmp;
use std::convert::{Infallible, Into};
use std::io::Write;
use std::time::Duration;
use tracing::metadata::LevelFilter;
use tracing::{Dispatch, Level, Subscriber};
use tracing_subscriber::fmt::format::FmtSpan;
use tracing_subscriber::fmt::MakeWriter;
use tracing_subscriber::layer::SubscriberExt;
use tracing_subscriber::{Layer, Registry};
use tsify::Tsify;
use wasm_bindgen::prelude::*;

/// Global allocator that reports allocation failures through `fatal` before failing.
///
/// On wasm32-unknown-unknown, an allocation failure aborts with a bare `unreachable` trap:
/// std's OOM handler doesn't invoke the panic hook, and its stderr message is discarded.
/// This also covers allocations requested by the JS glue (`__wbindgen_malloc`/`__wbindgen_realloc`).
struct OomReportingAllocator;

#[global_allocator]
static GLOBAL_ALLOCATOR: OomReportingAllocator = OomReportingAllocator;

unsafe impl GlobalAlloc for OomReportingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = System.alloc(layout);
        if ptr.is_null() {
            report_oom();
        }
        ptr
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        System.dealloc(ptr, layout)
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let ptr = System.alloc_zeroed(layout);
        if ptr.is_null() {
            report_oom();
        }
        ptr
    }

    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        let new_ptr = System.realloc(ptr, layout, new_size);
        if new_ptr.is_null() {
            report_oom();
        }
        new_ptr
    }
}

#[cold]
fn report_oom() {
    fatal("out of memory: shared core memory allocation failed. Scale up your service processes/container replicas.");
}

/// Setups the WASM module
#[wasm_bindgen(start)]
pub fn start() {
    // Setup our panic hook
    std::panic::set_hook(Box::new(|info| {
        fatal(&info.to_string());
    }));
}

#[wasm_bindgen]
pub enum LogLevel {
    TRACE = 0,
    DEBUG = 1,
    INFO = 2,
    WARN = 3,
    ERROR = 4,
}

/// How the state machine should behave when it hits a journal mismatch (non-determinism) error.
#[wasm_bindgen]
pub enum WasmJournalMismatchBehavior {
    /// Follow the normal retry policy.
    Retry = 0,
    /// Pause the invocation instead of retrying.
    Pause = 1,
    /// Fail the invocation terminally instead of retrying.
    Fail = 2,
}

impl From<WasmJournalMismatchBehavior> for JournalMismatchRetryBehavior {
    fn from(value: WasmJournalMismatchBehavior) -> Self {
        match value {
            WasmJournalMismatchBehavior::Retry => Self::FollowRetryPolicy,
            WasmJournalMismatchBehavior::Pause => Self::Pause,
            WasmJournalMismatchBehavior::Fail => Self::FailTerminally,
        }
    }
}

#[wasm_bindgen(raw_module = "../core_logging.js")]
extern "C" {
    #[wasm_bindgen]
    fn vm_log(level: LogLevel, s: &[u8], logger_id: Option<u32>);

    /// Called on panics
    #[wasm_bindgen]
    fn fatal(s: &str);
}

pub struct MakeWebConsoleWriter {
    logger_id: Option<u32>,
}

impl<'a> MakeWriter<'a> for MakeWebConsoleWriter {
    type Writer = ConsoleWriter;

    fn make_writer(&'a self) -> Self::Writer {
        ConsoleWriter {
            buffer: vec![],
            level: Level::TRACE, // if no level is known, assume the most detailed
            logger_id: self.logger_id,
        }
    }

    fn make_writer_for(&'a self, meta: &tracing::Metadata<'_>) -> Self::Writer {
        let level = *meta.level();
        ConsoleWriter {
            buffer: vec![],
            level,
            logger_id: self.logger_id,
        }
    }
}

pub struct ConsoleWriter {
    buffer: Vec<u8>,

    level: Level,
    logger_id: Option<u32>,
}

impl Write for ConsoleWriter {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        self.buffer.write(buf)
    }

    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

impl Drop for ConsoleWriter {
    fn drop(&mut self) {
        vm_log(
            match self.level {
                Level::TRACE => LogLevel::TRACE,
                Level::DEBUG => LogLevel::DEBUG,
                Level::INFO => LogLevel::INFO,
                Level::WARN => LogLevel::WARN,
                Level::ERROR => LogLevel::ERROR,
            },
            // Remove last character, which is always a new line
            &self.buffer[..cmp::max(0, self.buffer.len() - 1)],
            self.logger_id,
        )
    }
}

/// This will set the log level of the overall log subscriber.
#[wasm_bindgen]
pub fn set_log_level(level: LogLevel) {
    let _ = tracing::subscriber::set_global_default(log_subscriber(level, None));
}

fn log_subscriber(
    level: LogLevel,
    logger_id: Option<u32>,
) -> impl Subscriber + Send + Sync + 'static {
    let level = match level {
        LogLevel::TRACE => Level::TRACE,
        LogLevel::DEBUG => Level::DEBUG,
        LogLevel::INFO => Level::INFO,
        LogLevel::WARN => Level::WARN,
        LogLevel::ERROR => Level::ERROR,
    };

    let fmt_layer = if level == Level::TRACE {
        tracing_subscriber::fmt::layer()
            .with_ansi(false)
            .without_time()
            .with_span_events(FmtSpan::ENTER)
            .with_writer(MakeWebConsoleWriter { logger_id })
            .event_format(
                Pretty::default()
                    .without_time()
                    .with_thread_names(false)
                    .with_thread_ids(false)
                    .with_target(true)
                    .with_level(true),
            )
            .fmt_fields(PrettyFields::default())
            .boxed()
    } else {
        tracing_subscriber::fmt::layer()
            .with_ansi(false)
            .without_time()
            .with_thread_names(false)
            .with_thread_ids(false)
            .with_file(false)
            .with_line_number(false)
            .with_target(false)
            .with_level(false)
            .with_span_events(FmtSpan::NONE)
            .with_writer(MakeWebConsoleWriter { logger_id })
            .boxed()
    };

    Registry::default().with(
        fmt_layer
            // We do filtering here too,
            // as it might get expensive to pass logs through
            // the various layers even though we don't need them
            .with_filter(LevelFilter::from_level(level)),
    )
}

//--- Data model

#[wasm_bindgen]
pub enum WasmCommandType {
    Input,
    Output,
    GetState,
    GetStateKeys,
    SetState,
    ClearState,
    ClearAllState,
    GetPromise,
    PeekPromise,
    CompletePromise,
    Sleep,
    Call,
    OneWayCall,
    SendSignal,
    Run,
    AttachInvocation,
    GetInvocationOutput,
    CompleteAwakeable,
    CancelInvocation,
}

impl From<WasmCommandType> for CommandType {
    fn from(value: WasmCommandType) -> Self {
        match value {
            WasmCommandType::Input => CommandType::Input,
            WasmCommandType::Output => CommandType::Output,
            WasmCommandType::GetState => CommandType::GetState,
            WasmCommandType::GetStateKeys => CommandType::GetStateKeys,
            WasmCommandType::SetState => CommandType::SetState,
            WasmCommandType::ClearState => CommandType::ClearState,
            WasmCommandType::ClearAllState => CommandType::ClearAllState,
            WasmCommandType::GetPromise => CommandType::GetPromise,
            WasmCommandType::PeekPromise => CommandType::PeekPromise,
            WasmCommandType::CompletePromise => CommandType::CompletePromise,
            WasmCommandType::Sleep => CommandType::Sleep,
            WasmCommandType::Call => CommandType::Call,
            WasmCommandType::OneWayCall => CommandType::OneWayCall,
            WasmCommandType::SendSignal => CommandType::SendSignal,
            WasmCommandType::Run => CommandType::Run,
            WasmCommandType::AttachInvocation => CommandType::AttachInvocation,
            WasmCommandType::GetInvocationOutput => CommandType::GetInvocationOutput,
            WasmCommandType::CompleteAwakeable => CommandType::CompleteAwakeable,
            WasmCommandType::CancelInvocation => CommandType::CancelInvocation,
        }
    }
}

#[wasm_bindgen(getter_with_clone)]
#[derive(Clone)]
pub struct WasmHeader {
    #[wasm_bindgen(readonly)]
    pub key: String,
    #[wasm_bindgen(readonly)]
    pub value: String,
}
#[wasm_bindgen]
impl WasmHeader {
    #[wasm_bindgen(constructor)]
    pub fn new(key: String, value: String) -> WasmHeader {
        WasmHeader { key, value }
    }
}

impl From<Header> for WasmHeader {
    fn from(h: Header) -> Self {
        WasmHeader {
            key: h.key.into(),
            value: h.value.into(),
        }
    }
}

impl From<WasmHeader> for Header {
    fn from(h: WasmHeader) -> Self {
        Header {
            key: h.key.into(),
            value: h.value.into(),
        }
    }
}

#[wasm_bindgen(getter_with_clone)]
pub struct WasmResponseHead {
    #[wasm_bindgen(readonly)]
    pub status_code: u16,
    #[wasm_bindgen(readonly)]
    pub headers: Vec<WasmHeader>,
}

impl From<ResponseHead> for WasmResponseHead {
    fn from(value: ResponseHead) -> Self {
        WasmResponseHead {
            status_code: value.status_code,
            headers: value
                .headers
                .into_iter()
                .map(|Header { key, value }| WasmHeader {
                    key: key.into(),
                    value: value.into(),
                })
                .collect(),
        }
    }
}

type WasmNotificationHandle = u32;
type WasmEphemeralNotificationHandle = u32;

#[derive(Tsify, Serialize, Deserialize)]
#[tsify(into_wasm_abi, from_wasm_abi)]
pub struct WasmFailureMetadata {
    pub key: String,
    pub value: String,
}

#[derive(Tsify, Serialize, Deserialize)]
#[tsify(into_wasm_abi, from_wasm_abi)]
pub struct WasmFailure {
    pub code: u16,
    pub message: String,
    pub metadata: Vec<WasmFailureMetadata>,
}

impl From<Error> for WasmFailure {
    fn from(value: Error) -> Self {
        WasmFailure {
            code: value.code(),
            message: value.to_string(),
            metadata: vec![],
        }
    }
}

#[derive(Tsify, Serialize, Deserialize)]
#[tsify(into_wasm_abi, from_wasm_abi)]
pub struct WasmExponentialRetryConfig {
    pub initial_interval: Option<u64>,
    pub factor: f32,
    pub max_interval: Option<u64>,
    pub max_attempts: Option<u32>,
    pub max_duration: Option<u64>,
}

impl From<WasmExponentialRetryConfig> for RetryPolicy {
    fn from(value: WasmExponentialRetryConfig) -> Self {
        RetryPolicy::Exponential {
            initial_interval: Duration::from_millis(value.initial_interval.unwrap_or(10)),
            max_attempts: value.max_attempts,
            max_duration: value.max_duration.map(Duration::from_millis),
            factor: value.factor,
            max_interval: value.max_interval.map(Duration::from_millis),
            on_max_attempts: OnMaxAttempts::FailAsTerminal,
        }
    }
}

impl From<TerminalFailure> for WasmFailure {
    fn from(value: TerminalFailure) -> Self {
        WasmFailure {
            code: value.code,
            message: value.message,
            metadata: value
                .metadata
                .into_iter()
                .map(|(k, v)| WasmFailureMetadata { key: k, value: v })
                .collect(),
        }
    }
}

impl From<WasmFailure> for TerminalFailure {
    fn from(value: WasmFailure) -> Self {
        TerminalFailure {
            code: value.code,
            message: value.message,
            metadata: value
                .metadata
                .into_iter()
                .map(|metadata| (metadata.key, metadata.value))
                .collect(),
        }
    }
}

#[derive(Tsify, Serialize, Deserialize)]
#[tsify(into_wasm_abi, from_wasm_abi)]
pub struct WasmAwakeable {
    pub id: String,
    // Due to a bug in tsify, this doesn't correctly resolve the type alias WasmAsyncResultHandle, thus we use the u32 type directly.
    pub handle: u32,
}

#[derive(Tsify, Serialize, Deserialize)]
#[tsify(into_wasm_abi, from_wasm_abi)]
pub struct WasmRun {
    pub replayed: bool,
    // Due to a bug in tsify, this doesn't correctly resolve the type alias WasmAsyncResultHandle, thus we use the u32 type directly.
    pub handle: u32,
}

#[wasm_bindgen(getter_with_clone)]
pub struct WasmInput {
    #[wasm_bindgen(readonly)]
    pub invocation_id: String,
    #[wasm_bindgen(readonly)]
    pub key: String,
    #[wasm_bindgen(readonly)]
    pub idempotency_key: Option<String>,
    #[wasm_bindgen(readonly)]
    pub scope: Option<String>,
    #[wasm_bindgen(readonly)]
    pub limit_key: Option<String>,
    #[wasm_bindgen(readonly)]
    pub headers: Vec<WasmHeader>,
    #[wasm_bindgen(readonly)]
    pub input: Uint8Array,
    #[wasm_bindgen(readonly)]
    pub random_seed: u64,
}

impl From<Input> for WasmInput {
    fn from(value: Input) -> Self {
        WasmInput {
            invocation_id: value.invocation_id,
            key: value.key,
            idempotency_key: value.idempotency_key,
            scope: value.scope,
            limit_key: value.limit_key,
            headers: value.headers.into_iter().map(Into::into).collect(),
            input: (&*value.input).into(),
            random_seed: value.random_seed,
        }
    }
}

#[derive(Tsify, Serialize, Deserialize)]
#[tsify(into_wasm_abi, from_wasm_abi)]
pub enum WasmAsyncResultValue {
    NotReady,
    Empty,
    Success(
        // See https://github.com/madonoharu/tsify/pull/29
        #[tsify(type = "Uint8Array")] serde_bytes::ByteBuf,
    ),
    Failure(WasmFailure),
    StateKeys(Vec<String>),
    InvocationId(String),
}

#[derive(Tsify, Serialize, Deserialize)]
#[tsify(into_wasm_abi, from_wasm_abi)]
pub enum WasmDoProgressResult {
    /// Any of the given AsyncResultHandle completed
    AnyCompleted,
    /// The SDK should read from input at this point, or wait for any executing run
    WaitExternalProgress,
    /// The SDK should execute a pending run
    ExecuteRun(#[tsify(type = "number")] WasmNotificationHandle),
    /// Got cancel signal
    CancelSignalReceived,
    /// The notification of an ephemeral command is ready, take it with take_ephemeral_notification.
    EphemeralNotificationReady(#[tsify(type = "number")] WasmEphemeralNotificationHandle),
}

impl From<AwaitResponse> for WasmDoProgressResult {
    fn from(value: AwaitResponse) -> Self {
        match value {
            AwaitResponse::AnyCompleted => WasmDoProgressResult::AnyCompleted,
            AwaitResponse::WaitingExternalProgress { .. } => {
                WasmDoProgressResult::WaitExternalProgress
            }
            AwaitResponse::ExecuteRun(n) => WasmDoProgressResult::ExecuteRun(n.into()),
            AwaitResponse::CancelSignalReceived => WasmDoProgressResult::CancelSignalReceived,
            AwaitResponse::EphemeralNotificationReady(ephemeral_notification_id) => {
                WasmDoProgressResult::EphemeralNotificationReady(ephemeral_notification_id.into())
            }
        }
    }
}

#[derive(Tsify, Serialize, Deserialize)]
#[tsify(from_wasm_abi)]
pub enum WasmUnresolvedFuture {
    Single(#[tsify(type = "number")] WasmNotificationHandle),
    FirstCompleted(Vec<WasmUnresolvedFuture>),
    AllCompleted(Vec<WasmUnresolvedFuture>),
    FirstSucceededOrAllFailed(Vec<WasmUnresolvedFuture>),
    AllSucceededOrFirstFailed(Vec<WasmUnresolvedFuture>),
    Unknown(Vec<WasmUnresolvedFuture>),
}

impl From<WasmUnresolvedFuture> for UnresolvedFuture {
    fn from(value: WasmUnresolvedFuture) -> Self {
        match value {
            WasmUnresolvedFuture::Single(h) => UnresolvedFuture::Single(h.into()),
            WasmUnresolvedFuture::FirstCompleted(c) => {
                UnresolvedFuture::FirstCompleted(c.into_iter().map(Into::into).collect())
            }
            WasmUnresolvedFuture::AllCompleted(c) => {
                UnresolvedFuture::AllCompleted(c.into_iter().map(Into::into).collect())
            }
            WasmUnresolvedFuture::FirstSucceededOrAllFailed(c) => {
                UnresolvedFuture::FirstSucceededOrAllFailed(c.into_iter().map(Into::into).collect())
            }
            WasmUnresolvedFuture::AllSucceededOrFirstFailed(c) => {
                UnresolvedFuture::AllSucceededOrFirstFailed(c.into_iter().map(Into::into).collect())
            }
            WasmUnresolvedFuture::Unknown(c) => {
                UnresolvedFuture::Unknown(c.into_iter().map(Into::into).collect())
            }
        }
    }
}

#[derive(Tsify, Serialize, Deserialize)]
#[tsify(into_wasm_abi, from_wasm_abi)]
pub struct WasmCallHandle {
    #[tsify(type = "number")]
    invocation_id_completion_id: WasmNotificationHandle,
    #[tsify(type = "number")]
    call_completion_id: WasmNotificationHandle,
}

impl From<CallHandle> for WasmCallHandle {
    fn from(value: CallHandle) -> Self {
        Self {
            invocation_id_completion_id: value.invocation_id_notification_handle.into(),
            call_completion_id: value.call_notification_handle.into(),
        }
    }
}

#[derive(Tsify, Serialize, Deserialize)]
#[tsify(into_wasm_abi, from_wasm_abi)]
pub struct WasmSendHandle {
    #[tsify(type = "number")]
    invocation_id_completion_id: WasmNotificationHandle,
}

impl From<SendHandle> for WasmSendHandle {
    fn from(value: SendHandle) -> Self {
        Self {
            invocation_id_completion_id: value.invocation_id_notification_handle.into(),
        }
    }
}

// VM implementation

#[wasm_bindgen]
pub struct WasmVM {
    vm: CoreVM,
    log_dispatcher: Dispatch,
}

macro_rules! use_log_dispatcher {
    ($vm:expr, $f:expr) => {{
        let WasmVM { vm, log_dispatcher } = $vm;
        tracing::dispatcher::with_default(&log_dispatcher, || $f(vm))
    }};
}

#[wasm_bindgen]
impl WasmVM {
    #[wasm_bindgen(constructor)]
    pub fn new(
        headers: Vec<WasmHeader>,
        log_level: LogLevel,
        logger_id: u32,
        disable_payload_checks: bool,
        explicit_cancellation: bool,
        on_journal_mismatch: WasmJournalMismatchBehavior,
    ) -> Result<WasmVM, WasmFailure> {
        let log_dispatcher = Dispatch::new(log_subscriber(log_level, Some(logger_id)));

        let vm = tracing::dispatcher::with_default(&log_dispatcher, || {
            CoreVM::new(
                WasmHeaderList::from(headers),
                VMOptions {
                    non_determinism_checks: if disable_payload_checks {
                        NonDeterministicChecksOption::PayloadChecksDisabled
                    } else {
                        NonDeterministicChecksOption::Enabled
                    },
                    implicit_cancellation: if explicit_cancellation {
                        ImplicitCancellationOption::Disabled
                    } else {
                        ImplicitCancellationOption::Enabled {
                            cancel_children_calls: true,
                            cancel_children_one_way_calls: false,
                        }
                    },
                    awaiting_on_policy: Default::default(),
                    journal_mismatch_retry_behavior: on_journal_mismatch.into(),
                },
            )
        })?;

        Ok(Self { vm, log_dispatcher })
    }

    pub fn get_response_head(&self) -> WasmResponseHead {
        use_log_dispatcher!(self, |vm| CoreVM::get_response_head(vm).into())
    }

    pub fn notify_input(&mut self, buffer: Vec<u8>) {
        let buf = buffer.into();
        use_log_dispatcher!(self, |vm| CoreVM::notify_input(vm, buf))
    }

    pub fn notify_input_closed(&mut self) {
        self.vm.notify_input_closed();
    }

    pub fn notify_error(&mut self, error_message: String, stacktrace: Option<String>) {
        let mut e = Error::internal(error_message);
        if let Some(stacktrace) = stacktrace {
            e = e.with_stacktrace(stacktrace);
        }

        use_log_dispatcher!(self, |vm| CoreVM::notify_error(vm, e, None))
    }

    pub fn notify_error_with_delay_override(
        &mut self,
        error_message: String,
        stacktrace: Option<String>,
        delay_override: Option<u64>,
    ) {
        let mut e = Error::internal(error_message);
        if let Some(stacktrace) = stacktrace {
            e = e.with_stacktrace(stacktrace);
        }
        if let Some(delay_override) = delay_override {
            e = e.with_next_retry_delay_override(Duration::from_millis(delay_override))
        }

        use_log_dispatcher!(self, |vm| CoreVM::notify_error(vm, e, None))
    }

    pub fn notify_error_for_next_command(
        &mut self,
        error_message: String,
        stacktrace: Option<String>,
        wasm_command_type: WasmCommandType,
    ) {
        let mut e = Error::internal(error_message);
        if let Some(stacktrace) = stacktrace {
            e = e.with_stacktrace(stacktrace);
        }

        use_log_dispatcher!(self, |vm| CoreVM::notify_error(
            vm,
            e,
            Some(CommandRelationship::Next {
                ty: wasm_command_type.into(),
                name: None,
            })
        ))
    }

    pub fn notify_error_for_specific_command(
        &mut self,
        error_message: String,
        stacktrace: Option<String>,
        wasm_command_type: WasmCommandType,
        command_index: u32,
        command_name: Option<String>,
    ) {
        let mut e = Error::internal(error_message);
        if let Some(stacktrace) = stacktrace {
            e = e.with_stacktrace(stacktrace);
        }

        use_log_dispatcher!(self, |vm| CoreVM::notify_error(
            vm,
            e,
            Some(CommandRelationship::Specific {
                command_index,
                ty: wasm_command_type.into(),
                name: command_name.map(Into::into)
            })
        ))
    }

    pub fn take_output(&mut self) -> Uint8Array {
        (&*use_log_dispatcher!(self, CoreVM::take_output)).into()
    }

    pub fn is_ready_to_execute(&self) -> Result<bool, WasmFailure> {
        use_log_dispatcher!(self, CoreVM::is_ready_to_execute).map_err(Into::into)
    }

    pub fn is_completed(&self, handle: WasmNotificationHandle) -> bool {
        use_log_dispatcher!(self, |vm| CoreVM::is_completed(vm, handle.into()))
    }

    pub fn do_progress(
        &mut self,
        future: WasmUnresolvedFuture,
    ) -> Result<WasmDoProgressResult, WasmFailure> {
        Ok(use_log_dispatcher!(self, |vm| CoreVM::do_await(vm, future.into()))?.into())
    }

    pub fn take_notification(
        &mut self,
        handle: WasmNotificationHandle,
    ) -> Result<WasmAsyncResultValue, WasmFailure> {
        Ok(
            match use_log_dispatcher!(self, |vm| CoreVM::take_notification(vm, handle.into()))? {
                None => WasmAsyncResultValue::NotReady,
                Some(Value::Void) => WasmAsyncResultValue::Empty,
                Some(Value::Success(b)) => WasmAsyncResultValue::Success(b.to_vec().into()),
                Some(Value::Failure(f)) => WasmAsyncResultValue::Failure(f.into()),
                Some(Value::StateKeys(keys)) => WasmAsyncResultValue::StateKeys(keys),
                Some(Value::InvocationId(invocation_id)) => {
                    WasmAsyncResultValue::InvocationId(invocation_id)
                }
            },
        )
    }

    // Syscall(s)

    pub fn sys_input(&mut self) -> Result<WasmInput, WasmFailure> {
        use_log_dispatcher!(self, CoreVM::sys_input)
            .map(Into::into)
            .map_err(Into::into)
    }

    pub fn sys_get_state(&mut self, key: String) -> Result<WasmNotificationHandle, WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_state_get(
            vm,
            key,
            Default::default()
        ))
        .map(Into::into)
        .map_err(Into::into)
    }

    pub fn ephemeral_state_get(
        &mut self,
        key: String,
    ) -> Result<WasmEphemeralNotificationHandle, WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::ephemeral_state_get(vm, key))
            .map(Into::into)
            .map_err(Into::into)
    }

    pub fn take_ephemeral_notification(
        &mut self,
        ephemeral_notification_handle: WasmEphemeralNotificationHandle,
    ) -> Result<WasmAsyncResultValue, WasmFailure> {
        Ok(
            match use_log_dispatcher!(self, |vm| CoreVM::take_ephemeral_notification(
                vm,
                ephemeral_notification_handle.into()
            ))? {
                None => WasmAsyncResultValue::NotReady,
                Some(Value::Void) => WasmAsyncResultValue::Empty,
                Some(Value::Success(b)) => WasmAsyncResultValue::Success(b.to_vec().into()),
                Some(Value::Failure(f)) => WasmAsyncResultValue::Failure(f.into()),
                Some(Value::StateKeys(keys)) => WasmAsyncResultValue::StateKeys(keys),
                Some(Value::InvocationId(invocation_id)) => {
                    WasmAsyncResultValue::InvocationId(invocation_id)
                }
            },
        )
    }

    pub fn sys_get_state_keys(&mut self) -> Result<WasmNotificationHandle, WasmFailure> {
        use_log_dispatcher!(self, CoreVM::sys_state_get_keys)
            .map(Into::into)
            .map_err(Into::into)
    }

    pub fn sys_set_state(&mut self, key: String, buffer: Vec<u8>) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_state_set(
            vm,
            key,
            buffer.into(),
            Default::default()
        ))
        .map_err(Into::into)
    }

    pub fn sys_clear_state(&mut self, key: String) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_state_clear(vm, key)).map_err(Into::into)
    }

    pub fn sys_clear_all_state(&mut self) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, CoreVM::sys_state_clear_all).map_err(Into::into)
    }

    pub fn sys_sleep(
        &mut self,
        millis: u64,
        name: Option<String>,
    ) -> Result<WasmNotificationHandle, WasmFailure> {
        let now = now_since_unix_epoch();
        use_log_dispatcher!(self, |vm| CoreVM::sys_sleep(
            vm,
            name.unwrap_or_default(),
            now + Duration::from_millis(millis),
            Some(now)
        ))
        .map(Into::into)
        .map_err(Into::into)
    }

    pub fn sys_attach_invocation(
        &mut self,
        invocation_id: String,
    ) -> Result<WasmNotificationHandle, WasmFailure> {
        let target = restate_sdk_shared_core::AttachInvocationTarget::InvocationId(invocation_id);

        use_log_dispatcher!(self, |vm| CoreVM::sys_attach_invocation(vm, target))
            .map(Into::into)
            .map_err(Into::into)
    }

    pub fn sys_get_invocation_output(
        &mut self,
        invocation_id: String,
    ) -> Result<WasmNotificationHandle, WasmFailure> {
        let target = restate_sdk_shared_core::AttachInvocationTarget::InvocationId(invocation_id);

        use_log_dispatcher!(self, |vm| CoreVM::sys_get_invocation_output(vm, target))
            .map(Into::into)
            .map_err(Into::into)
    }

    pub fn sys_call(
        &mut self,
        service: String,
        handler: String,
        buffer: Vec<u8>,
        key: Option<String>,
        headers: Vec<WasmHeader>,
        idempotency_key: Option<String>,
        scope: Option<String>,
        limit_key: Option<String>,
        name: Option<String>,
    ) -> Result<WasmCallHandle, WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_call(
            vm,
            Target {
                service,
                handler,
                key,
                idempotency_key,
                scope,
                limit_key,
                headers: headers.into_iter().map(Header::from).collect(),
            },
            buffer.to_vec().into(),
            name,
            Default::default(),
        ))
        .map(Into::into)
        .map_err(Into::into)
    }

    #[allow(clippy::too_many_arguments)]
    pub fn sys_send(
        &mut self,
        service: String,
        handler: String,
        buffer: Vec<u8>,
        key: Option<String>,
        headers: Vec<WasmHeader>,
        delay: Option<u64>,
        idempotency_key: Option<String>,
        scope: Option<String>,
        limit_key: Option<String>,
        name: Option<String>,
    ) -> Result<WasmSendHandle, WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_send(
            vm,
            Target {
                service,
                handler,
                key,
                idempotency_key,
                scope,
                limit_key,
                headers: headers.into_iter().map(Header::from).collect(),
            },
            buffer.to_vec().into(),
            delay.map(|delay| now_since_unix_epoch() + Duration::from_millis(delay)),
            name,
            Default::default()
        ))
        .map(Into::into)
        .map_err(Into::into)
    }

    pub fn sys_awakeable(&mut self) -> Result<WasmAwakeable, WasmFailure> {
        use_log_dispatcher!(self, CoreVM::sys_awakeable)
            .map(
                |AwakeableHandle { id, handle }: AwakeableHandle| WasmAwakeable {
                    id,
                    handle: handle.into(),
                },
            )
            .map_err(Into::into)
    }

    pub fn sys_complete_awakeable_success(
        &mut self,
        id: String,
        buffer: Vec<u8>,
    ) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_complete_awakeable(
            vm,
            id,
            NonEmptyValue::Success(buffer.to_vec().into()),
            Default::default()
        ))
        .map_err(Into::into)
    }

    pub fn sys_complete_awakeable_failure(
        &mut self,
        id: String,
        value: WasmFailure,
    ) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_complete_awakeable(
            vm,
            id,
            NonEmptyValue::Failure(value.into()),
            Default::default()
        ))
        .map_err(Into::into)
    }

    pub fn sys_signal(
        &mut self,
        signal_name: String,
    ) -> Result<WasmNotificationHandle, WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::create_signal_handle(vm, signal_name))
            .map(Into::into)
            .map_err(Into::into)
    }

    pub fn sys_complete_signal_success(
        &mut self,
        invocation_id: String,
        signal_name: String,
        buffer: Vec<u8>,
    ) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_complete_signal(
            vm,
            invocation_id,
            signal_name,
            NonEmptyValue::Success(buffer.to_vec().into()),
        ))
        .map_err(Into::into)
    }

    pub fn sys_complete_signal_failure(
        &mut self,
        invocation_id: String,
        signal_name: String,
        value: WasmFailure,
    ) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_complete_signal(
            vm,
            invocation_id,
            signal_name,
            NonEmptyValue::Failure(value.into()),
        ))
        .map_err(Into::into)
    }

    pub fn sys_get_promise(&mut self, key: String) -> Result<WasmNotificationHandle, WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_get_promise(vm, key))
            .map(Into::into)
            .map_err(Into::into)
    }

    pub fn sys_peek_promise(&mut self, key: String) -> Result<WasmNotificationHandle, WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_peek_promise(vm, key))
            .map(Into::into)
            .map_err(Into::into)
    }

    pub fn sys_complete_promise_success(
        &mut self,
        key: String,
        buffer: Vec<u8>,
    ) -> Result<WasmNotificationHandle, WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_complete_promise(
            vm,
            key,
            NonEmptyValue::Success(buffer.to_vec().into()),
            Default::default()
        ))
        .map(Into::into)
        .map_err(Into::into)
    }

    pub fn sys_complete_promise_failure(
        &mut self,
        key: String,
        value: WasmFailure,
    ) -> Result<WasmNotificationHandle, WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_complete_promise(
            vm,
            key,
            NonEmptyValue::Failure(value.into()),
            Default::default()
        ))
        .map(Into::into)
        .map_err(Into::into)
    }

    pub fn sys_run(&mut self, name: String) -> Result<WasmRun, WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_run(vm, name))
            .map(|RunHandle { replayed, handle }: RunHandle| WasmRun {
                replayed,
                handle: handle.into(),
            })
            .map_err(Into::into)
    }

    pub fn propose_run_completion_success(
        &mut self,
        handle: WasmNotificationHandle,
        buffer: Vec<u8>,
    ) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::propose_run_completion(
            vm,
            handle.into(),
            RunExitResult::Success(buffer.to_vec().into()),
            RetryPolicy::None,
        ))
        .map_err(Into::into)
    }

    pub fn propose_run_completion_failure(
        &mut self,
        handle: WasmNotificationHandle,
        value: WasmFailure,
    ) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::propose_run_completion(
            vm,
            handle.into(),
            RunExitResult::TerminalFailure(value.into()),
            RetryPolicy::None
        ))
        .map_err(Into::into)
    }

    pub fn propose_run_completion_failure_transient(
        &mut self,
        handle: WasmNotificationHandle,
        error_message: String,
        error_stacktrace: Option<String>,
        attempt_duration: u64,
        config: Option<WasmExponentialRetryConfig>,
    ) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::propose_run_completion(
            vm,
            handle.into(),
            RunExitResult::RetryableFailure {
                attempt_duration: Duration::from_millis(attempt_duration),
                error: Error::internal(error_message)
                    .with_stacktrace(error_stacktrace.unwrap_or_default()),
            },
            config
                .map(|config| config.into())
                .unwrap_or(RetryPolicy::Infinite)
        ))
        .map_err(Into::into)
    }

    pub fn propose_run_completion_failure_transient_with_delay_override(
        &mut self,
        handle: WasmNotificationHandle,
        error_message: String,
        error_stacktrace: Option<String>,
        attempt_duration: u64,
        delay_override: Option<u64>,
        max_retry_attempts_override: Option<u32>,
        max_retry_duration_override: Option<u64>,
    ) -> Result<(), WasmFailure> {
        let retry_policy = if delay_override.is_some()
            || max_retry_attempts_override.is_some()
            || max_retry_duration_override.is_some()
        {
            RetryPolicy::FixedDelay {
                interval: delay_override.map(Duration::from_millis),
                max_attempts: max_retry_attempts_override,
                max_duration: max_retry_duration_override.map(Duration::from_millis),
                on_max_attempts: OnMaxAttempts::FailAsTerminal,
            }
        } else {
            RetryPolicy::Infinite
        };
        use_log_dispatcher!(self, |vm| CoreVM::propose_run_completion(
            vm,
            handle.into(),
            RunExitResult::RetryableFailure {
                attempt_duration: Duration::from_millis(attempt_duration),
                error: Error::internal(error_message)
                    .with_stacktrace(error_stacktrace.unwrap_or_default()),
            },
            retry_policy
        ))
        .map_err(Into::into)
    }

    pub fn propose_run_completion_failure_transient_with_pause(
        &mut self,
        handle: WasmNotificationHandle,
        error_message: String,
        error_stacktrace: Option<String>,
        attempt_duration: u64,
    ) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::propose_run_completion(
            vm,
            handle.into(),
            RunExitResult::RetryableFailure {
                attempt_duration: Duration::from_millis(attempt_duration),
                error: Error::internal(error_message)
                    .with_stacktrace(error_stacktrace.unwrap_or_default())
                    .with_should_pause(true),
            },
            RetryPolicy::Infinite
        ))
        .map_err(Into::into)
    }

    pub fn sys_cancel_invocation(
        &mut self,
        target_invocation_id: String,
    ) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_cancel_invocation(
            vm,
            target_invocation_id
        ))
        .map(Into::into)
        .map_err(Into::into)
    }

    pub fn sys_write_output_success(&mut self, buffer: Vec<u8>) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_write_output(
            vm,
            NonEmptyValue::Success(buffer.to_vec().into()),
            Default::default()
        ))
        .map(Into::into)
        .map_err(Into::into)
    }

    pub fn sys_write_output_failure(&mut self, value: WasmFailure) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, |vm| CoreVM::sys_write_output(
            vm,
            NonEmptyValue::Failure(value.into()),
            Default::default()
        ))
        .map(Into::into)
        .map_err(Into::into)
    }

    pub fn sys_end(&mut self) -> Result<(), WasmFailure> {
        use_log_dispatcher!(self, CoreVM::sys_end)
            .map(Into::into)
            .map_err(Into::into)
    }

    pub fn is_processing(&self) -> bool {
        use_log_dispatcher!(self, |vm| CoreVM::state(vm).is_processing())
    }

    pub fn last_command_index(&self) -> i32 {
        use_log_dispatcher!(self, |vm| CoreVM::last_command_index(vm) as i32)
    }
}

fn now_since_unix_epoch() -> Duration {
    Duration::from_millis(js_sys::Date::now() as u64)
}

// We need this wrapper for the shared core
struct WasmHeaderList(Vec<WasmHeader>);

impl From<Vec<WasmHeader>> for WasmHeaderList {
    fn from(value: Vec<WasmHeader>) -> Self {
        Self(value)
    }
}

impl HeaderMap for WasmHeaderList {
    type Error = Infallible;

    fn extract(&self, name: &str) -> Result<Option<&str>, Self::Error> {
        for WasmHeader { key, value } in &self.0 {
            if key.eq_ignore_ascii_case(name) {
                return Ok(Some(value));
            }
        }
        Ok(None)
    }
}

#[wasm_bindgen]
pub struct WasmIdentityVerifier {
    identity_verifier: IdentityVerifier,
}

#[wasm_bindgen]
impl WasmIdentityVerifier {
    #[wasm_bindgen(constructor)]
    pub fn new(keys: Vec<String>) -> Result<WasmIdentityVerifier, JsError> {
        let k: Vec<_> = keys.iter().map(|s| s.as_str()).collect();
        Ok(WasmIdentityVerifier {
            identity_verifier: IdentityVerifier::new(&k)?,
        })
    }

    pub fn verify_identity(&self, path: &str, headers: Vec<WasmHeader>) -> Result<(), JsError> {
        self.identity_verifier
            .verify_identity(&WasmHeaderList(headers), path)?;
        Ok(())
    }
}

#[wasm_bindgen]
pub fn cancel_handle() -> WasmNotificationHandle {
    CANCEL_NOTIFICATION_HANDLE.into()
}
