"""Usage tracking utilities for DSPy."""

from collections import defaultdict
from contextlib import contextmanager
from typing import Any, Generator

from pydantic import BaseModel

from dspy.dsp.utils.settings import settings


class UsageTracker:
    """Tracks LM usage data within a context."""

    def __init__(self):
        # Map of LM name to list of usage entries. For example:
        # {
        #     "openai/gpt-4o-mini": [
        #         {"prompt_tokens": 100, "completion_tokens": 200},
        #         {"prompt_tokens": 300, "completion_tokens": 400},
        #     ],
        # }
        self.usage_data = defaultdict(list)

    def _flatten_usage_entry(self, usage_entry: dict[str, Any]) -> dict[str, Any]:
        result = {}
        for key, value in usage_entry.items():
            if isinstance(value, BaseModel):
                # Convert Pydantic models to dicts, like `PromptTokensDetailsWrapper` from litellm.
                result[key] = value.model_dump()
            else:
                result[key] = value
        return result

    @staticmethod
    def _is_summable(value: Any) -> bool:
        """Whether a usage value is a count that can be added across entries.

        `bool` is excluded even though it is an `int` subclass: providers report flags
        (such as OpenRouter's `is_byok`) alongside token counts, and summing those would
        turn a flag into a meaningless tally.
        """
        return isinstance(value, (int, float)) and not isinstance(value, bool)

    def _merge_usage_entries(
        self, usage_entry1: dict[str, Any] | None, usage_entry2: dict[str, Any] | None
    ) -> dict[str, Any]:
        if usage_entry1 is None or len(usage_entry1) == 0:
            return dict(usage_entry2 or {})
        if usage_entry2 is None or len(usage_entry2) == 0:
            return dict(usage_entry1 or {})

        result = dict(usage_entry1)
        for k, v in usage_entry2.items():
            current_v = result.get(k)
            if isinstance(v, dict) or isinstance(current_v, dict):
                result[k] = self._merge_usage_entries(current_v, v)
            elif current_v is None:
                if v is not None:
                    result[k] = v
            elif self._is_summable(current_v) and self._is_summable(v):
                result[k] = current_v + v
            # Otherwise keep `current_v` as-is. `usage` is not guaranteed to hold only
            # counts: both litellm's `Usage` and dspy's `LMUsage` allow extra fields, so
            # whatever a provider reports flows through verbatim.
        return result

    def add_usage(self, lm: str, usage_entry: dict[str, Any]) -> None:
        """Add a usage entry to the tracker."""
        if len(usage_entry) > 0:
            self.usage_data[lm].append(self._flatten_usage_entry(usage_entry))

    def get_total_tokens(self) -> dict[str, dict[str, Any]]:
        """Calculate total tokens from all tracked usage."""
        total_usage_by_lm = {}
        for lm, usage_entries in self.usage_data.items():
            total_usage = {}
            for usage_entry in usage_entries:
                total_usage = self._merge_usage_entries(total_usage, usage_entry)
            total_usage_by_lm[lm] = total_usage
        return total_usage_by_lm


@contextmanager
def track_usage() -> Generator[UsageTracker, None, None]:
    """Context manager for tracking LM usage.

    When nested, the child will roll-up recorded usage into the parent upon exit.
    Note that usage added after the scope exit will not be recorded in the parent.
    """
    tracker = UsageTracker()

    parent = settings.usage_tracker
    with settings.context(usage_tracker=tracker):
        try:
            yield tracker
        finally:
            if parent is not None:
                for lm, entries in tracker.usage_data.items():
                    parent.usage_data[lm].extend(entries)
