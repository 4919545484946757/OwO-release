"""lm15 — a provider-neutral, low-level foundation for talking to LLM APIs.

lm15 is deliberately NOT a user-facing convenience layer. It is the dependency
for libraries that want to build their own take on the right Python API for
AI systems: one canonical representation (Request/Response/Message/Part,
stream events, errors), exact serde for it, and adapters that translate it to
and from each provider's wire format — stdlib-only, with its own HTTP
transport. Build your DSL on top; let lm15 handle the providers.

Conformance to the canonical representation is pinned by the lm15-contract
corpus; this package is the reference implementation, not the spec.

Quick tour:

    from lm15 import AnthropicLM, Request, Message

    lm = AnthropicLM(api_key="...")
    response = lm.complete(Request(model="claude-sonnet-4-5",
                                   messages=(Message.user("hello"),)))
    response.text          # canonical accessors
    for event in lm.stream(request): ...   # canonical stream events

The top level is curated for application developers.  Deeper audiences
import one module (API review, 2026-07-13):
`lm15.serde` (the complete to_dict/from_dict pairs), `lm15.providers`
(BaseProviderLM, ProviderDialect, transports protocols, Credential),
`lm15.errors` (map_http_error and friends), `lm15.registry` (the one
table of named providers: PROVIDERS / ProviderDefinition — dialect,
access policy, compat preset, console URL), `lm15.router` (the
RouteRule/DEFAULT_RULES tables and the ADAPTERS/CHAT_PRESET_ROUTES views
of the registry),
`lm15.profiles` / `lm15.compat` (profile and compat-policy machinery),
`lm15.sse`, `lm15.transports` (HTTP plumbing), `lm15.live` (realtime
sessions; optional `websockets` dependency), `lm15.auth` (local
subscription credentials: locked, atomic, double-checked refresh),
`lm15.authkit` (login-flow primitives: PKCE, device-code polling,
loopback listener, credential store), `lm15.doctor` (`explain_auth`:
rung-by-rung credential resolution, no secrets rendered), and
`lm15.vet` (the conformance shim CLI: `python -m lm15.vet`).

Migrating from the OpenAI SDK or litellm:
`LMRouter().complete_from_openai_chat(model, messages, **kwargs)` takes
their supported request options (their model strings too) and answers with
a `Response`. With `stream=True` it returns a lazy `ResponseStream`:
iterate text, then read `.response`; use `with` for early-exit cleanup.
`RouterConfig(api_keys={"openai": key})` supplies both OpenAI APIs;
exact endpoint entries still override shared credentials.
Underneath: `request_from_openai_chat(body, compat=...)` reads the JSON a
client would POST to `/chat/completions` into a `Request`, or refuses
with the key named (MAP-12), and
`response_from_openai_chat(body)` reads a Chat Completions response body
(a server's, or litellm's `ModelResponse.model_dump()`) into a `Response`
with the same reader the OpenAI Chat adapter uses (docs/migrating-from-
openai-chat.md).  They are the only place lm15 reads a foreign format.

The lowercase part-factory helpers (`text`, `image`, `tool_call`, ...) live in
`lm15.types`, not at the top level — generic lowercase names at package top
level invite collisions with user code.
"""

from ._version import __version__

# ── Canonical types ──────────────────────────────────────────────────
from .batch import AsyncBatchJob, BatchJob
from .video_jobs import AsyncVideoJob, VideoJob
from .live import Turn
from .types import (
    # request/response core
    Request,
    Response,
    Message,
    Usage,
    Config,
    CacheConfig,
    Reasoning,
    ToolChoice,
    ErrorDetail,
    ContinuationState,
    # parts
    TextPart,
    ThinkingPart,
    RefusalPart,
    CitationPart,
    ImagePart,
    AudioPart,
    VideoPart,
    DocumentPart,
    BinaryPart,
    ToolCallPart,
    ToolResultPart,
    DataPart,
    # tools
    FunctionTool,
    BuiltinTool,
    ToolCallInfo,
    # logprobs
    TokenLogprob,
    TopLogprob,
    # streaming
    StreamStartEvent,
    StreamDeltaEvent,
    StreamEndEvent,
    StreamErrorEvent,
    TextDelta,
    ThinkingDelta,
    AudioDelta,
    ImageDelta,
    ToolCallDelta,
    CitationDelta,
    ContinuationDelta,
    # auxiliary endpoints
    FileUploadRequest,
    FileInfo,
    FilePage,
    CacheInfo,
    CachePage,
    CachedPrefix,
    BatchRequest,
    BatchEntry,
    BatchJobInfo,
    VideoGenerationRequest,
    VideoJobInfo,
    ImageGenerationRequest,
    ImageGenerationResponse,
    SpeechGenerationRequest,
    SpeechGenerationResponse,
    AudioFormat,
    # live session types
    LiveConfig,
    # part factory for tool results (the one lowercase factory beginners
    # need at the top level; the rest stay in lm15.types)
    tool_result,
    # vocabulary aliases + constants
    Role,
    PartType,
    FinishReason,
    ReasoningEffort,
    ErrorCode,
    StreamEventType,
    ROLE_VALUES,
    FINISH_REASONS,
    ERROR_CODES,
)

# ── Access policies (auth by composition; spec/auth.md AUTH-10) ──────
from .features import AccessPolicy, EndpointSupport

# ── Errors ───────────────────────────────────────────────────────────
from .errors import (
    LM15Error,
    StreamAssemblyError,
    CollectionLimitError,
    StreamCleanupWarning,
    TransportError,
    LockTimeoutError,
    ConfigurationError,
    CapabilityError,
    ProviderError,
    AuthError,
    BillingError,
    RateLimitError,
    InvalidRequestError,
    ContextLengthError,
    TimeoutError,
    ServerError,
    UnsupportedModelError,
    UnsupportedFeatureError,
    NotConfiguredError,
    RETRYABLE_ERRORS,
)

# ── Providers ────────────────────────────────────────────────────────
from .providers import (
    OpenAILM,
    OpenAIChatLM,
    AnthropicLM,
    GeminiLM,
    ClaudeCodeLM,
    OpenAICodexLM,
    XaiLM,
    TypeSafeLM,
)
from .providers.openai_chat import request_from_openai_chat, response_from_openai_chat
from .protocols import ProviderLM
from .providers.async_base import (
    AsyncOpenAILM,
    AsyncOpenAIChatLM,
    AsyncAnthropicLM,
    AsyncGeminiLM,
    AsyncClaudeCodeLM,
    AsyncOpenAICodexLM,
    AsyncXaiLM,
    AsyncTypeSafeLM,
)

# ── Stream assembly ──────────────────────────────────────────────────
from .result import (
    ResponseStream,
    AsyncResponseStream,
    amaterialize_response,
    materialize_response,
    response_to_events,
)

# ── Model metadata (catalog hydration) ──────────────────────────────
from .models import ModelInfo, ModelRegistry

# ── Router (lm15.router) ─────────────────────────────────────────────
from .router import (
    AmbiguousModelError,
    AsyncLMRouter,
    LMRouter,
    MissingCredentialError,
    Resolution,
    RouterConfig,
    UnknownModelError,
)

# ── Connection budget (lm15.transports) ───────────────────────────────
from .transports import Timeouts

# ── MAP-13 adaptations (lm15.adaptation) ──────────────────────────────
from .adaptation import Adaptation, AdaptationPolicy

# ── Tool derivation (lm15.tools) ─────────────────────────────────────
from .tools import (
    DerivedParam,
    ToolConfig,
    ToolDerivation,
    ToolDerivationError,
    tool,
)
from .tools import derive as derive_tool

# ── Judgments (changes/2026-09-17-judgments.md) ─────────────────────
from .judgments import choice, judgments, score, yes_no
from .types import data

__all__ = [
    "__version__",
    # core
    "Request", "Response", "Message", "Usage", "Config", "CacheConfig",
    "Reasoning", "ToolChoice", "ErrorDetail", "ContinuationState",
    # parts
    "TextPart", "ThinkingPart", "RefusalPart", "CitationPart", "DataPart", "ImagePart",
    "AudioPart", "VideoPart", "DocumentPart", "BinaryPart", "ToolCallPart",
    "ToolResultPart",
    # tools
    "FunctionTool", "BuiltinTool", "ToolCallInfo", "tool_result",
    # logprobs
    "TokenLogprob", "TopLogprob",
    # streaming
    "StreamStartEvent", "StreamDeltaEvent", "StreamEndEvent",
    "StreamErrorEvent", "TextDelta", "ThinkingDelta", "AudioDelta",
    "ImageDelta", "ToolCallDelta", "CitationDelta", "ContinuationDelta",
    # auxiliary endpoints
    "FileUploadRequest", "FileInfo", "FilePage",
    "CacheInfo", "CachePage", "CachedPrefix",
    "BatchRequest", "BatchJobInfo", "BatchEntry",
    "VideoGenerationRequest", "VideoJobInfo", "VideoJob", "AsyncVideoJob",
    "BatchJob", "AsyncBatchJob",
    "ImageGenerationRequest", "ImageGenerationResponse",
    "SpeechGenerationRequest", "SpeechGenerationResponse", "AudioFormat",
    "LiveConfig", "Turn",
    # vocabularies
    "Role", "PartType", "FinishReason", "ReasoningEffort", "ErrorCode",
    "StreamEventType", "ROLE_VALUES", "FINISH_REASONS", "ERROR_CODES",
    # errors (the catchable taxonomy + the retry predicate)
    "LM15Error", "TransportError", "LockTimeoutError", "StreamAssemblyError", "CollectionLimitError", "StreamCleanupWarning", "ConfigurationError", "CapabilityError",
    "ProviderError", "AuthError", "BillingError", "RateLimitError",
    "InvalidRequestError", "ContextLengthError", "TimeoutError",
    "ServerError", "UnsupportedModelError", "UnsupportedFeatureError",
    "NotConfiguredError", "RETRYABLE_ERRORS",
    "AccessPolicy", "EndpointSupport",
    # providers
    "choice", "judgments", "score", "yes_no", "data",
    "OpenAILM", "OpenAIChatLM", "AnthropicLM", "GeminiLM", "ClaudeCodeLM", "OpenAICodexLM", "XaiLM", "TypeSafeLM", "AsyncTypeSafeLM",
    "ProviderLM",
    # the Chat Completions dialect read in: a request body -> Request (MAP-12), a response body -> Response
    "request_from_openai_chat", "response_from_openai_chat",
    # async mirror providers
    "AsyncOpenAILM", "AsyncOpenAIChatLM", "AsyncAnthropicLM", "AsyncGeminiLM",
    "AsyncClaudeCodeLM", "AsyncOpenAICodexLM", "AsyncXaiLM",
    # stream assembly
    "ResponseStream", "AsyncResponseStream",
    "materialize_response", "amaterialize_response", "response_to_events",
    # model metadata (catalog hydration)
    "ModelInfo", "ModelRegistry",
    # router (lm15.router; the rule/preset tables live there too)
    "LMRouter", "AsyncLMRouter", "RouterConfig", "Resolution",
    "Timeouts",
    "Adaptation", "AdaptationPolicy",
    "UnknownModelError",
    "AmbiguousModelError", "MissingCredentialError",
    # tool derivation (lm15.tools)
    "tool", "derive_tool", "ToolConfig", "ToolDerivation", "DerivedParam",
    "ToolDerivationError",
]
