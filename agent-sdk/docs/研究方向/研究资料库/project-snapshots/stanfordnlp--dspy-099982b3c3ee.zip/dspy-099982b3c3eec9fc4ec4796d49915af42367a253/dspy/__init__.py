import threading

from dspy import lm15 as lm15
from dspy.predict import *
from dspy.primitives import *
from dspy.retrievers import *
from dspy.signatures import *
from dspy.teleprompt import *
from dspy.predict.flex import Flex

from dspy.evaluate import Evaluate  # isort: skip
from dspy.clients import *  # isort: skip
from dspy.adapters import Adapter, ChatAdapter, JSONAdapter, XMLAdapter, TwoStepAdapter, Image, Audio, File, History, Type, Tool, ToolCalls, ToolCallResults, Code, Reasoning  # isort: skip
from dspy.primitives.sandbox_serializable import SandboxSerializable  # isort: skip
from dspy.utils.exceptions import (
    AdapterParseError,
    ContextWindowExceededError,
    DSPyError,
    LMAuthError,
    LMBillingError,
    LMCollectionLimitError,
    LMConfigurationError,
    LMError,
    LMInvalidRequestError,
    LMLockTimeoutError,
    LMNotConfiguredError,
    LMProviderError,
    LMRateLimitError,
    LMServerError,
    LMStreamAssemblyError,
    LMTimeoutError,
    LMTransportError,
    LMUnexpectedError,
    LMUnsupportedFeatureError,
    LMUnsupportedModelError,
    is_retryable_lm_error,
)
from dspy.utils.logging_utils import configure_dspy_loggers, disable_logging, enable_logging
from dspy.utils.asyncify import asyncify
from dspy.utils.syncify import syncify
from dspy.utils.saving import load
from dspy.streaming.streamify import streamify
from dspy.utils.usage_tracker import track_usage

from dspy.dsp.utils.settings import settings
from dspy.dsp.colbertv2 import ColBERTv2
from dspy.__metadata__ import __name__, __version__, __description__, __url__, __author__, __author_email__

configure_dspy_loggers(__name__)

# Singleton definitions and aliasing
configure = settings.configure
load_settings = settings.load
context = settings.context

BootstrapRS = BootstrapFewShotWithRandomSearch

_cache_lock = threading.Lock()


def __getattr__(name):
    """Defer building the cache until it's read, so that configure_cache can fully disable caching if desired."""
    if name == "cache":
        from dspy.clients import _get_dspy_cache

        with _cache_lock:
            if "cache" not in globals():
                globals()["cache"] = _get_dspy_cache()
            return globals()["cache"]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
