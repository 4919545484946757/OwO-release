import secrets

import click

from constants.languages import languages
from extensions.ext_application_services import application_services
from libs.helper import email as email_validate
from libs.password import password_pattern, valid_password


@click.command("reset-password", help="Reset the account password.")
@click.option("--email", prompt=True, help="Account email to reset password for")
@click.option("--new-password", prompt=True, help="New password")
@click.option("--password-confirm", prompt=True, help="Confirm new password")
def reset_password(email, new_password, password_confirm):
    """
    Reset password of owner account
    Only available in SELF_HOSTED mode
    """
    if new_password.strip() != password_confirm.strip():
        click.echo(click.style("Passwords do not match.", fg="red"))
        return
    normalized_email = email.strip().lower()

    account = application_services().accounts.lifecycle.get_account_by_email_with_case_fallback(email.strip())

    if not account:
        click.echo(click.style(f"Account not found for email: {email}", fg="red"))
        return

    try:
        valid_password(new_password)
    except ValueError:
        click.echo(click.style(f"Invalid password. Must match {password_pattern}", fg="red"))
        return

    application_services().accounts.lifecycle.reset_password(account.id, new_password, email=normalized_email)
    click.echo(click.style("Password reset successfully.", fg="green"))


@click.command("reset-email", help="Reset the account email.")
@click.option("--email", prompt=True, help="Current account email")
@click.option("--new-email", prompt=True, help="New email")
@click.option("--email-confirm", prompt=True, help="Confirm new email")
def reset_email(email, new_email, email_confirm):
    """
    Replace account email
    :return:
    """
    if new_email.strip() != email_confirm.strip():
        click.echo(click.style("New emails do not match.", fg="red"))
        return
    normalized_new_email = new_email.strip().lower()

    account = application_services().accounts.lifecycle.get_account_by_email_with_case_fallback(email.strip())

    if not account:
        click.echo(click.style(f"Account not found for email: {email}", fg="red"))
        return

    try:
        email_validate(normalized_new_email)
    except ValueError:
        click.echo(click.style(f"Invalid email: {new_email}", fg="red"))
        return

    application_services().accounts.lifecycle.set_email(account.id, normalized_new_email)
    click.echo(click.style("Email updated successfully.", fg="green"))


@click.command("create-tenant", help="Create account and tenant.")
@click.option("--email", prompt=True, help="Tenant account email.")
@click.option("--name", prompt=True, help="Workspace name.")
@click.option("--language", prompt=True, help="Account language, default: en-US.")
def create_tenant(email: str, language: str | None = None, name: str | None = None):
    """
    Create tenant account
    """
    if not email:
        click.echo(click.style("Email is required.", fg="red"))
        return

    # Create account
    email = email.strip().lower()

    if "@" not in email:
        click.echo(click.style("Invalid email address.", fg="red"))
        return

    account_name = email.split("@")[0]

    if language not in languages:
        language = "en-US"

    # Validates name encoding for non-Latin characters.
    name = name.strip().encode("utf-8").decode("utf-8") if name else None

    # Generate a random password that satisfies the password policy.
    # The iteration limit guards against infinite loops caused by unexpected bugs in valid_password.
    for _ in range(100):
        new_password = secrets.token_urlsafe(16)
        try:
            valid_password(new_password)
            break
        except Exception:
            continue
    else:
        click.echo(click.style("Failed to generate a valid password. Please try again.", fg="red"))
        return

    # register account
    account = application_services().accounts.lifecycle.register(
        email=email,
        name=account_name,
        password=new_password,
        language=language,
        create_workspace_required=False,
    )
    application_services().workspaces.provisioning.create_owner_workspace(account.id, name=name, if_missing=True)

    click.echo(
        click.style(
            f"Account and tenant created.\nAccount: {email}\nPassword: {new_password}",
            fg="green",
        )
    )
