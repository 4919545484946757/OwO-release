from __future__ import annotations

import json
import logging
from collections.abc import Generator, Iterable, Mapping
from typing import Any, override

from flask import Response
from flask_restx import Resource
from sqlalchemy.orm import Session
from werkzeug.exceptions import BadRequest

from constants.oauth_bearer import Scope
from controllers.common.human_input import stringify_form_default_values
from controllers.common.rbac import PlainApp, RBACCheck, RBACPermission
from controllers.openapi import openapi_ns
from controllers.openapi._contract import Example, Kind, endpoint, op_of
from controllers.openapi._errors import HumanInputFormNotFound, RecipientSurfaceMismatch
from controllers.openapi._files import end_read_transaction, merge_files
from controllers.openapi._hints import attach_stream_hints
from controllers.openapi._models import (
    FormSubmitResponse,
    Hint,
    HumanInputFormDefinitionResponse,
    OpenApiFormSubmitPayload,
)
from controllers.openapi.auth.context import Context
from controllers.openapi.auth.loaders import PathParam, load_app
from controllers.openapi.auth.requirements import (
    CheckAppAccess,
    CheckAppApiEnabled,
    CheckRBACPermission,
    CheckScope,
    CheckSubject,
    CheckWorkspaceMember,
    Requirement,
)
from controllers.openapi.auth.subjects import AccountSubject, ExternalSsoSubject, Subject
from core.app.entities.task_entities import HumanInputRequiredResponse, StreamEvent
from core.db.session_factory import session_factory
from core.workflow.human_input_policy import HumanInputSurface, is_recipient_type_allowed_for_surface
from extensions.ext_database import db
from libs.helper import to_timestamp
from models.enums import CreatorUserRole
from models.model import App
from services.human_input_service import FormNotFoundError, HumanInputService

logger = logging.getLogger(__name__)


class CheckFormSurface(Requirement):
    """`/openapi/v1` is allowed only the recipient types `human_input_policy` lists
    for it, so a console-bound form is refused before any handler body runs. It
    lives here rather than in `auth/requirements.py` so the auth layer never has
    to import this feature's domain.

    A form the caller could not have found anyway — missing, or belonging to
    another app — is left to the handler's own 404: answering 403 here would tell
    an outsider the form token exists.
    """

    @override
    def run(self, subject: Subject, ctx: Context, session: Session) -> None:
        form_token = ctx.view_args[PathParam.FORM_TOKEN]
        app = load_app(ctx)
        # `HumanInputService` takes an engine or a maker, never a `Session`, so this
        # read is a separate transaction from the handler's — as it was before the move.
        form = HumanInputService(session_factory.get_session_maker()).get_form_by_token(form_token)
        if form is None or form.app_id != app.id or form.tenant_id != app.tenant_id:
            return
        if not is_recipient_type_allowed_for_surface(form.recipient_type, HumanInputSurface.OPENAPI):
            raise RecipientSurfaceMismatch()


def _jsonify_form_definition(form) -> Response:
    definition_payload = form.get_definition().model_dump()
    payload = {
        "form_content": definition_payload["rendered_content"],
        "inputs": definition_payload["inputs"],
        "resolved_default_values": stringify_form_default_values(definition_payload["default_values"]),
        "user_actions": definition_payload["user_actions"],
        "expiration_time": to_timestamp(form.expiration_time),
    }
    return Response(json.dumps(payload, ensure_ascii=False), mimetype="application/json")


def _ensure_form_belongs_to_app(form, app_model: App) -> None:
    if form.app_id != app_model.id or form.tenant_id != app_model.tenant_id:
        raise HumanInputFormNotFound()


@openapi_ns.route("/apps/<string:app_id>/human-input-forms/<string:form_token>")
class OpenApiWorkflowHumanInputFormApi(Resource):
    @endpoint(
        op="describe.run.form",
        kind=Kind.OBJECT,
        summary="Read a human-input form",
        examples=(
            Example(
                title="Read the form a paused run is waiting on",
                input={"app_id": "<app_id>", "form_token": "<form_token>"},
            ),
        ),
        requirements=(
            CheckSubject(allowed=(AccountSubject, ExternalSsoSubject)),
            CheckAppApiEnabled(),
            CheckWorkspaceMember(),
            CheckScope(Scope.APPS_RUN),
            CheckRBACPermission(RBACCheck(RBACPermission.APP_TEST_AND_RUN, PlainApp())),
            CheckAppAccess(),
            CheckFormSurface(),
        ),
        returns=(200, HumanInputFormDefinitionResponse, "Form definition"),
    )
    def get(self, ctx: Context, app_id: str, form_token: str):
        service = HumanInputService(db.engine)
        form = service.get_form_by_token(form_token)
        if form is None:
            raise HumanInputFormNotFound()

        _ensure_form_belongs_to_app(form, ctx.app)
        service.ensure_form_active(form)
        return _jsonify_form_definition(form)


@openapi_ns.route("/apps/<string:app_id>/human-input-forms/<string:form_token>:submit")
class OpenApiWorkflowHumanInputFormSubmitApi(Resource):
    @endpoint(
        op="submit.run.form",
        kind=Kind.OBJECT,
        summary="Submit a human-input form",
        examples=(
            Example(
                title="Approve a paused run with a written comment",
                input={
                    "app_id": "<app_id>",
                    "form_token": "<form_token>",
                    "action": "approve",
                    "inputs": {"comment": "Looks good"},
                },
            ),
            Example(
                title="Submit a form answer that includes a local file",
                input={
                    "app_id": "<app_id>",
                    "form_token": "<form_token>",
                    "action": "submit",
                    "inputs": {},
                    "files": {"evidence": "./scan.png"},
                },
            ),
        ),
        requirements=(
            CheckSubject(allowed=(AccountSubject, ExternalSsoSubject)),
            CheckAppApiEnabled(),
            CheckWorkspaceMember(),
            CheckScope(Scope.APPS_RUN),
            CheckRBACPermission(RBACCheck(RBACPermission.APP_TEST_AND_RUN, PlainApp())),
            CheckAppAccess(),
            CheckFormSurface(),
        ),
        body=OpenApiFormSubmitPayload,
        returns=(200, FormSubmitResponse, "Form submitted"),
    )
    def post(self, ctx: Context, app_id: str, form_token: str, *, body: OpenApiFormSubmitPayload):
        service = HumanInputService(db.engine)
        form = service.get_form_by_token(form_token)
        if form is None:
            raise HumanInputFormNotFound()

        _ensure_form_belongs_to_app(form, ctx.app)

        submission_user_id: str | None = None
        submission_end_user_id: str | None = None
        if ctx.subject.caller_role is CreatorUserRole.ACCOUNT:
            submission_user_id = ctx.account.id
        else:
            submission_end_user_id = ctx.end_user.id

        if form.recipient_type is None:
            logger.warning("Recipient type is None for form, form_token=%s", form_token)
            raise BadRequest("Form recipient type is invalid")

        if body.files:
            end_read_transaction(ctx.session)
        inputs = merge_files(body.inputs, body.files, ctx.caller)

        try:
            service.submit_form_by_token(
                recipient_type=form.recipient_type,
                form_token=form_token,
                selected_action_id=body.action,
                form_data=inputs,
                submission_user_id=submission_user_id,
                submission_end_user_id=submission_end_user_id,
            )
        except FormNotFoundError:
            raise HumanInputFormNotFound()

        return FormSubmitResponse()


def form_hints(*, op: str, app_id: str, response: HumanInputRequiredResponse) -> list[Hint]:
    """One hint per action button of a paused form, its `inputs` blanked to the form's fields."""

    data = response.data
    if not data.form_token:
        return []
    fields = [field.model_dump(mode="json") for field in data.inputs]
    blank = {field.output_variable_name: None for field in data.inputs}
    return [
        Hint(
            summary=action.title or action.id,
            op=op,
            input={"app_id": app_id, "form_token": data.form_token, "action": action.id, "inputs": dict(blank)},
            form=fields,
        )
        for action in data.actions
    ]


def with_form_hints(events: Iterable[str], *, app_id: str) -> Generator[str]:
    """A run stream whose `human_input_required` events carry hints that target the submit route above."""

    op = op_of(OpenApiWorkflowHumanInputFormSubmitApi.post)

    def build(event: Mapping[str, Any]) -> list[Hint]:
        return form_hints(op=op, app_id=app_id, response=HumanInputRequiredResponse.model_validate(event))

    return attach_stream_hints(events, event=StreamEvent.HUMAN_INPUT_REQUIRED.value, build=build)
