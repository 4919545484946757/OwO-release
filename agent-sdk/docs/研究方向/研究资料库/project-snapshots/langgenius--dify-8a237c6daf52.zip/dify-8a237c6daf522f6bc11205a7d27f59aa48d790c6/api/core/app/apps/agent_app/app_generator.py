"""Agent App generator: orchestrate Agent App chat and finalize executions.

Agent App turns mirror the agent_chat generator (conversation + message +
queue + streamed response over the EasyUI chat pipeline), but the backing
config comes from the bound Agent Soul and the answer is produced by
``AgentAppRunner`` calling the dify-agent backend rather than an in-process
LLM/ReAct loop. Build-chat finalization uses this same streamed path and only
changes the runtime exit policy carried to the backend.
"""

from __future__ import annotations

import contextvars
import logging
import threading
import uuid
from collections.abc import Generator, Mapping
from typing import Any, Literal

from flask import Flask, current_app
from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from clients.agent_backend import AgentBackendRunEventAdapter
from clients.agent_backend.factory import create_agent_backend_run_client
from configs import dify_config
from constants import UUID_NIL
from core.agent.publish_visibility import agent_has_workflow_callable_active_snapshot
from core.app.app_config.easy_ui_based_app.model_config.converter import ModelConfigConverter
from core.app.app_config.features.file_upload.manager import FileUploadConfigManager
from core.app.apps.agent_app.app_config_manager import AgentAppConfigManager
from core.app.apps.agent_app.app_runner import AgentAppRunner
from core.app.apps.agent_app.errors import (
    AgentAppGeneratorError,
    AgentAppNotPublishedError,
)
from core.app.apps.agent_app.generate_response_converter import AgentAppGenerateResponseConverter
from core.app.apps.agent_app.runtime_request_builder import AgentAppRuntimeRequestBuilder
from core.app.apps.agent_app.session_store import AgentAppWorkspaceStore
from core.app.apps.base_app_queue_manager import AppQueueManager, PublishFrom
from core.app.apps.exc import GenerateTaskStoppedError
from core.app.apps.message_based_app_generator import MessageBasedAppGenerator
from core.app.apps.message_based_app_queue_manager import MessageBasedAppQueueManager
from core.app.entities.app_invoke_entities import (
    AgentAppGenerateEntity,
    DifyRunContext,
    InvokeFrom,
    UserFrom,
)
from core.credit_usage import CreditUsageAppType
from core.db.session_factory import session_factory
from core.ops.ops_trace_manager import TraceQueueManager
from extensions.ext_database import db
from factories import file_factory
from models import Account, App, AppModelConfig, Conversation, EndUser, Message, MessageAnnotation
from models.agent import (
    APP_BACKED_AGENT_SOURCES,
    Agent,
    AgentConfigDraft,
    AgentConfigDraftType,
    AgentConfigSnapshot,
    AgentConfigVersionKind,
    AgentScope,
    AgentStatus,
    AgentWorkspaceBinding,
    AgentWorkspaceOwnerType,
)
from models.agent_config_entities import AgentSoulConfig
from models.model import load_annotation_reply_config
from services.agent.workspace_service import AgentWorkspaceService, WorkspaceOwnerScope
from services.conversation_service import ConversationService

logger = logging.getLogger(__name__)


class AgentAppGenerator(MessageBasedAppGenerator):
    def generate(
        self,
        *,
        app_model: App,
        user: Account | EndUser,
        args: Mapping[str, Any],
        invoke_from: InvokeFrom,
        session: Session,
        streaming: bool = True,
    ) -> Mapping[str, Any] | Generator[Mapping | str]:
        if not streaming:
            raise AgentAppGeneratorError("Agent App only supports streaming mode")

        query = self._require_query(args)
        inputs = args["inputs"]
        raw_files = args.get("files") or []

        conversation = None
        conversation_id = args.get("conversation_id")
        if conversation_id:
            conversation = ConversationService.get_conversation(
                app_model=app_model, conversation_id=conversation_id, user=user, session=session
            )

        # New conversations use the current Agent generation. Existing
        # conversations use the immutable generation named by their Binding.
        agent, agent_config_id, agent_config_version_kind, agent_soul = self._resolve_agent(
            app_model,
            invoke_from=invoke_from,
            draft_type=args.get("draft_type"),
            user=user,
            session=session,
            conversation=conversation,
        )
        session_scope_config_version_id = self._session_scope_config_version_id(
            invoke_from=invoke_from,
            config_version_id=agent_config_id,
        )

        # Build the EasyUI-shaped config from the Agent Soul so the chat pipeline
        # can persist usage; the answer itself comes from the agent backend.
        app_model_config = (
            session.get(AppModelConfig, app_model.app_model_config_id) if app_model.app_model_config_id else None
        )
        annotation_reply = load_annotation_reply_config(session, app_model.id) if app_model_config else None
        app_config = AgentAppConfigManager.get_app_config(
            app_model=app_model,
            agent_soul=agent_soul,
            annotation_reply=annotation_reply,
            app_model_config=app_model_config,
            conversation=conversation,
        )
        model_conf = ModelConfigConverter.convert(app_config)
        with self._bind_file_access_scope(tenant_id=app_model.tenant_id, user=user, invoke_from=invoke_from):
            file_upload_config = (
                FileUploadConfigManager.convert(app_config.app_model_config_dict, is_vision=True) if raw_files else None
            )
            file_objs = (
                file_factory.build_from_mappings(
                    mappings=raw_files,
                    tenant_id=app_model.tenant_id,
                    config=file_upload_config,
                    access_controller=self._file_access_controller,
                )
                if raw_files and file_upload_config is not None
                else []
            )

        trace_manager = TraceQueueManager(app_model.id, user.id if isinstance(user, Account) else user.session_id)
        application_generate_entity = AgentAppGenerateEntity(
            task_id=str(uuid.uuid4()),
            app_config=app_config,
            model_conf=model_conf,
            file_upload_config=file_upload_config,
            conversation_id=conversation.id if conversation else None,
            inputs=self._prepare_user_inputs(
                user_inputs=inputs, variables=app_config.variables, tenant_id=app_model.tenant_id
            ),
            query=query,
            files=list(file_objs),
            parent_message_id=(
                args.get("parent_message_id")
                if invoke_from not in {InvokeFrom.SERVICE_API, InvokeFrom.OPENAPI}
                else UUID_NIL
            ),
            user_id=user.id,
            stream=streaming,
            invoke_from=invoke_from,
            extras={
                "auto_generate_conversation_name": args.get("auto_generate_name", True),
            },
            call_depth=0,
            trace_manager=trace_manager,
            agent_id=agent.id,
            agent_config_snapshot_id=agent_config_id,
            agent_config_version_kind=agent_config_version_kind,
            agent_session_scope_config_version_id=session_scope_config_version_id,
            agent_llm_gateway_enabled=True,
        )

        conversation, message = self._init_generate_records(
            application_generate_entity,
            conversation,
            session=session,
        )

        queue_manager = MessageBasedAppQueueManager(
            task_id=application_generate_entity.task_id,
            user_id=application_generate_entity.user_id,
            invoke_from=application_generate_entity.invoke_from,
            conversation_id=conversation.id,
            app_mode=conversation.mode,
            message_id=message.id,
        )

        context = contextvars.copy_context()
        worker_thread = threading.Thread(
            target=self._generate_worker,
            kwargs={
                "flask_app": current_app._get_current_object(),  # type: ignore
                "context": context,
                "application_generate_entity": application_generate_entity,
                "queue_manager": queue_manager,
                "conversation_id": conversation.id,
                "message_id": message.id,
                "user_from": UserFrom.ACCOUNT if isinstance(user, Account) else UserFrom.END_USER,
            },
        )
        worker_thread.start()

        response = self._handle_response(
            application_generate_entity=application_generate_entity,
            queue_manager=queue_manager,
            conversation=conversation,
            message=message,
            user=user,
            stream=streaming,
        )
        return AgentAppGenerateResponseConverter.convert(response=response, invoke_from=invoke_from)

    def _generate_worker(
        self,
        *,
        flask_app: Flask,
        context: contextvars.Context,
        application_generate_entity: AgentAppGenerateEntity,
        queue_manager: AppQueueManager,
        conversation_id: str,
        message_id: str,
        user_from: UserFrom,
    ) -> None:
        from libs.flask_utils import preserve_flask_contexts

        with preserve_flask_contexts(flask_app, context_vars=context):
            try:
                conversation = self._get_conversation(conversation_id)
                message = self._get_message(message_id)
                app_config = application_generate_entity.app_config

                # Apply app-level input guards (content moderation + annotation
                # reply) before reaching the Agent backend, mirroring the EasyUI
                # chat / agent-chat runners. These can short-circuit the turn.
                with session_factory.get_session_maker().begin() as session:
                    app_model = session.get(App, app_config.app_id)
                    if app_model is None:
                        raise AgentAppGeneratorError("App not found")
                    handled, query, annotation_reply = self._run_input_guards(
                        session=session,
                        application_generate_entity=application_generate_entity,
                        app_model=app_model,
                        message=message,
                        queue_manager=queue_manager,
                    )
                if annotation_reply:
                    from core.app.apps.agent_app.app_runner import publish_text_answer
                    from core.app.entities.queue_entities import QueueAnnotationReplyEvent

                    queue_manager.publish(
                        QueueAnnotationReplyEvent(message_annotation_id=annotation_reply.id),
                        PublishFrom.APPLICATION_MANAGER,
                    )
                    publish_text_answer(
                        queue_manager=queue_manager,
                        model_name=application_generate_entity.model_conf.model,
                        answer=annotation_reply.content,
                        user_query=query,
                    )
                if handled:
                    return

                dify_context = DifyRunContext(
                    tenant_id=app_config.tenant_id,
                    app_id=app_config.app_id,
                    user_id=application_generate_entity.user_id,
                    user_from=user_from,
                    invoke_from=application_generate_entity.invoke_from,
                    app_type=CreditUsageAppType.AGENT_V2,
                )
                with session_factory.create_session() as session:
                    agent, config_version, agent_soul = self._resolve_agent_by_id(
                        tenant_id=app_config.tenant_id,
                        agent_id=application_generate_entity.agent_id,
                        snapshot_id=application_generate_entity.agent_config_snapshot_id,
                        session=session,
                    )

                runner = self._build_runner()
                image_detail_config = (
                    application_generate_entity.file_upload_config.image_config.detail
                    if (
                        application_generate_entity.file_upload_config
                        and application_generate_entity.file_upload_config.image_config
                    )
                    else None
                )
                runner.run(
                    dify_context=dify_context,
                    agent_id=application_generate_entity.agent_id,
                    agent_config_snapshot_id=application_generate_entity.agent_config_snapshot_id,
                    agent_config_version_kind=application_generate_entity.agent_config_version_kind,
                    agent_soul=agent_soul,
                    home_snapshot_id=config_version.home_snapshot_id,
                    conversation_id=conversation.id,
                    query=query,
                    message_id=message.id,
                    model_name=application_generate_entity.model_conf.model,
                    queue_manager=queue_manager,
                    files=list(application_generate_entity.files),
                    image_detail_config=image_detail_config,
                    session_scope_snapshot_id=application_generate_entity.agent_session_scope_config_version_id,
                    build_draft_id=(
                        application_generate_entity.agent_config_snapshot_id
                        if application_generate_entity.agent_config_version_kind == AgentConfigVersionKind.BUILD_DRAFT
                        else None
                    ),
                )
            except GenerateTaskStoppedError:
                pass
            except Exception as e:
                logger.exception("Unknown Error in Agent App generate worker")
                queue_manager.publish_error(e, PublishFrom.APPLICATION_MANAGER)
            finally:
                db.session.close()

    @staticmethod
    def _require_query(args: Mapping[str, Any]) -> str:
        query = args.get("query")
        if not isinstance(query, str) or not query.strip():
            raise AgentAppGeneratorError("query is required")
        return query.replace("\x00", "")

    @staticmethod
    def _build_runner() -> AgentAppRunner:
        return AgentAppRunner(
            request_builder=AgentAppRuntimeRequestBuilder(),
            agent_backend_client=create_agent_backend_run_client(
                base_url=dify_config.AGENT_BACKEND_BASE_URL,
                api_token=dify_config.AGENT_BACKEND_API_TOKEN,
                use_fake=dify_config.AGENT_BACKEND_USE_FAKE,
                fake_scenario=dify_config.AGENT_BACKEND_FAKE_SCENARIO,
                stream_read_timeout_seconds=dify_config.AGENT_BACKEND_STREAM_READ_TIMEOUT_SECONDS,
                stream_max_reconnects=dify_config.AGENT_BACKEND_STREAM_MAX_RECONNECTS,
            ),
            event_adapter=AgentBackendRunEventAdapter(),
            session_store=AgentAppWorkspaceStore(),
            text_delta_debounce_seconds=dify_config.AGENT_APP_TEXT_DELTA_DEBOUNCE_SECONDS,
        )

    def _run_input_guards(
        self,
        *,
        session: Session,
        application_generate_entity: AgentAppGenerateEntity,
        app_model: App,
        message: Message,
        queue_manager: AppQueueManager,
    ) -> tuple[bool, str, MessageAnnotation | None]:
        """Apply input moderation + annotation reply before the backend call.

        Returns ``(handled, query, annotation_reply)``. Annotation output is
        published by the caller only after this transaction commits.
        """
        from core.app.apps.agent_app.app_runner import publish_text_answer
        from core.app.features.annotation_reply.annotation_reply import AnnotationReplyFeature
        from core.moderation.base import ModerationError
        from core.moderation.input_moderation import InputModeration

        app_config = application_generate_entity.app_config
        model_name = application_generate_entity.model_conf.model
        query = application_generate_entity.query or ""

        # content moderation (sensitive_word_avoidance); a blocked input yields a
        # preset answer, an "overridden" action returns a sanitized query.
        try:
            _, _, query = InputModeration().check(
                app_id=app_config.app_id,
                tenant_id=app_config.tenant_id,
                app_config=app_config,
                inputs=dict(application_generate_entity.inputs),
                query=query or "",
                message_id=message.id,
                trace_manager=application_generate_entity.trace_manager,
            )
        except ModerationError as e:
            publish_text_answer(queue_manager=queue_manager, model_name=model_name, answer=str(e), user_query=query)
            return True, query, None

        # annotation reply: a matching annotation answers the turn deterministically.
        if query:
            annotation_reply = AnnotationReplyFeature().query(
                app_record=app_model,
                message=message,
                query=query,
                user_id=application_generate_entity.user_id,
                invoke_from=application_generate_entity.invoke_from,
                session=session,
            )
            if annotation_reply:
                return True, query, annotation_reply

        return False, query, None

    def _resolve_agent(
        self,
        app_model: App,
        *,
        invoke_from: InvokeFrom,
        draft_type: Any,
        draft_id: str | None = None,
        user: Account | EndUser,
        session: Session,
        conversation: Conversation | None = None,
    ) -> tuple[Agent, str, Literal["snapshot", "draft", "build_draft"], AgentSoulConfig]:
        agent = session.scalar(
            select(Agent)
            .where(
                Agent.tenant_id == app_model.tenant_id,
                Agent.status == AgentStatus.ACTIVE,
                or_(
                    and_(
                        Agent.app_id == app_model.id,
                        Agent.scope == AgentScope.ROSTER,
                        Agent.source.in_(APP_BACKED_AGENT_SOURCES),
                    ),
                    Agent.backing_app_id == app_model.id,
                ),
            )
            .order_by(Agent.created_at.desc())
            .limit(1)
        )
        if agent is None:
            raise AgentAppGeneratorError("Agent App has no bound Agent")
        if invoke_from == InvokeFrom.DEBUGGER:
            draft = self._resolve_debug_draft(
                tenant_id=app_model.tenant_id,
                agent=agent,
                draft_type=draft_type,
                draft_id=draft_id,
                account_id=user.id if isinstance(user, Account) else None,
                session=session,
            )
            agent_soul = AgentSoulConfig.model_validate(draft.config_snapshot_dict)
            config_version_kind: Literal["snapshot", "draft", "build_draft"] = (
                "build_draft" if draft.draft_type == AgentConfigDraftType.DEBUG_BUILD else "draft"
            )
            return agent, draft.id, config_version_kind, agent_soul
        # Dirty drafts do not revoke a published snapshot, while the seeded
        # create/import snapshot must never become public runtime configuration.
        if not agent_has_workflow_callable_active_snapshot(session=session, agent=agent):
            raise AgentAppNotPublishedError("Agent has not been published")
        conversation_binding = self._resolve_conversation_binding(
            session=session,
            tenant_id=app_model.tenant_id,
            app_id=app_model.id,
            agent_id=agent.id,
            conversation=conversation,
        )
        snapshot_id = (
            conversation_binding.agent_config_version_id
            if conversation_binding is not None
            else agent.active_config_snapshot_id
        )
        _, snapshot, agent_soul = self._resolve_agent_by_id(
            tenant_id=app_model.tenant_id,
            agent_id=agent.id,
            snapshot_id=snapshot_id,
            session=session,
        )
        if conversation_binding is not None:
            AgentWorkspaceService.validate_binding_generation(
                conversation_binding,
                base_home_snapshot_id=snapshot.home_snapshot_id,
                agent_config_version_id=snapshot.id,
                agent_config_version_kind=AgentConfigVersionKind.SNAPSHOT,
            )
        return agent, snapshot.id, "snapshot", agent_soul

    @staticmethod
    def _resolve_conversation_binding(
        *,
        session: Session,
        tenant_id: str,
        app_id: str,
        agent_id: str,
        conversation: Conversation | None,
    ) -> AgentWorkspaceBinding | None:
        """Resolve the exact participant generation owned by an existing conversation."""

        if conversation is None or conversation.agent_workspace_binding_id is None:
            return None
        binding = AgentWorkspaceService.get_active_binding(
            session=session,
            tenant_id=tenant_id,
            binding_id=conversation.agent_workspace_binding_id,
            expected_owner_scope=WorkspaceOwnerScope(
                tenant_id=tenant_id,
                app_id=app_id,
                owner_type=AgentWorkspaceOwnerType.CONVERSATION,
                owner_id=conversation.id,
            ),
        )
        if binding is None or binding.agent_id != agent_id:
            raise AgentAppGeneratorError("Conversation participant Binding is unavailable")
        return binding

    @staticmethod
    def _session_scope_config_version_id(*, invoke_from: InvokeFrom, config_version_id: str) -> str | None:
        """Return the config version id that scopes Agent App session reuse.

        Console preview/debug chat uses a stable Agent draft row id; build mode
        uses the current user's build-draft row id. Published/web/API runs use
        immutable published snapshot ids. This keeps Workspace Binding continuity
        inside one editable surface without mixing draft/build/published state.
        """
        del invoke_from
        return config_version_id

    @staticmethod
    def _resolve_debug_draft(
        *,
        tenant_id: str,
        agent: Agent,
        draft_type: Any,
        account_id: str | None,
        session: Session,
        draft_id: str | None = None,
    ) -> AgentConfigDraft:
        effective_draft_type = (
            AgentConfigDraftType.DEBUG_BUILD
            if draft_type == AgentConfigDraftType.DEBUG_BUILD.value
            else AgentConfigDraftType.DRAFT
        )
        if effective_draft_type == AgentConfigDraftType.DRAFT:
            from services.agent.composer_service import AgentComposerService

            return AgentComposerService.get_or_create_normal_agent_draft(
                session=session,
                tenant_id=tenant_id,
                agent=agent,
                created_by=agent.updated_by or agent.created_by,
            )
        if not account_id:
            raise AgentAppGeneratorError("Build draft requires an account user")
        stmt = select(AgentConfigDraft).where(
            AgentConfigDraft.tenant_id == tenant_id,
            AgentConfigDraft.agent_id == agent.id,
            AgentConfigDraft.draft_type == AgentConfigDraftType.DEBUG_BUILD,
            AgentConfigDraft.account_id == account_id,
        )
        if draft_id is not None:
            stmt = stmt.where(AgentConfigDraft.id == draft_id)
        draft = session.scalar(stmt.order_by(AgentConfigDraft.updated_at.desc()).limit(1))
        if draft is not None:
            return draft
        raise AgentAppGeneratorError("Agent build draft not found")

    @staticmethod
    def _resolve_agent_by_id(
        *, tenant_id: str, agent_id: str, snapshot_id: str | None, session: Session
    ) -> tuple[Agent, AgentConfigSnapshot | AgentConfigDraft, AgentSoulConfig]:
        agent = session.scalar(select(Agent).where(Agent.id == agent_id, Agent.tenant_id == tenant_id))
        if agent is None:
            raise AgentAppGeneratorError("Agent not found")
        if not snapshot_id:
            raise AgentAppGeneratorError("Agent has no published version")
        snapshot = session.scalar(
            select(AgentConfigSnapshot).where(
                AgentConfigSnapshot.tenant_id == tenant_id,
                AgentConfigSnapshot.agent_id == agent_id,
                AgentConfigSnapshot.id == snapshot_id,
            )
        )
        if snapshot is not None:
            agent_soul = AgentSoulConfig.model_validate(snapshot.config_snapshot_dict)
            return agent, snapshot, agent_soul
        draft = session.scalar(
            select(AgentConfigDraft).where(
                AgentConfigDraft.tenant_id == tenant_id,
                AgentConfigDraft.agent_id == agent_id,
                AgentConfigDraft.id == snapshot_id,
            )
        )
        if draft is None:
            raise AgentAppGeneratorError("Agent published version not found")
        agent_soul = AgentSoulConfig.model_validate(draft.config_snapshot_dict)
        return agent, draft, agent_soul


__all__ = ["AgentAppGenerator", "AgentAppGeneratorError", "AgentAppNotPublishedError"]
