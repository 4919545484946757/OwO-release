from libs.exception import BaseHTTPException
from services.errors.app import (
    TRIGGER_WORKFLOW_SERVICE_MODE_UNAVAILABLE_CODE,
    TRIGGER_WORKFLOW_SERVICE_MODE_UNAVAILABLE_MESSAGE,
)


class AppUnavailableError(BaseHTTPException):
    error_code = "app_unavailable"
    description = "App unavailable, please check your app configurations."
    code = 400


class AgentNotPublishedError(BaseHTTPException):
    error_code = "agent_not_published"
    description = "Agent has not been published. Please publish the Agent before using the web app."
    code = 400


class NotCompletionAppError(BaseHTTPException):
    error_code = "not_completion_app"
    description = "Please check if your Completion app mode matches the right API route."
    code = 400


class NotChatAppError(BaseHTTPException):
    error_code = "not_chat_app"
    description = "Please check if your app mode matches the right API route."
    code = 400


class NotWorkflowAppError(BaseHTTPException):
    error_code = "not_workflow_app"
    description = "Please check if your Workflow app mode matches the right API route."
    code = 400


class TriggerWorkflowServiceModeUnavailableError(BaseHTTPException):
    error_code = TRIGGER_WORKFLOW_SERVICE_MODE_UNAVAILABLE_CODE
    description = TRIGGER_WORKFLOW_SERVICE_MODE_UNAVAILABLE_MESSAGE
    code = 403


class ConversationCompletedError(BaseHTTPException):
    error_code = "conversation_completed"
    description = "The conversation has ended. Please start a new conversation."
    code = 400


class ProviderNotInitializeError(BaseHTTPException):
    error_code = "provider_not_initialize"
    description = (
        "No valid model provider credentials found. "
        "Please go to Settings -> Model Provider to complete your provider credentials."
    )
    code = 400


class ProviderQuotaExceededError(BaseHTTPException):
    error_code = "provider_quota_exceeded"
    description = (
        "Your quota for Dify Hosted OpenAI has been exhausted. "
        "Please go to Settings -> Model Provider to complete your own provider credentials."
    )
    code = 400


class ProviderModelCurrentlyNotSupportError(BaseHTTPException):
    error_code = "model_currently_not_support"
    description = "Dify Hosted OpenAI trial currently not support the GPT-4 model."
    code = 400


class CompletionRequestError(BaseHTTPException):
    error_code = "completion_request_error"
    description = "Completion request failed."
    code = 400


class AppMoreLikeThisDisabledError(BaseHTTPException):
    error_code = "app_more_like_this_disabled"
    description = "The 'More like this' feature is disabled. Please refresh your page."
    code = 403


class AppSuggestedQuestionsAfterAnswerDisabledError(BaseHTTPException):
    error_code = "app_suggested_questions_after_answer_disabled"
    description = "The 'Suggested Questions After Answer' feature is disabled. Please refresh your page."
    code = 403


class NoAudioUploadedError(BaseHTTPException):
    error_code = "no_audio_uploaded"
    description = "Please upload your audio."
    code = 400


class AudioTooLargeError(BaseHTTPException):
    error_code = "audio_too_large"
    description = "Audio size exceeded. {message}"
    code = 413


class UnsupportedAudioTypeError(BaseHTTPException):
    error_code = "unsupported_audio_type"
    description = "Audio type not allowed."
    code = 415


class ProviderNotSupportSpeechToTextError(BaseHTTPException):
    error_code = "provider_not_support_speech_to_text"
    description = "Provider not support speech to text."
    code = 400


class SpeechToTextDisabledError(BaseHTTPException):
    error_code = "speech_to_text_disabled"
    description = "Speech to text is disabled."
    code = 400


class WebAppAuthRequiredError(BaseHTTPException):
    error_code = "web_sso_auth_required"
    description = "Web app authentication required."
    code = 401


class WebAppAuthAccessDeniedError(BaseHTTPException):
    error_code = "web_app_access_denied"
    description = "You do not have permission to access this web app."
    code = 401


class WebAppNotFoundError(BaseHTTPException):
    error_code = "app_not_found"
    description = "App not found."
    code = 404


class WebAppAccessServiceUnavailableError(BaseHTTPException):
    error_code = "web_app_access_unavailable"
    description = "Web app access service is unavailable."
    code = 503


class InvokeRateLimitError(BaseHTTPException):
    """Raised when the Invoke returns rate limit error."""

    error_code = "rate_limit_error"
    description = "Rate Limit Error"
    code = 429


class WebFormRateLimitExceededError(BaseHTTPException):
    error_code = "web_form_rate_limit_exceeded"
    description = "Too many form requests. Please try again later."
    code = 429
