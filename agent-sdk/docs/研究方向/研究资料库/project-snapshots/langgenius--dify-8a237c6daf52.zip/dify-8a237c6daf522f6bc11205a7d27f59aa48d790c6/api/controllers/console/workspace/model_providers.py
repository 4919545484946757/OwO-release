import io
from typing import Any, Literal

from flask import send_file
from flask_restx import Resource
from pydantic import BaseModel, Field, field_validator

from controllers.common.fields import SimpleResultResponse, ValidationResultResponse
from controllers.common.rbac import RBACCheck, Workspace
from controllers.common.schema import query_params_from_model, register_response_schema_models, register_schema_models
from controllers.console import console_ns
from controllers.console.wraps import (
    RBACPermission,
    account_initialization_required,
    is_admin_or_owner_required,
    model_validate,
    rbac_permission_required,
    setup_required,
    with_current_tenant_id,
    with_current_user,
)
from extensions.ext_application_services import application_services
from fields.base import ResponseModel
from graphon.model_runtime.entities.model_entities import ModelType
from graphon.model_runtime.errors.validate import CredentialsValidateFailedError
from libs.helper import dump_response, uuid_value
from libs.login import login_required
from models import Account
from services.billing_service import BillingService
from services.entities.model_provider_entities import (
    ModelProviderPluginSummaryResponse,
    ModelProviderSummaryResponse,
    ProviderResponse,
)
from services.model_provider.service import ModelProviderService


class ParserModelList(BaseModel):
    model_type: ModelType | None = None


class ParserCredentialId(BaseModel):
    credential_id: str | None = None

    @field_validator("credential_id")
    @classmethod
    def validate_optional_credential_id(cls, value: str | None) -> str | None:
        if value is None:
            return value
        return uuid_value(value)


class ParserCredentialCreate(BaseModel):
    credentials: dict[str, Any]
    name: str | None = Field(default=None, max_length=30)


class ParserCredentialUpdate(BaseModel):
    credential_id: str
    credentials: dict[str, Any]
    name: str | None = Field(default=None, max_length=30)

    @field_validator("credential_id")
    @classmethod
    def validate_update_credential_id(cls, value: str) -> str:
        return uuid_value(value)


class ParserCredentialDelete(BaseModel):
    credential_id: str

    @field_validator("credential_id")
    @classmethod
    def validate_delete_credential_id(cls, value: str) -> str:
        return uuid_value(value)


class ParserCredentialSwitch(BaseModel):
    credential_id: str

    @field_validator("credential_id")
    @classmethod
    def validate_switch_credential_id(cls, value: str) -> str:
        return uuid_value(value)


class ParserCredentialValidate(BaseModel):
    credentials: dict[str, Any]


class ParserPreferredProviderType(BaseModel):
    preferred_provider_type: Literal["system", "custom"]


class ModelProviderListResponse(ResponseModel):
    data: list[ProviderResponse]


class ModelProviderSummaryListResponse(ResponseModel):
    data: list[ModelProviderSummaryResponse]
    plugins: dict[str, ModelProviderPluginSummaryResponse]


class ModelProviderCreditsResponse(ResponseModel):
    pool_type: Literal["paid", "trial"] | None
    quota_limit: int | None = Field(description="Credit limit for the effective pool; -1 means unlimited.")
    quota_used: int | None
    remaining_credits: int | None = Field(description="Remaining credits; -1 means unlimited.")
    is_unlimited: bool
    is_exhausted: bool
    exhausted_at: int | None
    next_credit_reset_date: int | None


class ProviderCredentialsResponse(ResponseModel):
    credentials: dict[str, Any] | None = None


class ModelProviderPaymentCheckoutUrlResponse(ResponseModel):
    payment_link: str


register_schema_models(
    console_ns,
    ParserModelList,
    ParserCredentialId,
    ParserCredentialCreate,
    ParserCredentialUpdate,
    ParserCredentialDelete,
    ParserCredentialSwitch,
    ParserCredentialValidate,
    ParserPreferredProviderType,
)
register_response_schema_models(
    console_ns,
    SimpleResultResponse,
    ModelProviderListResponse,
    ModelProviderSummaryListResponse,
    ModelProviderCreditsResponse,
    ProviderCredentialsResponse,
    ValidationResultResponse,
    ModelProviderPaymentCheckoutUrlResponse,
)


@console_ns.route("/workspaces/current/model-providers")
class ModelProviderListApi(Resource):
    @console_ns.doc(params=query_params_from_model(ParserModelList))
    @console_ns.response(
        200, "Model providers retrieved successfully", console_ns.models[ModelProviderListResponse.__name__]
    )
    @setup_required
    @login_required
    @account_initialization_required
    @with_current_tenant_id
    @model_validate(ParserModelList)
    def get(self, args: ParserModelList, tenant_id: str):
        model_provider_service = ModelProviderService()
        provider_list = model_provider_service.get_provider_list(tenant_id=tenant_id, model_type=args.model_type)

        return ModelProviderListResponse(data=provider_list).model_dump(mode="json")


@console_ns.route("/workspaces/current/model-providers/summary")
class ModelProviderSummaryListApi(Resource):
    @console_ns.response(
        200,
        "Model provider summaries retrieved successfully",
        console_ns.models[ModelProviderSummaryListResponse.__name__],
    )
    @setup_required
    @login_required
    @account_initialization_required
    @with_current_tenant_id
    def get(self, tenant_id: str):
        providers, plugins = ModelProviderService().get_provider_summary_list(tenant_id=tenant_id)
        return dump_response(
            ModelProviderSummaryListResponse,
            {"data": providers, "plugins": plugins},
        )


@console_ns.route("/workspaces/current/model-providers/credits")
class ModelProviderCreditsApi(Resource):
    @console_ns.response(
        200, "Model provider credits retrieved successfully", console_ns.models[ModelProviderCreditsResponse.__name__]
    )
    @setup_required
    @login_required
    @account_initialization_required
    @with_current_tenant_id
    def get(self, tenant_id: str):
        credit_pool = application_services().workspaces.management.get_effective_credit_pool(tenant_id)
        return dump_response(ModelProviderCreditsResponse, credit_pool)


@console_ns.route("/workspaces/current/model-providers/<path:provider>/credentials")
class ModelProviderCredentialApi(Resource):
    @console_ns.doc(params=query_params_from_model(ParserCredentialId))
    @console_ns.response(
        200,
        "Provider credentials retrieved successfully",
        console_ns.models[ProviderCredentialsResponse.__name__],
    )
    @setup_required
    @login_required
    @is_admin_or_owner_required
    @rbac_permission_required(RBACCheck(RBACPermission.CREDENTIAL_MANAGE, Workspace()))
    @account_initialization_required
    @with_current_tenant_id
    @model_validate(ParserCredentialId)
    def get(self, args: ParserCredentialId, tenant_id: str, provider: str):
        model_provider_service = ModelProviderService()
        # if credential_id is not provided, return current used credential
        credentials = model_provider_service.get_provider_credential(
            tenant_id=tenant_id, provider=provider, credential_id=args.credential_id
        )

        return ProviderCredentialsResponse(credentials=credentials).model_dump(mode="json")

    @console_ns.expect(console_ns.models[ParserCredentialCreate.__name__])
    @console_ns.response(201, "Credential created successfully", console_ns.models[SimpleResultResponse.__name__])
    @setup_required
    @login_required
    @is_admin_or_owner_required
    @rbac_permission_required(RBACCheck(RBACPermission.CREDENTIAL_CREATE, Workspace()))
    @account_initialization_required
    @with_current_tenant_id
    @model_validate(ParserCredentialCreate)
    def post(self, args: ParserCredentialCreate, current_tenant_id: str, provider: str):
        model_provider_service = ModelProviderService()

        try:
            model_provider_service.create_provider_credential(
                tenant_id=current_tenant_id,
                provider=provider,
                credentials=args.credentials,
                credential_name=args.name,
            )
        except CredentialsValidateFailedError as ex:
            raise ValueError(str(ex))

        return SimpleResultResponse(result="success").model_dump(mode="json"), 201

    @console_ns.expect(console_ns.models[ParserCredentialUpdate.__name__])
    @console_ns.response(200, "Credential updated successfully", console_ns.models[SimpleResultResponse.__name__])
    @setup_required
    @login_required
    @is_admin_or_owner_required
    @rbac_permission_required(RBACCheck(RBACPermission.CREDENTIAL_MANAGE, Workspace()))
    @account_initialization_required
    @with_current_tenant_id
    @model_validate(ParserCredentialUpdate)
    def put(self, args: ParserCredentialUpdate, current_tenant_id: str, provider: str):
        model_provider_service = ModelProviderService()

        try:
            model_provider_service.update_provider_credential(
                tenant_id=current_tenant_id,
                provider=provider,
                credentials=args.credentials,
                credential_id=args.credential_id,
                credential_name=args.name,
            )
        except CredentialsValidateFailedError as ex:
            raise ValueError(str(ex))

        return SimpleResultResponse(result="success").model_dump(mode="json")

    @console_ns.expect(console_ns.models[ParserCredentialDelete.__name__])
    @console_ns.response(204, "Credential deleted successfully")
    @setup_required
    @login_required
    @is_admin_or_owner_required
    @rbac_permission_required(RBACCheck(RBACPermission.CREDENTIAL_MANAGE, Workspace()))
    @account_initialization_required
    @with_current_tenant_id
    @model_validate(ParserCredentialDelete)
    def delete(self, args: ParserCredentialDelete, current_tenant_id: str, provider: str):
        model_provider_service = ModelProviderService()
        model_provider_service.remove_provider_credential(
            tenant_id=current_tenant_id, provider=provider, credential_id=args.credential_id
        )

        return "", 204


@console_ns.route("/workspaces/current/model-providers/<path:provider>/credentials/switch")
class ModelProviderCredentialSwitchApi(Resource):
    @console_ns.expect(console_ns.models[ParserCredentialSwitch.__name__])
    @console_ns.response(200, "Success", console_ns.models[SimpleResultResponse.__name__])
    @setup_required
    @login_required
    @is_admin_or_owner_required
    @rbac_permission_required(RBACCheck(RBACPermission.CREDENTIAL_USE, Workspace()))
    @account_initialization_required
    @with_current_tenant_id
    @model_validate(ParserCredentialSwitch)
    def post(self, args: ParserCredentialSwitch, current_tenant_id: str, provider: str):
        service = ModelProviderService()
        service.switch_active_provider_credential(
            tenant_id=current_tenant_id,
            provider=provider,
            credential_id=args.credential_id,
        )
        return SimpleResultResponse(result="success").model_dump(mode="json")


@console_ns.route("/workspaces/current/model-providers/<path:provider>/credentials/validate")
class ModelProviderValidateApi(Resource):
    @console_ns.expect(console_ns.models[ParserCredentialValidate.__name__])
    @console_ns.response(
        200,
        "Provider credentials validated successfully",
        console_ns.models[ValidationResultResponse.__name__],
    )
    @setup_required
    @login_required
    @account_initialization_required
    @with_current_tenant_id
    @model_validate(ParserCredentialValidate)
    def post(self, args: ParserCredentialValidate, current_tenant_id: str, provider: str):
        tenant_id = current_tenant_id

        model_provider_service = ModelProviderService()

        result = True
        error = ""

        try:
            model_provider_service.validate_provider_credentials(
                tenant_id=tenant_id, provider=provider, credentials=args.credentials
            )
        except CredentialsValidateFailedError as ex:
            result = False
            error = str(ex)

        if not result:
            return ValidationResultResponse(result="error", error=error or "Unknown error").model_dump(mode="json")

        return ValidationResultResponse(result="success").model_dump(mode="json")


@console_ns.route("/workspaces/<string:tenant_id>/model-providers/<path:provider>/<string:icon_type>/<string:lang>")
class ModelProviderIconApi(Resource):
    """
    Get model provider icon
    """

    @console_ns.response(200, "Model provider icon")
    def get(self, tenant_id: str, provider: str, icon_type: str, lang: str):
        # response-contract:ignore binary send_file response
        model_provider_service = ModelProviderService()
        icon, mimetype = model_provider_service.get_model_provider_icon(
            tenant_id=tenant_id,
            provider=provider,
            icon_type=icon_type,
            lang=lang,
        )
        if icon is None:
            raise ValueError(f"icon not found for provider {provider}, icon_type {icon_type}, lang {lang}")
        return send_file(io.BytesIO(icon), mimetype=mimetype)


@console_ns.route("/workspaces/current/model-providers/<path:provider>/preferred-provider-type")
class PreferredProviderTypeUpdateApi(Resource):
    @console_ns.expect(console_ns.models[ParserPreferredProviderType.__name__])
    @console_ns.response(200, "Success", console_ns.models[SimpleResultResponse.__name__])
    @setup_required
    @login_required
    @is_admin_or_owner_required
    @rbac_permission_required(RBACCheck(RBACPermission.CREDENTIAL_USE, Workspace()))
    @account_initialization_required
    @with_current_tenant_id
    @model_validate(ParserPreferredProviderType)
    def post(self, args: ParserPreferredProviderType, tenant_id: str, provider: str):
        model_provider_service = ModelProviderService()
        model_provider_service.switch_preferred_provider(
            tenant_id=tenant_id, provider=provider, preferred_provider_type=args.preferred_provider_type
        )

        return SimpleResultResponse(result="success").model_dump(mode="json")


@console_ns.route("/workspaces/current/model-providers/<path:provider>/checkout-url")
class ModelProviderPaymentCheckoutUrlApi(Resource):
    @console_ns.doc(deprecated=True)
    @console_ns.response(
        200,
        "Model provider checkout URL retrieved successfully",
        console_ns.models[ModelProviderPaymentCheckoutUrlResponse.__name__],
    )
    @setup_required
    @login_required
    @is_admin_or_owner_required
    @account_initialization_required
    @with_current_user
    @with_current_tenant_id
    def get(self, current_tenant_id: str, current_user: Account, provider: str):
        if provider != "anthropic":
            raise ValueError(f"provider name {provider} is invalid")
        # pyrefly: ignore [deprecated]
        data = BillingService.get_model_provider_payment_link(
            provider_name=provider,
            tenant_id=current_tenant_id,
            account_id=current_user.id,
            prefilled_email=current_user.email,
        )
        return dump_response(ModelProviderPaymentCheckoutUrlResponse, data)
