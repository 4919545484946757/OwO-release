from flask import Blueprint
from flask_restx import Namespace

from libs.external_api import ExternalApi

bp = Blueprint("inner_api", __name__, url_prefix="/inner/api")

api = ExternalApi(
    bp,
    version="1.0",
    title="Inner API",
    description="Internal APIs for enterprise features, billing, knowledge retrieval, and plugin communication",
)

# Create namespace
inner_api_ns = Namespace("inner_api", description="Internal API operations", path="/")

from . import mail as _mail
from . import runtime_credentials as _runtime_credentials
from .agent import files as _agent_files
from .agent import llm as _agent_llm
from .agent import runtime_usage as _agent_runtime_usage
from .agent import tools as _agent_tools
from .app import dsl as _app_dsl
from .app import file_grants as _app_file_grants
from .knowledge import retrieval as _knowledge_retrieval
from .plugin import agent_config as _agent_config
from .plugin import plugin as _plugin
from .plugin import skills as _skills
from .workspace import workspace as _workspace

api.add_namespace(inner_api_ns)

__all__ = [
    "_agent_config",
    "_agent_files",
    "_agent_llm",
    "_agent_runtime_usage",
    "_agent_tools",
    "_app_dsl",
    "_app_file_grants",
    "_knowledge_retrieval",
    "_mail",
    "_plugin",
    "_runtime_credentials",
    "_skills",
    "_workspace",
    "api",
    "bp",
    "inner_api_ns",
]
