import errno
import logging
import queue
import threading
import time
from abc import ABC, abstractmethod
from enum import IntEnum, auto
from typing import Any

from cachetools import TTLCache, cachedmethod
from redis.exceptions import RedisError
from sqlalchemy.orm import DeclarativeMeta

from core.app.apps.execution_coordinator import (
    AppExecutionCoordinator,
    AppExecutionState,
    set_app_task_stop_flag,
)
from core.app.entities.app_invoke_entities import InvokeFrom
from core.app.entities.queue_entities import (
    AppQueueEvent,
    MessageQueueMessage,
    QueueErrorEvent,
    QueuePingEvent,
    QueueStopEvent,
    WorkflowQueueMessage,
)
from extensions.ext_redis import RedisClientWrapper, redis_client
from graphon.runtime import GraphRuntimeState

logger = logging.getLogger(__name__)


def _is_broken_pipe_error(error: BaseException) -> bool:
    current_error: BaseException | None = error
    while current_error is not None:
        if isinstance(current_error, BrokenPipeError):
            return True
        if isinstance(current_error, OSError) and current_error.errno == errno.EPIPE:
            return True
        current_error = current_error.__cause__ or current_error.__context__
    return False


class PublishFrom(IntEnum):
    APPLICATION_MANAGER = auto()
    TASK_PIPELINE = auto()


class AppQueueManager(ABC):
    def __init__(self, task_id: str, user_id: str, invoke_from: InvokeFrom):
        if not user_id:
            raise ValueError("user is required")

        self._task_id = task_id
        self._user_id = user_id
        self._invoke_from = invoke_from
        self.invoke_from = invoke_from  # Public accessor for invoke_from

        user_prefix = "account" if self._invoke_from.runs_as_account() else "end-user"
        self._task_belong_cache_key = AppQueueManager._generate_task_belong_cache_key(self._task_id)
        redis_client.setex(self._task_belong_cache_key, 1800, f"{user_prefix}-{self._user_id}")

        q: queue.Queue[WorkflowQueueMessage | MessageQueueMessage | None] = queue.Queue()

        self._q = q
        self._graph_runtime_state: GraphRuntimeState | None = None
        self._stopped_cache: TTLCache[tuple, bool] = TTLCache(maxsize=1, ttl=1)
        self._cache_lock = threading.Lock()
        self._listener_segment_completed = threading.Event()
        self._execution_coordinator = AppExecutionCoordinator(
            task_id=self._task_id,
            on_timeout=self._publish_timeout_stop,
        )

    def listen(self):
        """
        Listen to queue
        :return:
        """
        self._execution_coordinator.start_watchdog()
        start_time = time.monotonic()
        last_ping_time: int | float = 0
        try:
            while True:
                try:
                    message = self._q.get(timeout=1)
                    if message is None:
                        break

                    yield message
                except queue.Empty:
                    continue
                finally:
                    elapsed_time = time.monotonic() - start_time
                    manually_stopped = self._is_stopped()
                    if manually_stopped and self._execution_coordinator.request_abort("App task was stopped"):
                        # publish two messages to make sure the client can receive the stop signal
                        # and stop listening after the stop signal processed
                        self.publish(
                            QueueStopEvent(stopped_by=QueueStopEvent.StopBy.USER_MANUAL), PublishFrom.TASK_PIPELINE
                        )

                    if elapsed_time // 10 > last_ping_time:
                        self.publish(QueuePingEvent(), PublishFrom.TASK_PIPELINE)
                        last_ping_time = elapsed_time // 10
        finally:
            self._execution_coordinator.listener_closed(segment_completed=self._listener_segment_completed.is_set())
            self._graph_runtime_state = None  # Release reference once consumers finish or close the generator.

    def stop_listen(self, *, execution_state: AppExecutionState) -> None:
        """Complete the current listener segment with an explicit execution state."""
        if execution_state is AppExecutionState.PAUSED:
            self._execution_coordinator.mark_paused()
        elif execution_state is AppExecutionState.TERMINAL:
            self._execution_coordinator.mark_terminal()
        else:
            raise ValueError(f"Unsupported listener completion state: {execution_state}")

        self._listener_segment_completed.set()
        self._clear_task_belong_cache()
        self._q.put(None)

    @property
    def execution_state(self) -> AppExecutionState:
        return self._execution_coordinator.state

    def _publish_timeout_stop(self, reason: str) -> None:
        self.publish(
            QueueStopEvent(stopped_by=QueueStopEvent.StopBy.USER_MANUAL, reason=reason),
            PublishFrom.TASK_PIPELINE,
        )

    def _clear_task_belong_cache(self) -> None:
        """
        Remove the task belong cache key once listening is finished.
        """
        try:
            redis_client.delete(self._task_belong_cache_key)
        except RedisError:
            logger.exception(
                "Failed to clear task belong cache for task %s (key: %s)", self._task_id, self._task_belong_cache_key
            )

    def publish_error(self, e, pub_from: PublishFrom) -> None:
        """
        Publish error
        :param e: error
        :param pub_from: publish from
        :return:
        """
        self.publish(QueueErrorEvent(error=e), pub_from)

    @property
    def graph_runtime_state(self) -> GraphRuntimeState | None:
        """Retrieve the attached graph runtime state, if available."""
        return self._graph_runtime_state

    @graph_runtime_state.setter
    def graph_runtime_state(self, graph_runtime_state: GraphRuntimeState | None) -> None:
        """Attach the live graph runtime state reference for downstream consumers."""
        self._graph_runtime_state = graph_runtime_state

    def publish(self, event: AppQueueEvent, pub_from: PublishFrom) -> None:
        """
        Publish event to queue
        :param event:
        :param pub_from:
        :return:
        """
        self._check_for_sqlalchemy_models(event.model_dump())
        self._publish(event, pub_from)

    def is_stopped(self) -> bool:
        """Return whether the current task has been manually stopped."""
        return self._is_stopped()

    @abstractmethod
    def _publish(self, event: AppQueueEvent, pub_from: PublishFrom) -> None:
        """
        Publish event to queue
        :param event:
        :param pub_from:
        :return:
        """
        raise NotImplementedError

    @classmethod
    def set_stop_flag(
        cls, task_id: str, invoke_from: InvokeFrom, user_id: str, *, redis: RedisClientWrapper | None = None
    ) -> None:
        """
        Set task stop flag
        :return:
        """
        client = redis if redis is not None else redis_client
        result: Any | None = client.get(cls._generate_task_belong_cache_key(task_id))
        if result is None:
            return

        user_prefix = "account" if invoke_from in {InvokeFrom.EXPLORE, InvokeFrom.DEBUGGER} else "end-user"
        if result.decode("utf-8") != f"{user_prefix}-{user_id}":
            return

        stopped_cache_key = cls._generate_stopped_cache_key(task_id)
        client.setex(stopped_cache_key, 600, 1)

    @classmethod
    def set_stop_flag_no_user_check(cls, task_id: str) -> None:
        """
        Set task stop flag without user permission check.
        This method allows stopping workflows without user context.

        :param task_id: The task ID to stop
        :return:
        """
        set_app_task_stop_flag(task_id)

    @cachedmethod(lambda self: self._stopped_cache, lock=lambda self: self._cache_lock)
    def _is_stopped(self) -> bool:
        """Return whether the task has a stop flag.

        A broken Redis connection cannot establish that a stop was requested,
        so this check fails open to avoid interrupting the workflow generator.
        Other Redis errors retain their existing propagation behavior.
        """
        stopped_cache_key = AppQueueManager._generate_stopped_cache_key(self._task_id)
        try:
            result = redis_client.get(stopped_cache_key)
        except (BrokenPipeError, RedisError) as exc:
            if not _is_broken_pipe_error(exc):
                raise
            logger.warning(
                "Ignoring broken pipe while checking task stop flag; task=%s key=%s",
                self._task_id,
                stopped_cache_key,
                exc_info=True,
            )
            return False

        if result is not None:
            return True

        return False

    @classmethod
    def _generate_task_belong_cache_key(cls, task_id: str) -> str:
        """
        Generate task belong cache key
        :param task_id: task id
        :return:
        """
        return f"generate_task_belong:{task_id}"

    @classmethod
    def _generate_stopped_cache_key(cls, task_id: str) -> str:
        """
        Generate stopped cache key
        :param task_id: task id
        :return:
        """
        return f"generate_task_stopped:{task_id}"

    def _check_for_sqlalchemy_models(self, data: Any):
        # from entity to dict or list
        match data:
            case dict():
                for value in data.values():
                    self._check_for_sqlalchemy_models(value)
            case list():
                for item in data:
                    self._check_for_sqlalchemy_models(item)
            case _:
                if isinstance(data, DeclarativeMeta) or hasattr(data, "_sa_instance_state"):
                    raise TypeError(
                        "Critical Error: Passing SQLAlchemy Model instances that"
                        " cause thread safety issues is not allowed."
                    )
