"""Inner knowledge retrieval endpoints."""
