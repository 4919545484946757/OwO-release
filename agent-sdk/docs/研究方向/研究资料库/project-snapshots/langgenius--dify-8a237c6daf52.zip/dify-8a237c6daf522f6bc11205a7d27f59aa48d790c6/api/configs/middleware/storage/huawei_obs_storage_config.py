from pydantic import Field
from pydantic_settings import BaseSettings


class HuaweiCloudOBSStorageConfig(BaseSettings):
    """
    Configuration settings for Huawei Cloud Object Storage Service (OBS)
    """

    HUAWEI_OBS_BUCKET_NAME: str | None = Field(
        description="Name of the Huawei Cloud OBS bucket to store and retrieve objects (e.g., 'my-obs-bucket')",
        default=None,
    )

    HUAWEI_OBS_ACCESS_KEY: str | None = Field(
        description="Access Key ID for authenticating with Huawei Cloud OBS",
        default=None,
    )

    HUAWEI_OBS_SECRET_KEY: str | None = Field(
        description="Secret Access Key for authenticating with Huawei Cloud OBS",
        default=None,
    )

    HUAWEI_OBS_SERVER: str | None = Field(
        description="Endpoint URL for Huawei Cloud OBS (e.g., 'https://obs.cn-north-4.myhuaweicloud.com')",
        default=None,
    )

    HUAWEI_OBS_PATH_STYLE: bool = Field(
        description="Flag to indicate whether to use path-style URLs for OBS requests",
        default=False,
    )
