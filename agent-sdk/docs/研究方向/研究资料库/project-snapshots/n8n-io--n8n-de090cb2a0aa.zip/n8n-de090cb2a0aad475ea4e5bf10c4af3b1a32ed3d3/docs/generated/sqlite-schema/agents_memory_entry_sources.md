# agents_memory_entry_sources

## Description

<details>
<summary><strong>Table Definition</strong></summary>

```sql
CREATE TABLE "agents_memory_entry_sources" ("id" varchar(36) PRIMARY KEY NOT NULL, "agentId" varchar(36) NOT NULL, "memoryEntryId" varchar(36) NOT NULL, "observationId" varchar(36), "threadId" varchar(255) NOT NULL, "evidenceHash" varchar(64) NOT NULL, "evidenceText" text NOT NULL, "createdAt" datetime(3) NOT NULL DEFAULT (STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW')), "updatedAt" datetime(3) NOT NULL DEFAULT (STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW')), "candidateId" varchar(36), CONSTRAINT "CHK_agents_memory_entry_sources_exactly_one_source" CHECK (("observationId" IS NOT NULL AND "candidateId" IS NULL) OR ("observationId" IS NULL AND "candidateId" IS NOT NULL)), CONSTRAINT "FK_c38e8a57a36b880e39a52ada2e8" FOREIGN KEY ("agentId") REFERENCES "agents" ("id") ON DELETE CASCADE ON UPDATE NO ACTION, CONSTRAINT "FK_4706f6223313959b7437a2b48df" FOREIGN KEY ("memoryEntryId") REFERENCES "agents_memory_entries" ("id") ON DELETE CASCADE ON UPDATE NO ACTION, CONSTRAINT "FK_cb7c15d22fd068a0806aa57fc03" FOREIGN KEY ("observationId") REFERENCES "agents_observations" ("id") ON DELETE CASCADE ON UPDATE NO ACTION, CONSTRAINT "FK_451d387a182fa8dd8002dfc3a77" FOREIGN KEY ("threadId") REFERENCES "agents_threads" ("id") ON DELETE CASCADE ON UPDATE NO ACTION, CONSTRAINT "FK_87640d646b020c3be8e16cd0fa6" FOREIGN KEY ("candidateId") REFERENCES "agents_memory_entry_candidates" ("id") ON DELETE CASCADE)
```

</details>

## Columns

| Name | Type | Default | Nullable | Children | Parents | Comment |
| ---- | ---- | ------- | -------- | -------- | ------- | ------- |
| agentId | varchar(36) |  | false |  | [agents](agents.md) |  |
| candidateId | varchar(36) |  | true |  | [agents_memory_entry_candidates](agents_memory_entry_candidates.md) |  |
| createdAt | datetime(3) | STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW') | false |  |  |  |
| evidenceHash | varchar(64) |  | false |  |  |  |
| evidenceText | TEXT |  | false |  |  |  |
| id | varchar(36) |  | false |  |  |  |
| memoryEntryId | varchar(36) |  | false |  | [agents_memory_entries](agents_memory_entries.md) |  |
| observationId | varchar(36) |  | true |  | [agents_observations](agents_observations.md) |  |
| threadId | varchar(255) |  | false |  | [agents_threads](agents_threads.md) |  |
| updatedAt | datetime(3) | STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW') | false |  |  |  |

## Constraints

| Name | Type | Definition |
| ---- | ---- | ---------- |
| - | CHECK | CHECK (("observationId" IS NOT NULL AND "candidateId" IS NULL) OR ("observationId" IS NULL AND "candidateId" IS NOT NULL)) |
| - (Foreign key ID: 0) | FOREIGN KEY | FOREIGN KEY (candidateId) REFERENCES agents_memory_entry_candidates (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE |
| - (Foreign key ID: 1) | FOREIGN KEY | FOREIGN KEY (threadId) REFERENCES agents_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE |
| - (Foreign key ID: 2) | FOREIGN KEY | FOREIGN KEY (observationId) REFERENCES agents_observations (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE |
| - (Foreign key ID: 3) | FOREIGN KEY | FOREIGN KEY (memoryEntryId) REFERENCES agents_memory_entries (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE |
| - (Foreign key ID: 4) | FOREIGN KEY | FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE |
| id | PRIMARY KEY | PRIMARY KEY (id) |
| sqlite_autoindex_agents_memory_entry_sources_1 | PRIMARY KEY | PRIMARY KEY (id) |

## Indexes

| Name | Definition |
| ---- | ---------- |
| IDX_451d387a182fa8dd8002dfc3a7 | CREATE INDEX "IDX_451d387a182fa8dd8002dfc3a7" ON "agents_memory_entry_sources" ("threadId")  |
| IDX_a353ac251315ef0af6ad3c9f0a | CREATE UNIQUE INDEX "IDX_a353ac251315ef0af6ad3c9f0a" ON "agents_memory_entry_sources" ("memoryEntryId", "observationId", "evidenceHash")  |
| IDX_agents_mem_src_candidate_unique | CREATE UNIQUE INDEX "IDX_agents_mem_src_candidate_unique" ON "agents_memory_entry_sources" ("memoryEntryId", "candidateId", "evidenceHash") WHERE "candidateId" IS NOT NULL |
| IDX_agents_memory_entry_sources_candidateId | CREATE INDEX "IDX_agents_memory_entry_sources_candidateId" ON "agents_memory_entry_sources" ("candidateId")  |
| IDX_cb7c15d22fd068a0806aa57fc0 | CREATE INDEX "IDX_cb7c15d22fd068a0806aa57fc0" ON "agents_memory_entry_sources" ("observationId")  |
| IDX_f9573af4ed653f13b0ba1f7b12 | CREATE INDEX "IDX_f9573af4ed653f13b0ba1f7b12" ON "agents_memory_entry_sources" ("agentId", "threadId")  |
| sqlite_autoindex_agents_memory_entry_sources_1 | PRIMARY KEY (id) |

## Relations

```mermaid
erDiagram

"agents_memory_entry_sources" }o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_sources" }o--o| "agents_memory_entry_candidates" : "FOREIGN KEY (candidateId) REFERENCES agents_memory_entry_candidates (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_sources" }o--|| "agents_memory_entries" : "FOREIGN KEY (memoryEntryId) REFERENCES agents_memory_entries (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_sources" }o--o| "agents_observations" : "FOREIGN KEY (observationId) REFERENCES agents_observations (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_sources" }o--|| "agents_threads" : "FOREIGN KEY (threadId) REFERENCES agents_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"

"agents_memory_entry_sources" {
  varchar_36_ agentId FK
  varchar_36_ candidateId FK
  datetime_3_ createdAt
  varchar_64_ evidenceHash
  TEXT evidenceText
  varchar_36_ id PK
  varchar_36_ memoryEntryId FK
  varchar_36_ observationId FK
  varchar_255_ threadId FK
  datetime_3_ updatedAt
}
"agents" {
  varchar_36_ activeVersionId FK
  boolean availableInMCP
  datetime_3_ createdAt
  varchar_36_ id PK
  TEXT integrations
  varchar_128_ name
  varchar_255_ projectId FK
  INTEGER revision
  TEXT schema
  datetime_3_ setupCompletedAt
  TEXT skills
  TEXT tools
  datetime_3_ updatedAt
  varchar_36_ versionId
}
"agents_memory_entry_candidates" {
  varchar_36_ agentId FK
  smallint attemptCount
  TEXT content
  datetime_3_ createdAt
  TEXT evidenceText
  varchar_36_ id PK
  varchar_32_ kind
  varchar_255_ resourceId FK
  varchar_255_ runId
  varchar_36_ sourceMessageId FK
  varchar_16_ status
  varchar_255_ threadId FK
  varchar_255_ toolCallId
  datetime_3_ updatedAt
}
"agents_memory_entries" {
  varchar_36_ agentId FK
  TEXT content
  varchar_64_ contentHash
  datetime_3_ createdAt
  TEXT embedding
  varchar_128_ embeddingModel
  varchar_36_ id PK
  datetime_3_ lastSeenAt
  TEXT metadata
  varchar_255_ resourceId FK
  varchar_16_ status
  varchar_36_ supersededBy FK
  datetime_3_ updatedAt
}
"agents_observations" {
  varchar_36_ agentId FK
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_16_ marker
  varchar_255_ observationScopeId FK
  varchar_36_ parentId FK
  varchar_16_ status
  varchar_36_ supersededBy FK
  TEXT text
  INTEGER tokenCount
  datetime_3_ updatedAt
}
"agents_threads" {
  datetime_3_ createdAt
  varchar_128_ id PK
  TEXT metadata
  varchar_255_ resourceId
  varchar_255_ title
  datetime_3_ updatedAt
}
```

---

> Generated by [tbls](https://github.com/k1LoW/tbls)
