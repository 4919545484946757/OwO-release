# agent_execution

## Description

<details>
<summary><strong>Table Definition</strong></summary>

```sql
CREATE TABLE "agent_execution" ("id" varchar(36) PRIMARY KEY NOT NULL, "threadId" varchar(128) NOT NULL, "status" varchar(16) NOT NULL, "startedAt" datetime(3), "stoppedAt" datetime(3), "duration" integer NOT NULL DEFAULT (0), "userMessage" text, "model" varchar(255), "promptTokens" integer, "completionTokens" integer, "totalTokens" integer, "cost" real, "timeline" text, "error" text, "hitlStatus" varchar(16), "source" varchar(32), "createdAt" datetime(3) NOT NULL DEFAULT (STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW')), "updatedAt" datetime(3) NOT NULL DEFAULT (STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW')), "storedAt" varchar(2) NOT NULL DEFAULT ('db'), "attachments" text, "failureSummary" text, "author" text, "acceptsSteering" BOOLEAN NOT NULL DEFAULT FALSE, CONSTRAINT "CHK_agent_execution_storedAt" CHECK ((("storedAt" IN ('db', 'fs', 's3', 'az')))), CONSTRAINT "CHK_agent_execution_hitlStatus" CHECK (((((("hitlStatus" IN ('suspended', 'resumed'))))))), CONSTRAINT "CHK_agent_execution_status" CHECK (("status" IN ('running', 'success', 'error', 'cancelled', 'interrupted'))), CONSTRAINT "FK_add2432fb6034cc18b6af299dce" FOREIGN KEY ("threadId") REFERENCES "agent_execution_threads" ("id") ON DELETE CASCADE ON UPDATE NO ACTION)
```

</details>

## Columns

| Name | Type | Default | Nullable | Children | Parents | Comment |
| ---- | ---- | ------- | -------- | -------- | ------- | ------- |
| acceptsSteering | BOOLEAN | FALSE | false |  |  |  |
| attachments | TEXT |  | true |  |  |  |
| author | TEXT |  | true |  |  |  |
| completionTokens | INTEGER |  | true |  |  |  |
| cost | REAL |  | true |  |  |  |
| createdAt | datetime(3) | STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW') | false |  |  |  |
| duration | INTEGER | 0 | false |  |  |  |
| error | TEXT |  | true |  |  |  |
| failureSummary | TEXT |  | true |  |  |  |
| hitlStatus | varchar(16) |  | true |  |  |  |
| id | varchar(36) |  | false | [agent_execution_message_links](agent_execution_message_links.md) [agent_message_queue](agent_message_queue.md) |  |  |
| model | varchar(255) |  | true |  |  |  |
| promptTokens | INTEGER |  | true |  |  |  |
| source | varchar(32) |  | true |  |  |  |
| startedAt | datetime(3) |  | true |  |  |  |
| status | varchar(16) |  | false |  |  |  |
| stoppedAt | datetime(3) |  | true |  |  |  |
| storedAt | varchar(2) | 'db' | false |  |  |  |
| threadId | varchar(128) |  | false |  | [agent_execution_threads](agent_execution_threads.md) |  |
| timeline | TEXT |  | true |  |  |  |
| totalTokens | INTEGER |  | true |  |  |  |
| updatedAt | datetime(3) | STRFTIME('%Y-%m-%d %H:%M:%f', 'NOW') | false |  |  |  |
| userMessage | TEXT |  | true |  |  |  |

## Constraints

| Name | Type | Definition |
| ---- | ---- | ---------- |
| - | CHECK | CHECK ((("storedAt" IN ('db', 'fs', 's3', 'az')))) |
| - | CHECK | CHECK (((((("hitlStatus" IN ('suspended', 'resumed'))))))) |
| - | CHECK | CHECK (("status" IN ('running', 'success', 'error', 'cancelled', 'interrupted'))) |
| - (Foreign key ID: 0) | FOREIGN KEY | FOREIGN KEY (threadId) REFERENCES agent_execution_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE |
| id | PRIMARY KEY | PRIMARY KEY (id) |
| sqlite_autoindex_agent_execution_1 | PRIMARY KEY | PRIMARY KEY (id) |

## Indexes

| Name | Definition |
| ---- | ---------- |
| IDX_63d3c3a68b9cebf05f967f0b1c | CREATE INDEX "IDX_63d3c3a68b9cebf05f967f0b1c" ON "agent_execution" ("threadId", "createdAt")  |
| IDX_agent_execution_status | CREATE INDEX "IDX_agent_execution_status" ON "agent_execution" ("status") WHERE "status" = 'running' |
| sqlite_autoindex_agent_execution_1 | PRIMARY KEY (id) |

## Relations

```mermaid
erDiagram

"agent_execution_message_links" |o--|| "agent_execution" : "FOREIGN KEY (executionId) REFERENCES agent_execution (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_message_queue" }o--o| "agent_execution" : "FOREIGN KEY (executionId) REFERENCES agent_execution (id) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"agent_message_queue" }o--o| "agent_execution" : "FOREIGN KEY (steeringExecutionId) REFERENCES agent_execution (id) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"agent_execution" }o--|| "agent_execution_threads" : "FOREIGN KEY (threadId) REFERENCES agent_execution_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"

"agent_execution" {
  BOOLEAN acceptsSteering
  TEXT attachments
  TEXT author
  INTEGER completionTokens
  REAL cost
  datetime_3_ createdAt
  INTEGER duration
  TEXT error
  TEXT failureSummary
  varchar_16_ hitlStatus
  varchar_36_ id PK
  varchar_255_ model
  INTEGER promptTokens
  varchar_32_ source
  datetime_3_ startedAt
  varchar_16_ status
  datetime_3_ stoppedAt
  varchar_2_ storedAt
  varchar_128_ threadId FK
  TEXT timeline
  INTEGER totalTokens
  datetime_3_ updatedAt
  TEXT userMessage
}
"agent_execution_message_links" {
  datetime_3_ createdAt
  varchar_6_ direction
  varchar_36_ executionId PK
  varchar_36_ messageId PK
  INTEGER position
}
"agent_message_queue" {
  datetime_3_ createdAt
  varchar_36_ executionId FK
  INTEGER id
  varchar_36_ messageId FK
  TEXT payload
  INTEGER position
  varchar_36_ steeringExecutionId FK
  INTEGER steeringOrder
  varchar_128_ threadId FK
  datetime_3_ updatedAt
}
"agent_execution_threads" {
  varchar_16_ accessScope
  varchar_36_ agentId FK
  varchar_255_ agentName
  datetime_3_ createdAt
  varchar_8_ emoji
  varchar_128_ id PK
  varchar ownerId FK
  varchar_36_ parentAgentId
  varchar_128_ parentThreadId
  varchar_255_ projectId FK
  INTEGER sessionNumber
  varchar_32_ taskId
  varchar_36_ taskVersionId FK
  varchar_255_ title
  INTEGER totalCompletionTokens
  REAL totalCost
  INTEGER totalDuration
  INTEGER totalPromptTokens
  datetime_3_ updatedAt
}
```

---

> Generated by [tbls](https://github.com/k1LoW/tbls)
