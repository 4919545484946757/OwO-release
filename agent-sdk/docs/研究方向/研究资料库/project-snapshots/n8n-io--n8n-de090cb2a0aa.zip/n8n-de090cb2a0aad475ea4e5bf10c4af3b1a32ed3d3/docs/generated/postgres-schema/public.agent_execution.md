# public.agent_execution

## Columns

| Name | Type | Default | Nullable | Children | Parents | Comment |
| ---- | ---- | ------- | -------- | -------- | ------- | ------- |
| acceptsSteering | boolean | false | false |  |  | Accept input until the runtime closes admission |
| attachments | json |  | true |  |  | Metadata of files attached to the user turn ({id, fileName, mimeType, sizeBytes}[]); bytes live in BinaryDataService |
| author | json |  | true |  |  | Chat platform user who wrote the turn as {id, name}; null for runs outside chat integrations |
| completionTokens | integer |  | true |  |  |  |
| cost | double precision |  | true |  |  |  |
| createdAt | timestamp(3) with time zone | CURRENT_TIMESTAMP(3) | false |  |  |  |
| duration | integer | 0 | false |  |  |  |
| error | text |  | true |  |  |  |
| failureSummary | json |  | true |  |  | Execution failure projection as {count, latest} for session list queries |
| hitlStatus | varchar(16) |  | true |  |  |  |
| id | varchar(36) |  | false | [public.agent_execution_message_links](public.agent_execution_message_links.md) [public.agent_message_queue](public.agent_message_queue.md) |  |  |
| model | varchar(255) |  | true |  |  |  |
| promptTokens | integer |  | true |  |  |  |
| source | varchar(32) |  | true |  |  |  |
| startedAt | timestamp(3) with time zone |  | true |  |  |  |
| status | varchar(16) |  | false |  |  |  |
| stoppedAt | timestamp(3) with time zone |  | true |  |  |  |
| storedAt | varchar(2) | 'db'::character varying | false |  |  |  |
| threadId | varchar(128) |  | false |  | [public.agent_execution_threads](public.agent_execution_threads.md) |  |
| timeline | json |  | true |  |  |  |
| totalTokens | integer |  | true |  |  |  |
| updatedAt | timestamp(3) with time zone | CURRENT_TIMESTAMP(3) | false |  |  |  |
| userMessage | text |  | true |  |  |  |

## Constraints

| Name | Type | Definition |
| ---- | ---- | ---------- |
| CHK_agent_execution_hitlStatus | CHECK | CHECK ((("hitlStatus")::text = ANY ((ARRAY['suspended'::character varying, 'resumed'::character varying])::text[]))) |
| CHK_agent_execution_status | CHECK | CHECK (((status)::text = ANY ((ARRAY['running'::character varying, 'success'::character varying, 'error'::character varying, 'cancelled'::character varying, 'interrupted'::character varying])::text[]))) |
| CHK_agent_execution_storedAt | CHECK | CHECK ((("storedAt")::text = ANY ((ARRAY['db'::character varying, 'fs'::character varying, 's3'::character varying, 'az'::character varying])::text[]))) |
| FK_add2432fb6034cc18b6af299dce | FOREIGN KEY | FOREIGN KEY ("threadId") REFERENCES agent_execution_threads(id) ON DELETE CASCADE |
| PK_ba438acc8532addc12d1ef17049 | PRIMARY KEY | PRIMARY KEY (id) |
| agent_execution_acceptsSteering_not_null | n | NOT NULL "acceptsSteering" |
| agent_execution_createdAt_not_null | n | NOT NULL "createdAt" |
| agent_execution_duration_not_null | n | NOT NULL duration |
| agent_execution_id_not_null | n | NOT NULL id |
| agent_execution_status_not_null | n | NOT NULL status |
| agent_execution_storedAt_not_null | n | NOT NULL "storedAt" |
| agent_execution_threadId_not_null | n | NOT NULL "threadId" |
| agent_execution_updatedAt_not_null | n | NOT NULL "updatedAt" |

## Indexes

| Name | Definition |
| ---- | ---------- |
| IDX_63d3c3a68b9cebf05f967f0b1c | CREATE INDEX "IDX_63d3c3a68b9cebf05f967f0b1c" ON public.agent_execution USING btree ("threadId", "createdAt") |
| IDX_agent_execution_status | CREATE INDEX "IDX_agent_execution_status" ON public.agent_execution USING btree (status) WHERE ((status)::text = 'running'::text) |
| PK_ba438acc8532addc12d1ef17049 | CREATE UNIQUE INDEX "PK_ba438acc8532addc12d1ef17049" ON public.agent_execution USING btree (id) |

## Relations

```mermaid
erDiagram

"public.agent_execution_message_links" }o--|| "public.agent_execution" : "FOREIGN KEY (#quot;executionId#quot;) REFERENCES agent_execution(id) ON DELETE CASCADE"
"public.agent_message_queue" }o--o| "public.agent_execution" : "FOREIGN KEY (#quot;executionId#quot;) REFERENCES agent_execution(id)"
"public.agent_message_queue" }o--o| "public.agent_execution" : "FOREIGN KEY (#quot;steeringExecutionId#quot;) REFERENCES agent_execution(id)"
"public.agent_execution" }o--|| "public.agent_execution_threads" : "FOREIGN KEY (#quot;threadId#quot;) REFERENCES agent_execution_threads(id) ON DELETE CASCADE"

"public.agent_execution" {
  boolean acceptsSteering
  json attachments
  json author
  integer completionTokens
  double_precision cost
  timestamp_3__with_time_zone createdAt
  integer duration
  text error
  json failureSummary
  varchar_16_ hitlStatus
  varchar_36_ id
  varchar_255_ model
  integer promptTokens
  varchar_32_ source
  timestamp_3__with_time_zone startedAt
  varchar_16_ status
  timestamp_3__with_time_zone stoppedAt
  varchar_2_ storedAt
  varchar_128_ threadId FK
  json timeline
  integer totalTokens
  timestamp_3__with_time_zone updatedAt
  text userMessage
}
"public.agent_execution_message_links" {
  timestamp_3__with_time_zone createdAt
  varchar_6_ direction
  varchar_36_ executionId FK
  varchar_36_ messageId FK
  integer position
}
"public.agent_message_queue" {
  timestamp_3__with_time_zone createdAt
  varchar_36_ executionId FK
  bigint id
  varchar_36_ messageId FK
  json payload
  integer position
  varchar_36_ steeringExecutionId FK
  integer steeringOrder
  varchar_128_ threadId FK
  timestamp_3__with_time_zone updatedAt
}
"public.agent_execution_threads" {
  varchar_16_ accessScope
  varchar_36_ agentId FK
  varchar_255_ agentName
  timestamp_3__with_time_zone createdAt
  varchar_8_ emoji
  varchar_128_ id
  uuid ownerId FK
  varchar_36_ parentAgentId
  varchar_128_ parentThreadId
  varchar_255_ projectId FK
  integer sessionNumber
  varchar_32_ taskId
  varchar_36_ taskVersionId FK
  varchar_255_ title
  integer totalCompletionTokens
  double_precision totalCost
  integer totalDuration
  integer totalPromptTokens
  timestamp_3__with_time_zone updatedAt
}
```

---

> Generated by [tbls](https://github.com/k1LoW/tbls)
