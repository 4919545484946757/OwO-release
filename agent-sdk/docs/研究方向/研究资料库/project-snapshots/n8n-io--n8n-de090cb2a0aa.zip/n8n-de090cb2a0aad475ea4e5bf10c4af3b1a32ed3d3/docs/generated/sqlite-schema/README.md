# n8n database schema (SQLite)

## Description

Auto-generated from the SQLite migrations in @n8n/db. Do not edit by hand.

## Tables

| Name | Columns | Comment | Type |
| ---- | ------- | ------- | ---- |
| [activity_event](activity_event.md) | 11 |  | table |
| [agent_background_job](agent_background_job.md) | 20 |  | table |
| [agent_budget_applied_call](agent_budget_applied_call.md) | 2 |  | table |
| [agent_budget_spend](agent_budget_spend.md) | 4 |  | table |
| [agent_channel_status](agent_channel_status.md) | 11 |  | table |
| [agent_chat_attachments](agent_chat_attachments.md) | 12 |  | table |
| [agent_chat_subscriptions](agent_chat_subscriptions.md) | 6 |  | table |
| [agent_checkpoints](agent_checkpoints.md) | 7 |  | table |
| [agent_credential_dependency](agent_credential_dependency.md) | 3 |  | table |
| [agent_eval_dataset](agent_eval_dataset.md) | 10 |  | table |
| [agent_eval_rating](agent_eval_rating.md) | 8 |  | table |
| [agent_eval_result](agent_eval_result.md) | 16 |  | table |
| [agent_eval_run](agent_eval_run.md) | 14 |  | table |
| [agent_execution](agent_execution.md) | 23 |  | table |
| [agent_execution_message_links](agent_execution_message_links.md) | 5 |  | table |
| [agent_execution_threads](agent_execution_threads.md) | 19 |  | table |
| [agent_files](agent_files.md) | 10 |  | table |
| [agent_history](agent_history.md) | 9 |  | table |
| [agent_message_queue](agent_message_queue.md) | 10 |  | table |
| [agent_plan](agent_plan.md) | 8 |  | table |
| [agent_plan_history](agent_plan_history.md) | 6 |  | table |
| [agent_task_definition](agent_task_definition.md) | 8 |  | table |
| [agent_task_run_lock](agent_task_run_lock.md) | 6 |  | table |
| [agent_task_snapshot](agent_task_snapshot.md) | 9 |  | table |
| [agent_thread_grants](agent_thread_grants.md) | 4 |  | table |
| [agent_workflow_dependency](agent_workflow_dependency.md) | 3 |  | table |
| [agents](agents.md) | 14 |  | table |
| [agents_memory_entries](agents_memory_entries.md) | 13 |  | table |
| [agents_memory_entry_candidates](agents_memory_entry_candidates.md) | 14 |  | table |
| [agents_memory_entry_locks](agents_memory_entry_locks.md) | 6 |  | table |
| [agents_memory_entry_sources](agents_memory_entry_sources.md) | 10 |  | table |
| [agents_messages](agents_messages.md) | 12 |  | table |
| [agents_observation_cursors](agents_observation_cursors.md) | 6 |  | table |
| [agents_observation_locks](agents_observation_locks.md) | 7 |  | table |
| [agents_observations](agents_observations.md) | 11 |  | table |
| [agents_resources](agents_resources.md) | 4 |  | table |
| [agents_threads](agents_threads.md) | 6 |  | table |
| [ai_builder_temporary_workflow](ai_builder_temporary_workflow.md) | 4 |  | table |
| [ai_preference](ai_preference.md) | 8 |  | table |
| [annotation_tag_entity](annotation_tag_entity.md) | 4 |  | table |
| [auth_identity](auth_identity.md) | 5 |  | table |
| [auth_provider_sync_history](auth_provider_sync_history.md) | 11 |  | table |
| [binary_data](binary_data.md) | 9 |  | table |
| [chat_hub_agent_tools](chat_hub_agent_tools.md) | 2 |  | table |
| [chat_hub_agents](chat_hub_agents.md) | 13 |  | table |
| [chat_hub_messages](chat_hub_messages.md) | 17 |  | table |
| [chat_hub_session_tools](chat_hub_session_tools.md) | 2 |  | table |
| [chat_hub_sessions](chat_hub_sessions.md) | 13 |  | table |
| [chat_hub_tools](chat_hub_tools.md) | 9 |  | table |
| [credential_dependency](credential_dependency.md) | 5 |  | table |
| [credentials_entity](credentials_entity.md) | 14 |  | table |
| [data_table](data_table.md) | 5 |  | table |
| [data_table_column](data_table_column.md) | 7 |  | table |
| [deployment_key](deployment_key.md) | 7 |  | table |
| [dynamic_credential_entry](dynamic_credential_entry.md) | 6 |  | table |
| [dynamic_credential_resolver](dynamic_credential_resolver.md) | 6 |  | table |
| [dynamic_credential_user_entry](dynamic_credential_user_entry.md) | 6 |  | table |
| [evaluation_collection](evaluation_collection.md) | 9 |  | table |
| [evaluation_config](evaluation_config.md) | 12 |  | table |
| [event_destinations](event_destinations.md) | 4 |  | table |
| [execution_annotation_tags](execution_annotation_tags.md) | 2 |  | table |
| [execution_annotations](execution_annotations.md) | 6 |  | table |
| [execution_data](execution_data.md) | 4 |  | table |
| [execution_entity](execution_entity.md) | 19 |  | table |
| [execution_metadata](execution_metadata.md) | 4 |  | table |
| [folder](folder.md) | 6 |  | table |
| [folder_tag](folder_tag.md) | 2 |  | table |
| [idempotency_key](idempotency_key.md) | 9 |  | table |
| [insights_by_period](insights_by_period.md) | 6 |  | table |
| [insights_metadata](insights_metadata.md) | 5 |  | table |
| [insights_raw](insights_raw.md) | 5 |  | table |
| [installed_nodes](installed_nodes.md) | 4 |  | table |
| [installed_packages](installed_packages.md) | 6 |  | table |
| [instance_ai_checkpoints](instance_ai_checkpoints.md) | 9 |  | table |
| [instance_ai_events](instance_ai_events.md) | 7 |  | table |
| [instance_ai_iteration_logs](instance_ai_iteration_logs.md) | 6 |  | table |
| [instance_ai_mcp_registry_connections](instance_ai_mcp_registry_connections.md) | 7 |  | table |
| [instance_ai_messages](instance_ai_messages.md) | 8 |  | table |
| [instance_ai_observation_cursors](instance_ai_observation_cursors.md) | 5 |  | table |
| [instance_ai_observation_locks](instance_ai_observation_locks.md) | 6 |  | table |
| [instance_ai_observational_memory](instance_ai_observational_memory.md) | 32 |  | table |
| [instance_ai_observations](instance_ai_observations.md) | 10 |  | table |
| [instance_ai_pending_confirmations](instance_ai_pending_confirmations.md) | 12 |  | table |
| [instance_ai_resources](instance_ai_resources.md) | 5 |  | table |
| [instance_ai_thread_grants](instance_ai_thread_grants.md) | 5 |  | table |
| [instance_ai_thread_tabs](instance_ai_thread_tabs.md) | 5 |  | table |
| [instance_ai_threads](instance_ai_threads.md) | 7 |  | table |
| [instance_ai_workflow_snapshots](instance_ai_workflow_snapshots.md) | 7 |  | table |
| [instance_credential_assignment](instance_credential_assignment.md) | 4 |  | table |
| [instance_monitoring_report](instance_monitoring_report.md) | 10 |  | table |
| [instance_version_history](instance_version_history.md) | 5 |  | table |
| [invalid_auth_token](invalid_auth_token.md) | 2 |  | table |
| [mcp_registry_server](mcp_registry_server.md) | 7 |  | table |
| [migration_finding](migration_finding.md) | 10 |  | table |
| [migration_finding_sync](migration_finding_sync.md) | 3 |  | table |
| [migration_workflow_owner](migration_workflow_owner.md) | 7 |  | table |
| [oauth_access_tokens](oauth_access_tokens.md) | 3 |  | table |
| [oauth_authorization_codes](oauth_authorization_codes.md) | 13 |  | table |
| [oauth_clients](oauth_clients.md) | 10 |  | table |
| [oauth_refresh_tokens](oauth_refresh_tokens.md) | 8 |  | table |
| [oauth_user_consents](oauth_user_consents.md) | 5 |  | table |
| [poller_state](poller_state.md) | 7 |  | table |
| [processed_data](processed_data.md) | 5 |  | table |
| [project](project.md) | 9 |  | table |
| [project_pool_settings](project_pool_settings.md) | 4 |  | table |
| [project_relation](project_relation.md) | 5 |  | table |
| [project_secrets_provider_access](project_secrets_provider_access.md) | 5 |  | table |
| [promotion_config](promotion_config.md) | 7 |  | table |
| [promotion_connection](promotion_connection.md) | 7 |  | table |
| [promotion_connection_project](promotion_connection_project.md) | 4 |  | table |
| [promotion_provider](promotion_provider.md) | 8 |  | table |
| [role](role.md) | 7 |  | table |
| [role_mapping_rule](role_mapping_rule.md) | 7 |  | table |
| [role_mapping_rule_project](role_mapping_rule_project.md) | 2 |  | table |
| [role_scope](role_scope.md) | 2 |  | table |
| [scheduled_job](scheduled_job.md) | 25 |  | table |
| [scheduled_task](scheduled_task.md) | 19 |  | table |
| [scope](scope.md) | 3 |  | table |
| [secrets_provider_connection](secrets_provider_connection.md) | 7 |  | table |
| [self_healing_result](self_healing_result.md) | 15 |  | table |
| [settings](settings.md) | 3 |  | table |
| [shared_credentials](shared_credentials.md) | 5 |  | table |
| [shared_workflow](shared_workflow.md) | 5 |  | table |
| [tag_entity](tag_entity.md) | 4 |  | table |
| [test_case_execution](test_case_execution.md) | 16 |  | table |
| [test_run](test_run.md) | 16 |  | table |
| [token_exchange_jti](token_exchange_jti.md) | 3 |  | table |
| [trusted_key](trusted_key.md) | 4 |  | table |
| [trusted_key_source](trusted_key_source.md) | 8 |  | table |
| [trusted_source](trusted_source.md) | 15 |  | table |
| [trusted_source_identity](trusted_source_identity.md) | 8 |  | table |
| [type_availability_policy](type_availability_policy.md) | 7 |  | table |
| [type_availability_policy_attachment](type_availability_policy_attachment.md) | 6 |  | table |
| [type_availability_policy_scope](type_availability_policy_scope.md) | 8 |  | table |
| [user](user.md) | 15 |  | table |
| [user_api_keys](user_api_keys.md) | 9 |  | table |
| [user_favorites](user_favorites.md) | 4 |  | table |
| [variables](variables.md) | 5 |  | table |
| [webhook_entity](webhook_entity.md) | 6 |  | table |
| [workflow_builder_session](workflow_builder_session.md) | 9 |  | table |
| [workflow_dependency](workflow_dependency.md) | 9 |  | table |
| [workflow_entity](workflow_entity.md) | 20 |  | table |
| [workflow_history](workflow_history.md) | 11 |  | table |
| [workflow_publication_outbox](workflow_publication_outbox.md) | 8 |  | table |
| [workflow_publication_retry_state](workflow_publication_retry_state.md) | 4 |  | table |
| [workflow_publication_trigger_status](workflow_publication_trigger_status.md) | 8 |  | table |
| [workflow_publish_history](workflow_publish_history.md) | 6 |  | table |
| [workflow_published_version](workflow_published_version.md) | 4 |  | table |
| [workflow_review_activity](workflow_review_activity.md) | 7 |  | table |
| [workflow_review_activity_comment](workflow_review_activity_comment.md) | 8 |  | table |
| [workflow_review_request](workflow_review_request.md) | 12 |  | table |
| [workflow_review_request_authors](workflow_review_request_authors.md) | 2 |  | table |
| [workflow_review_request_reviewers](workflow_review_request_reviewers.md) | 2 |  | table |
| [workflow_review_request_workflow](workflow_review_request_workflow.md) | 5 |  | table |
| [workflow_statistics](workflow_statistics.md) | 7 |  | table |
| [workflow_suggestion](workflow_suggestion.md) | 16 |  | table |
| [workflow_suggestion_activity](workflow_suggestion_activity.md) | 7 |  | table |
| [workflows_tags](workflows_tags.md) | 2 |  | table |

## Relations

```mermaid
erDiagram

"activity_event" }o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"activity_event" }o--o| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"agent_background_job" }o--|| "agents" : "FOREIGN KEY (parentAgentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_channel_status" |o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_chat_attachments" }o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_chat_attachments" }o--o| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_chat_subscriptions" |o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_checkpoints" }o--o| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_credential_dependency" |o--|| "credentials_entity" : "FOREIGN KEY (credentialId) REFERENCES credentials_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_credential_dependency" |o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_eval_dataset" }o--o| "user" : "FOREIGN KEY (createdById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"agent_eval_dataset" }o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_eval_rating" }o--o| "user" : "FOREIGN KEY (ratedById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"agent_eval_rating" }o--|| "agent_eval_result" : "FOREIGN KEY (resultId) REFERENCES agent_eval_result (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_eval_result" }o--|| "agent_eval_run" : "FOREIGN KEY (runId) REFERENCES agent_eval_run (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_eval_run" }o--o| "user" : "FOREIGN KEY (createdById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"agent_eval_run" }o--|| "agent_eval_dataset" : "FOREIGN KEY (datasetId) REFERENCES agent_eval_dataset (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_execution" }o--|| "agent_execution_threads" : "FOREIGN KEY (threadId) REFERENCES agent_execution_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_execution_message_links" |o--|| "agents_messages" : "FOREIGN KEY (messageId) REFERENCES agents_messages (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_execution_message_links" |o--|| "agent_execution" : "FOREIGN KEY (executionId) REFERENCES agent_execution (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_execution_threads" }o--o| "user" : "FOREIGN KEY (ownerId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"agent_execution_threads" }o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_execution_threads" }o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_execution_threads" }o--o| "agent_history" : "FOREIGN KEY (taskVersionId) REFERENCES agent_history (versionId) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"agent_files" }o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_history" }o--o| "user" : "FOREIGN KEY (publishedById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"agent_history" }o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_message_queue" }o--o| "agent_execution" : "FOREIGN KEY (executionId) REFERENCES agent_execution (id) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"agent_message_queue" }o--|| "agent_execution_threads" : "FOREIGN KEY (threadId) REFERENCES agent_execution_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_message_queue" }o--|| "agents_messages" : "FOREIGN KEY (messageId) REFERENCES agents_messages (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_message_queue" }o--o| "agent_execution" : "FOREIGN KEY (steeringExecutionId) REFERENCES agent_execution (id) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"agent_plan" }o--|| "agent_execution_threads" : "FOREIGN KEY (threadId) REFERENCES agent_execution_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_plan_history" |o--|| "agent_plan" : "FOREIGN KEY (planId) REFERENCES agent_plan (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_task_definition" }o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_task_run_lock" |o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_task_snapshot" |o--|| "agent_history" : "FOREIGN KEY (versionId) REFERENCES agent_history (versionId) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_thread_grants" |o--|| "agent_execution_threads" : "FOREIGN KEY (threadId) REFERENCES agent_execution_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_workflow_dependency" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agent_workflow_dependency" |o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents" }o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents" }o--o| "agent_history" : "FOREIGN KEY (activeVersionId) REFERENCES agent_history (versionId) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"agents_memory_entries" }o--o| "agents_memory_entries" : "FOREIGN KEY (supersededBy) REFERENCES agents_memory_entries (id) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"agents_memory_entries" }o--|| "agents_resources" : "FOREIGN KEY (resourceId) REFERENCES agents_resources (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entries" }o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_candidates" }o--o| "agents_messages" : "FOREIGN KEY (sourceMessageId) REFERENCES agents_messages (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"agents_memory_entry_candidates" }o--|| "agents_threads" : "FOREIGN KEY (threadId) REFERENCES agents_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_candidates" }o--|| "agents_resources" : "FOREIGN KEY (resourceId) REFERENCES agents_resources (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_candidates" }o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_locks" |o--|| "agents_resources" : "FOREIGN KEY (resourceId) REFERENCES agents_resources (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_locks" |o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_sources" }o--o| "agents_memory_entry_candidates" : "FOREIGN KEY (candidateId) REFERENCES agents_memory_entry_candidates (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_sources" }o--|| "agents_threads" : "FOREIGN KEY (threadId) REFERENCES agents_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_sources" }o--o| "agents_observations" : "FOREIGN KEY (observationId) REFERENCES agents_observations (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_sources" }o--|| "agents_memory_entries" : "FOREIGN KEY (memoryEntryId) REFERENCES agents_memory_entries (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_memory_entry_sources" }o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_messages" }o--|| "agents_threads" : "FOREIGN KEY (threadId) REFERENCES agents_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_observation_cursors" |o--|| "agents_threads" : "FOREIGN KEY (observationScopeId) REFERENCES agents_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_observation_cursors" |o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_observation_locks" |o--|| "agents_threads" : "FOREIGN KEY (observationScopeId) REFERENCES agents_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_observation_locks" |o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_observations" }o--o| "agents_observations" : "FOREIGN KEY (supersededBy) REFERENCES agents_observations (id) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"agents_observations" }o--o| "agents_observations" : "FOREIGN KEY (parentId) REFERENCES agents_observations (id) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"agents_observations" }o--|| "agents_threads" : "FOREIGN KEY (observationScopeId) REFERENCES agents_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"agents_observations" }o--|| "agents" : "FOREIGN KEY (agentId) REFERENCES agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"ai_builder_temporary_workflow" }o--|| "instance_ai_threads" : "FOREIGN KEY (threadId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"ai_builder_temporary_workflow" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"ai_preference" }o--o| "user" : "FOREIGN KEY (createdById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"ai_preference" }o--o| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"ai_preference" }o--o| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"auth_identity" }o--o| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"chat_hub_agent_tools" |o--|| "chat_hub_tools" : "FOREIGN KEY (toolId) REFERENCES chat_hub_tools (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"chat_hub_agent_tools" |o--|| "chat_hub_agents" : "FOREIGN KEY (agentId) REFERENCES chat_hub_agents (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"chat_hub_agents" }o--|| "user" : "FOREIGN KEY (ownerId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"chat_hub_agents" }o--o| "credentials_entity" : "FOREIGN KEY (credentialId) REFERENCES credentials_entity (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"chat_hub_messages" }o--o| "chat_hub_agents" : "FOREIGN KEY (agentId) REFERENCES chat_hub_agents (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"chat_hub_messages" }o--o| "execution_entity" : "FOREIGN KEY (executionId) REFERENCES execution_entity (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"chat_hub_messages" }o--o| "chat_hub_messages" : "FOREIGN KEY (revisionOfMessageId) REFERENCES chat_hub_messages (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"chat_hub_messages" }o--o| "chat_hub_messages" : "FOREIGN KEY (retryOfMessageId) REFERENCES chat_hub_messages (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"chat_hub_messages" }o--o| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"chat_hub_messages" }o--o| "chat_hub_messages" : "FOREIGN KEY (previousMessageId) REFERENCES chat_hub_messages (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"chat_hub_messages" }o--|| "chat_hub_sessions" : "FOREIGN KEY (sessionId) REFERENCES chat_hub_sessions (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"chat_hub_session_tools" |o--|| "chat_hub_tools" : "FOREIGN KEY (toolId) REFERENCES chat_hub_tools (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"chat_hub_session_tools" |o--|| "chat_hub_sessions" : "FOREIGN KEY (sessionId) REFERENCES chat_hub_sessions (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"chat_hub_sessions" }o--|| "user" : "FOREIGN KEY (ownerId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"chat_hub_sessions" }o--o| "credentials_entity" : "FOREIGN KEY (credentialId) REFERENCES credentials_entity (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"chat_hub_sessions" }o--o| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"chat_hub_sessions" }o--o| "chat_hub_agents" : "FOREIGN KEY (agentId) REFERENCES chat_hub_agents (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"chat_hub_tools" }o--|| "user" : "FOREIGN KEY (ownerId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"credential_dependency" }o--|| "credentials_entity" : "FOREIGN KEY (credentialId) REFERENCES credentials_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"credentials_entity" }o--o| "dynamic_credential_resolver" : "FOREIGN KEY (resolverId) REFERENCES dynamic_credential_resolver (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"data_table" }o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"data_table_column" }o--|| "data_table" : "FOREIGN KEY (dataTableId) REFERENCES data_table (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"dynamic_credential_entry" |o--|| "dynamic_credential_resolver" : "FOREIGN KEY (resolver_id) REFERENCES dynamic_credential_resolver (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"dynamic_credential_entry" |o--|| "credentials_entity" : "FOREIGN KEY (credential_id) REFERENCES credentials_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"dynamic_credential_user_entry" |o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"dynamic_credential_user_entry" |o--|| "dynamic_credential_resolver" : "FOREIGN KEY (resolverId) REFERENCES dynamic_credential_resolver (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"dynamic_credential_user_entry" |o--|| "credentials_entity" : "FOREIGN KEY (credentialId) REFERENCES credentials_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"evaluation_collection" }o--o| "user" : "FOREIGN KEY (createdById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"evaluation_collection" }o--|| "evaluation_config" : "FOREIGN KEY (evaluationConfigId) REFERENCES evaluation_config (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"evaluation_collection" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"evaluation_config" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"execution_annotation_tags" |o--|| "annotation_tag_entity" : "FOREIGN KEY (tagId) REFERENCES annotation_tag_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"execution_annotation_tags" |o--|| "execution_annotations" : "FOREIGN KEY (annotationId) REFERENCES execution_annotations (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"execution_annotations" }o--|| "execution_entity" : "FOREIGN KEY (executionId) REFERENCES execution_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"execution_data" |o--|| "execution_entity" : "FOREIGN KEY (executionId) REFERENCES execution_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"execution_entity" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"execution_metadata" }o--|| "execution_entity" : "FOREIGN KEY (executionId) REFERENCES execution_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"folder" }o--o| "folder" : "FOREIGN KEY (parentFolderId) REFERENCES folder (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"folder" }o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"folder_tag" |o--|| "tag_entity" : "FOREIGN KEY (tagId) REFERENCES tag_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"folder_tag" |o--|| "folder" : "FOREIGN KEY (folderId) REFERENCES folder (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"idempotency_key" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"insights_by_period" }o--|| "insights_metadata" : "FOREIGN KEY (metaId) REFERENCES insights_metadata (metaId) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"insights_metadata" }o--o| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"insights_metadata" }o--o| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"insights_raw" }o--|| "insights_metadata" : "FOREIGN KEY (metaId) REFERENCES insights_metadata (metaId) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"installed_nodes" }o--|| "installed_packages" : "FOREIGN KEY (package) REFERENCES installed_packages (packageName) ON UPDATE CASCADE ON DELETE CASCADE MATCH NONE"
"instance_ai_checkpoints" }o--|| "instance_ai_threads" : "FOREIGN KEY (threadId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_events" |o--|| "instance_ai_threads" : "FOREIGN KEY (threadId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_iteration_logs" }o--|| "instance_ai_threads" : "FOREIGN KEY (threadId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_mcp_registry_connections" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_mcp_registry_connections" }o--|| "mcp_registry_server" : "FOREIGN KEY (serverSlug) REFERENCES mcp_registry_server (slug) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_mcp_registry_connections" }o--|| "credentials_entity" : "FOREIGN KEY (credentialId) REFERENCES credentials_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_messages" }o--|| "instance_ai_threads" : "FOREIGN KEY (threadId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_observation_cursors" |o--|| "instance_ai_threads" : "FOREIGN KEY (observationScopeId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_observation_locks" |o--|| "instance_ai_threads" : "FOREIGN KEY (observationScopeId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_observational_memory" }o--o| "instance_ai_threads" : "FOREIGN KEY (threadId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"instance_ai_observations" }o--o| "instance_ai_observations" : "FOREIGN KEY (supersededBy) REFERENCES instance_ai_observations (id) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"instance_ai_observations" }o--o| "instance_ai_observations" : "FOREIGN KEY (parentId) REFERENCES instance_ai_observations (id) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"instance_ai_observations" }o--|| "instance_ai_threads" : "FOREIGN KEY (observationScopeId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_pending_confirmations" }o--o| "instance_ai_checkpoints" : "FOREIGN KEY (checkpointKey) REFERENCES instance_ai_checkpoints (key) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_pending_confirmations" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_pending_confirmations" }o--|| "instance_ai_threads" : "FOREIGN KEY (threadId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_thread_grants" |o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_thread_grants" |o--|| "instance_ai_threads" : "FOREIGN KEY (threadId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_thread_tabs" |o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_thread_tabs" |o--|| "instance_ai_threads" : "FOREIGN KEY (threadId) REFERENCES instance_ai_threads (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_ai_threads" }o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"instance_credential_assignment" }o--|| "credentials_entity" : "FOREIGN KEY (credentialId) REFERENCES credentials_entity (id) ON UPDATE NO ACTION ON DELETE RESTRICT MATCH NONE"
"migration_finding" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"migration_workflow_owner" }o--o| "user" : "FOREIGN KEY (assignedById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"migration_workflow_owner" }o--o| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"migration_workflow_owner" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"oauth_access_tokens" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"oauth_access_tokens" }o--|| "oauth_clients" : "FOREIGN KEY (clientId) REFERENCES oauth_clients (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"oauth_authorization_codes" }o--|| "oauth_clients" : "FOREIGN KEY (clientId) REFERENCES oauth_clients (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"oauth_authorization_codes" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"oauth_refresh_tokens" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"oauth_refresh_tokens" }o--|| "oauth_clients" : "FOREIGN KEY (clientId) REFERENCES oauth_clients (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"oauth_user_consents" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"oauth_user_consents" }o--|| "oauth_clients" : "FOREIGN KEY (clientId) REFERENCES oauth_clients (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"poller_state" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"processed_data" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"project" }o--o| "user" : "FOREIGN KEY (creatorId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"project_pool_settings" |o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"project_relation" }o--|| "role" : "FOREIGN KEY (role) REFERENCES role (slug) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"project_relation" |o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"project_relation" |o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"project_secrets_provider_access" |o--|| "secrets_provider_connection" : "FOREIGN KEY (secretsProviderConnectionId) REFERENCES secrets_provider_connection (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"project_secrets_provider_access" |o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"promotion_config" }o--|| "promotion_connection" : "FOREIGN KEY (connectionId) REFERENCES promotion_connection (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"promotion_connection" }o--|| "promotion_provider" : "FOREIGN KEY (providerId) REFERENCES promotion_provider (id) ON UPDATE NO ACTION ON DELETE RESTRICT MATCH NONE"
"promotion_connection_project" }o--|| "promotion_connection" : "FOREIGN KEY (connectionId) REFERENCES promotion_connection (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"promotion_connection_project" |o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"role_mapping_rule" }o--|| "role" : "FOREIGN KEY (role) REFERENCES role (slug) ON UPDATE CASCADE ON DELETE CASCADE MATCH NONE"
"role_mapping_rule_project" |o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"role_mapping_rule_project" |o--|| "role_mapping_rule" : "FOREIGN KEY (roleMappingRuleId) REFERENCES role_mapping_rule (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"role_scope" |o--|| "scope" : "FOREIGN KEY (scopeSlug) REFERENCES scope (slug) ON UPDATE CASCADE ON DELETE CASCADE MATCH NONE"
"role_scope" |o--|| "role" : "FOREIGN KEY (roleSlug) REFERENCES role (slug) ON UPDATE CASCADE ON DELETE CASCADE MATCH NONE"
"scheduled_task" }o--|| "scheduled_job" : "FOREIGN KEY (jobId) REFERENCES scheduled_job (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"self_healing_result" }o--o| "user" : "FOREIGN KEY (dismissedById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"self_healing_result" }o--o| "workflow_suggestion" : "FOREIGN KEY (suggestionId) REFERENCES workflow_suggestion (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"self_healing_result" }o--|| "user" : "FOREIGN KEY (backgroundUserId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"self_healing_result" }o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"self_healing_result" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"shared_credentials" |o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"shared_credentials" |o--|| "credentials_entity" : "FOREIGN KEY (credentialsId) REFERENCES credentials_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"shared_workflow" |o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"shared_workflow" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"test_case_execution" }o--|| "test_run" : "FOREIGN KEY (testRunId) REFERENCES test_run (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"test_case_execution" }o--o| "execution_entity" : "FOREIGN KEY (pastExecutionId) REFERENCES execution_entity (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"test_case_execution" }o--o| "execution_entity" : "FOREIGN KEY (executionId) REFERENCES execution_entity (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"test_case_execution" }o--o| "execution_entity" : "FOREIGN KEY (evaluationExecutionId) REFERENCES execution_entity (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"test_run" }o--o| "evaluation_collection" : "FOREIGN KEY (collectionId) REFERENCES evaluation_collection (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"test_run" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"test_run" }o--o| "evaluation_config" : "FOREIGN KEY (evaluationConfigId) REFERENCES evaluation_config (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"trusted_key" |o--|| "trusted_key_source" : "FOREIGN KEY (sourceId) REFERENCES trusted_key_source (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"trusted_source_identity" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"trusted_source_identity" |o--|| "trusted_source" : "FOREIGN KEY (sourceId) REFERENCES trusted_source (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"type_availability_policy_attachment" |o--|| "type_availability_policy" : "FOREIGN KEY (policyId) REFERENCES type_availability_policy (id) ON UPDATE NO ACTION ON DELETE RESTRICT MATCH NONE"
"type_availability_policy_attachment" |o--|| "type_availability_policy_scope" : "FOREIGN KEY (scopeId) REFERENCES type_availability_policy_scope (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"type_availability_policy_scope" }o--o| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"user" }o--|| "role" : "FOREIGN KEY (roleSlug) REFERENCES role (slug) ON UPDATE NO ACTION ON DELETE NO ACTION MATCH NONE"
"user_api_keys" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"user_favorites" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"variables" }o--o| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_builder_session" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_builder_session" }o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_dependency" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_entity" }o--o| "workflow_history" : "FOREIGN KEY (activeVersionId) REFERENCES workflow_history (versionId) ON UPDATE NO ACTION ON DELETE RESTRICT MATCH NONE"
"workflow_entity" }o--o| "folder" : "FOREIGN KEY (parentFolderId) REFERENCES folder (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_history" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_publication_retry_state" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_publication_trigger_status" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_publication_trigger_status" }o--|| "workflow_history" : "FOREIGN KEY (versionId) REFERENCES workflow_history (versionId) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_publish_history" }o--o| "workflow_history" : "FOREIGN KEY (versionId) REFERENCES workflow_history (versionId) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"workflow_publish_history" }o--o| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"workflow_publish_history" }o--o| "workflow_history" : "FOREIGN KEY (versionId) REFERENCES workflow_history (versionId) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_publish_history" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_published_version" }o--|| "workflow_history" : "FOREIGN KEY (publishedVersionId) REFERENCES workflow_history (versionId) ON UPDATE NO ACTION ON DELETE RESTRICT MATCH NONE"
"workflow_published_version" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE RESTRICT MATCH NONE"
"workflow_published_version" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_published_version" }o--|| "workflow_history" : "FOREIGN KEY (publishedVersionId) REFERENCES workflow_history (versionId) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_review_activity" }o--|| "workflow_review_request" : "FOREIGN KEY (workflowReviewRequestId) REFERENCES workflow_review_request (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_review_activity" }o--o| "user" : "FOREIGN KEY (createdById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"workflow_review_activity_comment" }o--o| "user" : "FOREIGN KEY (createdById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"workflow_review_activity_comment" }o--|| "workflow_review_activity" : "FOREIGN KEY (activityId) REFERENCES workflow_review_activity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_review_request" }o--o| "user" : "FOREIGN KEY (closedById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"workflow_review_request" }o--o| "user" : "FOREIGN KEY (updatedById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"workflow_review_request" }o--o| "user" : "FOREIGN KEY (createdById) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"workflow_review_request" }o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_review_request_authors" |o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_review_request_authors" |o--|| "workflow_review_request" : "FOREIGN KEY (workflowReviewRequestId) REFERENCES workflow_review_request (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_review_request_reviewers" |o--|| "user" : "FOREIGN KEY (userId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_review_request_reviewers" |o--|| "workflow_review_request" : "FOREIGN KEY (workflowReviewRequestId) REFERENCES workflow_review_request (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_review_request_workflow" }o--o| "workflow_history" : "FOREIGN KEY (baselineVersionId) REFERENCES workflow_history (versionId) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"workflow_review_request_workflow" }o--|| "workflow_review_request" : "FOREIGN KEY (workflowReviewRequestId) REFERENCES workflow_review_request (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_review_request_workflow" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_review_request_workflow" }o--o| "workflow_history" : "FOREIGN KEY (workflowVersionId) REFERENCES workflow_history (versionId) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"workflow_suggestion" }o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_suggestion" }o--|| "project" : "FOREIGN KEY (projectId) REFERENCES project (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_suggestion" }o--|| "user" : "FOREIGN KEY (backgroundUserId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflow_suggestion_activity" }o--o| "user" : "FOREIGN KEY (actorId) REFERENCES user (id) ON UPDATE NO ACTION ON DELETE SET NULL MATCH NONE"
"workflow_suggestion_activity" }o--|| "workflow_suggestion" : "FOREIGN KEY (suggestionId) REFERENCES workflow_suggestion (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflows_tags" |o--|| "tag_entity" : "FOREIGN KEY (tagId) REFERENCES tag_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"
"workflows_tags" |o--|| "workflow_entity" : "FOREIGN KEY (workflowId) REFERENCES workflow_entity (id) ON UPDATE NO ACTION ON DELETE CASCADE MATCH NONE"

"activity_event" {
  varchar_64_ action
  varchar_32_ category
  datetime_3_ createdAt
  TEXT data
  INTEGER id
  varchar_36_ projectId FK
  varchar_36_ resourceId
  TEXT resourceName
  varchar_32_ resourceType
  INTEGER typeVersion
  varchar userId FK
}
"agent_background_job" {
  varchar_36_ childExecutionId
  varchar_128_ childThreadId
  datetime_3_ createdAt
  TEXT error
  varchar_36_ id PK
  varchar_16_ kind
  datetime_3_ notifiedAt
  varchar_36_ parentAgentId FK
  varchar_64_ parentPrincipalHash
  varchar_255_ parentResourceId
  varchar_128_ parentThreadId
  varchar pauseRequestId
  TEXT result
  datetime_3_ settledAt
  varchar_16_ status
  varchar_36_ subAgentId
  datetime_3_ timeoutAt
  varchar_255_ title
  datetime_3_ updatedAt
  varchar_36_ workflowId
}
"agent_budget_applied_call" {
  varchar callId PK
  datetime_3_ createdAt
}
"agent_budget_spend" {
  datetime_3_ createdAt
  varchar_128_ key PK
  REAL totalUsd
  datetime_3_ updatedAt
}
"agent_channel_status" {
  varchar_36_ agentId PK
  INTEGER attempts
  datetime_3_ backoffUntil
  datetime_3_ createdAt
  varchar_36_ credentialId PK
  TEXT errorMessage
  datetime_3_ expiresAt
  varchar_128_ hostId PK
  varchar_64_ integrationType PK
  varchar_16_ status
  datetime_3_ updatedAt
}
"agent_chat_attachments" {
  varchar_36_ agentId FK
  TEXT binaryDataId
  datetime_3_ createdAt
  varchar_255_ fileName
  INTEGER fileSizeBytes
  varchar_16_ id PK
  varchar_255_ mimeType
  varchar_36_ projectId FK
  varchar_255_ resourceId
  varchar_32_ source
  varchar_128_ threadId
  datetime_3_ updatedAt
}
"agent_chat_subscriptions" {
  varchar_36_ agentId PK
  datetime_3_ createdAt
  varchar_255_ credentialId PK
  varchar_64_ integrationType PK
  varchar_255_ threadId PK
  datetime_3_ updatedAt
}
"agent_checkpoints" {
  varchar_255_ agentId FK
  datetime_3_ createdAt
  boolean expired
  varchar_255_ runId PK
  TEXT state
  TEXT threadId
  datetime_3_ updatedAt
}
"agent_credential_dependency" {
  varchar_36_ agentId PK
  datetime_3_ createdAt
  varchar_36_ credentialId PK
}
"agent_eval_dataset" {
  varchar_36_ agentId FK
  TEXT columnMapping
  datetime_3_ createdAt
  varchar createdById FK
  TEXT datasetRef
  varchar_32_ datasetSource
  TEXT description
  varchar_36_ id PK
  varchar_128_ name
  datetime_3_ updatedAt
}
"agent_eval_rating" {
  TEXT comment
  TEXT correction
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar ratedById FK
  varchar_36_ resultId FK
  datetime_3_ updatedAt
  varchar_8_ vote
}
"agent_eval_result" {
  datetime_3_ completedAt
  datetime_3_ createdAt
  varchar_255_ errorCode
  TEXT errorDetails
  varchar_36_ id PK
  TEXT input
  TEXT metrics
  TEXT output
  datetime_3_ runAt
  varchar_36_ runId FK
  INTEGER runIndex
  varchar_255_ sourceRowId
  varchar status
  TEXT toolCalls
  datetime_3_ updatedAt
  JSON verdict
}
"agent_eval_run" {
  varchar_36_ agentVersionId
  boolean cancelRequested
  datetime_3_ completedAt
  datetime_3_ createdAt
  varchar createdById FK
  varchar_36_ datasetId FK
  varchar_255_ errorCode
  TEXT errorDetails
  varchar_36_ id PK
  TEXT metrics
  datetime_3_ runAt
  varchar_255_ runningInstanceId
  varchar status
  datetime_3_ updatedAt
}
"agent_execution" {
  BOOLEAN acceptsSteering
  TEXT attachments
  TEXT author
  INTEGER completionTokens
  REAL cost
  datetime_3_ createdAt
  INTEGER duration
  TEXT error
  TEXT failureSummary
  varchar_16_ hitlStatus
  varchar_36_ id PK
  varchar_255_ model
  INTEGER promptTokens
  varchar_32_ source
  datetime_3_ startedAt
  varchar_16_ status
  datetime_3_ stoppedAt
  varchar_2_ storedAt
  varchar_128_ threadId FK
  TEXT timeline
  INTEGER totalTokens
  datetime_3_ updatedAt
  TEXT userMessage
}
"agent_execution_message_links" {
  datetime_3_ createdAt
  varchar_6_ direction
  varchar_36_ executionId PK
  varchar_36_ messageId PK
  INTEGER position
}
"agent_execution_threads" {
  varchar_16_ accessScope
  varchar_36_ agentId FK
  varchar_255_ agentName
  datetime_3_ createdAt
  varchar_8_ emoji
  varchar_128_ id PK
  varchar ownerId FK
  varchar_36_ parentAgentId
  varchar_128_ parentThreadId
  varchar_255_ projectId FK
  INTEGER sessionNumber
  varchar_32_ taskId
  varchar_36_ taskVersionId FK
  varchar_255_ title
  INTEGER totalCompletionTokens
  REAL totalCost
  INTEGER totalDuration
  INTEGER totalPromptTokens
  datetime_3_ updatedAt
}
"agent_files" {
  varchar_36_ agentId FK
  TEXT binaryDataId
  datetime_3_ createdAt
  varchar_255_ fileName
  INTEGER fileSizeBytes
  varchar_16_ id PK
  varchar_255_ mimeType
  TEXT storageKey
  varchar_2_ storedAt
  datetime_3_ updatedAt
}
"agent_history" {
  varchar_36_ agentId FK
  varchar_255_ author
  datetime_3_ createdAt
  varchar publishedById FK
  TEXT schema
  TEXT skills
  TEXT tools
  datetime_3_ updatedAt
  varchar_36_ versionId PK
}
"agent_message_queue" {
  datetime_3_ createdAt
  varchar_36_ executionId FK
  INTEGER id
  varchar_36_ messageId FK
  TEXT payload
  INTEGER position
  varchar_36_ steeringExecutionId FK
  INTEGER steeringOrder
  varchar_128_ threadId FK
  datetime_3_ updatedAt
}
"agent_plan" {
  datetime_3_ closedAt
  datetime_3_ createdAt
  TEXT data
  INTEGER formatVersion
  varchar id PK
  INTEGER revision
  varchar_128_ threadId FK
  datetime_3_ updatedAt
}
"agent_plan_history" {
  datetime_3_ closedAt
  datetime_3_ createdAt
  TEXT data
  INTEGER formatVersion
  varchar planId PK
  INTEGER revision PK
}
"agent_task_definition" {
  varchar_36_ agentId FK
  datetime_3_ createdAt
  varchar_128_ cronExpression
  varchar_32_ id PK
  varchar_128_ name
  TEXT objective
  varchar_64_ timezone
  datetime_3_ updatedAt
}
"agent_task_run_lock" {
  varchar_36_ agentId PK
  datetime_3_ createdAt
  datetime_3_ heldUntil
  varchar holderId
  varchar_32_ taskId PK
  datetime_3_ updatedAt
}
"agent_task_snapshot" {
  datetime_3_ createdAt
  varchar_128_ cronExpression
  boolean enabled
  varchar_128_ name
  TEXT objective
  varchar_32_ taskId PK
  varchar_64_ timezone
  datetime_3_ updatedAt
  varchar_36_ versionId PK
}
"agent_thread_grants" {
  datetime_3_ createdAt
  varchar_512_ grantKey PK
  varchar_128_ threadId PK
  datetime_3_ updatedAt
}
"agent_workflow_dependency" {
  varchar_36_ agentId PK
  datetime_3_ createdAt
  varchar_36_ workflowId PK
}
"agents" {
  varchar_36_ activeVersionId FK
  boolean availableInMCP
  datetime_3_ createdAt
  varchar_36_ id PK
  TEXT integrations
  varchar_128_ name
  varchar_255_ projectId FK
  INTEGER revision
  TEXT schema
  datetime_3_ setupCompletedAt
  TEXT skills
  TEXT tools
  datetime_3_ updatedAt
  varchar_36_ versionId
}
"agents_memory_entries" {
  varchar_36_ agentId FK
  TEXT content
  varchar_64_ contentHash
  datetime_3_ createdAt
  TEXT embedding
  varchar_128_ embeddingModel
  varchar_36_ id PK
  datetime_3_ lastSeenAt
  TEXT metadata
  varchar_255_ resourceId FK
  varchar_16_ status
  varchar_36_ supersededBy FK
  datetime_3_ updatedAt
}
"agents_memory_entry_candidates" {
  varchar_36_ agentId FK
  smallint attemptCount
  TEXT content
  datetime_3_ createdAt
  TEXT evidenceText
  varchar_36_ id PK
  varchar_32_ kind
  varchar_255_ resourceId FK
  varchar_255_ runId
  varchar_36_ sourceMessageId FK
  varchar_16_ status
  varchar_255_ threadId FK
  varchar_255_ toolCallId
  datetime_3_ updatedAt
}
"agents_memory_entry_locks" {
  varchar_36_ agentId PK
  datetime_3_ createdAt
  datetime_3_ heldUntil
  varchar_64_ holderId
  varchar_255_ resourceId PK
  datetime_3_ updatedAt
}
"agents_memory_entry_sources" {
  varchar_36_ agentId FK
  varchar_36_ candidateId FK
  datetime_3_ createdAt
  varchar_64_ evidenceHash
  TEXT evidenceText
  varchar_36_ id PK
  varchar_36_ memoryEntryId FK
  varchar_36_ observationId FK
  varchar_255_ threadId FK
  datetime_3_ updatedAt
}
"agents_messages" {
  TEXT author
  TEXT content
  datetime_3_ createdAt
  varchar_36_ id PK
  TEXT modelContent
  DATETIME modelContextAt
  TEXT origin
  varchar_255_ resourceId
  varchar_36_ role
  varchar_255_ threadId FK
  varchar_36_ type
  datetime_3_ updatedAt
}
"agents_observation_cursors" {
  varchar_36_ agentId PK
  datetime_3_ createdAt
  datetime_3_ lastObservedAt
  varchar_36_ lastObservedMessageId
  varchar_255_ observationScopeId PK
  datetime_3_ updatedAt
}
"agents_observation_locks" {
  varchar_36_ agentId PK
  datetime_3_ createdAt
  datetime_3_ heldUntil
  varchar_64_ holderId
  varchar_255_ observationScopeId PK
  varchar_20_ taskKind PK
  datetime_3_ updatedAt
}
"agents_observations" {
  varchar_36_ agentId FK
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_16_ marker
  varchar_255_ observationScopeId FK
  varchar_36_ parentId FK
  varchar_16_ status
  varchar_36_ supersededBy FK
  TEXT text
  INTEGER tokenCount
  datetime_3_ updatedAt
}
"agents_resources" {
  datetime_3_ createdAt
  varchar_255_ id PK
  TEXT metadata
  datetime_3_ updatedAt
}
"agents_threads" {
  datetime_3_ createdAt
  varchar_128_ id PK
  TEXT metadata
  varchar_255_ resourceId
  varchar_255_ title
  datetime_3_ updatedAt
}
"ai_builder_temporary_workflow" {
  datetime_3_ createdAt
  varchar threadId FK
  datetime_3_ updatedAt
  varchar_36_ workflowId PK
}
"ai_preference" {
  TEXT content
  datetime_3_ createdAt
  varchar createdById FK
  varchar id PK
  varchar_36_ projectId FK
  varchar_16_ source
  datetime_3_ updatedAt
  varchar userId FK
}
"annotation_tag_entity" {
  datetime_3_ createdAt
  varchar_16_ id PK
  varchar_24_ name
  datetime_3_ updatedAt
}
"auth_identity" {
  timestamp createdAt
  VARCHAR_64_ providerId PK
  VARCHAR_32_ providerType PK
  timestamp updatedAt
  VARCHAR_36_ userId FK
}
"auth_provider_sync_history" {
  INTEGER created
  INTEGER disabled
  DATETIME endedAt
  TEXT error
  INTEGER id
  VARCHAR_32_ providerType
  TEXT runMode
  INTEGER scanned
  DATETIME startedAt
  TEXT status
  INTEGER updated
}
"binary_data" {
  datetime_3_ createdAt
  BLOB data
  varchar fileId PK
  varchar_255_ fileName
  INTEGER fileSize
  varchar_255_ mimeType
  varchar_255_ sourceId
  varchar_50_ sourceType
  datetime_3_ updatedAt
}
"chat_hub_agent_tools" {
  varchar agentId PK
  varchar toolId PK
}
"chat_hub_agents" {
  datetime_3_ createdAt
  varchar_36_ credentialId FK
  varchar_512_ description
  TEXT files
  TEXT icon
  varchar id PK
  varchar_64_ model
  varchar_256_ name
  varchar ownerId FK
  varchar_16_ provider
  TEXT suggestedPrompts
  TEXT systemPrompt
  datetime_3_ updatedAt
}
"chat_hub_messages" {
  varchar_36_ agentId FK
  TEXT attachments
  TEXT content
  datetime_3_ createdAt
  INTEGER executionId FK
  varchar id PK
  VARCHAR_256_ model
  varchar_128_ name
  varchar previousMessageId FK
  varchar_16_ provider
  varchar retryOfMessageId FK
  varchar revisionOfMessageId FK
  varchar sessionId FK
  varchar_16_ status
  varchar_16_ type
  datetime_3_ updatedAt
  varchar_36_ workflowId FK
}
"chat_hub_session_tools" {
  varchar sessionId PK
  varchar toolId PK
}
"chat_hub_sessions" {
  varchar_36_ agentId FK
  varchar_128_ agentName
  datetime_3_ createdAt
  varchar_36_ credentialId FK
  varchar id PK
  datetime_3_ lastMessageAt
  varchar_64_ model
  varchar ownerId FK
  varchar_16_ provider
  varchar_256_ title
  varchar_16_ type
  datetime_3_ updatedAt
  varchar_36_ workflowId FK
}
"chat_hub_tools" {
  datetime_3_ createdAt
  TEXT definition
  boolean enabled
  varchar id PK
  varchar_255_ name
  varchar ownerId FK
  varchar_255_ type
  REAL typeVersion
  datetime_3_ updatedAt
}
"credential_dependency" {
  datetime_3_ createdAt
  varchar_36_ credentialId FK
  varchar_255_ dependencyId
  varchar_64_ dependencyType
  INTEGER id
}
"credentials_entity" {
  datetime_3_ createdAt
  TEXT data
  TEXT description
  varchar_36_ id PK
  boolean isGlobal
  boolean isManaged
  boolean isResolvable
  varchar_128_ name
  DATETIME pendingAuthorizationExpiresAt
  boolean resolvableAllowFallback
  varchar_16_ resolverId FK
  varchar_32_ type
  datetime_3_ updatedAt
  VARCHAR_16_ usageScope
}
"data_table" {
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_128_ name
  varchar_36_ projectId FK
  datetime_3_ updatedAt
}
"data_table_column" {
  datetime_3_ createdAt
  varchar_36_ dataTableId FK
  varchar_36_ id PK
  INTEGER index
  varchar_128_ name
  varchar_32_ type
  datetime_3_ updatedAt
}
"deployment_key" {
  varchar_20_ algorithm
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_20_ status
  varchar_64_ type
  datetime_3_ updatedAt
  TEXT value
}
"dynamic_credential_entry" {
  datetime_3_ createdAt
  varchar_16_ credential_id PK
  TEXT data
  varchar_16_ resolver_id PK
  varchar_2048_ subject_id PK
  datetime_3_ updatedAt
}
"dynamic_credential_resolver" {
  TEXT config
  datetime_3_ createdAt
  varchar_16_ id PK
  varchar_128_ name
  varchar_128_ type
  datetime_3_ updatedAt
}
"dynamic_credential_user_entry" {
  datetime_3_ createdAt
  varchar_16_ credentialId PK
  TEXT data
  varchar_16_ resolverId PK
  datetime_3_ updatedAt
  varchar userId PK
}
"evaluation_collection" {
  datetime_3_ createdAt
  varchar createdById FK
  TEXT description
  varchar_36_ evaluationConfigId FK
  varchar_36_ id PK
  TEXT insightsCache
  varchar_128_ name
  datetime_3_ updatedAt
  varchar_36_ workflowId FK
}
"evaluation_config" {
  datetime_3_ createdAt
  TEXT datasetRef
  varchar_32_ datasetSource
  varchar_255_ endNodeName
  varchar_36_ id PK
  varchar_64_ invalidReason
  TEXT metrics
  varchar_128_ name
  varchar_255_ startNodeName
  varchar_16_ status
  datetime_3_ updatedAt
  varchar_36_ workflowId FK
}
"event_destinations" {
  datetime_3_ createdAt
  TEXT destination
  varchar_36_ id PK
  datetime_3_ updatedAt
}
"execution_annotation_tags" {
  INTEGER annotationId PK
  varchar_24_ tagId PK
}
"execution_annotations" {
  datetime_3_ createdAt
  INTEGER executionId FK
  INTEGER id
  TEXT note
  datetime_3_ updatedAt
  varchar_6_ vote
}
"execution_data" {
  TEXT data
  INT executionId PK
  TEXT workflowData
  VARCHAR_36_ workflowVersionId
}
"execution_entity" {
  bigint binaryDataSizeBytes
  datetime_3_ createdAt
  varchar_255_ deduplicationKey
  datetime_3_ deletedAt
  boolean finished
  INTEGER id
  bigint jsonSizeBytes
  varchar mode
  varchar retryOf
  varchar retrySuccessId
  datetime startedAt
  varchar status
  datetime stoppedAt
  varchar_2_ storedAt
  TEXT tracingContext
  BOOLEAN usedPrivateCredentials
  datetime waitTill
  varchar_36_ workflowId FK
  varchar_36_ workflowVersionId
}
"execution_metadata" {
  INTEGER executionId FK
  INTEGER id
  varchar_255_ key
  TEXT value
}
"folder" {
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_128_ name
  varchar_36_ parentFolderId FK
  varchar_36_ projectId FK
  datetime_3_ updatedAt
}
"folder_tag" {
  varchar_36_ folderId PK
  varchar_36_ tagId PK
}
"idempotency_key" {
  datetime_3_ createdAt
  TEXT fingerprint
  varchar_16_ id PK
  varchar_128_ idempotencyKey
  TEXT responseBody
  smallint responseStatus
  varchar_16_ status
  datetime_3_ updatedAt
  varchar userId FK
}
"insights_by_period" {
  INTEGER id
  INTEGER metaId FK
  datetime_0_ periodStart
  INTEGER periodUnit
  INTEGER type
  bigint value
}
"insights_metadata" {
  INTEGER metaId
  varchar_36_ projectId FK
  varchar_255_ projectName
  varchar_16_ workflowId FK
  varchar_128_ workflowName
}
"insights_raw" {
  INTEGER id
  INTEGER metaId FK
  datetime_0_ timestamp
  INTEGER type
  bigint value
}
"installed_nodes" {
  REAL latestVersion
  char_200_ name PK
  char_214_ package FK
  char_200_ type
}
"installed_packages" {
  char_70_ authorEmail
  char_70_ authorName
  datetime_3_ createdAt
  char_50_ installedVersion
  char_214_ packageName PK
  datetime_3_ updatedAt
}
"instance_ai_checkpoints" {
  datetime_3_ createdAt
  datetime_3_ expiredAt
  VARCHAR_64_ hostRunId
  varchar_255_ key PK
  varchar_255_ resourceId
  varchar_255_ runId
  TEXT state
  varchar threadId FK
  datetime_3_ updatedAt
}
"instance_ai_events" {
  datetime_3_ createdAt
  TEXT payload
  varchar_64_ runId
  INTEGER seq PK
  varchar threadId PK
  varchar_64_ type
  datetime_3_ updatedAt
}
"instance_ai_iteration_logs" {
  datetime_3_ createdAt
  TEXT entry
  varchar_36_ id PK
  varchar taskKey
  varchar threadId FK
  datetime_3_ updatedAt
}
"instance_ai_mcp_registry_connections" {
  datetime_3_ createdAt
  varchar_36_ credentialId FK
  varchar id PK
  varchar_255_ serverSlug FK
  TEXT toolPermissions
  datetime_3_ updatedAt
  varchar userId FK
}
"instance_ai_messages" {
  TEXT content
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_255_ resourceId
  varchar_16_ role
  varchar threadId FK
  varchar_32_ type
  datetime_3_ updatedAt
}
"instance_ai_observation_cursors" {
  datetime_3_ createdAt
  datetime_3_ lastObservedAt
  varchar_36_ lastObservedMessageId
  varchar observationScopeId PK
  datetime_3_ updatedAt
}
"instance_ai_observation_locks" {
  datetime_3_ createdAt
  datetime_3_ heldUntil
  varchar_64_ holderId
  varchar observationScopeId PK
  varchar_20_ taskKind PK
  datetime_3_ updatedAt
}
"instance_ai_observational_memory" {
  TEXT activeObservations
  TEXT bufferedMessageIds
  TEXT bufferedObservationChunks
  INTEGER bufferedObservationTokens
  TEXT bufferedObservations
  TEXT bufferedReflection
  INTEGER bufferedReflectionInputTokens
  INTEGER bufferedReflectionTokens
  TEXT config
  datetime_3_ createdAt
  INTEGER generationCount
  varchar_36_ id PK
  boolean isBufferingObservation
  boolean isBufferingReflection
  boolean isObserving
  boolean isReflecting
  datetime_3_ lastBufferedAtTime
  INTEGER lastBufferedAtTokens
  datetime_3_ lastObservedAt
  varchar_255_ lookupKey
  TEXT metadata
  INTEGER observationTokenCount
  TEXT observedMessageIds
  varchar observedTimezone
  varchar_32_ originType
  INTEGER pendingMessageTokens
  INTEGER reflectedObservationLineCount
  varchar_255_ resourceId
  varchar_16_ scope
  varchar threadId FK
  INTEGER totalTokensObserved
  datetime_3_ updatedAt
}
"instance_ai_observations" {
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_16_ marker
  varchar observationScopeId FK
  varchar_36_ parentId FK
  varchar_16_ status
  varchar_36_ supersededBy FK
  TEXT text
  INTEGER tokenCount
  datetime_3_ updatedAt
}
"instance_ai_pending_confirmations" {
  varchar_255_ checkpointKey FK
  varchar_36_ checkpointTaskId
  datetime_3_ createdAt
  datetime_3_ expiresAt
  varchar_16_ kind
  varchar_36_ messageGroupId
  varchar_36_ requestId PK
  varchar_36_ runId
  varchar threadId FK
  varchar_64_ toolCallId
  datetime_3_ updatedAt
  varchar userId FK
}
"instance_ai_resources" {
  datetime_3_ createdAt
  varchar_255_ id PK
  TEXT metadata
  datetime_3_ updatedAt
  TEXT workingMemory
}
"instance_ai_thread_grants" {
  datetime_3_ createdAt
  varchar_512_ grantKey PK
  varchar threadId PK
  datetime_3_ updatedAt
  varchar userId PK
}
"instance_ai_thread_tabs" {
  datetime_3_ createdAt
  TEXT state
  varchar threadId PK
  datetime_3_ updatedAt
  varchar userId PK
}
"instance_ai_threads" {
  datetime_3_ createdAt
  varchar id PK
  TEXT metadata
  varchar_36_ projectId FK
  varchar_255_ resourceId
  TEXT title
  datetime_3_ updatedAt
}
"instance_ai_workflow_snapshots" {
  datetime_3_ createdAt
  varchar_255_ resourceId
  varchar_36_ runId PK
  TEXT snapshot
  varchar status
  datetime_3_ updatedAt
  varchar_255_ workflowName PK
}
"instance_credential_assignment" {
  datetime_3_ createdAt
  varchar_36_ credentialId FK
  varchar_128_ credentialUseId PK
  datetime_3_ updatedAt
}
"instance_monitoring_report" {
  INTEGER attempts
  datetime_3_ createdAt
  TEXT dataPoints
  datetime_3_ deliveredAt
  varchar id PK
  datetime_3_ lastAttemptAt
  TEXT lastError
  varchar_10_ reportDate
  varchar_64_ status
  datetime_3_ updatedAt
}
"instance_version_history" {
  datetime_3_ createdAt
  INTEGER id
  INTEGER major
  INTEGER minor
  INTEGER patch
}
"invalid_auth_token" {
  datetime_3_ expiresAt
  varchar_512_ token PK
}
"mcp_registry_server" {
  datetime_3_ createdAt
  TEXT data
  datetime_3_ registryUpdatedAt
  varchar_255_ slug PK
  varchar_50_ status
  datetime_3_ updatedAt
  varchar_50_ version
}
"migration_finding" {
  datetime_3_ createdAt
  INTEGER id
  TEXT note
  datetime_3_ notifiedAt
  varchar_128_ ruleId
  varchar_32_ status
  datetime_3_ statusChangedAt
  varchar_16_ targetVersion
  datetime_3_ updatedAt
  varchar_36_ workflowId FK
}
"migration_finding_sync" {
  varchar_128_ ruleSetFingerprint
  datetime_3_ syncedAt
  varchar_16_ targetVersion PK
}
"migration_workflow_owner" {
  datetime_3_ assignedAt
  varchar assignedById FK
  datetime_3_ createdAt
  varchar_16_ source
  datetime_3_ updatedAt
  varchar userId FK
  varchar_36_ workflowId PK
}
"oauth_access_tokens" {
  varchar clientId FK
  varchar token PK
  varchar userId FK
}
"oauth_authorization_codes" {
  varchar clientId FK
  varchar_255_ code PK
  varchar codeChallenge
  varchar_255_ codeChallengeMethod
  datetime_3_ createdAt
  bigint expiresAt
  varchar redirectUri
  varchar resource
  TEXT scope
  varchar state
  datetime_3_ updatedAt
  boolean used
  varchar userId FK
}
"oauth_clients" {
  varchar_255_ clientSecret
  bigint clientSecretExpiresAt
  datetime_3_ createdAt
  TEXT grantTypes
  varchar id PK
  boolean isFirstParty
  varchar_255_ name
  TEXT redirectUris
  varchar_255_ tokenEndpointAuthMethod
  datetime_3_ updatedAt
}
"oauth_refresh_tokens" {
  varchar clientId FK
  datetime_3_ createdAt
  bigint expiresAt
  varchar resource
  TEXT scope
  varchar_255_ token PK
  datetime_3_ updatedAt
  varchar userId FK
}
"oauth_user_consents" {
  varchar clientId FK
  bigint grantedAt
  INTEGER id
  TEXT scope
  varchar userId FK
}
"poller_state" {
  datetime_3_ backoffUntil
  INTEGER consecutiveErrors
  datetime_3_ createdAt
  TEXT cursor
  varchar_36_ nodeId PK
  datetime_3_ updatedAt
  varchar_36_ workflowId PK
}
"processed_data" {
  varchar_255_ context PK
  datetime_3_ createdAt
  datetime_3_ updatedAt
  TEXT value
  varchar_36_ workflowId PK
}
"project" {
  datetime_3_ createdAt
  varchar creatorId FK
  TEXT customTelemetryTags
  varchar_512_ description
  TEXT icon
  varchar_36_ id PK
  varchar_255_ name
  varchar_36_ type
  datetime_3_ updatedAt
}
"project_pool_settings" {
  datetime_3_ createdAt
  varchar_63_ defaultPool
  varchar_36_ projectId PK
  datetime_3_ updatedAt
}
"project_relation" {
  datetime_3_ createdAt
  varchar_36_ projectId PK
  varchar role FK
  datetime_3_ updatedAt
  varchar userId PK
}
"project_secrets_provider_access" {
  datetime_3_ createdAt
  varchar_36_ projectId PK
  varchar_128_ role
  INTEGER secretsProviderConnectionId PK
  datetime_3_ updatedAt
}
"promotion_config" {
  varchar_36_ connectionId FK
  datetime_3_ createdAt
  varchar_16_ direction
  varchar_36_ id PK
  varchar_128_ name
  TEXT settings
  datetime_3_ updatedAt
}
"promotion_connection" {
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_128_ name
  varchar_36_ providerId FK
  varchar_16_ scope
  TEXT target
  datetime_3_ updatedAt
}
"promotion_connection_project" {
  varchar_36_ connectionId FK
  datetime_3_ createdAt
  varchar_36_ projectId PK
  datetime_3_ updatedAt
}
"promotion_provider" {
  TEXT auth
  varchar_32_ authType
  TEXT config
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_128_ name
  varchar_32_ type
  datetime_3_ updatedAt
}
"role" {
  datetime_3_ createdAt
  TEXT description
  TEXT displayName
  TEXT roleType
  varchar_128_ slug PK
  boolean systemRole
  datetime_3_ updatedAt
}
"role_mapping_rule" {
  datetime_3_ createdAt
  TEXT expression
  varchar_16_ id PK
  INTEGER order
  varchar_128_ role FK
  varchar_64_ type
  datetime_3_ updatedAt
}
"role_mapping_rule_project" {
  varchar_36_ projectId PK
  varchar_16_ roleMappingRuleId PK
}
"role_scope" {
  VARCHAR_128_ roleSlug PK
  VARCHAR_128_ scopeSlug PK
}
"scheduled_job" {
  INT concurrencyLimit
  datetime_3_ createdAt
  varchar_255_ cronExpression
  boolean enabled
  datetime_3_ fireAt
  INTEGER id
  INTEGER intervalSeconds
  varchar_16_ kind
  datetime_3_ lastFiredAt
  INTEGER maxAttempts
  INT misfireGraceSeconds
  varchar_16_ misfirePolicy
  varchar_255_ name
  datetime_3_ nextRunAt
  datetime_3_ orphanedAt
  varchar_255_ ownerId
  varchar_36_ ownerMemberId
  varchar_32_ ownerType
  TEXT payload
  INT recurrenceSize
  varchar_16_ recurrenceUnit
  varchar_128_ taskType
  INT timeoutSeconds
  varchar_64_ timezone
  datetime_3_ updatedAt
}
"scheduled_task" {
  INTEGER attempts
  varchar_255_ claimedBy
  datetime_3_ createdAt
  datetime_3_ dispatchedAt
  TEXT errorMessage
  datetime_3_ finishedAt
  INTEGER id
  INTEGER jobId FK
  INTEGER leaseEpoch
  datetime_3_ leaseExpiresAt
  INTEGER maxAttempts
  datetime_3_ missedAfter
  TEXT payload
  datetime_3_ runAt
  datetime_3_ scheduledFor
  datetime_3_ startedAt
  varchar_16_ status
  varchar_128_ taskType
  INT timeoutSeconds
}
"scope" {
  TEXT description
  TEXT displayName
  varchar_128_ slug PK
}
"secrets_provider_connection" {
  datetime_3_ createdAt
  TEXT encryptedSettings
  INTEGER id
  boolean isEnabled
  varchar_128_ providerKey
  varchar_36_ type
  datetime_3_ updatedAt
}
"self_healing_result" {
  varchar backgroundUserId FK
  datetime_3_ completedAt
  datetime_3_ createdAt
  datetime_3_ dismissedAt
  varchar dismissedById FK
  varchar_36_ executionId
  varchar_36_ id PK
  varchar_16_ outcome
  varchar_36_ projectId FK
  TEXT report
  varchar_36_ suggestionId FK
  TEXT summary
  datetime_3_ updatedAt
  TEXT usage
  varchar_36_ workflowId FK
}
"settings" {
  TEXT key PK
  boolean loadOnStartup
  TEXT value
}
"shared_credentials" {
  datetime_3_ createdAt
  varchar_36_ credentialsId PK
  varchar_36_ projectId PK
  TEXT role
  datetime_3_ updatedAt
}
"shared_workflow" {
  datetime_3_ createdAt
  varchar_36_ projectId PK
  TEXT role
  datetime_3_ updatedAt
  varchar_36_ workflowId PK
}
"tag_entity" {
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_24_ name
  datetime_3_ updatedAt
}
"test_case_execution" {
  datetime_3_ completedAt
  datetime_3_ createdAt
  varchar errorCode
  TEXT errorDetails
  INTEGER evaluationExecutionId FK
  INTEGER executionId FK
  varchar_36_ id PK
  TEXT inputs
  TEXT metrics
  TEXT outputs
  INTEGER pastExecutionId FK
  datetime_3_ runAt
  INTEGER runIndex
  varchar status
  varchar_36_ testRunId FK
  datetime_3_ updatedAt
}
"test_run" {
  boolean cancelRequested
  varchar_36_ collectionId FK
  datetime_3_ completedAt
  datetime_3_ createdAt
  varchar errorCode
  TEXT errorDetails
  varchar_36_ evaluationConfigId FK
  TEXT evaluationConfigSnapshot
  varchar_36_ id PK
  TEXT metrics
  datetime_3_ runAt
  varchar_255_ runningInstanceId
  varchar status
  datetime_3_ updatedAt
  varchar_36_ workflowId FK
  varchar_36_ workflowVersionId
}
"token_exchange_jti" {
  datetime_3_ createdAt
  datetime_3_ expiresAt
  varchar_255_ jti PK
}
"trusted_key" {
  datetime_3_ createdAt
  TEXT data
  varchar_255_ kid PK
  varchar_36_ sourceId PK
}
"trusted_key_source" {
  TEXT config
  datetime_3_ createdAt
  varchar_36_ id PK
  TEXT lastError
  datetime_3_ lastRefreshedAt
  varchar_32_ status
  varchar_32_ type
  datetime_3_ updatedAt
}
"trusted_source" {
  TEXT config
  INTEGER configVersion
  datetime_3_ createdAt
  varchar_36_ discoveryClaimToken
  datetime_3_ discoveryClaimedAt
  varchar_36_ id PK
  varchar issuer
  datetime_3_ lastCheckedAt
  TEXT lastError
  varchar_16_ managedBy
  TEXT metadata
  varchar_128_ name
  varchar_16_ status
  varchar_32_ type
  datetime_3_ updatedAt
}
"trusted_source_identity" {
  datetime_3_ createdAt
  datetime_3_ lastSeenAt
  varchar_32_ provenance
  varchar_36_ sourceId PK
  varchar_16_ status
  varchar subject PK
  datetime_3_ updatedAt
  varchar userId FK
}
"type_availability_policy" {
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_64_ kind
  TEXT rules
  datetime_3_ updatedAt
  varchar_36_ updatedBy
  INTEGER version
}
"type_availability_policy_attachment" {
  datetime_3_ createdAt
  boolean isFloor
  varchar_36_ policyId PK
  INTEGER priority
  varchar_36_ scopeId PK
  datetime_3_ updatedAt
}
"type_availability_policy_scope" {
  datetime_3_ createdAt
  varchar_16_ defaultAction
  varchar_36_ id PK
  varchar_64_ kind
  varchar_36_ projectId FK
  datetime_3_ updatedAt
  varchar_36_ updatedBy
  INTEGER version
}
"user" {
  datetime_3_ createdAt
  boolean disabled
  varchar_255_ email
  varchar_32_ firstName
  varchar id PK
  date lastActiveAt
  varchar_32_ lastName
  boolean mfaEnabled
  TEXT mfaRecoveryCodes
  TEXT mfaSecret
  varchar password
  TEXT personalizationAnswers
  varchar_128_ roleSlug FK
  TEXT settings
  datetime_3_ updatedAt
}
"user_api_keys" {
  varchar apiKey
  varchar audience
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_100_ label
  datetime_3_ lastUsedAt
  TEXT scopes
  datetime_3_ updatedAt
  varchar userId FK
}
"user_favorites" {
  INTEGER id
  varchar_255_ resourceId
  varchar_64_ resourceType
  varchar userId FK
}
"variables" {
  varchar_36_ id PK
  TEXT key
  varchar_36_ projectId FK
  TEXT type
  TEXT value
}
"webhook_entity" {
  varchar method PK
  varchar node
  INTEGER pathLength
  varchar webhookId
  varchar webhookPath PK
  varchar_36_ workflowId
}
"workflow_builder_session" {
  varchar_255_ activeVersionCardId
  datetime_3_ createdAt
  varchar id PK
  TEXT messages
  TEXT previousSummary
  varchar_255_ resumeAfterRestoreMessageId
  datetime_3_ updatedAt
  varchar userId FK
  varchar_36_ workflowId FK
}
"workflow_dependency" {
  datetime_3_ createdAt
  TEXT dependencyInfo
  varchar_255_ dependencyKey
  varchar_32_ dependencyType
  INTEGER id
  smallint indexVersionId
  varchar_36_ publishedVersionId
  varchar_36_ workflowId FK
  INTEGER workflowVersionId
}
"workflow_entity" {
  boolean active
  varchar_36_ activeVersionId FK
  TEXT connections
  datetime_3_ createdAt
  TEXT description
  varchar_36_ id PK
  boolean isArchived
  TEXT meta
  varchar_128_ name
  TEXT nodeGroups
  TEXT nodes
  varchar_36_ parentFolderId FK
  TEXT pinData
  TEXT settings
  varchar sourceWorkflowId
  TEXT staticData
  INTEGER triggerCount
  datetime_3_ updatedAt
  INTEGER versionCounter
  varchar_36_ versionId
}
"workflow_history" {
  varchar_255_ authors
  boolean autosaved
  TEXT connections
  datetime_3_ createdAt
  TEXT description
  varchar_128_ name
  TEXT nodeGroups
  TEXT nodes
  datetime_3_ updatedAt
  varchar_36_ versionId PK
  varchar_36_ workflowId FK
}
"workflow_publication_outbox" {
  datetime_3_ createdAt
  TEXT errorMessage
  INTEGER id
  varchar_36_ publishedVersionId
  varchar_20_ reason
  varchar_20_ status
  datetime_3_ updatedAt
  varchar_36_ workflowId
}
"workflow_publication_retry_state" {
  datetime_3_ createdAt
  varchar_36_ targetVersionId
  datetime_3_ updatedAt
  varchar_36_ workflowId PK
}
"workflow_publication_trigger_status" {
  datetime_3_ createdAt
  TEXT errorMessage
  varchar_36_ nodeId PK
  varchar_20_ status
  varchar_20_ triggerKind
  datetime_3_ updatedAt
  varchar_36_ versionId FK
  varchar_36_ workflowId PK
}
"workflow_publish_history" {
  datetime_3_ createdAt
  varchar_36_ event
  INTEGER id
  varchar userId FK
  varchar_36_ versionId FK
  varchar_36_ workflowId FK
}
"workflow_published_version" {
  datetime_3_ createdAt
  varchar_36_ publishedVersionId FK
  datetime_3_ updatedAt
  varchar_36_ workflowId PK
}
"workflow_review_activity" {
  datetime_3_ createdAt
  varchar createdById FK
  TEXT data
  INTEGER id
  varchar_64_ type
  INTEGER typeVersion
  varchar_36_ workflowReviewRequestId FK
}
"workflow_review_activity_comment" {
  INTEGER activityId FK
  TEXT body
  datetime_3_ createdAt
  varchar createdById FK
  datetime_3_ deletedAt
  TEXT history
  INTEGER id
  datetime_3_ updatedAt
}
"workflow_review_request" {
  datetime_3_ approvedAt
  varchar closedById FK
  datetime_3_ createdAt
  varchar createdById FK
  varchar_50_ decision
  TEXT description
  varchar_36_ id PK
  varchar_36_ projectId FK
  varchar_16_ state
  varchar_255_ title
  datetime_3_ updatedAt
  varchar updatedById FK
}
"workflow_review_request_authors" {
  varchar userId PK
  varchar_36_ workflowReviewRequestId PK
}
"workflow_review_request_reviewers" {
  varchar userId PK
  varchar_36_ workflowReviewRequestId PK
}
"workflow_review_request_workflow" {
  varchar_36_ baselineVersionId FK
  varchar_36_ id PK
  varchar_36_ workflowId FK
  varchar_36_ workflowReviewRequestId FK
  varchar_36_ workflowVersionId FK
}
"workflow_statistics" {
  INTEGER count
  INTEGER id
  DATETIME latestEvent
  VARCHAR_128_ name
  INTEGER rootCount
  VARCHAR_36_ workflowId
  VARCHAR_128_ workflowName
}
"workflow_suggestion" {
  varchar_32_ appliedAction
  varchar appliedActorId
  varchar_64_ appliedChecksum
  varchar_36_ appliedVersionId
  varchar backgroundUserId FK
  datetime_3_ closedAt
  varchar_16_ closedReason
  datetime_3_ createdAt
  TEXT expectedBaseline
  varchar_36_ id PK
  TEXT payload
  varchar_36_ projectId FK
  varchar_16_ resultKind
  varchar_16_ state
  datetime_3_ updatedAt
  varchar_36_ workflowId FK
}
"workflow_suggestion_activity" {
  varchar_16_ action
  varchar actorId FK
  varchar_16_ author
  datetime_3_ createdAt
  varchar_36_ id PK
  varchar_36_ suggestionId FK
  datetime_3_ updatedAt
}
"workflows_tags" {
  INTEGER tagId PK
  varchar_36_ workflowId PK
}
```

---

> Generated by [tbls](https://github.com/k1LoW/tbls)
