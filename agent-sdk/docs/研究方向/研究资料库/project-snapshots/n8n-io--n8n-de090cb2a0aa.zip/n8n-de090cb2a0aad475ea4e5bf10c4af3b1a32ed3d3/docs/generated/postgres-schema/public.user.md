# public.user

## Columns

| Name | Type | Default | Nullable | Children | Parents | Comment |
| ---- | ---- | ------- | -------- | -------- | ------- | ------- |
| createdAt | timestamp(3) with time zone | CURRENT_TIMESTAMP(3) | false |  |  |  |
| disabled | boolean | false | false |  |  |  |
| email | varchar(255) |  | true |  |  |  |
| firstName | varchar(32) |  | true |  |  |  |
| id | uuid | gen_random_uuid() | false | [public.activity_event](public.activity_event.md) [public.agent_eval_dataset](public.agent_eval_dataset.md) [public.agent_eval_rating](public.agent_eval_rating.md) [public.agent_eval_run](public.agent_eval_run.md) [public.agent_execution_threads](public.agent_execution_threads.md) [public.agent_history](public.agent_history.md) [public.ai_preference](public.ai_preference.md) [public.auth_identity](public.auth_identity.md) [public.chat_hub_agents](public.chat_hub_agents.md) [public.chat_hub_sessions](public.chat_hub_sessions.md) [public.chat_hub_tools](public.chat_hub_tools.md) [public.dynamic_credential_user_entry](public.dynamic_credential_user_entry.md) [public.evaluation_collection](public.evaluation_collection.md) [public.idempotency_key](public.idempotency_key.md) [public.instance_ai_mcp_registry_connections](public.instance_ai_mcp_registry_connections.md) [public.instance_ai_pending_confirmations](public.instance_ai_pending_confirmations.md) [public.instance_ai_thread_grants](public.instance_ai_thread_grants.md) [public.instance_ai_thread_tabs](public.instance_ai_thread_tabs.md) [public.migration_workflow_owner](public.migration_workflow_owner.md) [public.oauth_access_tokens](public.oauth_access_tokens.md) [public.oauth_authorization_codes](public.oauth_authorization_codes.md) [public.oauth_refresh_tokens](public.oauth_refresh_tokens.md) [public.oauth_user_consents](public.oauth_user_consents.md) [public.project](public.project.md) [public.project_relation](public.project_relation.md) [public.self_healing_result](public.self_healing_result.md) [public.trusted_source_identity](public.trusted_source_identity.md) [public.user_api_keys](public.user_api_keys.md) [public.user_favorites](public.user_favorites.md) [public.workflow_builder_session](public.workflow_builder_session.md) [public.workflow_publish_history](public.workflow_publish_history.md) [public.workflow_review_activity](public.workflow_review_activity.md) [public.workflow_review_activity_comment](public.workflow_review_activity_comment.md) [public.workflow_review_request](public.workflow_review_request.md) [public.workflow_review_request_authors](public.workflow_review_request_authors.md) [public.workflow_review_request_reviewers](public.workflow_review_request_reviewers.md) [public.workflow_suggestion](public.workflow_suggestion.md) [public.workflow_suggestion_activity](public.workflow_suggestion_activity.md) |  |  |
| lastActiveAt | date |  | true |  |  |  |
| lastName | varchar(32) |  | true |  |  |  |
| mfaEnabled | boolean | false | false |  |  |  |
| mfaRecoveryCodes | text |  | true |  |  |  |
| mfaSecret | text |  | true |  |  |  |
| password | varchar(255) |  | true |  |  |  |
| personalizationAnswers | json |  | true |  |  |  |
| roleSlug | varchar(128) | 'global:member'::character varying | false |  | [public.role](public.role.md) |  |
| settings | json |  | true |  |  |  |
| updatedAt | timestamp(3) with time zone | CURRENT_TIMESTAMP(3) | false |  |  |  |

## Constraints

| Name | Type | Definition |
| ---- | ---- | ---------- |
| FK_eaea92ee7bfb9c1b6cd01505d56 | FOREIGN KEY | FOREIGN KEY ("roleSlug") REFERENCES role(slug) |
| PK_ea8f538c94b6e352418254ed6474a81f | PRIMARY KEY | PRIMARY KEY (id) |
| UQ_e12875dfb3b1d92d7d7c5377e2 | UNIQUE | UNIQUE (email) |
| user_createdAt_not_null | n | NOT NULL "createdAt" |
| user_disabled_not_null | n | NOT NULL disabled |
| user_id_not_null | n | NOT NULL id |
| user_mfaEnabled_not_null | n | NOT NULL "mfaEnabled" |
| user_roleSlug_not_null | n | NOT NULL "roleSlug" |
| user_updatedAt_not_null | n | NOT NULL "updatedAt" |

## Indexes

| Name | Definition |
| ---- | ---------- |
| PK_ea8f538c94b6e352418254ed6474a81f | CREATE UNIQUE INDEX "PK_ea8f538c94b6e352418254ed6474a81f" ON public."user" USING btree (id) |
| UQ_e12875dfb3b1d92d7d7c5377e2 | CREATE UNIQUE INDEX "UQ_e12875dfb3b1d92d7d7c5377e2" ON public."user" USING btree (email) |
| user_role_idx | CREATE INDEX user_role_idx ON public."user" USING btree ("roleSlug") |

## Relations

```mermaid
erDiagram

"public.activity_event" }o--o| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.agent_eval_dataset" }o--o| "public.user" : "FOREIGN KEY (#quot;createdById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.agent_eval_rating" }o--o| "public.user" : "FOREIGN KEY (#quot;ratedById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.agent_eval_run" }o--o| "public.user" : "FOREIGN KEY (#quot;createdById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.agent_execution_threads" }o--o| "public.user" : "FOREIGN KEY (#quot;ownerId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.agent_history" }o--o| "public.user" : "FOREIGN KEY (#quot;publishedById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.ai_preference" }o--o| "public.user" : "FOREIGN KEY (#quot;createdById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.ai_preference" }o--o| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.auth_identity" }o--o| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id)"
"public.chat_hub_agents" }o--|| "public.user" : "FOREIGN KEY (#quot;ownerId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.chat_hub_sessions" }o--|| "public.user" : "FOREIGN KEY (#quot;ownerId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.chat_hub_tools" }o--|| "public.user" : "FOREIGN KEY (#quot;ownerId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.dynamic_credential_user_entry" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.evaluation_collection" }o--o| "public.user" : "FOREIGN KEY (#quot;createdById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.idempotency_key" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.instance_ai_mcp_registry_connections" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.instance_ai_pending_confirmations" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.instance_ai_thread_grants" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.instance_ai_thread_tabs" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.migration_workflow_owner" }o--o| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.migration_workflow_owner" }o--o| "public.user" : "FOREIGN KEY (#quot;assignedById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.oauth_access_tokens" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.oauth_authorization_codes" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.oauth_refresh_tokens" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.oauth_user_consents" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.project" }o--o| "public.user" : "FOREIGN KEY (#quot;creatorId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.project_relation" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.self_healing_result" }o--|| "public.user" : "FOREIGN KEY (#quot;backgroundUserId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.self_healing_result" }o--o| "public.user" : "FOREIGN KEY (#quot;dismissedById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.trusted_source_identity" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.user_api_keys" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.user_favorites" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.workflow_builder_session" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.workflow_publish_history" }o--o| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.workflow_review_activity" }o--o| "public.user" : "FOREIGN KEY (#quot;createdById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.workflow_review_activity_comment" }o--o| "public.user" : "FOREIGN KEY (#quot;createdById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.workflow_review_request" }o--o| "public.user" : "FOREIGN KEY (#quot;createdById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.workflow_review_request" }o--o| "public.user" : "FOREIGN KEY (#quot;updatedById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.workflow_review_request" }o--o| "public.user" : "FOREIGN KEY (#quot;closedById#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.workflow_review_request_authors" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.workflow_review_request_reviewers" }o--|| "public.user" : "FOREIGN KEY (#quot;userId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.workflow_suggestion" }o--|| "public.user" : "FOREIGN KEY (#quot;backgroundUserId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE CASCADE"
"public.workflow_suggestion_activity" }o--o| "public.user" : "FOREIGN KEY (#quot;actorId#quot;) REFERENCES #quot;user#quot;(id) ON DELETE SET NULL"
"public.user" }o--|| "public.role" : "FOREIGN KEY (#quot;roleSlug#quot;) REFERENCES role(slug)"

"public.user" {
  timestamp_3__with_time_zone createdAt
  boolean disabled
  varchar_255_ email
  varchar_32_ firstName
  uuid id
  date lastActiveAt
  varchar_32_ lastName
  boolean mfaEnabled
  text mfaRecoveryCodes
  text mfaSecret
  varchar_255_ password
  json personalizationAnswers
  varchar_128_ roleSlug FK
  json settings
  timestamp_3__with_time_zone updatedAt
}
"public.activity_event" {
  varchar_64_ action
  varchar_32_ category
  timestamp_3__with_time_zone createdAt
  json data
  integer id
  varchar_36_ projectId FK
  varchar_36_ resourceId
  text resourceName
  varchar_32_ resourceType
  integer typeVersion
  uuid userId FK
}
"public.agent_eval_dataset" {
  varchar_36_ agentId FK
  json columnMapping
  timestamp_3__with_time_zone createdAt
  uuid createdById FK
  json datasetRef
  varchar_32_ datasetSource
  text description
  varchar_36_ id
  varchar_128_ name
  timestamp_3__with_time_zone updatedAt
}
"public.agent_eval_rating" {
  text comment
  json correction
  timestamp_3__with_time_zone createdAt
  varchar_36_ id
  uuid ratedById FK
  varchar_36_ resultId FK
  timestamp_3__with_time_zone updatedAt
  varchar_8_ vote
}
"public.agent_eval_run" {
  varchar_36_ agentVersionId
  boolean cancelRequested
  timestamp_3__with_time_zone completedAt
  timestamp_3__with_time_zone createdAt
  uuid createdById FK
  varchar_36_ datasetId FK
  varchar_255_ errorCode
  json errorDetails
  varchar_36_ id
  json metrics
  timestamp_3__with_time_zone runAt
  varchar_255_ runningInstanceId
  varchar status
  timestamp_3__with_time_zone updatedAt
}
"public.agent_execution_threads" {
  varchar_16_ accessScope
  varchar_36_ agentId FK
  varchar_255_ agentName
  timestamp_3__with_time_zone createdAt
  varchar_8_ emoji
  varchar_128_ id
  uuid ownerId FK
  varchar_36_ parentAgentId
  varchar_128_ parentThreadId
  varchar_255_ projectId FK
  integer sessionNumber
  varchar_32_ taskId
  varchar_36_ taskVersionId FK
  varchar_255_ title
  integer totalCompletionTokens
  double_precision totalCost
  integer totalDuration
  integer totalPromptTokens
  timestamp_3__with_time_zone updatedAt
}
"public.agent_history" {
  varchar_36_ agentId FK
  varchar_255_ author
  timestamp_3__with_time_zone createdAt
  uuid publishedById FK
  json schema
  json skills
  json tools
  timestamp_3__with_time_zone updatedAt
  varchar_36_ versionId
}
"public.ai_preference" {
  text content
  timestamp_3__with_time_zone createdAt
  uuid createdById FK
  uuid id
  varchar_36_ projectId FK
  varchar_16_ source
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.auth_identity" {
  timestamp_3__with_time_zone createdAt
  varchar_255_ providerId
  varchar_32_ providerType
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.chat_hub_agents" {
  timestamp_3__with_time_zone createdAt
  varchar_36_ credentialId FK
  varchar_512_ description
  json files
  json icon
  uuid id
  varchar_64_ model
  varchar_256_ name
  uuid ownerId FK
  varchar_16_ provider
  json suggestedPrompts
  text systemPrompt
  timestamp_3__with_time_zone updatedAt
}
"public.chat_hub_sessions" {
  uuid agentId FK
  varchar_128_ agentName
  timestamp_3__with_time_zone createdAt
  varchar_36_ credentialId FK
  uuid id
  timestamp_3__with_time_zone lastMessageAt
  varchar_256_ model
  uuid ownerId FK
  varchar_16_ provider
  varchar_256_ title
  varchar_16_ type
  timestamp_3__with_time_zone updatedAt
  varchar_36_ workflowId FK
}
"public.chat_hub_tools" {
  timestamp_3__with_time_zone createdAt
  json definition
  boolean enabled
  uuid id
  varchar_255_ name
  uuid ownerId FK
  varchar_255_ type
  double_precision typeVersion
  timestamp_3__with_time_zone updatedAt
}
"public.dynamic_credential_user_entry" {
  timestamp_3__with_time_zone createdAt
  varchar_16_ credentialId FK
  text data
  varchar_16_ resolverId FK
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.evaluation_collection" {
  timestamp_3__with_time_zone createdAt
  uuid createdById FK
  text description
  varchar_36_ evaluationConfigId FK
  varchar_36_ id
  json insightsCache
  varchar_128_ name
  timestamp_3__with_time_zone updatedAt
  varchar_36_ workflowId FK
}
"public.idempotency_key" {
  timestamp_3__with_time_zone createdAt
  text fingerprint
  varchar_16_ id
  varchar_128_ idempotencyKey
  json responseBody
  smallint responseStatus
  varchar_16_ status
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.instance_ai_mcp_registry_connections" {
  timestamp_3__with_time_zone createdAt
  varchar_36_ credentialId FK
  uuid id
  varchar_255_ serverSlug FK
  json toolPermissions
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.instance_ai_pending_confirmations" {
  varchar_255_ checkpointKey FK
  varchar_36_ checkpointTaskId
  timestamp_3__with_time_zone createdAt
  timestamp_3__with_time_zone expiresAt
  varchar_16_ kind
  varchar_36_ messageGroupId
  varchar_36_ requestId
  varchar_36_ runId
  uuid threadId FK
  varchar_64_ toolCallId
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.instance_ai_thread_grants" {
  timestamp_3__with_time_zone createdAt
  varchar_512_ grantKey
  uuid threadId FK
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.instance_ai_thread_tabs" {
  timestamp_3__with_time_zone createdAt
  json state
  uuid threadId FK
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.migration_workflow_owner" {
  timestamp_3__with_time_zone assignedAt
  uuid assignedById FK
  timestamp_3__with_time_zone createdAt
  varchar_16_ source
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
  varchar_36_ workflowId FK
}
"public.oauth_access_tokens" {
  varchar clientId FK
  varchar token
  uuid userId FK
}
"public.oauth_authorization_codes" {
  varchar clientId FK
  varchar_255_ code
  varchar codeChallenge
  varchar_255_ codeChallengeMethod
  timestamp_3__with_time_zone createdAt
  bigint expiresAt
  varchar redirectUri
  varchar resource
  json scope
  varchar state
  timestamp_3__with_time_zone updatedAt
  boolean used
  uuid userId FK
}
"public.oauth_refresh_tokens" {
  varchar clientId FK
  timestamp_3__with_time_zone createdAt
  bigint expiresAt
  varchar resource
  json scope
  varchar_255_ token
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.oauth_user_consents" {
  varchar clientId FK
  bigint grantedAt
  integer id
  json scope
  uuid userId FK
}
"public.project" {
  timestamp_3__with_time_zone createdAt
  uuid creatorId FK
  json customTelemetryTags
  varchar_512_ description
  json icon
  varchar_36_ id
  varchar_255_ name
  varchar_36_ type
  timestamp_3__with_time_zone updatedAt
}
"public.project_relation" {
  timestamp_3__with_time_zone createdAt
  varchar_36_ projectId FK
  varchar role FK
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.self_healing_result" {
  uuid backgroundUserId FK
  timestamp_3__with_time_zone completedAt
  timestamp_3__with_time_zone createdAt
  timestamp_3__with_time_zone dismissedAt
  uuid dismissedById FK
  varchar_36_ executionId
  varchar_36_ id
  varchar_16_ outcome
  varchar_36_ projectId FK
  text report
  varchar_36_ suggestionId FK
  text summary
  timestamp_3__with_time_zone updatedAt
  json usage
  varchar_36_ workflowId FK
}
"public.trusted_source_identity" {
  timestamp_3__with_time_zone createdAt
  timestamp_3__with_time_zone lastSeenAt
  varchar_32_ provenance
  varchar_36_ sourceId FK
  varchar_16_ status
  varchar subject
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.user_api_keys" {
  varchar apiKey
  varchar audience
  timestamp_3__with_time_zone createdAt
  varchar_36_ id
  varchar_100_ label
  timestamp_3__with_time_zone lastUsedAt
  json scopes
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
}
"public.user_favorites" {
  integer id
  varchar_255_ resourceId
  varchar_64_ resourceType
  uuid userId FK
}
"public.workflow_builder_session" {
  varchar_255_ activeVersionCardId
  timestamp_3__with_time_zone createdAt
  uuid id
  json messages
  text previousSummary
  varchar_255_ resumeAfterRestoreMessageId
  timestamp_3__with_time_zone updatedAt
  uuid userId FK
  varchar_36_ workflowId FK
}
"public.workflow_publish_history" {
  timestamp_3__with_time_zone createdAt
  varchar_36_ event
  integer id
  uuid userId FK
  varchar_36_ versionId FK
  varchar_36_ workflowId FK
}
"public.workflow_review_activity" {
  timestamp_3__with_time_zone createdAt
  uuid createdById FK
  json data
  integer id
  varchar_64_ type
  integer typeVersion
  varchar_36_ workflowReviewRequestId FK
}
"public.workflow_review_activity_comment" {
  integer activityId FK
  text body
  timestamp_3__with_time_zone createdAt
  uuid createdById FK
  timestamp_3__with_time_zone deletedAt
  json history
  integer id
  timestamp_3__with_time_zone updatedAt
}
"public.workflow_review_request" {
  timestamp_3__with_time_zone approvedAt
  uuid closedById FK
  timestamp_3__with_time_zone createdAt
  uuid createdById FK
  varchar_50_ decision
  text description
  varchar_36_ id
  varchar_36_ projectId FK
  varchar_16_ state
  varchar_255_ title
  timestamp_3__with_time_zone updatedAt
  uuid updatedById FK
}
"public.workflow_review_request_authors" {
  uuid userId FK
  varchar_36_ workflowReviewRequestId FK
}
"public.workflow_review_request_reviewers" {
  uuid userId FK
  varchar_36_ workflowReviewRequestId FK
}
"public.workflow_suggestion" {
  varchar_32_ appliedAction
  uuid appliedActorId
  varchar_64_ appliedChecksum
  varchar_36_ appliedVersionId
  uuid backgroundUserId FK
  timestamp_3__with_time_zone closedAt
  varchar_16_ closedReason
  timestamp_3__with_time_zone createdAt
  json expectedBaseline
  varchar_36_ id
  json payload
  varchar_36_ projectId FK
  varchar_16_ resultKind
  varchar_16_ state
  timestamp_3__with_time_zone updatedAt
  varchar_36_ workflowId FK
}
"public.workflow_suggestion_activity" {
  varchar_16_ action
  uuid actorId FK
  varchar_16_ author
  timestamp_3__with_time_zone createdAt
  varchar_36_ id
  varchar_36_ suggestionId FK
  timestamp_3__with_time_zone updatedAt
}
"public.role" {
  timestamp_3__with_time_zone createdAt
  text description
  text displayName
  text roleType
  varchar_128_ slug
  boolean systemRole
  timestamp_3__with_time_zone updatedAt
}
```

---

> Generated by [tbls](https://github.com/k1LoW/tbls)
