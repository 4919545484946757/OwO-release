# public.agent_background_job

## Columns

| Name | Type | Default | Nullable | Children | Parents | Comment |
| ---- | ---- | ------- | -------- | -------- | ------- | ------- |
| childExecutionId | varchar(36) |  | true |  |  | Workflow jobs only |
| childThreadId | varchar(128) |  | true |  |  | Sub-agent jobs only; minted at dispatch, links to agent_execution_threads |
| createdAt | timestamp(3) with time zone | CURRENT_TIMESTAMP(3) | false |  |  |  |
| error | text |  | true |  |  |  |
| id | varchar(36) |  | false |  |  |  |
| kind | varchar(16) |  | false |  |  | What the job tracks: a detached sub-agent run or a workflow execution |
| notifiedAt | timestamp(3) with time zone |  | true |  |  | Time when the parent received the latest result or approval request |
| parentAgentId | varchar(36) |  | false |  | [public.agents](public.agents.md) |  |
| parentPrincipalHash | varchar(64) |  | false |  |  | Sandbox principal hash of the parent agent run |
| parentResourceId | varchar(255) |  | false |  |  | Memory resource of the parent agent run |
| parentThreadId | varchar(128) |  | false |  |  |  |
| pauseRequestId | uuid |  | true |  |  | Groups jobs stopped by one user request |
| result | text |  | true |  |  | Final answer of a settled sub-agent job |
| settledAt | timestamp(3) with time zone |  | true |  |  |  |
| status | varchar(16) |  | false |  |  | running: child works; suspended: child awaits approval; paused: user stopped the child; completed, failed, cancelled: terminal |
| subAgentId | varchar(36) |  | true |  |  | Sub-agent jobs only |
| timeoutAt | timestamp(3) with time zone |  | true |  |  | When reconciliation fails the job as timed out; NULL means no timeout |
| title | varchar(255) |  | false |  |  | Task name or workflow name, echoed in status-check listings |
| updatedAt | timestamp(3) with time zone | CURRENT_TIMESTAMP(3) | false |  |  |  |
| workflowId | varchar(36) |  | true |  |  | Workflow jobs only; scopes cancellation |

## Constraints

| Name | Type | Definition |
| ---- | ---- | ---------- |
| CHK_agent_background_job_kind | CHECK | CHECK (((kind)::text = ANY ((ARRAY['subagent'::character varying, 'workflow'::character varying])::text[]))) |
| CHK_agent_background_job_status | CHECK | CHECK (((status)::text = ANY ((ARRAY['running'::character varying, 'suspended'::character varying, 'paused'::character varying, 'completed'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[]))) |
| FK_d46c6f00730c2ef8bcb6ee24b67 | FOREIGN KEY | FOREIGN KEY ("parentAgentId") REFERENCES agents(id) ON DELETE CASCADE |
| PK_6e0db58281aa2b4c956dc0d58e9 | PRIMARY KEY | PRIMARY KEY (id) |
| agent_background_job_createdAt_not_null | n | NOT NULL "createdAt" |
| agent_background_job_id_not_null | n | NOT NULL id |
| agent_background_job_kind_not_null | n | NOT NULL kind |
| agent_background_job_parentAgentId_not_null | n | NOT NULL "parentAgentId" |
| agent_background_job_parentPrincipalHash_not_null | n | NOT NULL "parentPrincipalHash" |
| agent_background_job_parentResourceId_not_null | n | NOT NULL "parentResourceId" |
| agent_background_job_parentThreadId_not_null | n | NOT NULL "parentThreadId" |
| agent_background_job_status_not_null | n | NOT NULL status |
| agent_background_job_title_not_null | n | NOT NULL title |
| agent_background_job_updatedAt_not_null | n | NOT NULL "updatedAt" |

## Indexes

| Name | Definition |
| ---- | ---------- |
| IDX_93d62baabe9858816b5adafb44 | CREATE INDEX "IDX_93d62baabe9858816b5adafb44" ON public.agent_background_job USING btree ("parentThreadId", status) |
| IDX_agent_background_job_childExecutionId | CREATE UNIQUE INDEX "IDX_agent_background_job_childExecutionId" ON public.agent_background_job USING btree ("childExecutionId") WHERE ("childExecutionId" IS NOT NULL) |
| IDX_agent_background_job_parentThreadId | CREATE INDEX "IDX_agent_background_job_parentThreadId" ON public.agent_background_job USING btree ("parentThreadId") WHERE (((status)::text <> 'running'::text) AND ("notifiedAt" IS NULL)) |
| IDX_agent_background_job_timeoutAt | CREATE INDEX "IDX_agent_background_job_timeoutAt" ON public.agent_background_job USING btree ("timeoutAt") WHERE ((status)::text = ANY ((ARRAY['running'::character varying, 'suspended'::character varying])::text[])) |
| IDX_d46c6f00730c2ef8bcb6ee24b6 | CREATE INDEX "IDX_d46c6f00730c2ef8bcb6ee24b6" ON public.agent_background_job USING btree ("parentAgentId") |
| IDX_e43e630272995a93dfeb94ab3e | CREATE INDEX "IDX_e43e630272995a93dfeb94ab3e" ON public.agent_background_job USING btree ("settledAt") |
| PK_6e0db58281aa2b4c956dc0d58e9 | CREATE UNIQUE INDEX "PK_6e0db58281aa2b4c956dc0d58e9" ON public.agent_background_job USING btree (id) |

## Relations

```mermaid
erDiagram

"public.agent_background_job" }o--|| "public.agents" : "FOREIGN KEY (#quot;parentAgentId#quot;) REFERENCES agents(id) ON DELETE CASCADE"

"public.agent_background_job" {
  varchar_36_ childExecutionId
  varchar_128_ childThreadId
  timestamp_3__with_time_zone createdAt
  text error
  varchar_36_ id
  varchar_16_ kind
  timestamp_3__with_time_zone notifiedAt
  varchar_36_ parentAgentId FK
  varchar_64_ parentPrincipalHash
  varchar_255_ parentResourceId
  varchar_128_ parentThreadId
  uuid pauseRequestId
  text result
  timestamp_3__with_time_zone settledAt
  varchar_16_ status
  varchar_36_ subAgentId
  timestamp_3__with_time_zone timeoutAt
  varchar_255_ title
  timestamp_3__with_time_zone updatedAt
  varchar_36_ workflowId
}
"public.agents" {
  varchar_36_ activeVersionId FK
  boolean availableInMCP
  timestamp_3__with_time_zone createdAt
  varchar_36_ id
  json integrations
  varchar_128_ name
  varchar_255_ projectId FK
  integer revision
  json schema
  timestamp_3__with_time_zone setupCompletedAt
  json skills
  json tools
  timestamp_3__with_time_zone updatedAt
  varchar_36_ versionId
}
```

---

> Generated by [tbls](https://github.com/k1LoW/tbls)
