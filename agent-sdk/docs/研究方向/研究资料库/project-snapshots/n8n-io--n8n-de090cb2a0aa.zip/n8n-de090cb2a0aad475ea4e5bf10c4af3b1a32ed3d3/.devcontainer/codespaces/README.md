# Cloud agent sessions (Codespaces)

Run long-lived, human-steered agent sessions (Claude Code / OpenCode) on a
GitHub Codespace instead of your laptop: start a task, close the lid, steer it
from anywhere, resume tomorrow.

This is a separate devcontainer config from the laptop one in
`.devcontainer/` — it ships both agent CLIs, `tmux` for session persistence,
Playwright system deps, and Docker-in-Docker (for testcontainers and
`pnpm --filter n8n-containers services`), on the same Postgres sidecar setup.

## One-time setup (~5 min)

1. Give the GitHub CLI the codespace scope:

   ```bash
   gh auth refresh -h github.com -s codespace
   ```

2. Add provider keys at [github.com/settings/codespaces](https://github.com/settings/codespaces)
   if your client needs them. Give each secret access to `n8n-io/n8n`.
   - `ANTHROPIC_API_KEY` for Claude Code in the terminal (`pnpm session`).
     Alternative for Max subscriptions: `CLAUDE_CODE_OAUTH_TOKEN` from
     `claude setup-token`. The desktop app does not need either secret.
   - `OPENROUTER_API_KEY` for OpenCode.

## Choose a client

All clients run the agent, its tools, and builds in the Codespace. Your laptop
shows the conversation only.

| Client | Command | Use it when |
|---|---|---|
| Claude Code desktop app | `pnpm session ssh-config` once | You want the full desktop experience. |
| Claude Code in VS Code | Open the codespace in VS Code or the browser | You already work in VS Code. |
| Claude Code in a terminal | `pnpm session` | You want a plain terminal, or you are on a remote machine. |
| OpenCode | `pnpm session:opencode` | You use OpenCode. See [Local OpenCode clients](#local-opencode-clients). |

### Claude Code desktop app

1. From a local checkout, add an SSH host for your codespace:

   ```bash
   pnpm session ssh-config
   ```

   The command creates or starts the codespace. It writes the host
   `n8n-codespace` to `~/.ssh/n8n-codespace.conf` and includes that file from
   `~/.ssh/config`.
2. In the desktop app, add an SSH connection to the host `n8n-codespace`.
3. Open the folder `/workspaces/n8n`, or a worktree under `/workspaces`.

The desktop app installs its own Claude Code on the codespace and signs in
with your desktop account. Sessions continue when you close the app. They stop
when the codespace stops.

- **Run `pnpm session ssh-config` again after you recreate the codespace.**
- **If the connection times out**, the codespace is probably starting. Run
  `pnpm session ssh-config`, then connect again.
- **Test the connection** with `ssh n8n-codespace`.

### Claude Code in VS Code

The dev container installs the Claude Code extension. Open the codespace in
VS Code or the browser, then open the Claude Code panel. Sign in from the
extension if you did not add `ANTHROPIC_API_KEY` or `CLAUDE_CODE_OAUTH_TOKEN`.

### Claude Code in a terminal

```bash
pnpm session                       # attach Claude Code (creates everything on first run)
pnpm session:shell                 # open a shell in the default checkout
pnpm session:opencode              # connect the local OpenCode TUI
pnpm session:opencode fix-flaky    # use a separate remote worktree
pnpm session:opencode --web        # open OpenCode in the local browser
pnpm session:opencode --legacy     # use the remote TUI in tmux
pnpm session fix-flaky             # Claude Code in a separate worktree
pnpm session ls                    # what's running
pnpm session tunnel                # forward n8n ports (default 5678, 8080); Ctrl-C to stop
pnpm session ssh-config            # add the n8n-codespace SSH host for the desktop app
pnpm session stop                  # end of day: billing stops, disk survives
pnpm session rm                    # delete the codespace
```

The dev container supports Codespaces with 2, 4, or 8 cores. The session commands
create an 8-core Codespace by default.

- **Detach from tmux** with `Ctrl-b d` — the agent keeps working without you.
  Local OpenCode connections use the exit controls described below.
- **Scroll in tmux** with the mouse wheel (tmux mouse mode is on). To use the
  terminal's own text selection, hold **Shift** and drag.
- **Reattach** by running the same session command from any machine.
- Each named session gets its own worktree (`/workspaces/wt-<name>`, branch
  `session/<name>`), so parallel agents never touch each other's tree. A new
  branch starts from the latest `origin/master`. Builds
  in fresh worktrees are cache-hits via a shared turbo cache.
- First codespace creation takes ~20 min uncached (image + full build). After
  that, sessions attach instantly; new worktrees cost a `pnpm install` (~10 s: the
  store lives on `/workspaces`, so `node_modules` is hardlinked, not copied).

## Configure the local OpenCode harness

Install the pinned shared harness:

```bash
pnpm agent:harness
```

The command verifies the release checksum. It caches the bundle under
`~/.cache/n8n-agent-harness`. It then links the bundle plugin into
`~/.config/opencode/plugins`. Run the command again after the lock changes.
Restart OpenCode after the command completes.

## Local OpenCode clients

Run these commands from a local checkout. The TUI runs on your laptop. The
OpenCode server, repository, tools, and builds run in the Codespace. Browser
mode opens the remote web interface through a local connection.

```bash
pnpm session:opencode fix-flaky              # resume that workspace's latest conversation
pnpm session:opencode fix-flaky --web        # open it in a browser
pnpm session:opencode fix-flaky --new        # start a new conversation in that worktree
pnpm session:opencode --web --port 4100      # override the default browser port
pnpm session:opencode --help
```

For the TUI, install the same OpenCode version as the remote server. The
`OPENCODE_VERSION` argument in the [Dockerfile](Dockerfile) pins the version
for new images:

```bash
npm install -g opencode-ai@<version>
```

Use npm, not pnpm. The package gets its binary from a `postinstall` script.
pnpm does not run that script by default.

The launcher checks both versions. It reports a mismatch with both version
numbers before it opens the TUI. An existing Codespace can have a different
version. Install that version locally, or use `--web`. Browser mode does not
need a local OpenCode install.
The launcher sends its bootstrap code over SSH, so an existing Codespace does
not need a rebuild to use this connection method.
The remote server loads the shared OpenCode harness that the Codespace
post-start command installs. The local harness setup above is not required for
these commands.

The command prepares the worktree, starts or reuses one server, opens an SSH
tunnel, and connects the client. Each workspace opens its own conversation: the
most recently updated one in that worktree. A conversation moves to the front
when it receives a message. Switching to a conversation without sending a
message does not move it. Switching to another workspace's conversation does
not change what this workspace opens next. `--new` starts a new conversation
instead. It preserves the worktree and the old conversation.

- **Exit the TUI** with `/exit` or its quit shortcut. The launcher closes its
  tunnel. The remote server stays running.
- **Disconnect browser mode** with `Ctrl-C` in the launcher terminal. Closing
  the browser tab does not close the tunnel. Keep the launcher running while
  you use the browser.
- **Reconnect** with the same command after a network interruption. After a
  Codespace stop, the command restarts the server and opens the workspace's
  most recently updated conversation.
  A stop terminates running tools. It does not resume interrupted commands.
- **Browser mode uses local port 4096 by default.** Use `--port` to override it.
  TUI mode selects an available port unless you specify one.
  A fixed browser port preserves the browser origin across runs.
  An occupied fixed port causes an error. It does not stop the existing listener.
- **Use model and permission controls in the client.** The new connection uses
  the remote OpenCode configuration. It does not force the legacy `--auto` mode.
  For the old CLI flags, use `pnpm session:opencode fix-flaky --legacy --model <model>`.

Both server and tunnel bind to `127.0.0.1`. The server uses a generated password.
The TUI receives it through its environment. Browser mode uses a local proxy
that adds authentication and rejects requests from other browser origins. The
proxy supports streamed responses, attachments, and terminal WebSockets. The
password does not appear in the URL or terminal output. Other processes on
your laptop can access the local browser proxy while it runs. Do not forward
this proxy or the OpenCode server port to other machines.

The server enables only OpenRouter. It reads `OPENROUTER_API_KEY` when it starts.
It enables OpenCode code mode by default to reduce the initial tool context.
Browser mode opens the workspace's most recently updated conversation directly.
The web UI stores opened projects in browser storage. If a new-session page
shows **New project**, open `/workspaces/n8n` there once. Keep the same browser
port when you reconnect to preserve this selection.

The server runs in the detached tmux session `n8n-opencode-server`. Its log is
`/workspaces/.n8n-opencode/server.log`. That directory also holds the server
credentials. It is readable only by its owner.
An unhealthy server produces an error without stopping active work. Inspect
the log through `pnpm session:shell`. To restart it after checking active work,
run `tmux kill-session -t '=n8n-opencode-server'` in that shell. Then reconnect.
Restart the server after changing provider secrets, server configuration, or
the pinned harness release.

### Limits

- The launcher supports macOS and Linux. On Windows, run it in WSL. If the
  browser does not open automatically, open the printed URL yourself.
- Local clipboard and attachment controls depend on the client, terminal,
  file type, and model. A laptop file path does not copy a file to the Codespace.
  Use a supported attachment control or copy the file with `gh codespace cp`.
- Tools and local MCP processes run on the Codespace. Laptop configuration,
  browser sessions, and files do not sync automatically.
- Workspace names identify worktrees. Two agents that use the same name share
  files. Separate conversations alone do not isolate edits.
- The server survives a client disconnect while the Codespace stays running.
  Codespaces idle timeouts still apply. An open tunnel is not a guarantee that
  the Codespace will stay awake. Use `pnpm session stop` to stop compute billing.
- Existing tmux OpenCode conversations are not migrated automatically. Use
  `--legacy` to return to them.

For upstream behavior, see the [OpenCode CLI](https://opencode.ai/docs/cli/),
[server](https://opencode.ai/docs/server/), and [web](https://opencode.ai/docs/web/)
documentation.

## PR previews (a running instance of someone else's PR)

A preview is a codespace that serves one pull request, so a reviewer can use the
PR instead of reading it. It is a different box from a `pnpm session`: it uses
`.devcontainer/preview/devcontainer.json`, and its display name is
`preview/pr-<number>`.

**From GitHub:** for a PR targeting master, add the `codespace-preview` label to the PR.
[util-codespace-preview.yml](../../.github/workflows/util-codespace-preview.yml)
creates the box, serves the PR head, shares port 5678 with the org, and comments
the URL on the PR. A later push serves the new head in the same box. Remove the
label, or close the PR, to delete the box. The same workflow runs by hand from
the Actions tab: give it a PR number and `up`, `refresh` or `down`.

**From your laptop:** `pnpm preview up <pr>` does the same thing, plus
`pnpm preview refresh <pr>`, `pnpm preview down <pr>` and `pnpm preview ls`. It
needs `gh` with the codespace scope, the same as `pnpm session`.

- **Watch it come up on the PR.** The comment appears before the box work starts
  and updates about once a minute with a checklist of the phases, so you can see
  which step a slow preview is on. `pnpm preview up <pr>` prints the same phases as
  plain progress — the markers the comment reads are `--json` only.
- **Sign in with one click** at `<url>/preview-signin`. It logs you in as the
  seeded owner and sends you to the editor. The credentials are
  `preview@n8n.io` / `PreviewInstance1`. They are not secrets: the boundary is
  the org-visible forwarded port, which needs a GitHub sign-in and n8n org
  membership.
- **Configure the instance with `preview:*` labels.** `preview:enterprise` serves
  it with a licence, so enterprise features such as SSO and source control are
  present. `preview:debug` sets `N8N_LOG_LEVEL=debug`. Adding or removing one
  re-serves the box; it never creates or deletes one. From a laptop the labels
  apply the same way — `pnpm preview refresh <pr>` reads them from the PR. The
  toggles are defined in `scripts/codespace-preview/preview-labels.mjs`; add new ones there.
- **Configure the instance from a webhook.** A preview also reads extra
  environment from an n8n webhook, so a value can change without a commit. It
  needs the `CODESPACE_ENV_URL`, `CODESPACE_ENV_USER` and `CODESPACE_ENV_PASSWORD`
  codespace secrets. Every key the webhook returns becomes an environment
  variable, so editing that workflow runs code in the box. Without the secrets
  the preview serves as usual. See [WORKFLOWS.md](../../.github/WORKFLOWS.md).
- **A preview sleeps after 2 hours** of no use and GitHub deletes it after 24
  hours. A box that slept serves nothing and its port is private again, so wake
  it with `pnpm preview up <pr>` or a manual run of
  [util-codespace-preview.yml](../../.github/workflows/util-codespace-preview.yml)
  with `up`. Removing and adding the label works too, but it deletes the box and
  builds a new one.
- **A PR from a fork gets no preview.** A codespace's token is scoped to
  `n8n-io/n8n`, so it cannot check out a fork head.
- **A PR that predates this tooling has no `scripts/codespace-preview/preview-serve.mjs`.** The
  serve step says so and stops; rebase the PR on master and retry.

## Agent worker (drive a session from n8n)

`agent-worker.mjs` lets an n8n workflow drive an OpenCode session on the
codespace. This is how Slack (the Flaky bot) steers a session that runs here.
Each turn runs `openrouter/openai/gpt-5.6-sol` through
`opencode run --format json --auto`. The session state remains on disk. The
returned session ID continues a conversation across turns and a Codespace
restart.

**The worker polls outward. Nothing inbound is exposed.** GitHub sets every
forwarded port to private on start. It gives no API to make a port public. So
you cannot reach a codespace from outside reliably. The worker calls out
instead. It asks n8n for a turn addressed to this box's owner (`$GITHUB_USER`).
It runs the turn. It sends the result to the turn's resume URL. It uses no
tunnel, no open port, and no domain.

The post-start command installs the pinned OpenCode harness before it starts the
worker. It verifies a valid cached bundle before reuse. The worker does not start
if the harness is unavailable. `/tmp/post-start-status.json` contains the harness
and worker status.

The worker needs three
secrets and uses three optional secrets. Add them at
[github.com/settings/codespaces](https://github.com/settings/codespaces), the
same way as `ANTHROPIC_API_KEY`:

- `AGENT_WORKER_TOKEN` — the shared bearer token. The worker sends it on each poll.
- `N8N_DEQUEUE_URL` — the n8n webhook that returns a pending turn.
- `OPENROUTER_API_KEY` — the model provider key for Sol.
- `SLACK_BOT_TOKEN` — optional bot token for progress messages. It needs `chat:write` only.
- `FLAKY_MCP_URL` and `FLAKY_MCP_TOKEN` — optional Flaky MCP connection for OpenCode.

The worker explicitly reloads `/usr/local/lib/codespaces-env.sh` when its tmux
session starts. An existing tmux server can otherwise retain an environment
that did not load the Codespaces secrets.

The dequeue payload can include `slack.channel` and `slack.thread_ts`. The
worker posts one placeholder in that thread. It coalesces completed tool calls.
It updates the message at most once every 1.5 seconds. It does not send reasoning
text. The worker replaces the placeholder with the final answer.
If the Slack API fails, the turn still completes through the n8n resume URL.
The worker does not export its dequeue or Slack credentials to OpenCode. It uses
the harness `sandbox` runtime and `slack` profile. The profile supplies the
atomic-turn instruction.
Interactive sessions remove all worker-only credentials before they start.
Interactive OpenCode uses the global harness plugin with the `sandbox` runtime.
It does not set a profile. It keeps the dynamic OpenRouter configuration.

An idle worker starts with a 3-second poll interval. After each empty dequeue,
it doubles the interval and limits it to 30 seconds. Work resets the interval
to 3 seconds. Queued turns run without a delay between them.

The log is at `/tmp/agent-worker.log`. The tmux session is `agent-worker`. To
watch it, run `tmux attach -t agent-worker`. The worker does not start if a
required secret or `$GITHUB_USER` is missing.

A turn stops after about 25 minutes (`TURN_TIMEOUT_MS`). This limit is below the
n8n Wait limit. So the worker reports a clear message before n8n reports a
generic timeout. Keep the worker limit below the n8n limit if you change either.

**A turn is atomic, and the harness tells the session so.** The turn ends on the
session's final message, and its children end with it: a background `Bash` task
is killed, `Monitor` events never arrive, `PushNotification` has nowhere to go,
and `ScheduleWakeup` never fires. The session also gets no turn of its own to
report back in — the turn's resume URL continues one waiting n8n execution and is
then spent, so nothing on the box can post to the thread unprompted. A session
that backgrounds a build and signs off with "I'll verify once it finishes" is
therefore describing something that cannot happen. The harness `slack` profile
states this contract. This is only the n8n/Slack path: an
interactive session (`pnpm session`, tmux) is long-lived, so background work,
monitors and notifications behave normally there.

### Build and run the app in a session

The prebuild already installed the dependencies and warmed the build. So a
session rarely needs a cold `pnpm install` or a full `pnpm build`. Both are slow
(often 10–20 minutes cold). Both can outlast a turn's limit.

- **Bring the app up with one command: `pnpm dev:up`.** It installs missing
  dependencies, starts the backend, waits for health, and prints the URL. Add
  `--build` only when a frontend change must appear (see below).
- **Open the app** at `https://<codespace-name>-5678.app.github.dev`. `dev:up`
  makes that port visible to the org, thus any n8n member who is signed into
  GitHub can open it. You do not need a tunnel. GitHub makes every forwarded port
  private again at each container start, so `dev:up` shares it again on each run.
  To see the current state, run `gh codespace ports`. The share command needs `gh`
  with the codespace scope (see the one-time setup above). If it fails, `dev:up`
  starts the app, prints the reason, and gives you the command to try again. A
  private port opens for you only, in a browser that is signed in to GitHub. An
  anonymous or server caller gets a 302. That is why the worker polls outward.
- **`pnpm dev` no longer exists.** Use `pnpm dev:be` for the backend (on 5678).
  Use `pnpm dev:fe:editor` for the editor UI with hot reload (on 8080).
- **`dev:be` serves the editor from the `dist` build.** So a frontend edit does
  not hot-reload there. Run `pnpm dev:up --build` (or `pnpm build`) and restart
  to show it. For live frontend hot reload, use `pnpm dev:fe:editor`. That path
  needs `pnpm session tunnel 5678 8080` from your laptop. Its API base is set to
  `localhost:5678`, so the `-8080.app.github.dev` URL does not work on its own.
- Run `pnpm install` only when the dependencies change. `pnpm build` reuses the
  turbo cache and is fast when warm.
- To clear stale build outputs after a branch switch, run `pnpm reset`. Add
  `--full` if that does not clear it.
- Run a long build in the foreground and give it its own turn. Backgrounding it
  does not help: it is killed when the turn ends (see above). Do not chain an
  install and a full build behind other work in one turn either — that is what
  runs into the 25-minute limit.

## Flaky tools (MCP)

Claude sessions and the headless OpenCode worker get the `flaky` MCP server automatically: Currents
flaky/quarantine data, the `qa_*` BigQuery dataset, Sentry RCA, live Linear,
and repo investigation. The worker keeps the token in its environment and puts
only an environment reference in the OpenCode config. Forks have no secrets and
skip it. Tell the agent to call `get_flaky_context` first — it returns the rules
the tools assume.

`post-start.mjs` registers the server for Claude Code on each container start.
Its `headersHelper` reads the token from the secrets file on each connect, so
the server works in every client. The token is not copied into the Claude Code
MCP configuration.

## Quality and security skills (Claude plugins)

Claude sessions can also load the private skills from the
`n8n-io/n8n-agent-skills` repository. `post-start.mjs` installs both plugins on
each container start, so every session gets the skills with no per-session step:

- `quality` — bug insights, defect attribution, flaky test investigation,
  mutation and property testing, PR council, and more.
- `security` — security code review, adversarial review of security-fix PRs,
  regression test generation, and Security Hub report triage.

Together they add roughly 5k always-on tokens to every session. Drop a plugin
from `PLUGINS` in `plugins.mjs` if that budget matters more than the skills.
`post-start.mjs` and the `pnpm session` prelude in `scripts/cloud-session.mjs`
both read that list, so a session that races the container start still gets
every plugin.

The private marketplace uses the codespace's own GitHub auth — no extra token.
`devcontainer.json` grants the codespace read access to
`n8n-io/n8n-agent-skills` via `customizations.codespaces.repositories`, and
**each user authorizes that access once when they create the codespace** (GitHub
prompts for it, then remembers). Both repos are in the same org, which is what
lets this work.

The codespace authenticates git over HTTPS and has no SSH key, so `post-start.mjs`
sets `CLAUDE_CODE_PLUGIN_PREFER_HTTPS=1` — Claude Code's plugin loader otherwise
clones `owner/repo` shorthand over SSH and the private clone fails.

If a user does not authorize the grant, the clone fails and the skills step is
skipped (the worker still starts). Existing codespaces created before this change
need a recreate to get the prompt.

### When the skills are missing

`/tmp/post-start-status.json` lists what installed and what did not, and
`/tmp/post-start.log` has the detail. Reading the log:

- A failed `skills repo reachable` line means the grant was not authorized.
- A `marketplace add` failure mentioning `File exists` is a clone that died
  partway through `~/.claude/plugins/marketplaces/n8n-io-n8n-agent-skills`, the
  path the loader stages into before renaming it to the cache. This has been
  seen once as a transient failure, so the script removes that path and retries
  the add once.
- Any other `marketplace add` failure after a reachable repo means a
  loader-auth problem.

A failure that survives the retry needs a human — the container still starts and
the worker still runs, only the skills are missing.

Both `marketplace add` and `plugin install` are idempotent, so re-running the
script by hand is safe:

```bash
node /workspaces/n8n/.devcontainer/codespaces/post-start.mjs
```

Verify with `claude plugin list`, then restart the session (or `/reload-plugins`)
to pull the skills into context.

## Viewing the dev UI locally

`pnpm session tunnel` works with every client. With the terminal client, use
two terminal windows:

```bash
pnpm session          # window 1: attach the agent session
pnpm session tunnel   # window 2: forward 5678 + 8080 to localhost
```

Attaching lands you in the agent (Claude), not a shell — open a shell in a new
tmux window with `Ctrl-b c` (or ask the agent), then pick a dev server and open
the matching port:

- `pnpm dev:up` — backend on **5678** (editor served from the `dist` build).
  Open http://localhost:5678.
- `pnpm dev:fe:editor` — editor UI with hot reload on **8080**. Open
  http://localhost:8080. It needs the backend on 5678 too, so run `pnpm dev:up`
  alongside it.

The tunnel prints nothing while forwarding — that's normal. `Connection
refused` means nothing is listening on that port in the codespace yet; it
starts serving as soon as the dev server is up, no restart needed. Pass ports
to override the defaults (`pnpm session tunnel 5678 8080 5679`), but always
forward the pair together with matching numbers: the Vite dev UI points its
API base at `localhost:5678` (the `N8N_PORT` default), so an asymmetric or
partial mapping breaks it.

## What survives what

| Event | Running processes | Disk (checkout, worktrees, chat history) |
|---|---|---|
| Detach / close laptop / network drop | ✅ keep running | ✅ |
| Stop, or idle timeout (2 h for a codespace that `pnpm session` creates, max 4 h) | ❌ killed | ✅ |
| Delete (`pnpm session rm`) | ❌ | ❌ (push your branches first) |

After a stop, `pnpm session <name>` restarts the codespace (~30–60 s); run
`claude --resume` (or `--continue`) inside to restore the conversation from disk.

## Gotchas (learned the hard way)

- **Codespaces clones the repo to `/workspaces/n8n`**, not `/workspaces` —
  `workspaceFolder` here differs from the laptop config on purpose.
- **A failing `onCreateCommand` is fatal**: Codespaces discards the container
  and drops you into a minimal recovery container (no node, no CLIs). If your
  codespace has nothing installed, check
  `/workspaces/.codespaces/.persistedshare/creation.log`.
- **`gh codespace ssh` needs sshd inside the container** — provided by the
  `sshd` devcontainer feature, don't remove it.
- **User secrets aren't visible in ssh shells by default**: the codespace
  agent injects them into VS Code sessions only; they're delivered
  base64-encoded to `/workspaces/.codespaces/shared/.env-secrets`. The image
  sources `/usr/local/lib/codespaces-env.sh` in login shells (profile.d), in
  interactive shells (bashrc), and in the `pnpm session` prelude. Desktop app
  sessions do not source it. `git`, `gh`, `scripts/codespace-env.mjs`, and the
  `flaky` MCP entry read the file when they run, so they work everywhere. New
  code that needs a secret must do the same.
- **Do not read `CODESPACE_NAME` or `GITHUB_USER` from the process env** — use
  `scripts/codespace-env.mjs`. Codespaces gives these variables to VS Code
  sessions only. Other processes read them from `codespaces-env.sh`, and a
  process that tmux starts can get an empty copy: tmux keeps the environment of
  its own start, and `update-environment` does not refresh these keys. A worker
  polled correctly as its owner while `dev:up` in the same session saw an empty
  box name, printed the localhost URL, and did not share the port. The helper
  reads `/workspaces/.codespaces/shared`, which is always correct.
- **You cannot paste images into a terminal Claude session.** Image paste reads
  the clipboard of the machine where `claude` runs — the codespace, not your
  laptop. Drag the file into the VS Code explorer (or
  `gh codespace cp shot.png remote:/workspaces/n8n/`) and give Claude the
  path. The file stays on disk and survives detach and `--resume`.
- **`git push` / `gh` return 401 in tmux and long sessions** — same root
  cause as the secrets gotcha, plus rotation: Codespaces refreshes the
  on-disk `GITHUB_TOKEN` every few minutes, so a login-time snapshot goes
  stale. The image fixes both: a credential helper reads the current token
  on each `git push` (`gitcredential-refresh.sh`), and a shim at
  `/usr/local/bin/gh` does the same for `gh`. The token is scoped to
  `n8n-io/n8n`: fork-based flows do not work, push branches directly. Do
  not add SSH keys as a workaround — they have no per-repo granularity.
- Codespaces created by org members on this repo are **org-owned and
  org-billed** (organization ownership + a monthly Codespaces budget are
  enabled for n8n-io). Codespaces created before that change, or by
  non-members, bill to the personal account (free tier: 120 core-hours/month).
  If creation unexpectedly falls back to personal billing, the org budget is
  exhausted for the period.

## Costs

Compute bills only while the codespace runs: ~$0.72/hr for the 8-core box,
~nothing stopped. Usage draws from a shared monthly org budget, so
`pnpm session stop` when you leave; the idle timeout is the backstop, not the
plan.

Previews draw from the same budget on a 2-core box. Remove the
`codespace-preview` label when the review is done instead of waiting for the
24-hour retention.
