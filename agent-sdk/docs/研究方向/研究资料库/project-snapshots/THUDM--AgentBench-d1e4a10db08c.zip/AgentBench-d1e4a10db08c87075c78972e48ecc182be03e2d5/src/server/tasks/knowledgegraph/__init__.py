from .task import KnowledgeGraph
