# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Fixed

- **Every feature's tests now pass against its task's `combined.patch`** — the third dataset
  invariant, alongside fail-on-base / pass-on-gold, and the one the coop eval actually depends on:
  `test_merged` runs each feature's `tests.patch` against the merged tree, so a feature whose tests
  fail once a sibling's gold is present is unwinnable for every pair containing that sibling.
  Swept all 199 on Modal (linux/amd64) and local Docker (linux/arm64): 19 features in 5 tasks failed.
  `dspy/8563` f2–f6 (f1 changes `ToolCalls.format()`'s return shape; the pre-existing shape tests
  in the shared file failed in any tree with f1 — **8/15 pairs were hard zeros**) and `dspy/8635`
  f1–f6 (f6's `min_instr_chars=30` replaces the base tests' 11-char dummy instruction — **5/15
  pairs**; March's #40 had papered over it by setting the default to 0 in combined.patch only,
  contradicting f6's spec and gold) are fixed by making the pre-existing assertions in the sibling
  `tests.patch` files tolerant of the sibling behaviour; `openai_tiktoken/0` f3 (combined.patch
  still used the pre-#46 parameter name) and `pallets_jinja/1559` f3 (combined.patch did not
  implement `priority=` at all) and `pallets_jinja/1465` all 10 (combined.patch carried the PR's test-file diffs, so it could not apply on top of any `tests.patch`) are fixed in combined.patch. No `feature.patch` changed. Reasoning
  in `dataset/SPEC_AUDIT.md` ("Second pass").
- Re-verified fail-on-base / pass-on-gold for all 199 features on both architectures: 199/199.
- **Three task images had no linux/arm64 manifest** (`react-hook-form:task153`, `:task85`,
  `huggingface-datasets:task3997`), so those 13 features could not run on an arm64 Docker host at
  all. arm64 images were built natively and added to the existing indexes alongside the untouched
  amd64 manifests.

### Added

- **`scripts/check_combined.py`** — the sweep above; one sandbox per feature through the image's
  own `runner.sh`, `--backend modal|docker`.
- **`scripts/check_gradeable.py --backend docker`** — run the fail-on-base / pass-on-gold sweep on
  the local daemon (arm64 on Apple Silicon) as well as Modal (amd64). Both scripts now write
  sandbox files in 32 KB chunks; a single `echo` of `pallets_jinja/1465`'s 107 KB combined.patch
  exceeded Modal's 64 KiB `ARG_MAX` and showed up as 10 spurious `ERROR`s.

## [0.0.29] - 2026-08-14

### Fixed

- **All 199 features are now gradeable.** The property the benchmark rests on — a feature's tests
  must FAIL on the base commit and PASS with its gold patch — did not hold for 24 of them, and
  none were findable by reading the specs: 12 had a `runner.sh` that never invoked the feature's
  own tests, 8 broke on dependency drift, 5 carried feature 1's expectations in every test patch,
  2 had tests that did not discriminate, 1 had overlapping hunks. `pallets_jinja/1621` f5 passed
  6/6 on an untouched tree, so it scored for any submission at all. No `feature.patch` was
  modified: where a fix had a choice it went to the spec or the tests, never the reference.
  `scripts/check_gradeable.py` reproduces the sweep. Reasoning per feature is in
  `dataset/SPEC_AUDIT.md`.

- **Sandbox setup no longer deletes the build output the images pre-compile.** `test_merged` ran
  `git clean -fdx` before each graded feature, and `-x` removes gitignored paths — which is
  exactly where the images keep the artifacts they built at the base commit. typst's Dockerfile
  runs `cargo build --package typst-tests --tests` for this purpose and its `runner.sh` already
  said `git clean -fd  # No -x to preserve target/`; the harness overrode both, costing 335 crate
  compiles on every graded run.

- **Agent and git-daemon sandboxes live 3 hours instead of 1.** A heavy reasoner generates ~4x the
  tokens per step, so agents were still working when Modal reclaimed their sandbox at 3600s. Four
  separate sites pinned the old value and the explicit one in `adapter.py` silently beat the
  dataclass default. The git daemon expiring is the worse half: it hosts the bare repo both agents
  push and fetch through, so one expiry breaks every git operation in the pair at once and leaves
  agents chasing commits the remote no longer has (`fatal: invalid object name`).

- **An agent announces its departure on every exit path.** `mark_exited()` was only called after a
  clean submit, so a crash or a step-limit exit left the peer's `has_exited()` False forever. The
  peer then waited on someone who was never coming back: one agent issued 42 `sleep` commands
  totalling 91 minutes, received zero exit notices, and outlived its own sandbox doing it. Because
  a pair is only graded when both sides return, a single silent death loses the pair.

- **A peer that is killed is now detected, not just one that leaves politely.** Departure was
  entirely self-reported, which cannot work for the case that actually happens — the sandbox is
  reclaimed, the process is killed outright, and no `finally` runs. Agents now refresh an `:alive`
  key every step and `has_exited()` treats a lapsed heartbeat as gone, so silence is the signal
  and death needs no cooperation from the dead. `is_unreachable()` separates the two, and the
  message injected into the survivor's history says which happened rather than claiming a killed
  peer "completed their work" — an agent told something untrue about the remote acts on it. A peer
  that has not started yet is never mistaken for one that has died.

## [0.0.28] - 2026-08-10

### Fixed

- **Test-file stripping now covers every language, not only Python.** A test file the agent wrote
  must never reach the graded patch: it collides with the hidden `tests.patch` and `git apply`
  then rejects the *whole* patch, failing both features for a reason unrelated to their code. The
  rule matched `_test.py`, `/tests/`, `/test_`, so `metrics_test.go` sailed through — and that,
  not the merge, is what killed 3 of 4 runs on `go_chi/26`. Now recognises `_test.<ext>`,
  `.test.<ext>` / `.spec.<ext>`, `FooTest.java`, and `__tests__/`, `spec/`, `testdata/`
  directories, while leaving `contest/`, `protest.py`, `latest.py` and `pytest_helper.py` alone.

- **Language toolchains are on PATH in agent sandboxes.** Task images set `PATH` via Docker `ENV`,
  which `sb.exec` does not inherit, so anything outside `/usr/bin` was invisible. On `typst`
  (`rust:1.80-slim`) `cargo check` returned `cargo: command not found` while
  `/usr/local/cargo/bin/cargo` worked fine. This is a silent discriminator rather than a nuisance:
  the 27B hit it, ran `which rustc rustup cargo`, got nothing, and then wrote Rust for the entire
  task **without ever compiling** — which is why that pair produced a byte-identical patch that
  still failed to build with `E0277` and ran zero tests. A model that happened to try
  `find / -name cargo` recovered and got real compiler output. Cargo, Go and local bins are now
  prepended for every command.

## [0.0.27] - 2026-08-09

### Fixed

- **A malformed `send_message` is reported instead of vanishing into bash.** `send_message` is
  parsed out of the command string, not a real binary, so a call the regex did not match went
  through to the sandbox and died as `send_message: command not found` (rc 127) — which the
  agent reads as "messaging is broken" rather than "my quoting was wrong". Measured across two
  flash_10 runs: 7 messages lost this way (bare `--wait` with no body, unterminated heredoc,
  body via `< file`, invented flags like `-t 60`). The agent loop now returns a parse error
  naming the accepted forms.

- **Delivery says when the sender is blocked.** `send_and_wait` publishes that it is waiting
  (Redis key, TTL = the timeout, so a crashed waiter cannot leave it set) and the receiving
  agent's message is rendered as `[Message from agent1 — agent1 is BLOCKED waiting for your
  reply …]`.

  This targets a measured failure. Over 62 full 60s timeouts in two runs, the peer had already
  exited in **0** cases and had never seen the message in **0** cases; in 58 of 62 it held the
  message a median 2–12s into the window and then took a median of 7 more actions without
  replying. Raising the timeout does not fix that: 23 of the 30 late replies only arrived after
  the waiter unblocked and pinged again, so a clean counterfactual rescues 4/61 at 120s and
  7/61 at infinity. The cost of the timeouts is ~63 agent-minutes per pair of runs, ~10% of
  agent-alive time. Note it does **not** correlate with pass rate at this n (rho +0.25, p 0.31)
  — this is a compute-efficiency fix, not a score fix.

## [0.0.26] - 2026-08-09

### Changed

- **The coop prompt now tells the receiving side that a message may need an answer.** All
  messaging guidance was written from the sender's point of view — how to use `--wait`, what
  happens when the peer exits — while the only line describing the receiving side explained
  the `[Message from ...]` format and nothing more. So `--wait` was asymmetric in practice:
  the sender paid up to 60s of dead time and the receiver paid nothing for ignoring it.

  Measured in a flash_10 run: one agent sent three `--wait` questions and blocked the full
  60s on each. Its colleague received all three, ran 22, 13 and 8 steps of pytest/git/sed
  during those windows, and never replied — costing the sender 3 minutes, ~17% of its
  wall-clock, for zero information. Phrased as a courtesy ("answer when you can") rather
  than an instruction, because implementation is still the stated first priority and an
  agent mid-test-run should be able to finish before replying.

## [0.0.25] - 2026-08-09

### Fixed

- **Commands that read stdin no longer hang until the sandbox dies.** Modal's `sandbox.exec`
  hands the process an stdin pipe that never reaches EOF, so `grep pattern` with no file, a
  bare `cat`, or `python3` with no script blocked forever — and agents write those by
  accident routinely. Measured over one 27-pair run: three such calls consumed 3553s, 2353s
  and 2200s, i.e. 2.25 hours, against a p50 tool call of 0.4s. This is what put the tail of
  pair durations against the sandbox timeout rather than any slowness in inference (p50
  1.5s/step) or in the sandbox round trip (p50 0.4s).

  Commands now run under `exec < /dev/null`. Verified in a live sandbox: `grep -n break`
  goes from 31.2s (killed) to 0.2s. Heredocs are unaffected — a `<< EOF` redirect is
  per-command and takes precedence. The docker backend gets the same treatment via
  `stdin=subprocess.DEVNULL`, which is what SWE-ReX's local runtime already does.

- **A per-command timeout backstops what closing stdin cannot** — a genuine infinite loop.
  `command_timeout` defaults to 300s; the longest legitimate command observed is ~104s
  (`npm test`). Passed as argv rather than wrapped into the shell string, so nothing needs
  re-quoting. A timed-out command now returns a message saying so instead of empty output,
  so the agent can respond to it rather than being confused by a silent empty result.

## [0.0.24] - 2026-08-06

Five submission-path defects found by reading all 20 agent trajectories from a 10-pair
`flash_10` run. That run scored 0/10 pairs and 6/20 features, and most of the losses were
mechanical rather than the model failing to write code: three agents did the work and never
got it counted.

### Fixed

- **A pushed branch is no longer discarded when no PR was opened.** Grading required
  `refs/tags/pr/<agent>`, so an agent that committed and pushed successfully but died before
  `gh pr create` returned scored zero with its work sitting on the remote. Measured twice in
  one run, both times a Modal sandbox shutting down between the two commands; in one case the
  discarded patch was exactly what the failing assertion (`assert 'CMYK' == 'RGB'`) needed.
  `submitted_patch()` now falls back to the branch diff. The rule this mechanism exists to
  enforce — grade only what was *published*, so the colleague could see it — is satisfied by a
  pushed branch just as it is by a PR. An agent that pushed nothing still scores zero.

- **A misconfigured `origin` fails loudly instead of silently.** In one pair `origin` was still
  `https://github.com/go-chi/chi.git`, so every `git push origin agent2` failed with
  `could not read Username`. The agent had no way to distinguish a broken harness from an
  impossible task and lost 499 steps of work; the run recorded an empty patch, which reads as
  an agent failure. `setup()` now verifies `git remote get-url origin` against the team server
  and raises, matching how a missing `gh` shim is already treated.

- **`gh pr create` reports a conflicting peer branch.** Both PRs are merged before either
  feature suite runs, so a collision fails *both* agents — and nothing said so until scoring.
  Agents do not catch this themselves: one pair listed each other's open PRs, saw both, and
  still shipped conflicting edits to the same region. The shim now runs `git merge-tree` against
  each peer branch and says where to look. Guarded by a capability probe, since `--write-tree`
  needs git ≥ 2.38 and older git would report a conflict on every PR.

- **PR bodies containing markdown no longer kill the command.** Inside double quotes bash runs
  backticks as command substitution, so a body describing `` `parse()` `` died with `rc=137` and
  "command not found" for every identifier, before `gh` was reached. `--body-file -` reads the
  body from stdin; the prompt shows the heredoc form.

- **Ending the episode with unshared work is refused.** `echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT`
  and actually submitting were separate acts, so an agent could finish the task, verify its tests,
  announce "all changes are complete", fire the sentinel, and publish nothing — indistinguishable
  at grading from an agent that wrote no code. One agent did this after **943 steps**. If there is
  no PR and either a dirty tree or unpushed commits, the agent is given the exact submit sequence
  and the episode continues; capped at two nudges, after which ending empty is its own choice.

## [0.0.23] - 2026-08-05

### Changed

- **`mini_swe_agent_v2` submits a pull request instead of writing `patch.txt`.** Submission was a unified diff the agent wrote to a local file, which nothing else could see — so the artifact that got graded was decoupled from anything a colleague could read, and an agent could submit work it had never shared. The agent now commits what it wants to submit, pushes its branch, and opens a PR; the PR is what is graded. A `gh` shim (`connectors/gh_shim.sh`) implements `gh pr create/list/view/diff/checkout` over the shared remote using plain git, so agents use the spelling they already know rather than a command invented for this benchmark. A PR **tracks its branch**, as on a forge: agents are told to open one early so a colleague has context, and later commits are included once pushed.

  Consequences worth knowing: an agent that never opens a PR submits nothing and scores zero — that is an agent failure, and it is logged (`NO PR OPENED by <agent>`) so it stays attributable rather than looking like failed tests. Solo runs use the same path against a bare repo inside their own sandbox, so there is one submission mechanism rather than two that can drift. Both prompts got *smaller*: `patch.txt` needed ~30 lines teaching a diff incantation that exists nowhere in real engineering, while `gh pr create` needs none.

- **The shared remote is now `origin`, and the clone's upstream is removed.** It was `team`, while `origin` pointed at github.com and was unreachable — so the name agents reach for by reflex was the one that could not work.

### Fixed

- **Coop agents could read the entire upstream history, including the commits that came after the task commit.** A task image runs `git clone <upstream> && git checkout <task-sha>`, which leaves every later commit reachable through `refs/remotes/origin/*`, tags, and the local branch the clone left at the tip — `git checkout <sha>` only detaches HEAD, it does not move that branch. For any task derived from a real pull request, `git log --all -p` could therefore show the upstream implementation of the feature the agent was being asked to write. Setup now removes the remote, deletes remote refs, tags and leftover local branches, expires the reflog and prunes, so those objects are gone from the object database rather than merely unreferenced (verified with `git cat-file -e`). History *before* the task commit is kept — that is ordinary context, and `git log` still works.

- **A submission could be silently re-baselined by anyone pushing to `main`.** Submissions were diffed against `origin/main`, a movable ref on a daemon that runs `--enable=receive-pack` with no access control. One `git push origin HEAD:main`, from either agent, would change what both submissions contained. The base commit is now pinned at setup.

- **A failed `gh` shim install was a log warning.** Submission goes through `gh pr create`, so a sandbox without the shim cannot submit at all — and it would have surfaced hours later as an empty patch, indistinguishable from an agent that simply failed the task. Setup now raises.

### Fixed

- **Coop agents were told the shared git remote was read-only, so they never shared code.** The prompt titled the section "Shared Git Remote (read-only)", listed only `fetch`/`log`/`diff` under "Allowed (read-only)", never mentioned `push`, and instructed *"Do not merge, pull, or rebase their branch into yours"*. Both claims are wrong: `GitConnector` runs `git daemon --enable=receive-pack`, so the remote accepts writes, and grading never reads those branches — the evaluator applies each agent's submitted `patch.txt` to branches it creates itself (`eval/sandbox.py:473,480`). Measured across **117 trajectories in three `flash_10` runs: 292 `git fetch team` and 0 `git push team`.** Every one of those fetches returned the untouched baseline, because 0.0.22 only publishes an agent's patch at exit — by which point the peer can no longer act on it. Agents were following their instructions exactly; the instructions disabled the channel.

  This prompt was the only surface that said so. `GitConnector`'s own docstring already advertised `git push team <branch>` and `git merge team/<agent>`, and the shared coop prompt used by the `claude_code` / `codex` adapters (`agents/_coop/prompt.py`) already instructs agents to commit and "push so peers can fetch you". Only `mini_swe_agent_v2`'s coop config disagreed with the infrastructure it runs on.

  The section now describes a real read/write remote, tells agents to commit and `git push team HEAD:<agent_id>` as they work so a colleague can read their actual diff, and replaces the blanket prohibition with the one constraint that genuinely matters: **the submitted `patch.txt` must contain only that agent's own changes**, since the two submitted patches are merged and duplicated edits break the merge. Local `fetch`/`merge`/`cherry-pick` are now explicitly allowed — the rule is about what you submit, not what you do in your worktree — with `git diff -- <paths>` given as the way to scope a patch when both agents had to touch the same file.

### Changed

- Exit-time publication of `patch.txt` to `team/<agent_id>` (added in 0.0.22) is unchanged and still runs; it is now described as the *final* state of a branch agents are expected to have been pushing to all along, rather than the only thing that branch ever holds.

## [0.0.22] - 2026-08-04

### Fixed

- **A coop agent that finished could not be distinguished from one that was ignoring you.** When an agent submitted and exited, its peer kept talking to a mailbox nobody would ever read again: `MessagingConnector.send` queued into Redis and returned success unconditionally, with no liveness check. Measured over 8 `flash_10` pairs, **16 messages sent / 11 delivered (31% lost)**; in `pallets_click_task/2800/f1_f7` all 3 were lost — sent 35s after the peer's final turn. The sender was told `Message sent to agent2` (returncode 0) each time, and its own summary recorded *"Coordination with agent2 is ongoing … no expected conflicts"* immediately before submitting a patch that merge-conflicted. `send()` now returns `False` for a departed peer and the agent receives a non-zero result naming the cause and the recovery path, rather than a false success.

- **`send_message --wait` was documented but never implemented.** `DefaultAgent._handle_send_message` guarded on `hasattr(self.comm, "send_and_wait")`, and `MessagingConnector` had no such method — so `--wait` silently degraded to fire-and-forget. Agents asking a blocking question got an instant "Message sent" and moved on. `send_and_wait(recipient, content, timeout)` now exists, returns `(delivered, replies)`, and ends the wait as soon as the peer replies **or exits**, instead of burning the full 60s on a reply that cannot arrive.

- **`team/<peer>` never contained the peer's work.** `GitConnector.setup` pushes the base commit once and nothing updates the branch afterwards, while the prompt presents that remote as the sanctioned way to see a colleague's code. Across 19 agent runs there were **zero pushes**: in one pair an agent ran 24 `git fetch` / `git diff team/agent2` commands and saw the untouched baseline every time, then asked its colleague "have you submitted your branch yet?". Each agent now publishes its **submitted patch** (`patch.txt`, the artifact that is actually evaluated — not the working tree, which may differ) to `team/<agent_id>` on exit. It is built in a detached worktree from the pristine base, so the agent's own branch, index and working tree are untouched and a patch is never double-applied when the agent had already committed its work.

### Added

- Peers are told once, in context, when a colleague finishes: `[agent2 has completed their work and exited]`, with the branch to reconcile against. Publication is best-effort, so the exit marker records whether the patch actually reached the remote and the agent is only pointed at that branch when it really holds their submission.

### Changed

- The coop prompt now states what `team/<peer>` holds and when ("stays at the repository's starting state until your colleague submits" — an empty diff early means *not submitted yet*, not *no changes*), that `--wait` can return early, and that a colleague may exit before you do.

## [0.0.21] - 2026-08-04

### Fixed

- **`capture_token_ids` (0.0.20) never produced a capture.** litellm rebuilds each response into its own model; top-level extras survive on `ModelResponse`, but extras on a *choice* are swept into `provider_specific_fields` by `convert_to_model_response_object` — which is where vLLM's per-choice `token_ids` lands. Reading the raw key yielded nothing, and a live run logged the "server returned no token ids" warning on all 816 calls while the server was returning them the whole time. Also documents that this requires an OpenAI-style provider prefix: litellm's Anthropic path uses a different transform that discards both `prompt_token_ids` and `token_ids` outright.

## [0.0.20] - 2026-08-04

### Added

- **Optional `capture_token_ids` on `LitellmModelConfig`** (default `False`, so existing runs are byte-identical). When set, requests carry `extra_body={"return_token_ids": true}` and the ids the server actually used are stored on each assistant message as `extra["token_capture"]`, persisting into the saved trajectory. Reconstructing them afterwards is not equivalent: BPE is non-injective, tool-call serialization can differ between inference and training, and under context compaction the prompt a turn saw no longer exists in the final message list. Requires vLLM >= 0.10.2 or SGLang with `return_token_ids` support.

## [0.0.19] - 2026-05-25

### Fixed

- **`claude_code` adapter — assistant turns were being silently dropped from `agent*_traj.json`.** The session-JSONL parser (`parse_session_jsonl` in `src/cooperbench/agents/claude_code/parsers.py`) treated `message.role` as authoritative and rejected any event whose role wasn't in `{user, assistant, system}`. Recent claude-code session writers emit assistant turns with `message.role: None` — the role lives only in the top-level `event.type` — so every LLM turn (text, thinking, tool_use) got filtered out, leaving traj files that contained only `user` tool_result entries. Affected every `claude_code` run since the session-format shift (including all 0.0.17 / 0.0.18 trajectories on disk). Now falls back to `event.type` when `message.role` is missing; on a representative session (`anyhow_task/390/f1_f4/agent2_session.jsonl`) this recovers all 86 assistant events, taking the parsed trajectory from 43 messages (all user) to 129 (43 user + 86 assistant). The underlying `*_session.jsonl` and `*_stream.jsonl` files were always complete — only the derived `*_traj.json` was wrong, so historical runs can be re-parsed by calling `parse_session_jsonl` on the on-disk session file.

## [0.0.18] - 2026-05-25

### Removed

- **`cooperbench._proxy` module and the `--openai-base-url` / `--openai-model` CLI flags are gone.** Both existed because `claude_code` (which wraps the Anthropic CLI that only speaks `/v1/messages`) was assumed to need a LiteLLM translation layer to reach an OpenAI-compatible vLLM. That assumption was wrong: vLLM v0.17.1+ implements the Anthropic Messages API natively at the same `/v1/messages` path, so claude-code can be pointed straight at the vLLM endpoint with `--base-url`. Removing the auto-spawned LiteLLM also removes a class of bugs we kept hitting from LiteLLM version drift (`/v1/responses` auto-rewrite on `litellm>=1.82` when the inbound request has `thinking={"type":"enabled"}` — claude-code 2.1.x sends it by default; `litellm_params.stream: false` being ignored by some provider prefixes; intermittent `API Error: Content block not found` from vLLM's streaming `tool_call` extractor desynchronizing block_start / block_delta events).

### Changed

- **`--base-url` now points straight at a vLLM-served model.** Existing `--base-url` / `--auth-token` flags are kept and are the only knobs you need. `ANTHROPIC_BASE_URL` is forwarded into the task container; the adapter rewrites `localhost` / `127.0.0.1` → `host.docker.internal`, adds the matching `--add-host` to the container, injects a placeholder auth token if you didn't supply one, and writes `~/.claude/settings.json` with `CLAUDE_CODE_ATTRIBUTION_HEADER=0` (KV-cache perf fix on vLLM/llama.cpp). Real Anthropic runs (no `--base-url`) are unaffected.
- **`docs/QWEN_LOCAL.md`** rewritten to show the single-command direct flow:
  ```
  cooperbench run --base-url https://your-vllm-host -m Qwen/Qwen3.5-9B \
    -a claude_code --setting coop -s lite -c 2 --no-auto-eval
  ```
  No LiteLLM, no proxy subprocess, no extras.

### Verified

- Direct curl against `https://cooperbench--qwen35-9b-128k-serve.modal.run/v1/messages`: tool conversation returns proper Anthropic `tool_use` blocks with parsed `input`, `stop_reason: "tool_use"`; streaming returns proper `content_block_start` → `content_block_delta` → `content_block_stop` ordering with no missed start events.
- End-to-end coop run with the new flow on the same `anyhow_task` pair that was failing in `0.0.17` against the older `--openai-base-url` proxy path: agents iterate over multiple tool rounds against vLLM directly. (Adapter-level behavior unchanged from `0.0.17`; only the routing layer simplified.)

## [0.0.17] - 2026-05-25

### Fixed

- **Auto-proxy now forces non-streaming upstream — fixes `API Error: Content block not found` aborts mid-task for `claude_code` against vLLM-served Qwen3.x.** `cooperbench._proxy.managed_litellm` previously spawned LiteLLM with inline `--model` flags, which left the upstream `stream` parameter pass-through. vLLM 0.19.0's `qwen3_coder` / `qwen3_xml` streaming tool-call extractors intermittently forward `content_block_delta` events without first emitting a matching `content_block_start` for the synthesized `tool_use` block; claude-code's stream parser then raises `Content block not found` and the agent loop aborts. The fix switches to a temp YAML config that sets `litellm_params.stream: false`, so LiteLLM buffers the full upstream response and re-emits well-formed Anthropic SSE (with proper `content_block_start` → `content_block_delta` → `content_block_stop` ordering) to claude-code. Empirically on Qwen3.5-9B at 128k against a 4-pair dspy_task batch: 4/6 agents Submitted with 8 occurrences of `Content block not found` (streaming upstream) → **8/8 Submitted with 0 errors** (non-streaming upstream); patch sizes 30/102/72/76/70/48/186/47 lines, real multi-turn iteration (up to 35 steps). Confirmed end-to-end through the auto-proxy with a fresh `cooperbench run --openai-base-url ...`: 0 errors, both agents produced sensible diffs. Tracking upstream as [vllm-project/vllm#39056](https://github.com/vllm-project/vllm/issues/39056).

## [0.0.16] - 2026-05-25

### Fixed

- **`swe_agent` now supports `--backend docker` too** — adapter was hardcoded to `swerex.ModalDeploymentConfig`.  Added a backend dispatch that picks `DockerDeploymentConfig` when `config["backend"] == "docker"`.  Required two follow-on fixes: (a) `docker_args=["--entrypoint", ""]` to clear the task image's `ENTRYPOINT=runner.sh` (otherwise swerex's `sh -c "..."` becomes a `runner.sh sh -c "..."` and the first positional arg gets interpreted as a feature-patch path); (b) monkey-patch swerex's `DockerDeployment._get_swerex_start_cmd` to invoke `pipx run --spec swe-rex swerex-remote ...` instead of `pipx run swe-rex ...` — upstream swerex assumes the package's executable matches the package name, but the published `swe-rex` package provides an executable named `swerex-remote`.  Smoke-tested with `dottxt_ai_outlines/1655 [1,3]` solo: 1/1 pass in 2m 53s.
- **codex `exec` hung indefinitely in Modal sandbox** — codex's `exec` mode tries to read additional input from stdin and blocks until EOF.  Docker's non-tty `docker exec` gives it EOF immediately, but Modal sandbox `exec` keeps stdin open, so codex sat for the full sandbox lifetime (~2h) printing "Reading additional input from stdin..." and producing zero stream output.  Fix: add `</dev/null` to the codex invocation in `codex/adapter.py::_build_codex_command`.  Smoke-tested with a solo run on `dottxt_ai_outlines/1655 [1,3]`: 1/1 pass in 1m 48s.
- **`cooperbench eval` now refuses to eval an openhands_sdk run with a non-modal backend** — openhands_sdk produces patches that include a committed `patch.txt` artifact in the working tree and relies on Modal-hosted Redis for inter-agent coordination; running the eval through Docker silently changed the test environment.  The eval now reads the run's `config.json`, detects `agent_framework == "openhands_sdk"`, and exits with a clear warning if `--backend != modal`.
- **`normalize_patch` was eating trailing blank context lines** — the helper used `text.strip()` to collapse trailing whitespace before re-appending a single newline.  A unified-diff blank-context line is encoded as `" \n"` (one space + LF), which `strip()` consumes along with the terminator.  Result: the last hunk's body became one (or two, for consecutive blank lines) shorter than its `@@ -L,N @@` header claimed, and `git apply` rejected it.  In a 10-task team-mode run on `claude_code` this manifested as every "merge conflicts / both features fail" task — the malformed patches couldn't 3-way-merge cleanly even though they applied.  Now uses `text.lstrip("\n").rstrip("\n") + "\n"` so blank context lines are preserved.
- **`mini_swe_agent_v2` adapter wasn't normalizing patches at all** — `adapter.py:252` did `(r.get("output") or "").strip()` and returned the raw stripped string.  Every msa patch on disk ended in a non-newline byte, so `git apply` rejected them outright (msa accidentally hid behind the same blank-context bug as `normalize_patch`, just one layer deeper).  Now routes through the fixed `normalize_patch` helper, matching `claude_code` and `codex`.
- **`mini_swe_agent_v2` Modal sandbox died on first exec** — `environments/modal.py::_start_sandbox` called `modal.Sandbox.create(image=..., ...)` with no command.  Combined with `image.entrypoint([])` clearing the image's entrypoint, the sandbox ran the image's `CMD` (e.g. `/bin/bash`) which exited immediately on stdin-less startup, so the next `exec()` hit "Sandbox not found".  Across a 10-task run every agent failed at step 1 (~$0.015 each) with 260 retried-sandbox-died errors.  Now passes `"sleep", "infinity"` as the positional command, matching the eval backend's existing fix.
- **`claude_code` and `codex` adapters silently ignored `--backend modal`** — both call shared `_coop.runtime.build_environment`, which was hardcoded to `DockerEnvironment` regardless of the `config["backend"]` the runner threaded through.  At concurrency=10 in team mode this surfaced as ~20 simultaneous `docker run` attempts on the host, several of which hit the 120s startup timeout (~half of `cx` member agents died at container creation).  `build_environment` now takes a `backend` kwarg; both adapters pass `config.get("backend", "docker")`.

### Changed

- **Team-mode primitives moved to `cooperbench.team_harness`** — extracted from `cooperbench/agents/_team` (private) to `cooperbench/team_harness` (public, library-shaped) so other benchmarks can consume the coordination algorithm without depending on CooperBench's task layout.  Adds a `TeamSession` facade that bundles per-run state (run_id, Redis URL, agents, scratchpad volume) and exposes adapter-facing factories (`env_for`, `scratchpad_mount_args`, `mcp_config`, `prompt_for`, `prompt_section`, `loop_poller`, `task_list_client`, `harvest_metrics`).  Adapters consume the session instead of calling loose helpers; the runner constructs one per run.
- **Stronger team-mode lead prompt** — `_team/prompt.py::_lead_block` previously buried the integration step at the bottom of a long workflow list, and Claude/Codex consistently exited after their own feature without ever reading `/workspace/shared/<agent>.patch`.  Replaced with an opening hard-rule ("the integration step is the WHOLE point of your job — DO NOT SKIP IT") and a 5-point pre-submission checklist (tasks done → member patches present → patches applied → tree compiles → both features visible in `git diff`).  Also asks the lead to drop a `PLAN.md` upfront that divides the file regions per feature.  Member block now opens with "stay in your lane" and points at that plan.
- **Eval `test_merged` policy: `identical → naive → lead-when-naive-conflicts`**.  The previous chain tried `identical → naive → union → solo-fallback`; both `union` and the member-fallback were dropped.  Rationale: union merge concatenates conflicting hunks, which usually produces syntactically broken code and rewards lucky non-overlap rather than real coordination.  The lead is the team's designated integrator; if naive merge conflicts, the lead's `patch.txt` alone is the team's deliverable, and it must pass both feature suites unaided.  Member fallback removed for the same reason — if the lead didn't integrate, the team's coordination failed regardless of what the member produced.  Surfaced in `eval.json` as `merge.strategy = "solo-agent1"` when the lead-alone path succeeded.

### Added

- **Azure OpenAI support for the litellm/SDK adapters** (`mini_swe_agent_v2`, `swe_agent`, `openhands_sdk`) — same `AZURE_OPENAI_API_KEY` + `AZURE_OPENAI_ENDPOINT` env vars and deployment name via `-m`.  Shared detection lives in `cooperbench/agents/_azure.py`; each adapter routes its model through litellm's openai-compatible provider pointed at Azure's v1 base (`model = openai/<deployment>`, `api_base` + `api_key`), mirroring how the OpenAI SDK is pointed at Azure — no `api_version` pin needed (both the openai-compatible and native `azure/` litellm routes were verified; the former is used).  `claude_code` is intentionally excluded.  Validated the litellm→Azure route directly; `mini_swe_agent_v2` validated end-to-end (docker).  `openhands_sdk` requires the Modal backend and `swe_agent` the swerex path, so those are wired but not yet end-to-end-validated against Azure.
- **Azure OpenAI support for the codex adapter** — set `AZURE_OPENAI_API_KEY` + `AZURE_OPENAI_ENDPOINT` (the OpenAI-compatible v1 base, e.g. `https://<resource>.cognitiveservices.azure.com/openai/v1`) and pass the Azure *deployment* name via `-m`.  When both are present they take precedence over `OPENAI_API_KEY`: a custom `model_provider = "azure"` block is written to codex's `config.toml` and the key is read from the env var (no `auth.json`).  Azure runs use codex's plain output instead of `--json` — codex 0.132's JSONL event stream deterministically fails against Azure's HTTP/2 `/responses` endpoint ("stream disconnected"; the outbound request is byte-identical between modes, so it's a codex response-handling bug) while plain output works — so token/cost/trajectory telemetry is unavailable on the Azure path; the patch is still harvested from `patch.txt` and the final message via `--output-last-message`.  Validated end-to-end on `dottxt_ai_outlines/1655 [1,3]`: Submitted, eval passes both features.
- **Ablation flags for team mode** — five `--team-no-*` CLI flags (`--team-no-task-list`, `--team-no-scratchpad`, `--team-no-mcp`, `--team-no-auto-refresh`, `--team-no-protocol`) gate each coordination feature independently.  Each flag flips one boolean on `TeamHarnessConfig`; the session's factory methods return `None`/`[]`/`{}` for disabled features so adapter blocks skip cleanly.  The lead/member role split stays on as the always-on baseline (without it team collapses to coop).  `result.json` now surfaces `team_features: {...}` so post-hoc analysis can attribute pass-rate deltas to the specific feature that was off.  End-to-end smoke on `dottxt_ai_outlines/1371 [1,2]` with codex: default writes `task_log.json`+`tasks.json`+metrics; `--team-no-task-list --team-no-scratchpad --team-no-mcp` drops all three and produces no `cb-team-*` Docker volume.
- **`cooperbench run` can now drive `claude_code` against any OpenAI-compatible endpoint with a single command.** New `--openai-base-url` / `--openai-model` flags auto-spawn a LiteLLM translation proxy for the lifetime of the run: cooperbench picks a free local port, runs `litellm --model openai/<model> --api_base <url> ...` as a subprocess (with `OPENAI_API_KEY=dummy` in its env), polls `/health/liveliness` until ready, sets `ANTHROPIC_BASE_URL`/`ANTHROPIC_AUTH_TOKEN` to the local port for the run, and tears down on exit (including on SIGTERM/Ctrl-C via `start_new_session=True`).  Mutually exclusive with the existing `--base-url` / `--auth-token` flags, which remain available as an escape hatch for users who manage their own proxy.  Implementation in `src/cooperbench/_proxy.py` (`managed_litellm` context manager) wired into `cli.py::_run_command`.  Driven by the need to run `claude_code` against a self-hosted vLLM serving Qwen3.5-9B (128k) on Modal without two-terminal ceremony; pip install + one CLI call is the whole flow.  See `docs/QWEN_LOCAL.md`.
- **Custom-endpoint support in `claude_code` adapter** — when `ANTHROPIC_BASE_URL`/`ANTHROPIC_AUTH_TOKEN` are set (either directly or via the auto-proxy above), the adapter now: (a) forwards them into the container with `localhost`/`127.0.0.1` rewritten to `host.docker.internal`; (b) adds `--add-host=host.docker.internal:host-gateway` to the container so the rewrite actually resolves; (c) preserves the model name (no provider-prefix strip — the upstream proxy controls naming); (d) injects a placeholder auth token when the user passes a base URL without one, since claude-code refuses to start without a credential; (e) writes `~/.claude/settings.json` inside the container with `CLAUDE_CODE_ATTRIBUTION_HEADER=0` — that header otherwise busts the KV cache on vLLM/llama.cpp backends (~90% slowdown).  Real Anthropic runs are unaffected: none of this fires when `ANTHROPIC_BASE_URL` is empty.
- **Per-model budget profile registry in `claude_code` adapter** — new `_MODEL_PROFILES` dict (`src/cooperbench/agents/claude_code/adapter.py`) keyed by case-insensitive substring match against the model name.  Currently ships one entry (`qwen`) that sets `max_output_tokens=4096`, `file_read_max_tokens=4000`, `mcp_max_output_tokens=2000`, and `disallowed_tools=SMALL_CONTEXT_DISALLOWED_TOOLS` — the last one strips ~20 tool schemas (CronCreate, EnterPlanMode, NotebookEdit, WebFetch/Search, etc.) that would otherwise eat thousands of baseline tokens of system prompt on a small-context model.  Profile values fill in defaults; any keys the caller passes via `config` override them, so callers can tune per-run.  Models without a matching profile (Claude, GPT-5.5 routed through a different proxy, ...) get stock Claude Code behavior.  Settings land in `~/.claude/settings.json` because Claude Code ignores those env vars when routing through `ANTHROPIC_BASE_URL` — they must live in the settings file under `env`.
- **`docs/QWEN_LOCAL.md`** — end-to-end guide for running `claude_code` against a self-hosted OpenAI-compatible endpoint using only the PyPI package (the canonical single-command flow), plus the manual-proxy escape hatch.
- **`dataset/subsets/core.json`** — 10-pair core subset for quick agent comparisons.  Stratified sampling: largest-remainder proportional allocation by repo's full-dataset pair count, with a one-slot floor per primary language (Python / Go / Rust / TS).  Within each repo, pairs are sampled by spreading across tasks before any repeat.  Reproducible via `python scripts/generate_core_subset.py` (seed=42).  Pass-rate on `core` tracks the overall dataset's shape without per-task eval data.
- **`docs/BENCHMARK_RESULTS.md`** — horizontal team-mode comparison of `claude_code` / `codex` / `mini_swe_agent_v2` / `openhands_sdk` on the `core` subset.  Per-task pass/fail matrix with merge strategy used, framework totals (`msa` 6/10, `oh` 5/10, `cc` 5/10, `cx` 5/10), and a narrative of the reruns that surfaced the bugs in the unreleased Fixed/Changed sections.

## [0.0.15] - 2026-05-18

### Added

- **Claude Code adapter** (`cooperbench.agents.claude_code`).  Wraps the
  Claude Code CLI inside the task's Docker container with coop messaging
  and git-collaboration support.  Authenticates via the host's
  `ANTHROPIC_API_KEY`, registers the shared `coop-*` shell wrappers, and
  participates in solo / coop / coop+git / team runs alongside the
  existing `mini_swe_agent_v2`, `swe_agent`, and `openhands_sdk`
  adapters.

- **Codex adapter** (`cooperbench.agents.codex`).  Wraps the OpenAI
  Codex CLI (`codex exec --json --sandbox danger-full-access
  --skip-git-repo-check`).  Writes `${CODEX_HOME}/auth.json` inside the
  container so the CLI authenticates without prompts, parses Codex's
  JSONL event stream for status / token totals / messages, and reports
  cost as `0.0` because Codex does not emit a cost field.  Includes a
  one-shot model-name fallback (retries without `--model` if Codex
  rejects the requested model) and a preflight `OPENAI_API_KEY` check.

- **`team` setting** alongside `solo` and `coop`.  N agents organized
  as one lead + N-1 members, with a Redis-backed shared task list
  (atomic claim via `coop-task-claim`), a shared scratchpad volume
  mounted at `/workspace/shared`, and role-specific prompt blocks.
  All five adapters (`mini_swe_agent_v2`, `swe_agent`, `openhands_sdk`,
  `claude_code`, `codex`) accept the new `team_role` / `team_id` /
  `task_list_url` kwargs; CLI adapters install `coop-task-create` /
  `coop-task-claim` / `coop-task-update` / `coop-task-list` shell
  wrappers next to the existing `coop-*` messaging tools.  Post-run,
  the task-list audit log is used to compute coordination metrics
  (`time_to_first_claim_seconds`, `claims_per_agent`,
  `updates_per_agent`, `tasks_done`, `unowned_at_end`) saved in
  `result.json`.

- **Team-mode filesystem mirror** of the task list at
  `/workspace/shared/tasks/`.  One `<id>.json` per task plus
  `_index.json` (cheap `ls` target) and `_log.jsonl` (audit trail),
  written via tempfile+replace so readers never observe partial state.
  Lets agents `ls` and `cat` tasks with their existing tools instead of
  going through the `coop-task-list` CLI.

- **Typed `coop-request` / `coop-respond` protocol**
  (`cooperbench.agents._team.protocol`) layered on plain Redis
  messaging.  `coop-request <peer> <kind> <body>` returns a request_id
  and optionally blocks via `--wait N`; `coop-respond <request_id>
  <body>` writes back.  The sender's `await_response` uses BLPOP so it
  sleeps instead of busy-polling, and both events flow into the shared
  task-log so coordination metrics include protocol events.

- **MCP long-poll server** (`cooperbench.agents._team.mcp_server`).
  Stdio JSON-RPC server exposing a single `wait_for_message` tool
  backed by BLPOP on the agent's inbox.  Registered automatically for
  CLI adapters: Claude Code writes to `$CLAUDE_CONFIG_DIR/.claude.json`,
  Codex writes to `$CODEX_HOME/config.toml`.  Gives opaque CLI agent
  loops the closest thing to push-style inbox delivery.

- **In-loop task-list auto-refresh** for `mini_swe_agent_v2`
  (`cooperbench.agents._team.loop_refresh`).  `TeamPoller` runs between
  LLM queries — same hook as the existing inbox poll — and prepends a
  compact `[Team task list] open: 1, in_progress: 2, ...` summary so
  the LLM doesn't need to remember to call `coop-task-list`.

- **Shared `cooperbench.agents._coop` module** holding the
  agent-agnostic coop primitives that the CLI adapters previously
  duplicated: `coop_msg.py` (Redis-backed messaging CLI installed as
  `coop-send` / `coop-recv` / `coop-broadcast` / `coop-peek` /
  `coop-agents`), `prompt.py` (solo / coop / coop+git prompt assembly),
  `runtime.py` (`ContainerEnv` protocol, environment assembly,
  in-container file I/O helpers, git-setup command construction,
  sent-messages log parsing, and `normalize_patch`), and
  `install_snippet.sh` (sourced from each adapter's `setup.sh`).

### Fixed

- **`mini_swe_agent_v2`: prevent re-exploration loops after compaction**
  (PR #54).  The default compaction summarizer was producing terse,
  generic summaries that lost the file contents agents had already
  read.  After compaction the agent would re-cat/grep the same files,
  hit the 100-step limit, and fail to submit — in one full coop run,
  91% of agents (63/72 sampled trajectories) hit `LimitsExceeded` with
  mean ~99 of 100 steps used.  Two targeted changes: (1) `summarize_context`
  now serializes prior turns into a single user message as a tagged
  transcript, preventing the model from role-playing as the next
  assistant turn; (2) the default `compaction_summary_prompt` is now
  a structured template with explicit headings (FILE MAP, RELEVANT CODE
  READ, KEY SYMBOLS, SEARCH RESULTS, EDITS, BUILD/TEST OUTPUT, COLLEAGUE
  MESSAGES, OPEN QUESTIONS, CURRENT PLAN), asks for verbatim quoting
  with `file:line` citations, and includes an anti-hallucination guard
  for line counts.  Measured on an A/B replay of 9 real solver segments,
  coverage of post-compaction re-explores went from 40% to 57% on a
  heuristic file+symbol scorer.

- **`runner/coop`: coerce message timestamps to float before sorting**
  (PR #49).  `execute_coop` crashed mid-rollout with `TypeError: '<'
  not supported between instances of 'int' and 'str'` when one agent
  adapter reported numeric timestamps (`mini_swe_agent` uses
  `time.time()` floats) and another reported ISO strings (OpenHands
  SDK).  The sort fired before `agent{fid}_traj.json` was written, so
  callers relying on the structured trajectory got nothing even though
  the rollout completed.  Added `_message_timestamp_key` that
  best-effort coerces to float (None / non-numeric → 0.0).

- **CLI adapter patch normalization** (PR #51).  The previous Claude
  Code adapter's `.strip()` on `patch.txt` was eating the trailing
  newline that `git apply` requires, producing "corrupt patch at line
  N" errors.  Replaced with `normalize_patch()` (one trailing newline,
  no leading whitespace) in the shared `_coop` module.

- **Team-mode prompt: explicit `patch.txt` submission step**.  The
  initial team-mode end-to-end had members writing diffs to
  `/workspace/shared/<id>.patch` only and never to
  `/workspace/repo/patch.txt`, scoring 0/2 despite great coordination.
  Both lead and member prompts now have an explicit
  `### Final submission — REQUIRED` section that names `patch.txt` as
  the only file the bench evaluates and provides the exact
  `git diff > patch.txt` command.  Verified by a follow-up run on the
  same task that scored 2/2.

- **Result-table rendering for team mode**.  Cosmetic fix to
  `runner/core._print_single_result` — team mode's per-agent dicts
  carry `patch_lines: int`, but the previous code tried
  `len(r.get("patch", "").splitlines())` and showed 0.

### Changed

- **`fakeredis` is now a dev dependency** (and `uv.lock` is regenerated
  to match).  Six team-mode test modules import `fakeredis` to mock
  Redis; without it pinned, CI's `uv pip install -e ".[dev]"` left it
  missing and pytest collection failed.

## [0.0.14] - 2026-04-30

### Changed

- **`mini_swe_agent_v2` patch is now read directly from `patch.txt` in the agent's container.**  Previously the adapter parsed the patch out of the agent's stdout (whatever followed the `echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT` sentinel).  In a real coop+git run with GPT-5.4 against the v0.0.13 prompts, ~50% of agents still emitted the bare sentinel without `&& cat patch.txt` — but **all 18/18 agents still wrote a `patch.txt` file** in their working directory.  Reading the file directly via `docker exec cat patch.txt` after `agent.run()` returns is deterministic regardless of which submit-command variant the agent picked.  Submit step in `coop.yaml` / `solo.yaml` simplified to the bare `echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT` (still framed as `EXACT command required` so models follow it consistently).  No fallback to stdout submission text — `patch.txt` is the only source of truth.

## [0.0.13] - 2026-04-30

### Fixed

- **`mini_swe_agent_v2` Submit step now uses upstream's prescriptive wording.**  In a real coop+git run with GPT-5.4 against the v0.0.12 prompts, ~50% of agents reverted to the bare `echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT` (without `&& cat patch.txt`), producing empty patches even when they had edited files.  Strong-prior models trained on upstream mini-swe-agent's older `swebench.yaml` recognise that pattern from training and override the prompt.  Restore upstream's exact framing — `Submit (EXACT command required) / You MUST use this EXACT command to submit:` — so the prompt reads as prescriptive rather than as one example among many.

## [0.0.12] - 2026-04-30

### Changed

- **`mini_swe_agent_v2` patch is now the agent's `submission`** — the adapter no longer captures `base_commit` and runs `git diff <base>` at end-of-run. Instead the patch comes directly from `result['submission']`, which the env populates with everything the agent emits after `echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT`. Mirrors upstream mini-swe-agent's SWE-bench config. The `coop.yaml` / `solo.yaml` prompts now instruct the agent to curate via `git diff -- file1 file2 > patch.txt`, verify with `cat patch.txt`, and submit with `echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT && cat patch.txt`. No working-tree-extraction fallback — if the agent didn't submit, there is no patch.
- **`config/mini.yaml` split into `config/solo.yaml` + `config/coop.yaml`** — the previous single file conditioned everything on `{% if agent_id %}` blocks. The adapter now selects which file to load via `is_coop = len(agents) > 1`. While splitting, fixed a leak in the solo branch where the `CRITICAL REQUIREMENTS` section still mentioned `send_message to your colleague` for an agent with no colleague.
- **Shared singleton git server for `--git` coop runs** — replaces the previous design that spun up a fresh `debian:bookworm-slim` container per run, ran `apt-get install git`, slept 3s, and returned (resulting in race conditions where agents' initial `git push` beat the daemon to startup). The new design auto-creates one image (`cooperbench-git-server:local`), one network (`cooperbench`), and one container (`cooperbench-git`) on first use; per-run isolation comes from path namespacing under `/git/<run_id>/repo.git`. Idempotent — first run pays a ~30s image-build cost, subsequent runs reuse the singleton in ~140ms. Mirrors the Redis-style "one daemon, many namespaces" pattern.
- **Submission prompts simplified + `.git` footgun warnings** — the `## Submission` section in `coop.yaml` / `solo.yaml` is now ~5 lines (write a `git diff` to `patch.txt`, `cat` it, submit with `echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT && cat patch.txt`).  Adds an explicit `<CRITICAL>` block forbidding `rm -rf .git`, `git init`, `git rm -rf .`, and `git reset --hard` inside `/workspace/repo` — these are easy footguns for small models, observed in the wild causing patches to come out as malformed `new file mode` diffs that fail to apply.

### Fixed

- **Eval surfaces `git apply` failures instead of silently masking them.**  `_setup_branches` now emits explicit `PATCH<N>_APPLIED` / `_SKIPPED` / `_FAILED` markers per agent and returns an `apply_status` dict.  `test_merged` writes that to the result and refuses to call merge `clean` when any input patch failed to apply — instead reporting `merge.status: "missing_input"`.  Previously, an agent submitting a malformed patch (e.g. a `new file mode` diff against an existing file) would have its branch silently end up empty, and the subsequent merge against the other agent's branch would report `clean` despite the missing input — making the eval lie about partial success.
- **Per-feature eval result schema enriched.**  `feature1` / `feature2` now carry `feature_id`, `exit_code`, `tests_passed`, and `tests_failed` (was just `passed: bool` + a 50KB `test_output` blob).  Lets consumers reason about results without grepping raw pytest output.

- **`mini_swe_agent_v2` adapter no longer crashes on `content=None`** — tool-calling assistant turns leave `content=None` (the body lives in `tool_calls`), and CooperBench's downstream `_extract_conversation` does `"send_message" in content`, which raises `TypeError` on None. The adapter now coerces to `""` before populating `AgentResult.messages`.
- **`mini_swe_agent_v2` adapter wires up the `agent_config` flag** — previously listed in `MiniSweAgentV2Runner.run`'s signature but never read from. Now loads the YAML and deep-merges its `config:` block over the defaults. Forward-compatible: `**kwargs` accepted so unknown caller-side args don't crash `run()`.
- **`mini_swe_agent_v2` adapter drops the dead `SEND_MESSAGE_TOOL` import** — only `BASH_TOOL` is registered with the model; `send_message` is intercepted from inside the bash command string. The leftover import was confusing.
- **`DockerEnvironmentConfig.network`** — added a typed `network` field so the `--network <name>` flag reaches `docker run`. Previously the adapter passed `network=...` as a kwarg, but Pydantic silently dropped it (no such field), and agent containers ended up on the default bridge with no route to the per-run git server's IP. With the new shared-singleton git server design, agent containers must join the shared `cooperbench` network for DNS-by-name resolution to work.
- **`DefaultAgent.serialize()` no longer mutates `_segments`** — `run()` calls `save()` in its finally clause every step, and once compaction had fired, each `serialize()` call appended another snapshot of the current live messages as a fresh solver segment (and reset the buffer, which the next `query()` repopulated). Net effect: one compaction produced N+1 overlapping post-compaction solver segments instead of 1. Fix: `serialize()` builds the snapshot list locally without touching `self._segments`.

### Added

- **`cooperbench` CLI auto-loads `./.env`** — `cli.py` now calls `dotenv.load_dotenv()` at module load, so project-local `OPENAI_API_KEY` etc. is picked up without users having to `set -a && source .env` ahead of every invocation. Matches the convention used elsewhere in the codebase.

## [0.0.11] - 2026-04-18

### Added

- **Context compaction (summarization) for `mini_swe_agent_v2`** — long-running agents no longer exhaust the model context window. When the previous LLM response's `prompt_tokens` reaches `compaction_token_trigger` (default `28000`), the agent calls the model a second time (without tools) to summarize old turns and replaces the live history with `[system, task, summary] + recent_turns` (last `compaction_keep_recent_turns=2` assistant turns kept verbatim). Repeated compactions naturally fold the previous summary back into `old_turns`. Configurable via `agent.compaction_enabled` / `compaction_token_trigger` / `compaction_keep_recent_turns` / `compaction_summary_prompt`; **enabled by default**.
- **Full-trajectory artifact** — when any compaction occurs, the adapter writes `{log_dir}/{agent_id}_full_traj.json` containing a `segments` list (alternating `solver` / `summarizer` blocks) so the unabridged pre-compaction history is preserved for analysis even though the live `messages` list has been shortened.
- **`LitellmModel.summarize_context(messages, summary_prompt)`** — separate completion call (no tools) used by the agent's compaction step; tracks cost via `GLOBAL_MODEL_STATS` and tags the resulting message with `extra.summary=True`.

### Changed

- **`mini_swe_agent_v2` adapter config merge** — switched from shallow `dict.update` to `recursive_merge`, so partial overrides (e.g. only `agent.compaction_enabled`) no longer clobber sibling keys from the default YAML.

## [0.0.10] - 2026-04-18

### Fixed

- **Docker eval backend entrypoint handling** - `eval/backends/docker.py` started its sandbox container with `command="sleep infinity"` but no `entrypoint` override, so images that set an `ENTRYPOINT` (e.g. the benchmark dataset images with `/usr/local/bin/runner.sh`) would consume `sleep infinity` as entrypoint arguments and exit immediately. Every subsequent `docker exec` then hit "container is not running". Clear the entrypoint on startup (`entrypoint=""`) so `sleep infinity` runs as PID 1; `runner.sh` is still invoked explicitly via `docker exec` during evaluation. Matches the Modal and GCP eval backends and completes the fix started in 0.0.9 for the agent-side environments.

## [0.0.9] - 2026-04-17

### Fixed

- **Docker backend entrypoint handling for `mini_swe_agent` and `mini_swe_agent_v2`** - Containers whose images set an `ENTRYPOINT` (e.g. the benchmark dataset images that use `/usr/local/bin/runner.sh` as their entrypoint) were exiting immediately because `sleep infinity` / `sleep <timeout>` was passed as arguments to the entrypoint rather than as the container command. Both docker environments now explicitly clear the entrypoint (`--entrypoint ""` / `/bin/bash -c`), matching the behaviour of the Modal and GCP backends.

## [0.0.8] - 2026-04-17

### Fixed

- **`git index.lock` in coop eval** - Stale lock file left by `runner.sh` after the first feature test no longer blocks the second feature's `git checkout`/`reset` in `_run_tests`

## [0.0.7] - 2026-04-17

### Changed

- **Docker is now the default backend** for both `cooperbench run` and `cooperbench eval`, as well as every helper API (`evaluate`, `_evaluate_single`, `run_patch_test`, `test_merged`, `test_solo`, `get_backend`, `get_environment`, agent adapter config fallbacks, and the coop/solo runners). Previously defaulted to `modal`.

### Fixed

- **Auto-eval now honours `--backend`** - `cooperbench run --backend <X>` no longer silently falls back to modal during the inline evaluation phase; the value is threaded through both the single-task and multi-task auto-eval paths (`runner/core.py`).

## [0.0.6] - 2026-04-17

### Added

- **`cooperbench prepare`** - New CLI subcommand that downloads the benchmark dataset from HuggingFace (`CodeConflict/cooperbench-dataset`) into `./dataset`, so PyPI users don't need to clone the GitHub repo
- **`scripts/upload_dataset_to_hf.py`** - Maintainer script to sync the local `dataset/` tree up to the HuggingFace dataset repo

### Changed

- **README** - Replaced `git clone` dataset instructions with `cooperbench prepare`; fixed stale HuggingFace URL
- Added `huggingface-hub>=0.24` as a core dependency

## [0.0.5] - 2026-02-14

### Added

- **mini_swe_agent_v2** - New agent framework with improved tool-call based architecture, litellm model integration, cache control, multimodal support, and retry logic

### Changed

- **Python 3.10 support** - Lowered minimum Python version from 3.12 to 3.10, replacing `typing.Self`, `typing.override`, and PEP 695 type aliases with `typing_extensions` equivalents
- **Removed `browser-use` dependency** - Dropped from both root and vendored openhands-tools dependencies
- **Removed `openhands-agent-server` dependency** - Dropped unused dependency from vendored openhands-workspace
- **Fixed lint/type errors** - Resolved ruff F401 unused import and mypy type error in mini_swe_agent_v2

## [0.0.4] - 2026-02-14

### Added

- **Token usage tracking** - `AgentResult` now reports `input_tokens`, `output_tokens`, `cache_read_tokens`, and `cache_write_tokens` throughout the pipeline
- **Fallback cost calculator** - New `pricing.py` module computes cost from token counts when litellm doesn't report it, with manual pricing table for custom endpoints
- **Log directory passthrough** - Runners now pass `log_dir` path to agents for downstream logging (PR #32)
- **Eval stats in summary** - Run summary JSON now includes pass rate and per-task eval results when auto-eval is enabled
- **Gold conflict checker** - New `scripts/check_gold_conflicts.py` to detect merge conflicts between gold patches across all tasks using parallel Modal sandboxes
- **Benchmark runner script** - New `scripts/run_benchmark.sh` for quick experiment launches
- **Model smoke test** - New `scripts/test_model.py` to verify models work via LiteLLM

### Changed

- **Improved cooperation prompt** - Replaced situational-awareness prompt with explicit numbered workflow (plan → coordinate → summarize) after A/B testing showed better coordination and lower cost
- **OpenHands SDK dependencies promoted to core** - Moved from `[openhands]` optional extra into base dependencies for simpler installation
- **HTTP retry logic** - Remote conversation requests now retry on 5xx errors with exponential backoff (via tenacity)
- **Patch extraction timing** - Patches are now extracted while the sandbox is still alive, before stats collection

### Fixed

- **Pricing calculation** - Fixed cost reporting for models where litellm returns zero cost
- **MaxIterationsReached handling** - Now caught inside the conversation loop instead of as an outer exception, preventing lost patches
- **Custom API base URLs** - `ANTHROPIC_BASE_URL` and `OPENAI_BASE_URL` now forwarded to sandboxes

## [0.0.3] - 2026-02-04

### Added

- **Agent SDK support** - New agent SDK framework with Modal support for sandboxed execution
- **Inter-agent messaging** - Added messaging capability between agents in cooperative settings
- **GCP Batch evaluator** - New GCP-based evaluator using Google Cloud Batch for scalable evaluation
- **GCP execution environment** - Added GCP VM support for agent execution
- **Docker-based Git server** - Local Git server running on Docker for coop mode collaboration
- **External agents support** - Support for external agents via environment variables and registry
- **Agent configuration** - CLI and runner now accept optional agent config path
- **Auto-eval feature** - Automatic evaluation after task completion
- **Interactive GCP configuration wizard** - Streamlined GCP setup with comprehensive documentation

### Changed

- Increased default max steps to 100
- Improved messaging prompts and fixed messaging bugs
- Consolidated GCP documentation into single comprehensive guide
- Updated dataset lite split
- Re-run tasks with Error status instead of skipping

### Fixed

- Git server configuration now properly passed to runners
- Fixed resource leaks on GCP and formatting of cwd path
- Docker timeout fixes
- Fixed skip errored tasks behavior
- Various linter fixes and test improvements

## [0.0.2] - 2026-01-31

### Changed

- **Complete architecture rewrite** - Replaced OpenHands-based execution with Modal sandboxes
- New agent framework: `mini_swe_agent` with tool-based interface
- Simplified CLI: `cooperbench run` and `cooperbench eval` commands
- Redis-based inter-agent messaging for cooperative settings
- Optional git collaboration for shared code changes

### Removed

- OpenHands Docker integration
- Planning phase (agents now plan and execute in single flow)
- `[llm]`, `[execution]`, `[serve]` optional dependencies
- Old Python API (`BenchSetting`, `FileInterface`, `create_plan`, `create_execution`)

### Added

- Modal sandbox execution environment
- `mini_swe_agent` framework with bash, file editing, and messaging tools
- Git connector for multi-agent code collaboration
- Comprehensive test suite

## [0.1.0] - 2026-01-15

### Added

- Initial release with OpenHands-based execution
- Planning and execution phases
- Support for single, solo, coop, and coop_ablation settings
- HuggingFace dataset integration
