# 当前功能清单：实现、页面与证据

## 证据等级
- U：本次在真实 Electron 窗口观察到。表单/空列表可见，不代表提交执行成功。
- S：当前源码有入口或调用链，未在本次运行功能任务。
- H：读到既有 2026-10-10 验证记录，属于历史运行证据。当地脚本模型不是云端模型。
没有表项可以只因 U/S 被标成“全流程验收通过”。以下路径均相对 agent-sdk；资料包 source 保留对应仓库路径。

| 功能 | 用户入口与已有行为 | 主要源码/API | 本次证据与限制 |
|---|---|---|---|
| Electron 工作台 | 本地服务加载、壳与业务前端分离 | desktop/electron/src/main/main.js；desktop/web | U，真实窗口已打开 |
| 核心监管 | ready/fatal、实例/API 校验、代际、重启退避、复用 | main.js、core-supervision.js | S；未故障注入 |
| 托盘/单实例/外链 | 主进程已有相关处理 | main.js | S；未验收安装、自启、发布 |
| 工作区 | 目录选择、项目别名、会话分组 | workspace-state.js；core/folder-picker.js；app-domain.js | U 02/25；未切换目录 |
| 会话管理 | 新建、历史、搜索、归档、恢复 | app-domain.js；/session、/sessions | U 21；未新建/归档 |
| 对话回合 | 文本、Markdown、流式事件、工具步骤、完成 | app.js；core/turn-sse.js；/session/{id}/turn | U 历史回复；H 本地脚本回合 |
| 回合控制 | 中止、重连、错误恢复入口 | app-domain.js；core/recovery.js | S；本次无活动任务 |
| 附件与语音入口 | 输入框附件和麦克风 | index.html；shell/speech.js | U 图标；未文件/语音验收 |
| 模型配置 | 默认模型、服务商、端点、输出上限 | index.html；app.js；views/settings-panel.view.js；/settings | U 17/18；未保存或测连通 |
| 自定义模型 | 连接元数据、协议、凭据、温度/超时随回合覆盖 | core/model-routing.js；crates/owo-agent-core/src/gateway/custom.rs；protocol | U 18；H 本地端点覆盖测试 |
| 推理与上下文 | effort 选择、上下文估算、模型输出预算 | app.js；core/model-output-budget.js | U 21；参数实际支持依赖服务商 |
| 权限/审批 | 概览、矩阵、范围、撤销、待审批；完全访问确认 | permissions/*.js；/permissions/overview、/permissions/spec | U 23 仅查看；未批准或撤销 |
| 审计/diff/回退/导出 | 右侧检查器、过滤、MD/HTML、回退入口 | app-domain.js；traces_api.rs | U 22；无当前 diff，未回退 |
| Eval/轨迹 | 套件入口、轨迹列表和回放 | panels/eval.panel.js；/eval/gate；/traces | U 03 有历史两条轨迹；未评测 |
| 子代理 | 只读探索/通用子代理任务入口 | index.html；subagent_api.rs | S；未委派 |
| 项目规则 | AGENTS.md 查看/保存入口 | app-domain.js；项目相关路由 | S；未保存规则 |
| 项目任务创建 | 目标、目录、读写范围、自动/单/多 Agent、模板、预览 | project-launcher.panel.js；/teams；模板目录 | U 08；未创建，不能展示执行 |
| WorkSwarm | 创建、团队列表、模板提案；详情含任务/产物/质量 | workswarm.panel.js；workswarm/*；workswarm_api/handlers.rs | U 09/10 空列表；详情只有 S |
| 团队控制 | steer、continue、retry、replace、cancel；审计/恢复 | workswarm.panel.js；/teams/{id}/steer | S；未运行取消/恢复 |
| 产物与评审 | 产物版本、评审状态、变更/diff、交付清单 | workswarm/render*.js；artifact_review_api.rs | S；缺实际产物截图 |
| 人工待办 | 人工结果、待评审产物、失败步骤、写入权 | action-center.panel.js；团队/项目/产物 API | U 11 无待办；不表示无能力 |
| 项目历史 | 运行、交付与待办聚合，复跑入口 | project-history.panel.js | S；未复跑 |
| 自动化 | 间隔/每日/单次、提醒/任务、开关、执行记录 | automations.panel.js；/automations | U 04/06 空列表；未调度执行 |
| 操作学习 | 录制/暂停/恢复/结束、技能信息 | app-domain.js；/learn/* | U 04；未录制/执行 |
| 桌面操作任务 | 目标应用、动作范围、时长、任务级审批 | app-domain.js；/computer-use/task | S；不等于通用桌面自治 |
| 工作流 | .owflow 列表、校验、运行、审批/审计 | workflow.panel.js；workflow_api.rs | U 15 无文件；未校验或运行 |
| Goal/Plan | 目标、计划编辑、状态/审计/云端进度入口 | goal.panel.js；goal_api/handlers.rs | S；“云端”文案不证明跨机可用 |
| 笔记 | 标题、Markdown、块树、搜索、编辑、导出 | notes.panel.js；notes_api/handlers.rs | S；本次未编辑 |
| 技能/插件/MCP | 能力扩展、连接、市场目录和安装/评审入口 | plugin-market.panel.js；mcp_api.rs；plugin_market_api.rs | U 05 配置页；未联网或安装 |
| 团队技能共享 | 导出、base64 导入/评审、版本和审计 | team.panel.js；team_api.rs | S；不等于协作账号系统 |
| 记忆图谱 | 查询、时间线、实体共现、关系、观察到技能 | memory.panel.js；memory_graph_api.rs | U 12；未检索/挖掘；实验能力 |
| 用量/预算/可观测性 | Tokens、成本/预算、指标、SLO/诊断 | app.js；observability.panel.js；/usage、/metrics/* | S；不可把估算/缺失用量当真实成本 |
| 单/团队对比 | 参考回放和真实模型两种模式、任务集与检查器 | product-comparison.panel.js；/product-eval/runs | U 14 参考回放默认；未执行 |
| Fleet | 控制面与节点状态入口 | fleet.panel.js | S；实验能力，未跨机验收 |
| 能力目录 | 成熟度和入口 | capabilities.panel.js；capabilities.rs | U 13：Stable 0、Beta 5、Experimental 2 |
| 桌宠 | 第二窗口、皮肤/状态、审批/停止入口 | pet/*；main.js；/activity、/desktop/pet | S；U 24 未看到角色；勿用黄色悬浮角色作证 |
| 外观/快捷键 | 浅深色、紧凑模式、设置分类 | style.css；app.js | U 19/20 两种主题；未做全尺寸验收 |

## 重点事实
- 能力目录登记仅 7 项，未覆盖全部页面；“共 7 项”不能解释成整个项目仅 7 项，也不能反向把所有其它页面标 Stable。
- 本次现有会话回复中的自我介绍属于模型生成文本，不能作为架构证据。
- 既有 custom-model 冒烟证明脚本端点选择、真实只读文件工具、终止记录和审计；不证明当前用户云端服务可用、完整团队交付或发布验收。
- 当前权限矩阵可见 workspace 为“工作区内读写”，与旧说明快照存在口径差异。需要对照当前策略实现再审查，不能机械沿用旧只读结论。本次没有改变档位。
