use crate::OWO_API_VERSION;
use axum::Json;
use serde_json::Value;

pub(crate) async fn openapi_spec() -> Json<Value> {
    Json(serde_json::json!({
        "openapi": "3.1.0",
        "info": { "title": "OwO Agent SDK API", "version": env!("CARGO_PKG_VERSION") },
        // R10 契约治理：API 版本号（破坏性变更递增 minor；弃用期 ≥2 minor）。
        "x-owo-api-version": OWO_API_VERSION,
        "servers": [{ "url": "http://127.0.0.1:4096" }],
        "paths": {
            "/health": { "get": { "operationId": "health", "responses": { "200": { "description": "service health + build info", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/HealthResponse" } } } } } } },
            "/usage": { "get": { "operationId": "usageSummary", "responses": { "200": { "description": "model token usage snapshot and budget config" } } } },
            "/audit": { "get": { "operationId": "auditList", "parameters": [{ "name": "limit", "in": "query", "required": false, "schema": { "type": "integer" } }], "responses": { "200": { "description": "recent audit entries" } } } },
            "/session": { "post": {
                "operationId": "createSession",
                "requestBody": { "content": { "application/json": { "schema": { "$ref": "#/components/schemas/CreateSessionRequest" } } } },
                "responses": { "200": { "description": "session created", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/SessionInfo" } } } } }
            } },
            "/session/{id}": { "get": { "operationId": "getSession", "parameters": [path_param("id")], "responses": { "200": { "description": "session detail with durable host facts", "content": {"application/json": {"schema": {"$ref": "#/components/schemas/SessionDetail"}}} } } }, "delete": { "operationId": "deleteSession", "parameters": [path_param("id")], "responses": { "200": { "description": "session deleted (store + memory cache)" }, "404": { "description": "session not found" } } } },
            "/session/{id}/turn": { "post": {
                "operationId": "agentTurn",
                "parameters": [{ "name": "id", "in": "path", "required": true, "schema": { "type": "string" } }],
                "requestBody": { "content": { "application/json": { "schema": { "$ref": "#/components/schemas/TurnRequest" } } } },
                "responses": { "200": { "description": "SSE event stream", "headers": { "x-owo-turn-id": { "description": "Stable turn identifier used with the durable replay endpoint", "schema": { "type": "string" } } } } }
            } },
            "/session/{id}/turn/events": { "get": {
                "operationId": "turnEventsAfter",
                "parameters": [path_param("id"), { "name": "turn_id", "in": "query", "required": true, "schema": { "type": "string" } }, { "name": "after_seq", "in": "query", "required": false, "schema": { "type": "integer", "format": "int64", "minimum": 0 } }, { "name": "limit", "in": "query", "required": false, "schema": { "type": "integer", "minimum": 1, "maximum": 1000 } }],
                "responses": { "200": { "description": "Persisted turn events after the session-scoped sequence cursor", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/TurnEventReplayPage" } } } }, "404": { "description": "session not found" } }
            } },
            "/session/{id}/attachments": { "get": { "operationId": "attachmentsList", "parameters": [path_param("id")], "responses": { "200": { "description": "attachment list" } } }, "post": { "operationId": "attachmentUpload", "parameters": [path_param("id")], "responses": { "200": { "description": "uploaded attachment" } } } },
            "/session/{id}/abort": { "post": { "operationId": "abortTurn", "parameters": [path_param("id")], "responses": {"200": {"description": "Cancellation request state, not proof of process termination", "content": {"application/json": {"schema": {"type": "object", "required": ["ok", "state"], "properties": {"ok": {"type": "boolean"}, "turn_id": {"type": "string", "nullable": true}, "state": {"type": "string", "enum": ["cancellation_requested", "cancellation_queued", "no_active_turn", "already_finished"]}}}}}}, "400": {"description": "Invalid cancellation request or turn UUID"}, "413": {"description": "Cancellation body exceeds 4096 bytes"}, "503": {"description": "Pending cancellation capacity reached"}}, "requestBody": {"required": false, "content": {"application/json": {"schema": {"type": "object", "properties": {"turn_id": {"type": "string", "format": "uuid", "description": "Cancel only this turn. Omitted for legacy current-session cancellation."}}}}}} } },
            "/session/{id}/permission/{request_id}": { "post": { "operationId": "respondPermission", "parameters": [path_param("id"), path_param("request_id")], "responses": {"200": {"description": "Decision delivered; granted describes actual reusable grant creation", "content": {"application/json": {"schema": {"type": "object", "required": ["ok", "allowed", "granted"], "properties": {"ok": {"type": "boolean"}, "allowed": {"type": "boolean"}, "granted": {"type": "boolean"}}}}}}, "404": {"description": "Request missing or belongs to another session"}, "410": {"description": "Approval response channel closed; no reusable grant created"}}, "requestBody": {"required": true, "content": {"application/json": {"schema": {"type": "object", "required": ["allow"], "properties": {"allow": {"type": "boolean"}, "remember": {"type": "boolean", "nullable": true, "description": "Legacy compatibility field"}, "scope": {"type": "string", "nullable": true, "description": "Reusable scope applies only to eligible read operations; write and execution approval applies once."}}}}}} } },
            "/session/{id}/diff": { "get": { "operationId": "sessionDiff", "parameters": [path_param("id")], "responses": { "200": { "description": "diff list" } } } },
            "/session/{id}/revert": { "post": { "operationId": "sessionRevert", "parameters": [path_param("id")], "requestBody": { "required": false, "content": { "application/json": { "schema": { "type": "object", "properties": { "receipt_id": { "type": "string", "description": "可选执行收据 ID；省略时使用最近一张未撤销收据" } } } } } }, "responses": { "200": { "description": "ok" }, "409": { "description": "撤销冲突：目标文件内容不再匹配 Agent 最近一次写入，整批零覆盖；错误码 storage/revert_conflict/not_retryable" } } } },
            "/session/{id}/fork": { "post": { "operationId": "sessionFork", "parameters": [path_param("id")], "responses": { "200": { "description": "forked session" } } } },
            "/session/{id}/rewind": { "post": { "operationId": "sessionRewind", "parameters": [path_param("id")], "responses": { "200": { "description": "ok" } } } },
            "/session/{id}/redo": { "post": { "operationId": "sessionRedo", "parameters": [path_param("id")], "responses": { "200": { "description": "ok" } } } },
            "/session/{id}/rename": { "post": { "operationId": "sessionRename", "parameters": [path_param("id")], "responses": { "200": { "description": "renamed session" } } } },
            "/session/{id}/archive": { "post": { "operationId": "sessionArchive", "parameters": [path_param("id")], "responses": { "200": { "description": "archive state" } } } },
            "/session/{id}/pin": { "post": { "operationId": "sessionPin", "parameters": [path_param("id")], "responses": { "200": { "description": "pin state" } } } },
            "/session/{id}/model": { "post": { "operationId": "sessionSetModel", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "model": { "type": "string", "nullable": true, "description": "非空=固定请求模型；null/空串/\"default\"=清除覆盖（回退 OPENAI_MODEL→启动配置→内置默认；哨兵不落库、不进请求体）" } } } } } }, "responses": { "200": { "description": "{ id, model, model_override }" }, "404": { "description": "session not found" } } } },
            "/session/{id}/children": { "get": { "operationId": "sessionChildren", "parameters": [path_param("id")], "responses": { "200": { "description": "children" } } } },
            "/session/{id}/export/{format}": { "get": { "operationId": "exportSession", "parameters": [path_param("id"), path_param("format")], "responses": { "200": { "description": "md or html" } } } },
            "/sessions": { "get": { "operationId": "listSessions", "responses": { "200": { "description": "session list" } } } },
            "/skills": { "get": { "operationId": "listSkills", "responses": { "200": { "description": "skill list" } } } },
            "/skills/{name}": { "get": { "operationId": "skillDetail", "parameters": [path_param("name")], "responses": { "200": { "description": "skill detail with SKILL.md content" } } }, "post": { "operationId": "skillEdit", "parameters": [path_param("name")], "responses": { "200": { "description": "updated" } } } },
            "/skills/{name}/enabled": { "post": { "operationId": "skillEnabled", "parameters": [path_param("name")], "responses": { "200": { "description": "enabled state" } } } },
            "/eval/run": { "post": { "operationId": "runEval", "requestBody": { "content": { "application/json": { "schema": { "$ref": "#/components/schemas/EvalRunRequest" } } } }, "responses": { "200": { "description": "eval report" } } } },
            "/product-eval/runs": {
                "post": {
                    "operationId": "createProductEvalRun",
                    "summary": "受理一次产品评测矩阵（异步执行）",
                    "requestBody": { "required": true, "content": { "application/json": { "schema": { "type": "object", "required": ["suite", "execution", "modes", "repetitions"], "properties": {
                        "suite": { "type": "string", "enum": ["v1"], "description": "仅允许注册名 v1；客户端本地路径一律拒绝" },
                        "execution": { "type": "string", "enum": ["reference", "live"], "description": "reference=免模型参考回放+检查器；live=真实执行器（single→SingleAgentExecutor，workswarm→WorkSwarmExecutor）" },
                        "modes": { "type": "array", "items": { "type": "string", "enum": ["single", "workswarm"] }, "minItems": 1, "description": "对照拓扑子集；结果报告 wire 中 agent_mode 为核心小写词 single/multi（workswarm ≡ multi）" },
                        "repetitions": { "type": "integer", "minimum": 1, "maximum": 20, "description": "重复次数（覆盖 suite 默认）" },
                        "category": { "type": ["string", "null"], "enum": ["code", "research", "document", null], "description": "只跑指定分类" },
                        "only": { "type": ["string", "null"], "description": "只跑 id 包含该子串的任务" }
                    } } } } },
                    "responses": {
                        "202": { "description": "受理", "content": { "application/json": { "schema": { "type": "object", "required": ["run_id", "status"], "properties": { "run_id": { "type": "string", "description": "eval-…" }, "status": { "type": "string", "enum": ["queued"] } } } } } },
                        "400": { "description": "语义校验失败（未知 suite/execution/mode、repetitions 越界、suite 加载失败、过滤后无任务）", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Error" } } } },
                        "409": { "description": "已有评测矩阵运行或收尾中；为保证 Single/Team 测量隔离而拒绝并发运行", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Error" } } } },
                        "422": { "description": "结构校验失败（缺字段/类型错）", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Error" } } } }
                    }
                },
                "get": {
                    "operationId": "listProductEvalRuns",
                    "summary": "评测运行列表（created_at 倒序）",
                    "responses": { "200": { "description": "runs", "content": { "application/json": { "schema": { "type": "object", "properties": { "runs": { "type": "array", "items": { "$ref": "#/components/schemas/ProductEvalRunSummary" } } } } } } } }
                }
            },
            "/product-eval/runs/{id}": {
                "get": {
                    "operationId": "getProductEvalRun",
                    "summary": "评测运行详情：进度 + 运行参数 + 完整报告（聚合指标/每 case 对比/失败步骤/Artifact refs）",
                    "parameters": [path_param("id")],
                    "responses": {
                        "200": { "description": "run summary + report", "content": { "application/json": { "schema": { "allOf": [
                            { "$ref": "#/components/schemas/ProductEvalRunSummary" },
                            { "type": "object", "properties": { "report": { "oneOf": [
                                { "type": "null", "description": "尚无报告（未开始执行/工厂失败/损坏）" },
                                { "$ref": "#/components/schemas/ProductEvalReport" }
                            ] } } }
                        ] } } } },
                        "404": { "description": "运行不存在", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Error" } } } }
                    }
                }
            },
            "/product-eval/runs/{id}/cancel": {
                "post": {
                    "operationId": "cancelProductEvalRun",
                    "summary": "取消评测运行（幂等：置协作令牌并立即 cancelled；重复/终态后取消零副作用）",
                    "parameters": [path_param("id")],
                    "responses": {
                        "200": { "description": "取消受理或原状态", "content": { "application/json": { "schema": { "type": "object", "required": ["run_id", "status"], "properties": { "run_id": { "type": "string" }, "status": { "type": "string", "enum": ["queued", "running", "cancelled", "completed", "failed", "interrupted"] } } } } } },
                        "404": { "description": "运行不存在", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Error" } } } }
                    }
                }
            },
            "/context/snapshot": { "get": { "operationId": "contextSnapshot", "responses": { "200": { "description": "situation snapshot" } } } },
            "/perception/events": { "get": { "operationId": "perceptionSubscribe", "responses": { "200": { "description": "SSE perception event stream" } } } },
            "/perception/capture": { "post": { "operationId": "perceptionCapture", "responses": { "200": { "description": "capture meta with OCR summary" } } } },
            "/perception/layers": { "post": { "operationId": "perceptionLayers", "responses": { "200": { "description": "layer authorization updated" } } } },
            "/perception/tree": { "post": { "operationId": "perceptionTree", "responses": { "200": { "description": "deep UI tree dump" } } } },
            "/perception/ocr": { "post": { "operationId": "perceptionOcr", "responses": { "200": { "description": "OCR text with bounding boxes" } } } },
            "/perception/ocr/status": { "get": { "operationId": "ocrStatus", "responses": { "200": { "description": "OCR engine diagnostics" } } } },
            "/perception/ocr/region": { "post": { "operationId": "perceptionOcrRegion", "responses": { "200": { "description": "region OCR text with bounding boxes" } } } },
            "/learn/record": { "post": { "operationId": "learnRecord", "responses": { "200": { "description": "learn state" } } } },
            "/learn/start": { "post": { "operationId": "learnStart", "responses": { "200": { "description": "learn state" } } } },
            "/learn/pause": { "post": { "operationId": "learnPause", "responses": { "200": { "description": "learn state" } } } },
            "/learn/resume": { "post": { "operationId": "learnResume", "responses": { "200": { "description": "learn state" } } } },
            "/learn/stop": { "post": { "operationId": "learnStop", "responses": { "200": { "description": "stopped with sample count" } } } },
            "/learn/clear": { "post": { "operationId": "learnClear", "responses": { "200": { "description": "ok" } } } },
            "/learn/execute": { "post": { "operationId": "learnExecute", "responses": { "200": { "description": "execution report" } } } },
            "/learn/packages": { "get": { "operationId": "learnPackages", "responses": { "200": { "description": "flow skill packages" } } } },
            "/learn/packages/{name}": { "get": { "operationId": "learnPackageDetail", "parameters": [path_param("name")], "responses": { "200": { "description": "package detail" } } }, "delete": { "operationId": "learnPackageDelete", "parameters": [path_param("name")], "responses": { "200": { "description": "deleted" } } } },
            "/learn/sink": { "post": { "operationId": "learnSink", "responses": { "200": { "description": "sunk package" } } } },
            "/learn/execute-package": { "post": { "operationId": "learnExecutePackage", "responses": { "200": { "description": "execution report" } } } },
            "/learn/export/{name}": { "get": { "operationId": "learnExport", "parameters": [path_param("name")], "responses": { "200": { "description": "owskill zip" } } } },
            "/learn/import": { "post": { "operationId": "learnImport", "responses": { "200": { "description": "imported package" } } } },
            "/skill/verify": { "post": { "operationId": "skillVerify", "responses": { "200": { "description": "validation result" } } } },
            "/proactive/observe": { "post": { "operationId": "proactiveObserve", "responses": { "200": { "description": "optional suggestion" } } } },
            "/proactive/decide": { "post": { "operationId": "proactiveDecide", "responses": { "200": { "description": "ok" } } } },
            "/proactive/suggestions": { "get": { "operationId": "proactiveSuggestions", "responses": { "200": { "description": "suggestion list" } } } },
            "/stt/transcribe": { "post": { "operationId": "sttTranscribe", "responses": { "200": { "description": "transcription text" } } } },
            "/automations": { "get": { "operationId": "automationsList", "responses": { "200": { "description": "automation tasks" } } }, "post": { "operationId": "automationsCreate", "responses": { "200": { "description": "created task" } } } },
            "/automations/{id}/toggle": { "post": { "operationId": "automationsToggle", "parameters": [path_param("id")], "responses": { "200": { "description": "enabled state" } } } },
            "/automations/{id}": { "delete": { "operationId": "automationsDelete", "parameters": [path_param("id")], "responses": { "200": { "description": "ok" } } } },
            "/automations/runs": { "get": { "operationId": "automationsRuns", "responses": { "200": { "description": "recent automation run records (task_id/limit query)" } } } },
            "/activity": { "get": { "operationId": "activityList", "responses": { "200": { "description": "active turns snapshot (session/phase/tool) + pending approval count" } } } },
            "/desktop/model-credentials": {"post": {"operationId": "desktopModelCredentialBind", "description": "Paired desktop owner only. Publishes or revokes a restricted, endpoint-bound environment reference; never returns a secret.", "requestBody": {"required": true, "content": {"application/json": {"schema": {"$ref": "#/components/schemas/DesktopModelCredentialBinding"}}}}, "responses": {"200": {"description": "Reference updated"}, "400": {"description": "Invalid credential binding"}, "403": {"description": "Paired desktop proof required"}}}},
            "/desktop/pet": { "get": { "operationId": "petStateGet", "responses": { "200": { "description": "desktop pet visibility (desired/actual/overlay_online)" } } }, "post": { "operationId": "petStateSet", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "visible": { "type": "boolean" } }, "required": ["visible"] } } } }, "responses": { "200": { "description": "desired pet visibility updated" } } } },
            "/desktop/pet/report": { "post": { "operationId": "petStateReport", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "visible": { "type": "boolean" } }, "required": ["visible"] } } } }, "responses": { "200": { "description": "overlay heartbeat accepted; returns desired visibility" } } } },
            "/approvals/pending": { "get": { "operationId": "pendingApprovalsList", "responses": { "200": { "description": "cross-session pending approval requests" } } } },
            "/session/{id}/answer/{question_id}": { "post": { "operationId": "respondQuestion", "parameters": [path_param("id"), path_param("question_id")], "responses": { "200": { "description": "ok" } } } },
            "/fs/pick-directory": { "post": { "operationId": "fsPickDirectory", "requestBody": { "content": { "application/json": { "schema": { "type": "object" } } } }, "responses": { "200": { "description": "selected absolute directory path (null when cancelled)" } } } },
            "/fs/open": { "post": { "operationId": "fsOpenPath", "requestBody": { "content": { "application/json": { "schema": { "type": "object" } } } }, "responses": { "200": { "description": "opened the workspace path with the requested opener (opener = program actually used)" } } } },
            "/automations/reminders": { "get": { "operationId": "automationsReminders", "responses": { "200": { "description": "pending reminders" } } } },
            "/automations/reminders/clear": { "post": { "operationId": "automationsClearReminders", "responses": { "200": { "description": "ok" } } } },
            "/settings": { "get": { "operationId": "settingsGet", "responses": { "200": { "description": "workspace settings" } } }, "post": { "operationId": "settingsUpdate", "responses": { "200": { "description": "workspace settings" } } } },
            "/settings/egress": { "post": { "operationId": "settingsEgress", "responses": { "200": { "description": "cloud enabled state" } } } },
            "/settings/provider-test": { "post": { "operationId": "settingsProviderTest", "responses": { "200": { "description": "provider self-diagnosis (R3 §3.4): stable code provider/not_configured|endpoint_reachable|endpoint_unreachable + masked endpoint; no secrets, no model calls (TCP probe only)" } } } },
            "/permissions": { "get": { "operationId": "permissionsStatus", "responses": { "200": { "description": "当前权限档位 + 授权记忆（脱敏）" } } }, "post": { "operationId": "permissionsSetProfile", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "profile": { "type": "string", "enum": ["read_only", "workspace", "auto_review", "full_access", "custom"] } }, "required": ["profile"] } } } }, "responses": { "200": { "description": "profile 已切换" } } } },
            "/permissions/grants": { "get": { "operationId": "grantsList", "responses": { "200": { "description": "授权记忆列表（脱敏）" } } } },
            "/permissions/grants/revoke": { "post": { "operationId": "grantsRevoke", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "grant_id": { "type": "string" }, "tool_id": { "type": "string" }, "all": { "type": "boolean" } } } } } }, "responses": { "200": { "description": "授权记忆已撤销（grant/tool/workspace 三种粒度，返回条数）" } } } },
            "/permissions/overview": { "get": { "operationId": "permissionsOverview", "responses": { "200": { "description": "§4.5 权限中心总览：档位 + 结构化 spec + 四维生效判定 + 全局待审批 + 授权记忆 + 近期决定（服务端展开，前端不自行推导范围）" } } } },
            "/permissions/spec": { "post": { "operationId": "permissionsSetSpec", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "spec": permission_spec_schema(), "confirm": { "type": "boolean" }, "duration_secs": { "type": "integer" } }, "required": ["spec"] } } } }, "responses": { "200": { "description": "结构化配置已写入并即时生效（只收紧；完全访问需 confirm + 时长）" }, "400": { "description": "validation/failed | confirmation/required | conflict/read_only" } } } },
            "/whitelist": { "get": { "operationId": "whitelistList", "responses": { "200": { "description": "whitelist entries" } } } },
            "/session/{id}/context": { "get": { "operationId": "sessionContext", "parameters": [path_param("id")], "responses": { "200": { "description": "context stats: messages/tokens/budget/compaction/rules" } } } },
    "/session/{id}/compact": { "post": { "operationId": "compactSession", "parameters": [path_param("id")], "responses": { "200": { "description": "compaction result: compacted/summary/tokens_before/tokens_after" } } } },
            "/skills/health": { "get": { "operationId": "skillsHealth", "responses": { "200": { "description": "flow skill health overview" } } } },
            "/skills/health/{name}/reset": { "post": { "operationId": "skillHealthReset", "parameters": [path_param("name")], "responses": { "200": { "description": "health reset" } } } },
            "/plugins": { "get": { "operationId": "pluginsList", "responses": { "200": { "description": "discovered plugins with manifests" } } } },
            "/plugins/{id}/enabled": { "post": { "operationId": "pluginEnabled", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "enabled": { "type": "boolean" } }, "required": ["enabled"] } } } }, "responses": { "200": { "description": "plugin enabled state" } } } },
            "/subagent/run": { "post": { "operationId": "subagentRun", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "prompt": { "type": "string" }, "read_only": { "type": "boolean" }, "model": { "type": "string" } }, "required": ["prompt"] } } } }, "responses": { "200": { "description": "subagent execution result" } } } },
            "/project/rules": { "get": { "operationId": "projectRulesGet", "responses": { "200": { "description": "AGENTS.md/CLAUDE.md rules with injection status" } } }, "post": { "operationId": "projectRulesPost", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "content": { "type": "string" } }, "required": ["content"] } } } }, "responses": { "200": { "description": "rules written" } } } },
            "/project/rules/template": { "post": { "operationId": "projectRulesTemplate", "responses": { "200": { "description": "AGENTS.md template written" } } } },
            "/mcp": { "get": { "operationId": "mcpList", "responses": { "200": { "description": "configured MCP servers" } } } },
            "/mcp/add": { "post": { "operationId": "mcpAdd", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "name": { "type": "string" }, "transport": { "type": "string", "enum": ["stdio", "http"] }, "command": { "type": "string" }, "args": { "type": "array", "items": { "type": "string" } }, "url": { "type": "string" } }, "required": ["name", "transport"] } } } }, "responses": { "200": { "description": "server added and connected" } } } },
            "/mcp/remove": { "post": { "operationId": "mcpRemove", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "name": { "type": "string" } }, "required": ["name"] } } } }, "responses": { "200": { "description": "server removed" } } } },
            "/mcp/health": { "get": { "operationId": "mcpHealthSnapshot", "responses": { "200": { "description": "per-server MCP health (state machine, circuit breaker, failure counters)" } } } },
            "/mcp/reconnect": { "post": { "operationId": "mcpReconnect", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "name": { "type": "string" } }, "required": ["name"] } } } }, "responses": { "200": { "description": "server reconnected from saved config (process-level uninstall + hot connect)" } } } },
            "/mcp/enabled": { "post": { "operationId": "mcpEnabled", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "name": { "type": "string" }, "enabled": { "type": "boolean" } }, "required": ["name", "enabled"] } } } }, "responses": { "200": { "description": "tool prefix enable/disable (process-level, model-invisible, not persisted)" } } } },
            "/capabilities": { "get": { "operationId": "capabilitiesList", "responses": { "200": { "description": "capability catalog (single source for UI/CLI/diagnostics/help, §8.3)" } } } },
            "/locate/query": { "post": { "operationId": "locateQuery", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "app_id": { "type": "string" }, "role": { "type": "string" }, "name_pattern": { "type": "string" }, "parent": { "type": "string" }, "stable_id": { "type": "string" }, "min_confidence": { "type": "number" } }, "required": [] } } } }, "responses": { "200": { "description": "multi-source locate result" } } } },
            "/traces": { "get": { "operationId": "tracesList", "responses": { "200": { "description": "trace list" } } } },
            "/traces/{index}": { "get": { "operationId": "traceShow", "parameters": [path_param("index")], "responses": { "200": { "description": "trace detail" } } } },
            "/memory/observations": { "get": { "operationId": "memoryObservations", "responses": { "200": { "description": "situation memory observations" } } } },
            "/memory/recall": { "get": { "operationId": "memoryRecall", "responses": { "200": { "description": "semantic memory recall" } } } },
            "/memory/clear": { "post": { "operationId": "memoryClear", "responses": { "200": { "description": "memory cleared" } } } },
            "/memory/mine-skill": { "post": { "operationId": "memoryMineSkill", "responses": { "200": { "description": "mined flow skill package" } } } },
            "/whitelist/manage": { "post": { "operationId": "whitelistManage", "responses": { "200": { "description": "whitelist entries" } } } },
            "/computer-use/tasks": { "get": { "operationId": "computerTasksList", "responses": { "200": { "description": "computer-use task list" } } } },
            "/computer-use/task": { "post": { "operationId": "computerTaskCreate", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "target_app": { "type": "string" }, "description": { "type": "string" }, "allowed_actions": { "type": "array", "items": { "type": "string" } }, "max_duration_ms": { "type": "integer" } }, "required": ["target_app"] } } } }, "responses": { "200": { "description": "task created (Pending)" } } } },
            "/computer-use/task/{id}/{action}": { "post": { "operationId": "computerTaskTransition", "parameters": [path_param("id"), path_param("action")], "responses": { "200": { "description": "task state transitioned" } } } },
            "/computer-use/task/{id}/check/{action}": { "get": { "operationId": "computerTaskCheck", "parameters": [path_param("id"), path_param("action")], "responses": { "200": { "description": "task executable check" } } } },
            "/computer-use/sensitive-check": { "post": { "operationId": "computerSensitiveCheck", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "name": { "type": "string" }, "role": { "type": "string" }, "ocr_text": { "type": "string" } }, "required": ["name"] } } } }, "responses": { "200": { "description": "sensitive ui detection" } } } },
            "/computer-use/task/{id}/run": { "post": { "operationId": "computerTaskRun", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "goals": { "type": "array", "items": { "type": "object", "properties": { "anchor_text": { "type": "string" }, "action": { "type": "string" }, "value": { "type": "string" }, "verify_text": { "type": "string" } } } } } } } } }, "responses": { "200": { "description": "approved task executed (closed loop)" } } } },
            "/cloud/tasks": { "post": { "operationId": "cloudTaskSubmit", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "name": { "type": "string" }, "workspace_dir": { "type": "string" }, "commands": { "type": "array", "items": { "type": "string" } }, "env_passthrough": { "type": "array", "items": { "type": "string" } }, "timeout_secs": { "type": "integer" } } } } } }, "responses": { "200": { "description": "cloud task durably queued; task_id is returned before background execution" } } } },
            "/cloud/tasks/{id}": { "get": { "operationId": "cloudTaskStatus", "parameters": [path_param("id")], "responses": { "200": { "description": "cloud task status + usage" } } } },
            "/cloud/tasks/{id}/result": { "get": { "operationId": "cloudTaskResult", "parameters": [path_param("id")], "responses": { "200": { "description": "cloud task result + diff summary" } } } },
            "/cloud/tasks/{id}/cancel": { "post": { "operationId": "cloudTaskCancel", "parameters": [path_param("id")], "responses": { "200": { "description": "cancellation accepted; active tasks report cancel_requested until the runner persists Canceled" } } } },
            "/openapi.json": { "get": { "operationId": "openapiSpec", "responses": { "200": { "description": "OpenAPI 3.1 spec" } } } },
            "/perception/elements": { "post": { "operationId": "perceptionElements", "responses": { "200": { "description": "element registry snapshot" } } } },
            "/perception/ocr/bytes": { "post": { "operationId": "perceptionOcrBytes", "responses": { "200": { "description": "OCR text from raw image bytes" } } } },
            "/perception/window": { "post": { "operationId": "perceptionWindow", "responses": { "200": { "description": "active window info" } } } },
            "/perception/template/build": { "post": { "operationId": "perceptionTemplateBuild", "responses": { "200": { "description": "window template built" } } } },
            "/perception/template/build-ocr": { "post": { "operationId": "perceptionTemplateBuildOcr", "responses": { "200": { "description": "window template built with OCR" } } } },
            "/perception/template/detect": { "post": { "operationId": "perceptionTemplateDetect", "responses": { "200": { "description": "template detection result" } } } },
            "/perception/template/detect-ocr": { "post": { "operationId": "perceptionTemplateDetectOcr", "responses": { "200": { "description": "template detection with OCR" } } } },
            "/perception/template/{app_id}": { "get": { "operationId": "perceptionTemplateGet", "parameters": [path_param("app_id")], "responses": { "200": { "description": "stored window template" } } } },
            "/learn/status": { "get": { "operationId": "learnStatus", "responses": { "200": { "description": "learn pipeline state" } } } },
            "/desktop/foreground": { "get": { "operationId": "desktopForeground", "responses": { "200": { "description": "foreground window info" } } } },
            "/desktop/windows": { "get": { "operationId": "desktopWindows", "responses": { "200": { "description": "window list" } } } },
            "/desktop/activate": { "post": { "operationId": "desktopActivate", "responses": { "200": { "description": "window activated" } } } },
            "/desktop/click": { "post": { "operationId": "desktopClick", "responses": { "200": { "description": "mouse click performed" } } } },
            "/desktop/type": { "post": { "operationId": "desktopType", "responses": { "200": { "description": "text typed" } } } },
            "/desktop/key": { "post": { "operationId": "desktopKey", "responses": { "200": { "description": "key pressed" } } } },
            "/desktop/shortcut": { "post": { "operationId": "desktopShortcut", "responses": { "200": { "description": "shortcut performed" } } } },
            "/desktop/launch": { "post": { "operationId": "desktopLaunch", "responses": { "200": { "description": "app launched" } } } },
            "/desktop/scroll": { "post": { "operationId": "desktopScroll", "responses": { "200": { "description": "scroll performed" } } } },
            "/desktop/wait": { "post": { "operationId": "desktopWait", "responses": { "200": { "description": "wait performed" } } } },
            "/vision/status": { "get": { "operationId": "visionStatus", "responses": { "200": { "description": "vision engine diagnostics" } } } },
            "/vision/describe": { "post": { "operationId": "visionDescribe", "responses": { "200": { "description": "image description" } } } },
            "/vision/verify": { "post": { "operationId": "visionVerify", "responses": { "200": { "description": "verification result" } } } },
            "/vision/ground": { "post": { "operationId": "visionGround", "responses": { "200": { "description": "vision grounded location" } } } },
            "/notes": { "get": { "operationId": "notesList", "responses": { "200": { "description": "note list" } } }, "post": { "operationId": "notesCreate", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "title": { "type": "string" }, "markdown": { "type": "string" } }, "required": ["title"] } } } }, "responses": { "201": { "description": "note created" } } } },
            "/notes/{id}": { "get": { "operationId": "notesGet", "parameters": [path_param("id")], "responses": { "200": { "description": "note block tree" } } }, "put": { "operationId": "notesReplace", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "title": { "type": "string" }, "blocks": { "type": "array", "items": { "type": "object" } } } } } } }, "responses": { "200": { "description": "note replaced" } } }, "delete": { "operationId": "notesDelete", "parameters": [path_param("id")], "responses": { "200": { "description": "note deleted" } } } },
            "/notes/import": { "post": { "operationId": "notesImport", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "title": { "type": "string" }, "markdown": { "type": "string" } }, "required": ["title", "markdown"] } } } }, "responses": { "201": { "description": "note imported from markdown" } } } },
            "/notes/search": { "get": { "operationId": "notesSearch", "parameters": [{ "name": "q", "in": "query", "required": true, "schema": { "type": "string" } }], "responses": { "200": { "description": "cross-document search hits" } } } },
            "/notes/{id}/export/{format}": { "get": { "operationId": "notesExport", "parameters": [path_param("id"), path_param("format")], "responses": { "200": { "description": "note exported as md or html" } } } },
            "/notes/{id}/blocks": { "post": { "operationId": "notesAddBlock", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "parent": { "type": "string" }, "after": { "type": "string" }, "kind": { "type": "string" }, "text": { "type": "string" }, "data": { "type": "object" } }, "required": ["kind"] } } } }, "responses": { "201": { "description": "block added" } } } },
            "/notes/{id}/blocks/move": { "post": { "operationId": "notesMoveBlock", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "block_id": { "type": "string" }, "parent": { "type": "string" }, "after": { "type": "string" } }, "required": ["block_id"] } } } }, "responses": { "200": { "description": "block moved" } } } },
            "/notes/{id}/blocks/{block_id}": { "patch": { "operationId": "notesUpdateBlock", "parameters": [path_param("id"), path_param("block_id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "text": { "type": "string" }, "data": { "type": "object" } } } } } }, "responses": { "200": { "description": "block updated" } } }, "delete": { "operationId": "notesDeleteBlock", "parameters": [path_param("id"), path_param("block_id")], "responses": { "200": { "description": "removed block subtree ids" } } } },
            "/notes/{id}/reindex": { "post": { "operationId": "notesReindex", "parameters": [path_param("id")], "responses": { "200": { "description": "full-text index rebuilt" } } } },
            "/workflow": { "get": { "operationId": "workflowList", "responses": { "200": { "description": "discovered .owflow flows" } } } },
            "/workflow/validate": { "post": { "operationId": "workflowValidate", "requestBody": { "content": { "application/json": { "schema": { "type": "object" } } } }, "responses": { "200": { "description": "definition validation report" } } } },
            "/workflow/{name}": { "get": { "operationId": "workflowGet", "parameters": [path_param("name")], "responses": { "200": { "description": "flow definition with validation" } } } },
            "/workflow/{name}/run": { "post": { "operationId": "workflowRun", "parameters": [path_param("name")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "ctx": { "type": "object" } } } } } }, "responses": { "201": { "description": "workflow run started" } } } },
            "/workflow/{name}/runs": { "get": { "operationId": "workflowRuns", "parameters": [path_param("name")], "responses": { "200": { "description": "run list for flow" } } } },
            "/workflow/run/{run_id}": { "get": { "operationId": "workflowRunSnapshot", "parameters": [path_param("run_id")], "responses": { "200": { "description": "run snapshot" } } } },
            "/workflow/run/{run_id}/abort": { "post": { "operationId": "workflowRunAbort", "parameters": [path_param("run_id")], "responses": { "200": { "description": "abort requested" } } } },
            "/workflow/run/{run_id}/audit": { "get": { "operationId": "workflowRunAudit", "parameters": [path_param("run_id")], "responses": { "200": { "description": "run audit tail" } } } },
            "/goal": { "get": { "operationId": "goalList", "responses": { "200": { "description": "goal list" } } }, "post": { "operationId": "goalCreate", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "objective": { "type": "string" }, "budget": { "type": "object", "properties": { "max_steps": { "type": "integer" }, "max_replans": { "type": "integer" } } } }, "required": ["objective"] } } } }, "responses": { "201": { "description": "goal created" } } } },
            "/goal/{id}": { "get": { "operationId": "goalGet", "parameters": [path_param("id")], "responses": { "200": { "description": "goal detail" } } } },
            "/goal/{id}/plan": { "get": { "operationId": "goalPlanGet", "parameters": [path_param("id")], "responses": { "200": { "description": "goal plan" } } }, "post": { "operationId": "goalPlanCreate", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "steps": { "type": "array", "items": { "type": "object" } } }, "required": ["steps"] } } } }, "responses": { "201": { "description": "plan created with waves preview" } } } },
            "/goal/{id}/run": { "post": {
                "operationId": "goalRun",
                "parameters": [path_param("id")],
                "requestBody": { "content": { "application/json": { "schema": {
                    "type": "object",
                    "properties": {
                        "parallelism": { "type": "integer", "description": "wave 内并发执行步数上限" },
                        "allow_replan": { "type": "boolean" },
                        "execution": {
                            "type": "object",
                            "description": "执行路径选择；缺省 process。mode=worker_pool 必须提供非空 workers",
                            "properties": {
                                "mode": { "type": "string", "enum": ["process", "worker_pool"] },
                                "workers": {
                                    "type": "array",
                                    "description": "worker_pool 受控子进程配置（命令仅限当前可执行文件；env 白名单拒凭据键）",
                                    "items": {
                                        "type": "object",
                                        "required": ["name", "command", "cwd"],
                                        "properties": {
                                            "name": { "type": "string" },
                                            "command": { "type": "string" },
                                            "args": { "type": "array", "items": { "type": "string" } },
                                            "cwd": { "type": "string" },
                                            "env": { "type": "object", "additionalProperties": { "type": "string" } },
                                            "budget": { "type": "object", "properties": { "max_turns": { "type": "integer" }, "max_duration_secs": { "type": "integer" }, "max_memory_mb": { "type": "integer" }, "max_cpu_cores": { "type": "number" } } },
                                            "max_restarts": { "type": "integer" },
                                            "base_backoff_secs": { "type": "integer" }
                                        }
                                    }
                                },
                                "targets": {
                                    "type": "array",
                                    "description": "A2 显式执行目标绑定（按 worker 一个目标；显式绑定不可用即等待/询问/拒绝，不静默改派）",
                                    "items": {
                                        "type": "object",
                                        "required": ["worker", "target"],
                                        "properties": {
                                            "worker": { "type": "string", "description": "绑定键：计划步骤 id 或步骤声明的 worker 名（agent 只允许 in_process）" },
                                            "target": { "type": "string", "enum": ["in_process", "local_process", "fleet_node"] },
                                            "node_id": { "type": "string", "description": "fleet_node 必填；不允许隐式选节点" },
                                            "capabilities": { "type": "array", "items": { "type": "string" } },
                                            "permission_scope": {
                                                "type": "object",
                                                "description": "默认 deny：未列出的能力一律不授予；deny 优先于 allow",
                                                "properties": {
                                                    "allow": { "type": "array", "items": { "type": "string" } },
                                                    "deny": { "type": "array", "items": { "type": "string" } },
                                                    "network_egress": { "type": "boolean", "default": false }
                                                }
                                            },
                                            "budget": { "type": "object", "properties": { "max_attempts": { "type": "integer", "description": "对 plan 步骤 retries 取 min" }, "max_duration_secs": { "type": "integer", "description": "派发等待/池预算派生上限（0=不限）" } } },
                                            "input_cas_ref": { "type": "string" },
                                            "correlation_id": { "type": "string", "description": "缺省派生 <goal_id>/<run_id>/<worker>" }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } } } },
                "responses": {
                    "202": { "description": "run started" },
                    "400": { "description": "非法 execution/targets 配置（缺 workers、矛盾绑定、fleet_node 缺 node_id 等）" },
                    "404": { "description": "goal or plan not found" },
                    "422": { "description": "request body deserialization failed (unknown mode/target literal)" }
                }
            } },
            "/goal/{id}/status": { "get": { "operationId": "goalStatus", "parameters": [path_param("id")], "responses": { "200": { "description": "goal run state snapshot" } } } },
            "/goal/{id}/abort": { "post": { "operationId": "goalAbort", "parameters": [path_param("id")], "responses": { "200": { "description": "abort requested" } } } },
            "/goal/{id}/audit": { "get": { "operationId": "goalAudit", "parameters": [path_param("id")], "responses": { "200": { "description": "goal audit tail" } } } },
            "/goal/{id}/runs": { "get": { "operationId": "goalRuns", "parameters": [path_param("id")], "responses": { "200": { "description": "goal run list" } } } },
            "/cloud/tasks/{id}/events": { "get": { "operationId": "cloudTaskEvents", "parameters": [path_param("id")], "responses": { "200": { "description": "SSE progress stream for cloud task (requires Bearer)" }, "401": { "description": "missing or invalid bearer token" } } } },
            "/plugins/market": { "get": { "operationId": "pluginMarketCatalog", "responses": { "200": { "description": "plugin market catalog merged with local" } } } },
            "/plugins/market/seed": { "post": { "operationId": "pluginMarketSeed", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "entries": { "type": "array", "items": { "type": "object" } } }, "required": ["entries"] } } } }, "responses": { "200": { "description": "market seeded" } } } },
            "/plugins/market/versions": { "get": { "operationId": "pluginMarketVersions", "parameters": [{ "name": "id", "in": "query", "required": true, "schema": { "type": "string" } }, { "name": "app", "in": "query", "required": false, "schema": { "type": "string" } }], "responses": { "200": { "description": "compatible version resolution" } } } },
            "/plugins/market/verify": { "post": { "operationId": "pluginMarketVerify", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "dir": { "type": "string" } }, "required": ["dir"] } } } }, "responses": { "200": { "description": "plugin dir verified" } } } },
            "/plugins/market/install": { "post": { "operationId": "pluginMarketInstall", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "dir": { "type": "string" } }, "required": ["dir"] } } } }, "responses": { "200": { "description": "plugin installed" } } } },
            "/plugins/market/update": { "post": { "operationId": "pluginMarketUpdate", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "id": { "type": "string" }, "dir": { "type": "string" } }, "required": ["id", "dir"] } } } }, "responses": { "200": { "description": "plugin updated" } } } },
            "/plugins/market/uninstall": { "post": { "operationId": "pluginMarketUninstall", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "id": { "type": "string" } }, "required": ["id"] } } } }, "responses": { "200": { "description": "plugin uninstalled" } } } },
            "/plugins/market/scan": { "get": { "operationId": "pluginMarketScan", "parameters": [{ "name": "dir", "in": "query", "required": false, "schema": { "type": "string" } }], "responses": { "200": { "description": "risk scan summary" } } } },
            "/plugins/market/audit": { "get": { "operationId": "pluginMarketAudit", "parameters": [{ "name": "n", "in": "query", "required": false, "schema": { "type": "integer" } }], "responses": { "200": { "description": "plugin market audit tail" } } } },
            "/plugins/market/refresh": { "post": { "operationId": "pluginMarketRefresh", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "url": { "type": "string" } } } } } }, "responses": { "200": { "description": "market registry refreshed" } } } },
            "/plugins/market/install-remote": { "post": { "operationId": "pluginMarketInstallRemote", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "id": { "type": "string" }, "version": { "type": "string" }, "url": { "type": "string" } }, "required": ["id"] } } } }, "responses": { "200": { "description": "remote plugin signed and installed" } } } },
            "/team/export": { "post": { "operationId": "teamExport", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "type": { "type": "string" }, "id": { "type": "string" } }, "required": ["type", "id"] } } } }, "responses": { "200": { "description": "packaged skill bytes + manifest summary" } } } },
            "/team/review": { "post": { "operationId": "teamReview", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "package_b64": { "type": "string" } }, "required": ["package_b64"] } } } }, "responses": { "200": { "description": "review findings without import" } } } },
            "/team/import": { "post": { "operationId": "teamImport", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "package_b64": { "type": "string" } }, "required": ["package_b64"] } } } }, "responses": { "200": { "description": "imported or blocked with findings" } } } },
            "/team/versions": { "get": { "operationId": "teamVersions", "parameters": [{ "name": "id", "in": "query", "required": true, "schema": { "type": "string" } }], "responses": { "200": { "description": "team package version history" } } } },
            "/team/audit": { "get": { "operationId": "teamAudit", "responses": { "200": { "description": "team api audit tail" } } } },
            // R13 WorkSwarm S0（§8.5）：多 Agent 协同运行 + Project Space + 模板注册表。
            "/teams": { "post": { "operationId": "workswarmCreateTeam", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "goal_id": { "type": "string" }, "parent_session_id": { "type": "string", "description": "optional REPL session; server snapshots bounded same-workspace user constraints" }, "objective": { "type": "string" }, "mode": { "type": "string", "enum": ["single", "team", "swarmflow"] }, "template_id": { "type": "string" }, "roles": { "type": "array", "items": { "type": "object" } }, "budget": { "type": "object" }, "human_policy": { "type": "string" }, "strategy": { "type": "string", "enum": ["auto", "single", "team"], "description": "五期组队策略（缺省 auto：按任务画像判定，不再盲目启用多 Agent）；未知值 400" }, "workspace": { "type": "object", "description": "六期（可选）：绑定真实项目工作区；缺省 = 服务端默认工作区", "properties": { "root": { "type": "string", "description": "项目目录（绝对路径）" }, "read_only": { "type": "boolean", "description": "缺省 true（只读）；写入需允许路径+权限审批" }, "write_allowed_paths": { "type": "array", "items": { "type": "string" }, "description": "相对 root 的允许写入路径" }, "tree_depth": { "type": "integer", "description": "目录树展示深度（1-8）" } }, "required": ["root"] } }, "required": ["objective"] } } } }, "responses": { "202": { "description": "team run created; background run loop drives phases；body 含 strategy_decision（组队决策：mode/roles/parallelism/budget_calls_total/reasons，供 UI 渲染组队理由与调用预算）与 workspace（六期绑定回显）" } } }, "get": { "operationId": "workswarmListTeams", "responses": { "200": { "description": "team run list; items = TeamRun + 进程内运行标志（R2 additive）", "content": { "application/json": { "schema": { "type": "object", "properties": { "teams": { "type": "array", "items": { "type": "object", "description": "TeamRun 字段（透传）+ 以下运行标志；additive 不改变既有字段", "properties": { "active": { "type": "boolean", "description": "运行循环正在执行阶段（人节点等待窗口 / 终态为 false）" }, "interrupted": { "type": "boolean", "description": "R2：磁盘 Running 但无活动运行 → 已识别为中断，等待显式 continue/retry 恢复" } } } } }, "required": ["teams"] } } } } } } },
            "/teams/{id}": { "get": { "operationId": "workswarmGetTeam", "parameters": [path_param("id")], "responses": { "200": { "description": "team + task view + audit tail; R2 additive: interrupted", "content": { "application/json": { "schema": { "type": "object", "properties": { "team": { "type": "object", "description": "TeamRun（透传）" }, "interrupted": { "type": "boolean", "description": "R2：中断标记（请求时先做一次幂等中断识别）" }, "tasks": { "type": "object", "description": "任务视图（步骤 × 状态）" }, "audit_tail": { "type": "array", "items": { "type": "object", "properties": { "ts": { "type": "string" }, "event": { "type": "string" }, "detail": { "type": "string" } } } } ,"worker_profiles": { "type": "array", "nullable": true, "description": "七期（二路 wire）additive：按角色 WorkerProfile（工具权限 + 调用预算）；旧记录缺失 → UI 缺省空/false/null", "items": { "type": "object", "properties": { "role": { "type": "string" }, "visible_tools": { "type": "array", "items": { "type": "string" } }, "read_only": { "type": "boolean" }, "write_allowed_paths": { "type": "array", "nullable": true, "items": { "type": "string" } }, "max_turns": { "type": "integer", "nullable": true }, "can_use_browser": { "type": "boolean" }, "can_run_command": { "type": "boolean" } }, "required": ["role", "visible_tools", "read_only", "can_use_browser", "can_run_command"] } },"write_lease": { "type": "object", "nullable": true, "description": "七期（二路 wire）additive：单一写租约（null = 未持有；取消中团队状态 stopping/stopped 渲染为 正在停止/已停止）", "properties": { "holder_role": { "type": "string" }, "holder_step_id": { "type": "string" }, "acquired_at_ms": { "type": "integer" }, "released_at_ms": { "type": "integer", "nullable": true } }, "required": ["holder_role", "holder_step_id", "acquired_at_ms"] },"changes": { "type": "array", "nullable": true, "description": "七期（二路 wire）additive：文件变更列表（与既有 workspace git-status 路由可互用；diff 预览容错读 diff / diff_content 双键）", "items": { "type": "object", "properties": { "path": { "type": "string" }, "state": { "type": "string", "enum": ["added", "modified", "deleted"] }, "added_lines": { "type": "integer", "nullable": true }, "deleted_lines": { "type": "integer", "nullable": true }, "diff": { "type": "string", "nullable": true, "description": "可选：该文件的 unified diff（UI 容错读 diff / diff_content 双键）" } }, "required": ["path", "state"] } }}, "required": ["team", "interrupted", "tasks", "audit_tail"] } } } }, "404": { "description": "unknown team" } } } },
            "/teams/{id}/context": {
                "get": { "operationId": "workswarmReadTeamContext", "parameters": [path_param("id")], "responses": { "200": { "description": "versioned team facts with bounded CAS content" }, "404": { "description": "unknown team" } } },
                "post": { "operationId": "workswarmPublishTeamContext", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "expected_revision": { "type": "integer", "format": "int64" }, "key": { "type": "string" }, "value": { "type": "string", "maxLength": 65536 }, "producer": { "type": "string" }, "task_id": { "type": "string", "nullable": true }, "source_refs": { "type": "array", "items": { "type": "string" } }, "file_hash": { "type": "string", "nullable": true } }, "required": ["expected_revision", "key", "value", "producer"] } } } }, "responses": { "201": { "description": "candidate fact published" }, "400": { "description": "invalid fact" }, "404": { "description": "unknown team" }, "409": { "description": "stale expected_revision" } } }
            },
            "/teams/{id}/tasks": { "get": { "operationId": "workswarmGetTeamTasks", "parameters": [path_param("id")], "responses": { "200": { "description": "team task graph (step x status)" } } } },
            "/teams/{id}/events": { "get": { "operationId": "workswarmTeamEvents", "parameters": [path_param("id"), { "name": "Last-Event-ID", "in": "header", "required": false, "schema": { "type": "string" }, "description": "审计事件断线续传游标（时间戳 + 团队内序号）；缺省重放最近 50 条" }, { "name": "format", "in": "query", "required": false, "schema": { "type": "string", "enum": ["json"] } }], "responses": { "200": { "description": "SSE team event stream (audit replay frames {type:audit,ts,event,detail} + state frames {type:state,status,active,interrupted}; ends at terminal); ?format=json 返回一次性快照（见 content schema，R2 additive: interrupted）", "content": { "application/json": { "schema": { "type": "object", "properties": { "team_id": { "type": "string" }, "status": { "type": "string", "description": "Debug 格式团队状态（如 Running / Created / Completed）" }, "active": { "type": "boolean" }, "interrupted": { "type": "boolean", "description": "R2：中断标记（磁盘 Running 但无活动运行）" }, "audit": { "type": "array", "items": { "type": "object", "properties": { "ts": { "type": "string" }, "event": { "type": "string" }, "detail": { "type": "string" } } } } }, "required": ["team_id", "status", "active", "interrupted", "audit"] } } } }, "401": { "description": "missing or invalid bearer token" }, "404": { "description": "unknown team" } } } },
            "/teams/{id}/steer": { "post": { "operationId": "workswarmSteerTeam", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "command": { "type": "string", "enum": ["continue", "retry", "steer", "replace", "cancel"], "description": "R2 冻结契约：retry 局部重试 = { command: retry, step_id, note }，仅允许指定一个 Failed/Aborted/中断中的步骤" }, "step_id": { "type": "string", "description": "retry 必填（缺失/空 → 400）；steer 可选（空 = 全部未完成节点）" }, "new_input": { "type": "object", "description": "steer 专用：合并进步骤输入" }, "note": { "type": "string", "description": "retry/steer/replace 的变更理由（进入 DecisionRecord）" }, "role": { "type": "string", "description": "replace 专用：目标角色" }, "new_worker": { "type": "string", "description": "replace 专用：agent 节点新 worker" }, "new_user_id": { "type": "string", "description": "replace 专用：人节点新用户 ID" } }, "required": ["command"] } } } }, "responses": { "200": { "description": "steer applied (only uncompleted nodes; DecisionRecord kept)", "content": { "application/json": { "schema": { "type": "object", "properties": { "team_id": { "type": "string" }, "status": { "type": "string", "description": "Debug 格式团队状态" }, "interrupted": { "type": "boolean", "description": "R2：中断标记（continue/retry 成功恢复后为 false）" } }, "required": ["team_id", "status", "interrupted"] } } } }, "400": { "description": "validation failed（retry 缺 step_id / 未知 command）" }, "404": { "description": "unknown team or step" }, "409": { "description": "run is active（retry 目标已成功同样 409，重复发送无额外副作用）" } } } },
            "/projects/{id}": { "get": { "operationId": "workswarmGetProjectSpace", "parameters": [path_param("id")], "responses": { "200": { "description": "project space summary (tasks/artifacts/decisions/activity)" } } } },
            "/projects/{id}/artifacts": { "get": { "operationId": "workswarmListArtifacts", "parameters": [path_param("id")], "responses": { "200": { "description": "versioned shared artifacts (content via CAS ref)；五期 additive：每项含 supersedes_artifact_id（返工重跑登记时指向前版，前端按此合并版本时间线/v1v2 差异；null = 首版）", "content": { "application/json": { "schema": { "type": "object", "properties": { "project_id": { "type": "string" }, "artifacts": { "type": "array", "items": { "type": "object", "additionalProperties": true, "properties": { "artifact_id": { "type": "string" }, "kind": { "type": "string" }, "version": { "type": "integer" }, "producer": { "type": "string" }, "content_ref": { "type": "string" }, "review_state": { "type": "string" }, "supersedes_artifact_id": { "type": "string", "nullable": true }, "preview": { "type": "string" }, "validation": { "type": "object", "description": "七期（三路）additive：格式校验 {format, valid, reason?}", "properties": { "format": { "type": "string" }, "valid": { "type": "boolean" }, "reason": { "type": "string", "nullable": true } } }, "sha256": { "type": "string", "description": "七期（三路）additive：内容 SHA256（hex）" }, "size_bytes": { "type": "integer", "description": "七期（三路）additive：内容字节数" }, "evidence_refs": { "type": "array", "items": { "type": "string" }, "description": "七期（三路）additive：证据引用" } } } } }, "required": ["project_id", "artifacts"] } } } } } } },
            "/tasks/{id}/handoff": { "post": { "operationId": "workswarmSubmitHandoff", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "team_id": { "type": "string" }, "from_member": { "type": "string" }, "to_member": { "type": "string" }, "completed_summary": { "type": "string" }, "open_issues": { "type": "array", "items": { "type": "string" } }, "output_artifact_refs": { "type": "array", "items": { "type": "string" } }, "evidence_refs": { "type": "array", "items": { "type": "string" } }, "suggested_next_actions": { "type": "array", "items": { "type": "string" } }, "known_risks": { "type": "array", "items": { "type": "string" } } }, "required": ["team_id", "from_member"] } } } }, "responses": { "200": { "description": "structured handoff recorded" } } } },
            "/tasks/{id}/human-result": { "post": { "operationId": "workswarmSubmitHumanResult", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "team_id": { "type": "string" }, "result": { "type": "string" } }, "required": ["team_id", "result"] } } } }, "responses": { "200": { "description": "human node result recorded; downstream wakes automatically" } } } },
            "/teams/templates": { "get": { "operationId": "workswarmListTemplates", "responses": { "200": { "description": "adopted team templates" } } } },
            "/teams/templates/proposals": { "get": { "operationId": "workswarmListTemplateProposals", "responses": { "200": { "description": "team template proposals (proposal only, never auto-enabled)" } } } },
            "/teams/templates/proposals/{proposal_id}/adopt": { "post": { "operationId": "workswarmAdoptTemplateProposal", "parameters": [path_param("proposal_id")], "responses": { "200": { "description": "proposal adopted into template registry (idempotent)" } } } },
            "/teams/templates/proposals/{proposal_id}/reject": { "post": { "operationId": "workswarmRejectTemplateProposal", "parameters": [path_param("proposal_id")], "responses": { "200": { "description": "proposal rejected (record kept, auditable)" }, "404": { "description": "proposal not found" }, "400": { "description": "proposal already adopted" } } } },
            // V1 四期（第三路）：Artifact 评审闭环（版本链 + 不可变评审记录 + approved head）。
            "/artifacts/{id}/review": { "post": { "operationId": "artifactSubmitReview", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "team_id": { "type": "string" }, "decision": { "type": "string", "enum": ["approve", "request_changes", "reject"], "description": "评审决定（snake_case）" }, "reviewer": { "type": "string", "description": "评审者（member_id / user_id / 角色名）" }, "comment": { "type": "string" }, "expected_version": { "type": "integer", "description": "乐观并发目标版本；缺省跳过版本校验；不符 → 409" }, "idempotency_key": { "type": "string", "description": "幂等键；同键重放零副作用返回既有记录" } }, "required": ["team_id", "decision", "reviewer", "idempotency_key"] } } } }, "responses": { "201": { "description": "review recorded; body = { replayed: false, review, artifact, approved_head }", "content": { "application/json": { "schema": { "type": "object", "properties": { "replayed": { "type": "boolean" }, "review": { "$ref": "#/components/schemas/ArtifactReviewRecord" }, "artifact": { "type": "object", "additionalProperties": true, "description": "评审后的 Artifact（review_state 已迁移）" }, "approved_head": { "type": "object", "nullable": true, "additionalProperties": true, "description": "decision=approve 时的 (project, kind) approved head Artifact" } }, "required": ["replayed", "review", "artifact"] } } } }, "200": { "description": "idempotent replay（同幂等键重放，零副作用；replayed: true）", "content": { "application/json": { "schema": { "type": "object", "properties": { "replayed": { "type": "boolean", "description": "恒为 true（回放既有记录）" }, "review": { "$ref": "#/components/schemas/ArtifactReviewRecord" }, "artifact": { "type": "object", "additionalProperties": true, "description": "评审后的 Artifact（当前状态）" }, "approved_head": { "type": "object", "nullable": true, "additionalProperties": true, "description": "decision=approve 时的 (project, kind) approved head Artifact" } }, "required": ["replayed", "review", "artifact"] } } } }, "400": { "description": "validation failed（未知 decision；缺必填字段为 Json extractor 422）" }, "403": { "description": "producer self-approve without human policy authorization（需 self_review_allowed）" }, "404": { "description": "artifact or team not found" }, "409": { "description": "expected_version stale（旧页面提交）/ artifact superseded / idempotency key reused on other artifact" }, "422": { "description": "missing required field（team_id/decision/reviewer/idempotency_key）" } } } },
            "/artifacts/{id}/history": { "get": { "operationId": "artifactReviewHistory", "parameters": [path_param("id")], "responses": { "200": { "description": "review history (asc) + version chain (supersedes/superseded_by) + approved head", "content": { "application/json": { "schema": { "type": "object", "properties": { "artifact_id": { "type": "string" }, "kind": { "type": "string" }, "version": { "type": "integer" }, "producer": { "type": "string" }, "review_state": { "type": "string", "enum": ["draft", "pending_review", "approved", "rejected", "superseded"] }, "supersedes_artifact_id": { "type": "string", "nullable": true }, "superseded_by": { "type": "string", "nullable": true }, "reviews": { "type": "array", "items": { "$ref": "#/components/schemas/ArtifactReviewRecord" } }, "approved_head": { "type": "object", "nullable": true, "additionalProperties": true, "description": "(project, kind) 的当前 approved head Artifact（指向真实存在且已批准版本；否则 null）" } }, "required": ["artifact_id", "kind", "version", "producer", "review_state", "reviews", "approved_head"] } } } }, "404": { "description": "artifact not found" } } } },
            // 五期（第二路）：Artifact 自动返工与最终交付物。
            "/artifacts/{id}/rework": { "post": { "operationId": "artifactSubmitRework", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "team_id": { "type": "string" }, "review_id": { "type": "string", "description": "要求修改（request_changes）评审记录 id；同一评审仅允许一个返工任务" }, "instruction": { "type": "string", "description": "返工指令（注入重跑步骤输入 rework.instruction）" }, "idempotency_key": { "type": "string", "description": "幂等键；同键/同评审重复请求幂等返回原任务" } }, "required": ["team_id", "review_id", "instruction"] } } } }, "responses": { "201": { "description": "返工意图已持久化并派发（dispatching → requested → completed/failed）；新版本登记后将 v1 标为 Superseded，approved head 不变直至新版本批准" }, "200": { "description": "idempotent replay（同评审/同幂等键重复请求，返回原返工任务）" }, "404": { "description": "artifact / team / review not found" }, "409": { "description": "该评审已创建过返工任务（幂等冲突）或团队状态不允许" } } } },
            // 七期（第三路）：Artifact 交付（内容/元数据）+ 项目交付清单。路由实现位于第三路
            // 模块 artifact_delivery_api.rs，经 artifact_review_api::router 内部合并挂载
            //（#[path] 子模块 artifact_delivery，见 build_router 中既有 .merge(artifact_review_api::router)），
            // 无需本文件额外 merge（重复挂载同路径会 panic）；第四路完成 UI/TS 契约收口。
            "/artifacts/{id}/content": { "get": { "operationId": "artifactContent", "parameters": [path_param("id")], "responses": { "200": { "description": "Artifact 下载/预览载荷（content = 原始文本，非 JSON 编码）", "content": { "application/json": { "schema": { "type": "object", "properties": { "artifact_id": { "type": "string" }, "format": { "type": "string", "enum": ["json", "csv", "research", "markdown"] }, "sha256": { "type": "string" }, "size_bytes": { "type": "integer" }, "content": { "type": "string" } }, "required": ["artifact_id", "format", "sha256", "size_bytes", "content"] } } } }, "404": { "description": "artifact not found" } } } },
            "/artifacts/{id}/metadata": { "get": { "operationId": "artifactMetadata", "parameters": [path_param("id")], "responses": { "200": { "description": "Artifact 元数据：格式校验结果 + SHA256 + 证据引用（handoff 可选，位于既有 handoff 键下）", "content": { "application/json": { "schema": { "type": "object", "properties": { "artifact_id": { "type": "string" }, "team_id": { "type": "string" }, "task_id": { "type": "string", "nullable": true }, "attempt_id": { "type": "string", "nullable": true }, "kind": { "type": "string" }, "format": { "type": "string", "enum": ["json", "csv", "research", "markdown"] }, "version": { "type": "integer" }, "sha256": { "type": "string" }, "size_bytes": { "type": "integer" }, "validation": { "type": "object", "properties": { "format": { "type": "string" }, "valid": { "type": "boolean" }, "reason": { "type": "string", "nullable": true } }, "required": ["format", "valid"] }, "evidence_refs": { "type": "array", "items": { "type": "string" } }, "handoff": { "type": "object", "nullable": true, "additionalProperties": true, "description": "可选：WorkerOutputV1 handoff 记录（谁完成/遗留问题/下一步建议）" } }, "required": ["artifact_id", "team_id", "kind", "format", "version", "sha256", "size_bytes", "validation", "evidence_refs"] } } } }, "404": { "description": "artifact not found" } } } },
            "/projects/{id}/delivery-manifest": { "get": { "operationId": "projectDeliveryManifest", "parameters": [path_param("id")], "responses": { "200": { "description": "项目交付清单（approved 版本概览 + 内容端点相对路径 content_url，供下载/校验）", "content": { "application/json": { "schema": { "type": "object", "properties": { "project_id": { "type": "string" }, "generated_at": { "type": "string" }, "manifest": { "type": "array", "items": { "type": "object", "properties": { "artifact_id": { "type": "string" }, "kind": { "type": "string" }, "format": { "type": "string" }, "version": { "type": "integer" }, "sha256": { "type": "string" }, "size_bytes": { "type": "integer" }, "approved": { "type": "boolean" }, "content_url": { "type": "string", "description": "内容端点相对路径（GET /artifacts/{id}/content）" } }, "required": ["artifact_id", "kind", "format", "version", "sha256", "size_bytes", "approved", "content_url"] } } }, "required": ["project_id", "generated_at", "manifest"] } } } }, "404": { "description": "project not found" } } } },
            "/projects/{id}/deliverables": { "get": { "operationId": "projectDeliverables", "parameters": [path_param("id")], "responses": { "200": { "description": "最终交付物视图：approved = 各 kind 当前已批准版本（供下载/继续使用）；pending = 待评审；rejected_or_superseded = 被驳回/被取代版本（历史保留）", "content": { "application/json": { "schema": { "type": "object", "properties": { "project_id": { "type": "string" }, "approved": { "type": "array", "items": { "type": "object", "additionalProperties": true } }, "pending": { "type": "array", "items": { "type": "object", "additionalProperties": true } }, "rejected_or_superseded": { "type": "array", "items": { "type": "object", "additionalProperties": true } } }, "required": ["project_id", "approved", "pending", "rejected_or_superseded"] } } } }, "404": { "description": "project not found" } } } },
            // 五期（第三路）：TeamRun 角色指标与脱敏诊断导出。
            "/teams/{id}/metrics": { "get": { "operationId": "teamMetrics", "parameters": [path_param("id")], "responses": { "200": { "description": "角色指标：workers[]（起止/耗时/模型调用/token/估算费用/尝试/终态/失败原因/输出 Artifact）+ summary（总墙钟/总调用/总费用/最慢 Worker/失败/返工/产物版本数/预算耗尽原因）；JSONL 持久化，重启可读", "content": { "application/json": { "schema": { "type": "object", "properties": { "team_id": { "type": "string" }, "workers": { "type": "array", "items": { "type": "object", "additionalProperties": true } }, "summary": { "type": "object", "additionalProperties": true } }, "required": ["team_id"] } } } }, "404": { "description": "team not found" } } } },
            "/teams/{id}/diagnostic": { "get": { "operationId": "teamDiagnostic", "parameters": [path_param("id")], "responses": { "200": { "description": "脱敏诊断导出（TeamRun/任务状态/Artifact 与评审记录/Handoff/指标/审计尾迹；凭据、Authorization、完整敏感输入已脱敏）", "content": { "application/json": { "schema": { "type": "object", "additionalProperties": true } } } }, "404": { "description": "team not found" } } } },
            // 六期（第二路）：Project Workspace 真实工作区绑定（默认只读；写入需允许路径+权限审批；规范化阻止 .. / symlink / Junction 越界）。
            "/projects/{id}/workspace": {
              "put": { "operationId": "projectBindWorkspace", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "root": { "type": "string" }, "read_only": { "type": "boolean" }, "write_allowed_paths": { "type": "array", "items": { "type": "string" } }, "tree_depth": { "type": "integer" } }, "required": ["root"] } } } }, "responses": { "200": { "description": "工作区绑定已写入（body = 绑定回显：project_id/root/read_only/write_allowed_paths/tree_depth/bound_at）" }, "400": { "description": "root 不存在/非法或越界路径" }, "404": { "description": "project not found" } } },
              "get": { "operationId": "projectGetWorkspace", "parameters": [path_param("id")], "responses": { "200": { "description": "当前工作区绑定，body = {workspace:{project_id/root/read_only/write_allowed_paths/tree_depth/created_at/root_canonical/write_allowed_canonical}}（UI 容错同时接受顶层形状）", "content": { "application/json": { "schema": { "type": "object", "properties": { "workspace": { "type": "object", "additionalProperties": true, "properties": { "project_id": { "type": "string" }, "team_id": { "type": "string" }, "root": { "type": "string" }, "read_only": { "type": "boolean" }, "write_allowed_paths": { "type": "array", "items": { "type": "string" } }, "tree_depth": { "type": "integer", "nullable": true } } } }, "required": ["workspace"] } } } }, "404": { "description": "project not found" } } }
            },
            "/projects/{id}/workspace/tree": { "get": { "operationId": "projectWorkspaceTree", "parameters": [path_param("id"), { "name": "depth", "in": "query", "schema": { "type": "integer", "description": "目录树深度（1-8，缺省用绑定值）" } }], "responses": { "200": { "description": "扁平目录树（entries:[{path,type:dir|file,size?}]；root/truncated 附加；UI 按路径层级缩进渲染）；工作区未绑定/不存在 → 404", "content": { "application/json": { "schema": { "type": "object", "properties": { "root": { "type": "string" }, "depth": { "type": "integer" }, "truncated": { "type": "boolean" }, "entries": { "type": "array", "items": { "type": "object", "additionalProperties": true, "properties": { "path": { "type": "string" }, "type": { "type": "string", "enum": ["dir", "file"] }, "size": { "type": "integer", "nullable": true } } } } }, "required": ["entries"] } } } }, "404": { "description": "project / workspace not found" } } } },
            "/workspace/tree": { "get": { "operationId": "previewWorkspaceTree", "parameters": [ { "name": "root", "in": "query", "required": true, "schema": { "type": "string", "description": "候选工作区根目录（绝对路径）" } }, { "name": "depth", "in": "query", "schema": { "type": "integer", "description": "目录树深度（1-8，缺省 2）" } } ], "responses": { "200": { "description": "预绑定目录树预览（形状与 /projects/{id}/workspace/tree 一致；root 为 canonical 回显）", "content": { "application/json": { "schema": { "type": "object", "properties": { "root": { "type": "string" }, "depth": { "type": "integer" }, "truncated": { "type": "boolean" }, "entries": { "type": "array", "items": { "type": "object", "additionalProperties": true, "properties": { "path": { "type": "string" }, "type": { "type": "string", "enum": ["dir", "file"] }, "size": { "type": "integer", "nullable": true } } } } }, "required": ["entries"] } } } }, "400": { "description": "root 缺失/非绝对路径/目录不存在/非目录" } } } },
            "/projects/{id}/workspace/git-status": { "get": { "operationId": "projectWorkspaceGitStatus", "parameters": [path_param("id")], "responses": { "200": { "description": "Git 工作区状态：entries = git status --porcelain 行字符串数组（如 \" M path\"/\"?? path\"），另有 root/git（布尔：是否 Git 仓库）/porcelain（原文）；非 Git 仓库 entries 为空数组，不报错", "content": { "application/json": { "schema": { "type": "object", "properties": { "root": { "type": "string" }, "git": { "type": "boolean" }, "porcelain": { "type": "string" }, "entries": { "type": "array", "items": { "type": "string" } } }, "required": ["entries"] } } } }, "404": { "description": "project not found" } } } },
            // 七期（第二路 wire）：Worker 代码变更追踪读取面（workspace_change_tracker 落盘 JSON 的聚合视图）。
            "/projects/{id}/workspace/changes": { "get": { "operationId": "projectWorkspaceChanges", "parameters": [path_param("id")], "responses": { "200": { "description": "七期（二路 wire）additive：Worker 代码变更追踪——changed_files = 全部记录窗口新增变更文件（去重保序）；diff_summary = 最近一条记录的 git diff --stat 摘要；has_violation = 是否存在白名单越界记录（scope_violation）；records = 逐步骤记录（角色/步骤/时刻/变更文件/diff ref/越界原因）；无记录（只读团队/未执行写角色）返回空 records，UI 全字段容错读取", "content": { "application/json": { "schema": { "type": "object", "properties": { "team_id": { "type": "string" }, "git": { "type": "boolean", "description": "最近一条记录是否取得有效 git 快照；无记录为 false" }, "changed_files": { "type": "array", "items": { "type": "string" } }, "diff_summary": { "type": "string", "description": "最近一条记录的 git diff --stat 文本；无记录为空串" }, "has_violation": { "type": "boolean" }, "records": { "type": "array", "items": { "type": "object", "additionalProperties": true, "properties": { "role": { "type": "string" }, "step": { "type": "string" }, "at": { "type": "integer", "description": "记录时刻（Unix 毫秒）" }, "git": { "type": "boolean" }, "changed_files": { "type": "array", "items": { "type": "string" } }, "diff_summary": { "type": "string" }, "diff_ref": { "type": "string", "nullable": true, "description": "diff 补丁文件相对 run_dir 路径；非 git / 无变更为 null" }, "violation": { "type": "string", "nullable": true, "description": "白名单越界原因（scope_violation）；null = 通过" } } } } }, "required": ["team_id", "git", "changed_files", "diff_summary", "has_violation", "records"] } } } }, "404": { "description": "project / team not found" } } } },
            // 八期（第二路 wire）：ChangeSet 审批闭环——写角色执行前快照 / 执行后生成，可接受/拒绝/安全撤销。
            "/teams/{id}/change-sets": { "get": { "operationId": "teamChangeSets", "parameters": [path_param("id")], "responses": { "200": { "description": "八期（二路 wire）：团队的 ChangeSet 列表——change_set 元素含 change_set_id/team_id/step_id/attempt_id/role/base_hashes/result_hashes/changed_files/diff_ref/status/decisions/created_at/resolved_at；status ∈ pending_review|accepted|rejected|reverted|conflicted；未接受 ChangeSet 阻断该团队最终 approved head（change_set_store::approval_block_for_team 门控），UI 全字段容错读取", "content": { "application/json": { "schema": { "type": "object", "properties": { "team_id": { "type": "string" }, "change_sets": { "type": "array", "items": { "type": "object", "additionalProperties": true, "properties": { "change_set_id": { "type": "string" }, "team_id": { "type": "string" }, "step_id": { "type": "string" }, "attempt_id": { "type": "string", "nullable": true }, "role": { "type": "string" }, "base_hashes": { "type": "object", "additionalProperties": true, "description": "执行前文件内容哈希（内容进 CAS）" }, "result_hashes": { "type": "object", "additionalProperties": true, "description": "执行后文件内容哈希" }, "changed_files": { "type": "array", "items": { "type": "string" } }, "diff_ref": { "type": "string", "nullable": true }, "status": { "type": "string", "enum": ["pending_review", "accepted", "rejected", "reverted", "conflicted"] }, "decisions": { "type": "array", "items": { "type": "object", "additionalProperties": true }, "description": "幂等决定记录（accept/reject/revert 只增不改）" }, "created_at": { "type": "string" }, "resolved_at": { "type": "string", "nullable": true } } } } }, "required": ["team_id", "change_sets"] } } } }, "404": { "description": "team not found" } } } },
            "/change-sets/{id}": { "get": { "operationId": "changeSetDetail", "parameters": [path_param("id")], "responses": { "200": { "description": "单个 ChangeSet（形状同 teamChangeSets.change_sets 元素）", "content": { "application/json": { "schema": { "type": "object", "additionalProperties": true, "required": ["change_set_id", "status"], "properties": { "change_set_id": { "type": "string" }, "team_id": { "type": "string" }, "step_id": { "type": "string" }, "attempt_id": { "type": "string", "nullable": true }, "role": { "type": "string" }, "changed_files": { "type": "array", "items": { "type": "string" } }, "diff_ref": { "type": "string", "nullable": true }, "status": { "type": "string", "enum": ["pending_review", "accepted", "rejected", "reverted", "conflicted"] }, "created_at": { "type": "string" }, "resolved_at": { "type": "string", "nullable": true } } } } } }, "404": { "description": "change set not found" } } } },
            "/change-sets/{id}/accept": { "post": { "operationId": "changeSetAccept", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "required": ["idempotency_key"], "properties": { "idempotency_key": { "type": "string", "description": "幂等键：同键重放返回 replayed:true 且零副作用" } } } } } }, "responses": { "200": { "description": "接受变更（幂等重放返回 replayed:true 且零副作用）；accept 保留修改并解除该 ChangeSet 对最终 approved head 的阻断", "content": { "application/json": { "schema": { "type": "object", "additionalProperties": true, "properties": { "change_set": { "type": "object", "additionalProperties": true }, "replayed": { "type": "boolean" } } } } } }, "404": { "description": "change set not found" }, "409": { "description": "已终态（跨动作）或文件被用户再次修改（status=conflicted，不覆盖用户新内容）" } } } },
            "/change-sets/{id}/reject": { "post": { "operationId": "changeSetReject", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "required": ["idempotency_key"], "properties": { "idempotency_key": { "type": "string", "description": "幂等键：同键重放返回 replayed:true 且零副作用" } } } } } }, "responses": { "200": { "description": "拒绝变更（幂等重放返回 replayed:true 且零副作用）；reject 仅恢复该 ChangeSet 修改的文件（新建文件=删除恢复），恢复前逐文件比对当前哈希", "content": { "application/json": { "schema": { "type": "object", "additionalProperties": true, "properties": { "change_set": { "type": "object", "additionalProperties": true }, "replayed": { "type": "boolean" } } } } } }, "404": { "description": "change set not found" }, "409": { "description": "文件被用户再次修改（status=conflicted，不覆盖用户新内容）或已终态跨动作" } } } },
            "/change-sets/{id}/revert": { "post": { "operationId": "changeSetRevert", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "required": ["idempotency_key"], "properties": { "idempotency_key": { "type": "string", "description": "幂等键：同键重放返回 replayed:true 且零副作用" } } } } } }, "responses": { "200": { "description": "安全撤销（幂等重放返回 replayed:true 且零副作用）；仅恢复该 ChangeSet 修改的文件，恢复前比较当前文件哈希：=结果哈希→恢复、=基线哈希→已恢复跳过、否则 409 + status=conflicted", "content": { "application/json": { "schema": { "type": "object", "additionalProperties": true, "properties": { "change_set": { "type": "object", "additionalProperties": true }, "replayed": { "type": "boolean" } } } } } }, "404": { "description": "change set not found" }, "409": { "description": "文件被用户再次修改（status=conflicted，不覆盖用户新内容）或已终态跨动作" } } } },
            // 八期（第三路 wire）：统一 Human Inbox——四类待办（human_result/artifact_review/change_set/step_retry）持久化、领取与直接处理。
            "/human/inbox":{"get":{"operationId":"humanInboxList","parameters":[{"name":"kind","in":"query","required":false,"schema":{"type":"string","enum":["human_result","artifact_review","change_set","step_retry"]}},{"name":"status","in":"query","required":false,"schema":{"type":"string","enum":["open","claimed","resolved"]}},{"name":"team_id","in":"query","required":false,"schema":{"type":"string"}},{"name":"project_id","in":"query","required":false,"schema":{"type":"string"}}],"responses":{"200":{"description":"统一待办列表：items 元素含 item_id/kind/status/assignee/team_id/project_id/target_id/summary/created_at/claimed_at/resolved_at/detail（detail 为按 kind 的领域上下文，开放对象）；counts = 按 kind 计数；服务重启后未处理事项恢复，已解决事项不再出现","content":{"application/json":{"schema":{"type":"object","properties":{"items":{"type":"array","items":{"type":"object","additionalProperties":true,"properties":{"item_id":{"type":"string"},"kind":{"type":"string","enum":["human_result","artifact_review","change_set","step_retry"]},"status":{"type":"string","enum":["open","claimed","resolved"]},"assignee":{"type":"string","nullable":true},"team_id":{"type":"string"},"project_id":{"type":"string"},"target_id":{"type":"string"},"summary":{"type":"string"},"created_at":{"type":"string"},"claimed_at":{"type":"string","nullable":true},"resolved_at":{"type":"string","nullable":true},"detail":{"type":"object","additionalProperties":true}}}},"counts":{"type":"object","additionalProperties":true}},"required":["items","counts"]}}}}}}},
            "/human/inbox/{id}": { "get": { "operationId": "humanInboxItem", "parameters": [path_param("id")], "responses": { "200": { "description": "单条待办（形状同 humanInboxList.items 元素）", "content": { "application/json": { "schema": { "type": "object", "additionalProperties": true, "properties": { "item": { "type": "object", "additionalProperties": true } } } } } }, "404": { "description": "待办不存在" } } } },
            "/human/inbox/{id}/claim": { "post": { "operationId": "humanInboxClaim", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "user": { "type": "string" } }, "required": ["user"] } } } }, "responses": { "200": { "description": "领取成功（同人重复领取幂等返回）{item}" }, "400": { "description": "user 为空" }, "404": { "description": "待办不存在" }, "409": { "description": "已被其他用户领取（同一待办仅允许一个用户处理）" } } } },
            "/human/inbox/{id}/release": { "post": { "operationId": "humanInboxRelease", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "user": { "type": "string" } }, "required": ["user"] } } } }, "responses": { "200": { "description": "释放成功（仅领取者可释放）{item}" }, "400": { "description": "user 为空" }, "404": { "description": "待办不存在" }, "409": { "description": "已被其他用户领取或当前状态不允许" } } } },
            "/human/inbox/{id}/resolve": { "post": { "operationId": "humanInboxResolve", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "additionalProperties": true, "properties": { "user": { "type": "string", "description": "处理人（审计/领取校验；review 类缺省兼作 reviewer）" }, "resolution_id": { "type": "string", "description": "幂等键（兼容别名 idempotency_key）" }, "decision": { "type": "string", "enum": ["approve", "request_changes", "reject"], "description": "artifact_review" }, "action": { "type": "string", "enum": ["accept", "reject"], "description": "change_set" }, "result": { "type": "string", "description": "human_result 结果文本" }, "reviewer": { "type": "string" }, "comment": { "type": "string" }, "expected_version": { "type": "integer" }, "note": { "type": "string" } } } } } }, "responses": { "200": { "description": "按 kind 分派到既有领域能力（Human 结果提交 / Artifact 评审 / ChangeSet accept/reject / Step retry；不绕过原权限与幂等检查）后返回 {resolved:true, replayed, item_id, kind, result}；重放幂等 200", "content": { "application/json": { "schema": { "type": "object", "additionalProperties": true, "properties": { "resolved": { "type": "boolean" }, "replayed": { "type": "boolean" }, "item_id": { "type": "string" }, "kind": { "type": "string" }, "result": { "type": "object", "additionalProperties": true } } } } } }, "400": { "description": "请求体与 kind 不匹配" }, "404": { "description": "待办不存在" }, "409": { "description": "未被领取/已被他人领取/领域冲突（如 artifact 已终态）" } } } },
            // 六期（第三路）：内置团队模板目录（候选仅展示；手动安装后参与自动匹配；安装幂等且不扩大权限）。
            "/teams/templates/catalog": { "get": { "operationId": "teamTemplateCatalog", "responses": { "200": { "description": "内置模板目录（候选区）：每项含 installed 与 template 对象（template_id/name/mode/roles[{role,depends_on,handoff_contract}]）+ budget_calls_per_role[]/completion_criteria[]/tool_scope/artifact_kinds[]/auto_match_keywords；安装经 POST /teams/templates/catalog/{id}/install 后 installed=true 并参与自动匹配", "content": { "application/json": { "schema": { "type": "object", "properties": { "catalog": { "type": "array", "items": { "type": "object", "additionalProperties": true, "properties": { "installed": { "type": "boolean" }, "template": { "type": "object", "additionalProperties": true, "properties": { "template_id": { "type": "string" }, "name": { "type": "string" }, "mode": { "type": "string" } } } } } } }, "required": ["catalog"] } } } } } } },
            "/teams/templates/catalog/{id}/install": { "post": { "operationId": "teamTemplateCatalogInstall", "parameters": [path_param("id")], "responses": { "200": { "description": "首次安装 {installed:true, already_installed:false, template, auto_match, budget_hint}；幂等重放 {installed:false, already_installed:true, note}（不覆盖既有同名模板）。安装后模板进入注册表并参与自动匹配（find_match），不自动扩大文件/命令/网络权限" }, "404": { "description": "template not found in catalog" } } } },
            // R1 DesktopWorld/WorldModel 训练闭环（§8.5/§5.11-5.12）：仿真环境 + 租约 fencing + transition 语料 + 世界模型候选/晋升。
            "/desktop-envs": { "post": { "operationId": "desktopWorldCreateEnv", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "env_id": { "type": "string" }, "task": { "type": "object", "properties": { "task_id": { "type": "string" }, "app": { "type": "string" }, "seed": { "type": "integer" }, "assets": { "type": "object" } }, "required": ["task_id", "app", "seed"] }, "owner": { "type": "string" } }, "required": ["task"] } } } }, "responses": { "200": { "description": "env created: initial lease proof + first-frame WorldStateV1 observation" }, "409": { "description": "env_id already exists" } } } },
            "/desktop-envs/{id}/reset": { "post": { "operationId": "desktopWorldResetEnv", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "task": { "type": "object", "properties": { "task_id": { "type": "string" }, "app": { "type": "string" }, "seed": { "type": "integer" }, "assets": { "type": "object" } }, "required": ["task_id", "app", "seed"] }, "lease": { "type": "object", "properties": { "owner": { "type": "string" }, "token": { "type": "string" }, "epoch": { "type": "integer" } }, "required": ["owner", "token", "epoch"] } }, "required": ["task", "lease"] } } } }, "responses": { "200": { "description": "env reset to task initial state; lease proof returned" }, "404": { "description": "env not found" }, "409": { "description": "lease fencing conflict (stale token/epoch)" } } } },
            "/desktop-envs/{id}/lease": { "post": { "operationId": "desktopWorldLeaseOp", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "op": { "type": "string", "enum": ["acquire", "renew", "release"] }, "lease": { "type": "object", "properties": { "owner": { "type": "string" }, "token": { "type": "string" }, "epoch": { "type": "integer" } }, "required": ["owner", "token", "epoch"] }, "owner": { "type": "string" } }, "required": ["op"] } } } }, "responses": { "200": { "description": "lease acquired/renewed/released; current lease record returned" }, "404": { "description": "env not found" }, "409": { "description": "lease fencing conflict" }, "400": { "description": "renew/release missing lease proof" } } } },
            "/desktop-envs/{id}/observe": { "get": { "operationId": "desktopWorldObserveEnv", "parameters": [path_param("id")], "responses": { "200": { "description": "current WorldStateV1 observation (scene graph + window stack)" }, "404": { "description": "env not found" } } } },
            "/desktop-envs/{id}/step": { "post": { "operationId": "desktopWorldStepEnv", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "action": { "type": "object", "properties": { "action_id": { "type": "string" }, "kind": { "type": "string" }, "semantic_intent": { "type": "string" }, "target_id": { "type": "string" }, "arguments": { "type": "object" }, "risk": { "type": "string" }, "reversible": { "type": "boolean" } }, "required": ["action_id", "kind", "semantic_intent"] }, "lease": { "type": "object", "properties": { "owner": { "type": "string" }, "token": { "type": "string" }, "epoch": { "type": "integer" } }, "required": ["owner", "token", "epoch"] }, "episode_id": { "type": "string" }, "record": { "type": "boolean" }, "task_goal": { "type": "string" }, "history": { "type": "array", "items": { "type": "string" } } }, "required": ["action", "lease"] } } } }, "responses": { "200": { "description": "step executed: before/after state refs, transition id, verdict + reward parts, shadow prediction evaluation" }, "404": { "description": "env not found" }, "409": { "description": "lease fencing conflict (stale token/epoch)" } } } },
            "/desktop-envs/{id}/snapshot": { "post": { "operationId": "desktopWorldSnapshotEnv", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object" } } } }, "responses": { "200": { "description": "snapshot persisted; snapshot_id returned (read path, no lease)" }, "404": { "description": "env not found" } } } },
            "/desktop-envs/{id}/restore": { "post": { "operationId": "desktopWorldRestoreEnv", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "snapshot": { "type": "string" }, "lease": { "type": "object", "properties": { "owner": { "type": "string" }, "token": { "type": "string" }, "epoch": { "type": "integer" } }, "required": ["owner", "token", "epoch"] } }, "required": ["snapshot", "lease"] } } } }, "responses": { "200": { "description": "env restored from snapshot; observation returned" }, "404": { "description": "env or snapshot not found" }, "409": { "description": "lease fencing conflict" } } } },
            "/desktop-envs/{id}/judge": { "post": { "operationId": "desktopWorldJudgeEnv", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "success": { "type": "object", "properties": { "name": { "type": "string" }, "assertions": { "type": "array", "items": { "type": "object" } } }, "required": ["name", "assertions"] } }, "required": ["success"] } } } }, "responses": { "200": { "description": "verdict against success spec (read path, no lease)" }, "404": { "description": "env not found" } } } },
            "/desktop-envs/{id}/inject-fault": { "post": { "operationId": "desktopWorldInjectFault", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "fault": { "type": "object", "properties": { "type": { "type": "string", "enum": ["modal_popup", "element_drift", "sluggish_steps"] }, "text": { "type": "string" }, "element_id": { "type": "string" }, "dx": { "type": "integer" }, "dy": { "type": "integer" }, "steps": { "type": "integer" } }, "required": ["type"] }, "lease": { "type": "object", "properties": { "owner": { "type": "string" }, "token": { "type": "string" }, "epoch": { "type": "integer" } }, "required": ["owner", "token", "epoch"] } }, "required": ["fault", "lease"] } } } }, "responses": { "200": { "description": "fault injected into env" }, "404": { "description": "env not found" }, "409": { "description": "lease fencing conflict" } } } },
            "/world-model/predict": { "post": { "operationId": "worldModelPredict", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "env_id": { "type": "string" }, "action": { "type": "object", "properties": { "action_id": { "type": "string" }, "kind": { "type": "string" }, "semantic_intent": { "type": "string" }, "target_id": { "type": "string" }, "arguments": { "type": "object" } }, "required": ["action_id", "kind", "semantic_intent"] }, "context": { "type": "object" }, "with_advice": { "type": "boolean" }, "candidates": { "type": "array", "items": { "type": "object" } } }, "required": ["env_id", "action"] } } } }, "responses": { "200": { "description": "predicted structural state diff + probability (read path, env unchanged); advice with candidates when with_advice" }, "404": { "description": "env not found" }, "400": { "description": "no active world model (empty transition corpus)" } } } },
            "/world-model/providers": { "get": { "operationId": "worldModelProviders", "responses": { "200": { "description": "active rule model + candidates + per-signature samples + calibration report" } } } },
            "/transitions/{id}": { "get": { "operationId": "transitionGet", "parameters": [path_param("id")], "responses": { "200": { "description": "TransitionTraceV1 record" }, "404": { "description": "transition not found" } } } },
            "/datasets/build": { "post": { "operationId": "datasetBuild", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "config": { "type": "object" }, "env_id": { "type": "string" }, "episode_id": { "type": "string" }, "task_id": { "type": "string" } } } } } }, "responses": { "200": { "description": "dataset built + split; manifest with dataset_id returned" }, "400": { "description": "no transition corpus to build from" } } } },
            "/datasets/{id}/manifest": { "get": { "operationId": "datasetManifest", "parameters": [path_param("id")], "responses": { "200": { "description": "DatasetManifest (splits + counts + build config)" }, "404": { "description": "dataset not found" } } } },
            "/model-candidates": { "post": { "operationId": "modelCandidateRegister", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "candidate_id": { "type": "string", "description": "缺省自动生成 model_id-model_version-<uuid8>" }, "model_id": { "type": "string" }, "model_version": { "type": "string" }, "source": { "type": "string", "description": "来源说明（缺省：手动注册 shadow 起步）" }, "provider_ref": { "$ref": "#/components/schemas/CandidateProviderRef", "description": "可执行 provider 身份声明（缺省 metadata_only；声明≠接线，还需进程内真实接线才积累影子样本）" } }, "required": ["model_id", "model_version"] } } } }, "responses": { "200": { "description": "candidate registered as shadow (never auto-activated); body = ModelCandidate", "content": { "application/json": { "schema": { "$ref": "#/components/schemas/ModelCandidate" } } } }, "409": { "description": "candidate_id already exists" } } } },
            "/model-candidates/{id}/promote": { "post": { "operationId": "modelCandidatePromote", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "ack": { "type": "boolean" }, "reason": { "type": "string" } }, "required": ["ack", "reason"] } } } }, "responses": { "200": { "description": "candidate promoted to active provider (human ack required); body = { candidate, active, previous_active, samples, gates }", "content": { "application/json": { "schema": { "type": "object", "properties": { "candidate": { "$ref": "#/components/schemas/ModelCandidate" }, "active": { "type": "string" }, "previous_active": { "type": "string", "nullable": true }, "samples": { "type": "integer", "format": "int64", "description": "真实影子样本数" }, "gates": { "type": "object", "description": "晋升门控明细快照（审计口径）", "properties": { "min_shadow_samples": { "type": "integer", "format": "int64" }, "provider_wired": { "type": "object", "properties": { "kind": { "type": "string" }, "locator": { "type": "string" } }, "required": ["kind", "locator"] }, "calibration_summary": { "allOf": [{ "$ref": "#/components/schemas/CalibrationReport" }] }, "regression_check": { "type": "object", "nullable": true, "description": "相对上一任 active 的退化检查（无前任或前任无样本时为 null）", "properties": { "previous_active": { "type": "string" }, "previous_samples": { "type": "integer", "format": "int64" }, "hit_rate_delta": { "type": "number" }, "mean_delta_jaccard_delta": { "type": "number" }, "mean_calibration_error_delta": { "type": "number" }, "max_regression_delta": { "type": "number" }, "passed": { "type": "boolean" } } } }, "required": ["min_shadow_samples", "provider_wired", "calibration_summary"] } }, "required": ["candidate", "active", "previous_active", "samples", "gates"] } } } }, "404": { "description": "candidate not found" }, "400": { "description": "ack=false or empty reason" }, "422": { "description": "governance gate refused（metadata_only / 未接线 / 样本不足 / 相对前任退化超阈值）" } } } },
            "/eval/gate/run": { "post": { "operationId": "evalGateRun", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "suite": { "type": "string" }, "model": { "type": "string" } } } } } }, "responses": { "200": { "description": "eval report or skipped reason" } } } },
            "/eval/gate/report": { "get": { "operationId": "evalGateReport", "parameters": [{ "name": "file", "in": "query", "required": false, "schema": { "type": "string" }, "description": "报告文件名；省略时返回最新报告" }], "responses": { "200": { "description": "latest or selected eval report" }, "400": { "description": "invalid report file name" }, "404": { "description": "report not found" } } } },
            "/eval/gate/reports": { "get": { "operationId": "evalGateReports", "responses": { "200": { "description": "eval report history" } } } },
            "/schemas": { "get": { "operationId": "schemasList", "responses": { "200": { "description": "JSON Schema 版本化发布索引（plugin-manifest/owskill/owflow）" } } } },
            "/schemas/{kind}/{version}": { "get": { "operationId": "schemaGet", "parameters": [path_param("kind"), path_param("version")], "responses": { "200": { "description": "JSON Schema (draft-07)" } } } },
            "/metrics/overview": { "get": { "operationId": "metricsOverview", "responses": { "200": { "description": "aggregated traces/tools/approvals metrics" } } } },
            "/metrics/turns": { "get": { "operationId": "metricsTurns", "parameters": [{ "name": "limit", "in": "query", "required": false, "schema": { "type": "integer" } }], "responses": { "200": { "description": "recent turn durations" } } } },
            "/metrics/tools": { "get": { "operationId": "metricsTools", "responses": { "200": { "description": "tool call frequency and failure ranking" } } } },
            "/metrics/health": { "get": { "operationId": "metricsHealth", "responses": { "200": { "description": "component health checklist" } } } },
            "/memory/graph/entries": { "get": { "operationId": "memoryGraphEntries", "parameters": [{ "name": "app", "in": "query", "required": false, "schema": { "type": "string" } }, { "name": "from", "in": "query", "required": false, "schema": { "type": "string" } }, { "name": "to", "in": "query", "required": false, "schema": { "type": "string" } }, { "name": "limit", "in": "query", "required": false, "schema": { "type": "integer" } }], "responses": { "200": { "description": "structured memory entries" } } } },
            "/memory/graph/timeline": { "get": { "operationId": "memoryGraphTimeline", "parameters": [{ "name": "from", "in": "query", "required": false, "schema": { "type": "string" } }, { "name": "to", "in": "query", "required": false, "schema": { "type": "string" } }], "responses": { "200": { "description": "time-bucketed timeline" } } } },
            "/memory/graph/entities": { "get": { "operationId": "memoryGraphEntities", "parameters": [{ "name": "limit", "in": "query", "required": false, "schema": { "type": "integer" } }], "responses": { "200": { "description": "entity/tag aggregation" } } } },
            "/memory/graph/links": { "get": { "operationId": "memoryGraphLinks", "responses": { "200": { "description": "manual relation list" } } } },
            "/memory/graph/link": { "post": { "operationId": "memoryGraphLinkAdd", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "a": { "type": "string" }, "b": { "type": "string" }, "relation": { "type": "string" }, "note": { "type": "string" } }, "required": ["a", "b", "relation"] } } } }, "responses": { "201": { "description": "relation added" } } }, "delete": { "operationId": "memoryGraphLinkDelete", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "a": { "type": "string" }, "b": { "type": "string" }, "relation": { "type": "string" } }, "required": ["a", "b", "relation"] } } } }, "responses": { "200": { "description": "relation removed" } } } },
            "/memory/graph/recall": { "get": { "operationId": "memoryGraphRecall", "parameters": [{ "name": "q", "in": "query", "required": true, "schema": { "type": "string" } }, { "name": "top_k", "in": "query", "required": false, "schema": { "type": "integer" } }], "responses": { "200": { "description": "recall with entity hits" } } } },
            "/intent/parse": { "post": { "operationId": "intentParse", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "text": { "type": "string" } }, "required": ["text"] } } } }, "responses": { "200": { "description": "parsed intent with args and confidence" } } } },
            "/command/run": { "post": { "operationId": "commandRun", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "mode": { "type": "string" }, "text": { "type": "string" }, "wav_b64": { "type": "string" } }, "required": ["mode"] } } } }, "responses": { "200": { "description": "intent routed to action with results" } } } },
            "/command/audit": { "get": { "operationId": "commandAudit", "responses": { "200": { "description": "command execution audit tail" } } } },
            "/workflow/run/{run_id}/approval": { "post": { "operationId": "workflowRunApproval", "parameters": [path_param("run_id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "decision": { "type": "string" } }, "required": ["decision"] } } } }, "responses": { "200": { "description": "approval decision recorded" } } } },
            "/workflow/run/{run_id}/events": { "get": { "operationId": "workflowRunEvents", "parameters": [path_param("run_id")], "responses": { "200": { "description": "SSE run event stream (requires Bearer)" }, "401": { "description": "missing or invalid bearer token" } } } },
            "/events/stream": { "get": { "operationId": "eventsStream", "security": [{ "bearerAuth": [] }], "parameters": [{ "name": "last_event_id", "in": "query", "required": false, "schema": { "type": "integer" }, "description": "续传起点（调试/脚本用；缺省=新订阅只收新事件，0=显式全量重放历史）" }, { "name": "Last-Event-ID", "in": "header", "required": false, "schema": { "type": "integer" }, "description": "断线续传起点（优先于 query 参数；缺省=只收新事件）" }], "responses": { "200": { "description": "reliable SSE event stream（带 Last-Event-ID 时零丢失续传重放；新订阅从当前 head 起只收新事件 + 有界背压；需 Bearer fetch-stream）" }, "401": { "description": "missing or invalid bearer token" } } } },
            "/metrics/runtime": { "get": { "operationId": "metricsRuntime", "responses": { "200": { "description": "runtime process metrics" } } } },
            "/metrics/slo": { "get": { "operationId": "metricsSlo", "responses": { "200": { "description": "SLO registry with error budget and attainment status" } } } },
            "/metrics/slo/alerts": { "get": { "operationId": "metricsSloAlerts", "responses": { "200": { "description": "SLO alert rules and structured alert events" } } } },
            "/metrics/slo/report": { "get": { "operationId": "metricsSloReport", "parameters": [{ "name": "days", "in": "query", "required": false, "schema": { "type": "integer" } }], "responses": { "200": { "description": "SLO period report (JSON)" } } } },
            "/metrics/prometheus": { "get": { "operationId": "metricsPrometheus", "responses": { "200": { "description": "Prometheus text exposition format" } } } },
            "/diagnostics/requests": { "get": { "operationId": "diagnosticsRequests", "summary": "开发诊断：安全请求 ledger（R3 §8.1）", "parameters": [{ "name": "limit", "in": "query", "required": false, "schema": { "type": "integer", "minimum": 1, "maximum": 512, "description": "取最近 N 条（缺省 200，上限=环形容量）" } }], "responses": { "200": { "description": "环形窗口报告：total/returned/cap/aggregates{health,auth_token,business}/records[]；records 每条严格六字段（method,route_template,started_at,duration_ms,status,source），禁止出现 Authorization/查询串/请求体/响应体/私人路径", "content": { "application/json": { "schema": { "type": "object", "required": ["total", "returned", "cap", "aggregates", "records"], "properties": { "total": { "type": "integer" }, "returned": { "type": "integer" }, "cap": { "type": "integer" }, "aggregates": { "type": "object", "required": ["health", "auth_token", "business"], "properties": { "health": { "type": "integer" }, "auth_token": { "type": "integer" }, "business": { "type": "integer" } } }, "records": { "type": "array", "items": { "type": "object", "required": ["method", "route_template", "started_at", "duration_ms", "status", "source"], "properties": { "method": { "type": "string" }, "route_template": { "type": "string" }, "started_at": { "type": "string", "description": "RFC3339 毫秒 UTC" }, "duration_ms": { "type": "integer" }, "status": { "type": "integer" }, "source": { "type": "string", "description": "x-owo-client 头消毒值（[a-z0-9_-]{1,32}），异常/缺失→other" } } } } } } } } }, "401": { "description": "缺少或非法 bearer token" } } } },
            "/auth/token": { "get": { "operationId": "authTokenBootstrap", "security": [], "responses": { "200": { "description": "development bootstrap token; desktop release requires an ephemeral process-pairing proof header" }, "403": { "description": "desktop process pairing proof missing or invalid" } } } },
            "/storage/backup": { "post": { "operationId": "storageBackup", "responses": { "200": { "description": "zip backup (b64 + saved path)" } } } },
            "/storage/restore": { "post": { "operationId": "storageRestore", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "archive_b64": { "type": "string" } }, "required": ["archive_b64"] } } } }, "responses": { "200": { "description": "restore result with pre-backup" } } } },
            "/storage/export": { "post": { "operationId": "storageExport", "responses": { "200": { "description": "full standard JSON export" } } } },
            "/storage/clear": { "post": { "operationId": "storageClear", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "confirm": { "type": "string", "enum": ["CLEAR_ALL"] } } } } } }, "responses": { "200": { "description": "cleared with integrity check" } } } },
            "/server/status": { "get": { "operationId": "serverStatus", "responses": { "200": { "description": "concurrency gate + storage migration status" } } } },
            "/server/shutdown": { "post": { "operationId": "serverShutdown", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "confirm": { "type": "boolean" } }, "required": ["confirm"] } } } }, "responses": { "200": { "description": "graceful shutdown requested" } } } },
            "/usage/summary": { "get": { "operationId": "usageSummaryV2", "responses": { "200": { "description": "four-dimension usage aggregation + budget hard-stop state" } } } },
            "/usage/records": { "get": { "operationId": "usageRecords", "parameters": [{ "name": "dimension", "in": "query", "required": false, "schema": { "type": "string", "enum": ["session", "workflow_run", "goal_step", "tool"] } }, { "name": "limit", "in": "query", "required": false, "schema": { "type": "integer" } }], "responses": { "200": { "description": "usage records filtered by dimension" } } } },
            "/usage/report": { "get": { "operationId": "usageReport", "parameters": [{ "name": "days", "in": "query", "required": false, "schema": { "type": "integer" } }], "responses": { "200": { "description": "usage aggregation report over window (budget/soak friendly)" } } } },
            "/usage/topup": { "post": { "operationId": "usageTopup", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "amount": { "type": "number" } } } } } }, "responses": { "200": { "description": "budget topped up and hard stop cleared" } } } },
            "/fleet/nodes/register": { "post": { "operationId": "fleetNodesRegister", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "node_id": { "type": "string" }, "card": { "type": "object" } }, "required": ["node_id", "card"] } } } }, "responses": { "200": { "description": "node registered with lease" } } } },
            "/fleet/nodes": { "get": { "operationId": "fleetNodesList", "responses": { "200": { "description": "node status snapshots" } } } },
            "/fleet/nodes/{node_id}/heartbeat": { "post": { "operationId": "fleetNodeHeartbeat", "parameters": [path_param("node_id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "lease_token": { "type": "string" } }, "required": ["lease_token"] } } } }, "responses": { "200": { "description": "lease renewed with latest epoch/token" }, "409": { "description": "stale token or expired lease (fencing)" } } } },
            "/fleet/nodes/{node_id}/tasks": { "get": { "operationId": "fleetNodeTasks", "parameters": [path_param("node_id")], "responses": { "200": { "description": "claimable/claimed tasks for node" } } } },
            "/fleet/tasks/submit": { "post": { "operationId": "fleetTasksSubmit", "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "task_id": { "type": "string" }, "worker": { "type": "string" }, "input": { "type": "object" }, "correlation_id": { "type": "string" }, "lineage": { "type": "array", "items": { "type": "string" } }, "approval_required": { "type": "boolean" } }, "required": ["task_id", "worker", "input"] } } } }, "responses": { "200": { "description": "task submitted with idempotency key" } } } },
            "/fleet/tasks/{id}": { "get": { "operationId": "fleetTaskGet", "parameters": [path_param("id")], "responses": { "200": { "description": "task view with status and events" } } } },
            "/fleet/tasks/{id}/claim": { "post": { "operationId": "fleetTaskClaim", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "node_id": { "type": "string" }, "lease_token": { "type": "string" }, "epoch": { "type": "integer" } }, "required": ["node_id", "lease_token", "epoch"] } } } }, "responses": { "200": { "description": "task claimed by node (fencing verified)" }, "409": { "description": "stale token/epoch or node mismatch" } } } },
            "/fleet/tasks/{id}/progress": { "post": { "operationId": "fleetTaskProgress", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "node_id": { "type": "string" }, "lease_token": { "type": "string" }, "epoch": { "type": "integer" }, "text": { "type": "string" }, "evidence": { "type": "array", "items": { "type": "object" } } }, "required": ["node_id", "lease_token", "epoch", "text"] } } } }, "responses": { "200": { "description": "progress + structured evidence recorded" } } } },
            "/fleet/tasks/{id}/result": { "post": { "operationId": "fleetTaskResult", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "node_id": { "type": "string" }, "lease_token": { "type": "string" }, "epoch": { "type": "integer" }, "ok": { "type": "boolean" }, "output": { "type": "object" }, "output_cas": { "type": "string" }, "evidence": { "type": "array", "items": { "type": "object" } }, "error": { "type": "string" } }, "required": ["node_id", "lease_token", "epoch", "ok"] } } } }, "responses": { "200": { "description": "task result recorded (terminal)" } } } },
            "/fleet/tasks/{id}/cancel-ack": { "post": { "operationId": "fleetTaskCancelAck", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "node_id": { "type": "string" }, "lease_token": { "type": "string" }, "epoch": { "type": "integer" } }, "required": ["node_id", "lease_token", "epoch"] } } } }, "responses": { "200": { "description": "node confirmed cancellation" } } } },
            "/fleet/tasks/{id}/cancel": { "post": { "operationId": "fleetTaskCancel", "parameters": [path_param("id")], "responses": { "200": { "description": "task cancelled" } } } },
            "/fleet/tasks/{id}/events": { "get": { "operationId": "fleetTaskEvents", "parameters": [path_param("id"), { "name": "format", "in": "query", "required": false, "schema": { "type": "string", "enum": ["json"] } }], "responses": { "200": { "description": "SSE task event stream (history replay + live; ?format=json returns array; requires Bearer)" }, "401": { "description": "missing or invalid bearer token" } } } },
            "/fleet/approvals/{id}/respond": { "post": { "operationId": "fleetApprovalRespond", "parameters": [path_param("id")], "requestBody": { "content": { "application/json": { "schema": { "type": "object", "properties": { "decision": { "type": "string", "enum": ["approve", "reject"] }, "approved_by": { "type": "string" } }, "required": ["decision", "approved_by"] } } } }, "responses": { "200": { "description": "approval decision recorded" } } } }
        },
        "components": {
            "schemas": {
                "ArtifactReviewRecord": {
                    "type": "object",
                    "description": "不可变评审记录（V1 四期第三路；只增不改，append-only）",
                    "properties": {
                        "review_id": { "type": "string" },
                        "artifact_id": { "type": "string" },
                        "artifact_version": { "type": "integer", "description": "被评审的产物版本" },
                        "team_id": { "type": "string" },
                        "decision": { "type": "string", "enum": ["approve", "request_changes", "reject"] },
                        "reviewer": { "type": "string" },
                        "comment": { "type": "string" },
                        "idempotency_key": { "type": "string", "description": "唯一约束；同键重放零副作用" },
                        "content_ref": { "type": "string", "description": "评审时的产物内容引用（取证锚点）" },
                        "created_at": { "type": "string" }
                    },
                    "required": ["review_id", "artifact_id", "artifact_version", "team_id", "decision", "reviewer", "idempotency_key", "created_at"]
                },
                "CreateSessionRequest": {
                    "type": "object",
                    "properties": {
                        "workspace": { "type": "string" },
                        "model": { "type": "string" },
                        "system_prompt": { "type": "string" }
                    },
                    "required": ["workspace"]
                },
                "SessionInfo": {
                    "type": "object",
                    "properties": {
                        "id": { "type": "string" },
                        "workspace": { "type": "string" },
                        "updated_at": { "type": "string" },
                        "title": { "type": "string" },
                        "archived": { "type": "boolean" },
                        "pinned": { "type": "boolean" },
                        "parent_id": { "type": "string" },
                        "fork_point": { "type": "integer" },
                        "model": { "type": "string" },
                        "created_at": { "type": "string" }
                    }
                },
                "DesktopModelCredentialBinding": {"type": "object", "additionalProperties": false, "required": ["credential_ref", "model", "base_url"], "properties": {"credential_ref": {"type": "string", "pattern": "^[a-fA-F0-9]{32}$"}, "model": {"type": "string", "maxLength": 200}, "base_url": {"type": "string", "format": "uri"}, "api_format": {"type": "string", "enum": ["openai", "anthropic"]}, "api_key": {"type": ["string", "null"], "writeOnly": true, "maxLength": 8192, "description": "Omit to revoke. Never persisted by this API."}}},
                "SessionTurnHistoryV1": {"type": "object", "properties": {"last_turn_id": {"type": "string"}, "latest_seq": {"type": "integer"}, "last_event_at": {"type": "string"}, "last_event_type": {"type": "string"}, "last_terminal": {"type": ["object", "null"], "properties": {"turn_id": {"type": "string"}, "seq": {"type": "integer"}, "created_at": {"type": "string"}, "payload": {"type": "object", "additionalProperties": true}}}, "last_stats": {"type": ["object", "null"], "properties": {"turn_id": {"type": "string"}, "seq": {"type": "integer"}, "created_at": {"type": "string"}, "payload": {"type": "object", "additionalProperties": true}}}}},
                "SessionDetail": {"type": "object", "properties": {"id": {"type": "string"}, "title": {"type": "string"}, "model": {"type": "string"}, "model_override": {"type": ["string", "null"]}, "workspace": {"type": "string"}, "messages": {"type": "array", "items": {"type": "object", "additionalProperties": true}}, "turn_history": {"anyOf": [{"$ref": "#/components/schemas/SessionTurnHistoryV1"}, {"type": "null"}]}, "turn_history_error": {"type": ["string", "null"]}, "active_turn_id": {"type": ["string", "null"]}, "activity": {"type": ["object", "null"], "additionalProperties": true}}},
                "CustomModelConnection": {"type": "object", "additionalProperties": false, "required": ["model", "base_url"], "description": "Explicit connection for this turn only; credentials are never persisted with sessions or traces.", "properties": {"model": {"type": "string"}, "base_url": {"type": "string", "format": "uri"}, "api_format": {"type": "string", "enum": ["openai", "anthropic"]}, "use_full_url": {"type": "boolean"}, "api_key": {"type": "string", "writeOnly": true}, "api_key_env": {"type": "string", "pattern": "^OWO_CUSTOM_MODEL_SECRET_[a-fA-F0-9]{32}$"}, "temperature": {"type": "number", "minimum": 0, "maximum": 2}, "timeout_secs": {"type": "integer", "minimum": 1, "maximum": 3600}}},
                "TurnRequest": {
                    "type": "object",
                    "properties": {
                        "prompt": { "type": "string" },
                        "model_connection": { "$ref": "#/components/schemas/CustomModelConnection" },
                        "attachments": { "type": "array", "items": { "type": "string" } },
                        "read_only": { "type": "boolean", "description": "Narrow this turn to host-verified read operations; false never relaxes host policy" },
                        "turn_id": { "type": "string", "format": "uuid", "description": "Preallocated identity for scoped cancellation, replay and duplicate suppression" }
                    },
                    "required": ["prompt"]
                },
                "TurnEventRecord": {
                    "type": "object",
                    "properties": {
                        "session_id": { "type": "string" },
                        "turn_id": { "type": "string" },
                        "seq": { "type": "integer", "format": "int64", "minimum": 1 },
                        "created_at": { "type": "string" },
                        "payload": { "type": "object", "description": "Versioned SseEvent payload" }
                    },
                    "required": ["session_id", "turn_id", "seq", "created_at", "payload"]
                },
                "TurnEventReplayPage": {
                    "type": "object",
                    "properties": {
                        "events": { "type": "array", "items": { "$ref": "#/components/schemas/TurnEventRecord" } },
                        "active": { "type": "boolean" },
                        "state": { "type": "string", "enum": ["active", "completed", "failed", "interrupted"] },
                        "next_after_seq": { "type": "integer", "format": "int64", "minimum": 0 }
                    },
                    "required": ["events", "active", "state", "next_after_seq"]
                },
                "EvalRunRequest": {
                    "type": "object",
                    "properties": { "suite_id": { "type": "string" } },
                    "required": ["suite_id"]
                },
                "Error": {
                    "type": "object",
                    "properties": { "error": { "type": "string" } },
                    "required": ["error"]
                },
                "ProductEvalRunSummary": {
                    "type": "object",
                    "description": "ProductEval 运行摘要（列表元素与详情基底；六态：queued/running/cancelled/completed/failed/interrupted）",
                    "properties": {
                        "run_id": { "type": "string" },
                        "suite": { "type": "string" },
                        "execution": { "type": "string", "enum": ["reference", "live"] },
                        "modes": { "type": "array", "items": { "type": "string", "enum": ["single", "workswarm"] } },
                        "repetitions": { "type": "integer" },
                        "category": { "type": ["string", "null"], "enum": ["code", "research", "document", null] },
                        "only": { "type": ["string", "null"] },
                        "model": { "type": ["string", "null"] },
                        "status": { "type": "string", "enum": ["queued", "running", "cancelled", "completed", "failed", "interrupted"] },
                        "created_at": { "type": "string" },
                        "started_at": { "type": ["string", "null"] },
                        "finished_at": { "type": ["string", "null"] },
                        "planned_total": { "type": "integer", "description": "计划单元格总数（modes × cases × repetitions）" },
                        "progress": {
                            "type": "object",
                            "properties": {
                                "done": { "type": "integer", "description": "已完成单元格（journal 行数）" },
                                "total": { "type": "integer", "description": "= planned_total" }
                            },
                            "required": ["done", "total"]
                        },
                        "error": { "type": ["string", "null"] }
                    },
                    "required": ["run_id", "suite", "execution", "modes", "repetitions", "status", "created_at", "planned_total", "progress"]
                },
                "MatrixKey": {
                    "type": "object",
                    "description": "矩阵单元格：(case_id, agent_mode, repetition)；agent_mode 为核心小写词（workswarm 拓扑序列化为 multi）",
                    "properties": {
                        "case_id": { "type": "string" },
                        "agent_mode": { "type": "string", "enum": ["single", "multi"] },
                        "repetition": { "type": "integer" }
                    },
                    "required": ["case_id", "agent_mode", "repetition"]
                },
                "EnablementRule": {
                    "type": "object",
                    "properties": { "name": { "type": "string" }, "satisfied": { "type": "boolean" }, "detail": { "type": "string" } },
                    "required": ["name", "satisfied", "detail"]
                },
                "ModeComparison": {
                    "type": "object",
                    "description": "共享 Team 自动启用结论：质量/成功率守卫、样本量、收益与资源护栏",
                    "properties": {
                        "multi_success_rate_diff": { "type": "number" },
                        "multi_wall_rel_change": { "type": ["number", "null"], "nullable": true },
                        "multi_calls_rel_change": { "type": ["number", "null"], "nullable": true },
                        "multi_tool_calls_rel_change": { "type": ["number", "null"], "nullable": true },
                        "multi_tokens_rel_change": { "type": ["number", "null"], "nullable": true },
                        "multi_cost_rel_change": { "type": ["number", "null"], "nullable": true },
                        "rules": { "type": "array", "items": { "$ref": "#/components/schemas/EnablementRule" } },
                        "alignment_guardrails": { "type": "array", "items": { "$ref": "#/components/schemas/EnablementRule" } },
                        "quality_guardrails": { "type": "array", "items": { "$ref": "#/components/schemas/EnablementRule" } },
                        "resource_guardrails": { "type": "array", "items": { "$ref": "#/components/schemas/EnablementRule" } },
                        "enabled": { "type": "boolean" },
                        "sample_sufficient": { "type": "boolean" }
                    },
                    "required": ["multi_success_rate_diff", "multi_wall_rel_change", "multi_calls_rel_change", "multi_tool_calls_rel_change", "multi_tokens_rel_change", "multi_cost_rel_change", "rules", "alignment_guardrails", "quality_guardrails", "resource_guardrails", "enabled", "sample_sufficient"]
                },
                "ProductEvalRun": {
                    "type": "object",
                    "description": "一次运行的完整记录（journal 最小单元；失败记录同样保留；Option 字段缺数据时序列化为 null）",
                    "properties": {
                        "key": { "$ref": "#/components/schemas/MatrixKey" },
                        "category": { "type": "string", "enum": ["code", "research", "document"] },
                        "status": { "type": "string", "enum": ["passed", "failed", "error", "timeout", "cancelled"], "description": "单元格级状态（核心 RunStatus 小写词）" },
                        "wall_ms": { "type": "integer", "format": "int64" },
                        "model_calls": { "type": "integer" },
                        "tool_calls": { "type": ["integer", "null"], "nullable": true, "description": "精确工具调用数；旧记录或执行器无法观测时为 null" },
                        "prompt_tokens": { "type": ["integer", "null"], "format": "int64", "nullable": true },
                        "completion_tokens": { "type": ["integer", "null"], "format": "int64", "nullable": true },
                        "total_tokens": { "type": ["integer", "null"], "format": "int64", "nullable": true },
                        "cost_usd": { "type": ["number", "null"], "nullable": true },
                        "failed_steps": { "type": "array", "items": { "type": "string" }, "description": "失败步骤（检查器描述/执行器阶段名）" },
                        "retries": { "type": "integer" },
                        "cancellations": { "type": "integer" },
                        "artifact_refs": { "type": "array", "items": { "type": "string" }, "description": "最终 Artifact 引用（沙盒内相对路径）" },
                        "tool_log": { "type": "array", "items": { "type": "string" }, "description": "真实工具调用轨迹（单 Agent 执行器填写：工具+实参摘要+结果；旧记录缺省为空数组）" },
                        "model": { "type": ["string", "null"], "nullable": true },
                        "started_at": { "type": "string" },
                        "finished_at": { "type": "string" },
                        "error": { "type": ["string", "null"], "nullable": true }
                    },
                    "required": ["key", "category", "status", "wall_ms", "model_calls", "tool_calls", "prompt_tokens", "completion_tokens", "total_tokens", "cost_usd", "failed_steps", "retries", "cancellations", "artifact_refs", "tool_log", "model", "started_at", "finished_at", "error"]
                },
                "ProductEvalMetrics": {
                    "type": "object",
                    "description": "聚合指标：成功率分母为全部已尝试运行（失败/错误/超时一律计入，禁止剔除重算）",
                    "properties": {
                        "runs_total": { "type": "integer" },
                        "passed": { "type": "integer" },
                        "failed": { "type": "integer" },
                        "errors": { "type": "integer" },
                        "timeouts": { "type": "integer" },
                        "cancelled": { "type": "integer" },
                        "success_rate": { "type": "number" },
                        "mean_wall_ms": { "type": "number" },
                        "total_model_calls": { "type": "integer", "format": "int64" },
                        "total_tool_calls": { "type": ["integer", "null"], "format": "int64", "nullable": true },
                        "total_tokens": { "type": ["integer", "null"], "format": "int64", "nullable": true },
                        "estimated_cost_usd": { "type": ["number", "null"], "nullable": true }
                    },
                    "required": ["runs_total", "passed", "failed", "errors", "timeouts", "cancelled", "success_rate", "mean_wall_ms", "total_model_calls", "total_tool_calls", "total_tokens", "estimated_cost_usd"]
                },
                "CaseModeMetrics": {
                    "type": "object",
                    "description": "按 (case_id, mode) 分组的细分统计（单 Agent vs WorkSwarm 对照列）",
                    "properties": {
                        "case_id": { "type": "string" },
                        "category": { "type": "string", "enum": ["code", "research", "document"] },
                        "agent_mode": { "type": "string", "enum": ["single", "multi"] },
                        "runs_total": { "type": "integer" },
                        "passed": { "type": "integer" },
                        "success_rate": { "type": "number" },
                        "mean_wall_ms": { "type": "number" },
                        "mean_model_calls": { "type": "number" },
                        "mean_tool_calls": { "type": ["number", "null"], "nullable": true },
                        "total_tokens": { "type": ["integer", "null"], "format": "int64", "nullable": true }
                    },
                    "required": ["case_id", "category", "agent_mode", "runs_total", "passed", "success_rate", "mean_wall_ms", "mean_model_calls", "mean_tool_calls", "total_tokens"]
                },
                "ProductEvalReport": {
                    "type": "object",
                    "description": "ProductEvalReport 原样（core 序列化；聚合全部 journal 记录含失败 + 未完成单元格清单）",
                    "properties": {
                        "schema_version": { "type": "integer" },
                        "suite_name": { "type": "string" },
                        "suite_hash": { "type": "string" },
                        "execution": { "type": "string", "enum": ["reference", "live"] },
                        "model": { "type": ["string", "null"], "nullable": true },
                        "generated_at": { "type": "string" },
                        "runs": { "type": "array", "items": { "$ref": "#/components/schemas/ProductEvalRun" } },
                        "pending": { "type": "array", "items": { "$ref": "#/components/schemas/MatrixKey" } },
                        "metrics": { "$ref": "#/components/schemas/ProductEvalMetrics" },
                        "per_case": { "type": "array", "items": { "$ref": "#/components/schemas/CaseModeMetrics" } },
                        "comparison": { "$ref": "#/components/schemas/ModeComparison", "nullable": true }
                    },
                    "required": ["schema_version", "suite_name", "suite_hash", "execution", "model", "generated_at", "runs", "pending", "metrics", "per_case"]
                },
                "CalibrationReport": {
                    "type": "object",
                    "description": "预测校准报告（WM0 聚合：命中、误差与不确定度分桶）",
                    "properties": {
                        "samples": { "type": "integer", "format": "int64" },
                        "success_hit_rate": { "type": "number" },
                        "mean_calibration_error": { "type": "number" },
                        "mean_delta_jaccard": { "type": "number" },
                        "uncertainty_buckets": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "label": { "type": "string" },
                                    "samples": { "type": "integer", "format": "int64" },
                                    "hit_rate": { "type": "number" }
                                },
                                "required": ["label", "samples", "hit_rate"]
                            }
                        }
                    },
                    "required": ["samples", "success_hit_rate", "mean_calibration_error", "mean_delta_jaccard", "uncertainty_buckets"]
                },
                "CandidateProviderRef": {
                    "description": "候选 provider 身份（§5.12.4 治理，声明≠接线）：external 需进程内真实接线后才积累影子样本；metadata_only 零样本且不可晋升",
                    "oneOf": [
                        {
                            "type": "object",
                            "properties": {
                                "type": { "type": "string", "enum": ["external"] },
                                "kind": { "type": "string", "description": "provider 类型标识（如 wm1-http、local-onnx）" },
                                "locator": { "type": "string", "description": "定位串（端点或资源标识）" }
                            },
                            "required": ["type", "kind", "locator"]
                        },
                        {
                            "type": "object",
                            "properties": {
                                "type": { "type": "string", "enum": ["metadata_only"] }
                            },
                            "required": ["type"]
                        }
                    ]
                },
                "ModelCandidate": {
                    "type": "object",
                    "description": "世界模型候选（新候选恒 shadow 起步，达标后显式人工晋升；Option 字段缺省序列化为 null）",
                    "properties": {
                        "candidate_id": { "type": "string" },
                        "model_id": { "type": "string" },
                        "model_version": { "type": "string" },
                        "source": { "type": "string" },
                        "status": { "type": "string", "enum": ["shadow", "active", "rejected"] },
                        "created_at": { "type": "string", "description": "RFC3339" },
                        "promoted_at": { "type": "string", "nullable": true },
                        "promote_reason": { "type": "string", "nullable": true },
                        "provider": { "$ref": "#/components/schemas/CandidateProviderRef", "description": "provider 身份治理（响应 wire 字段名为 provider；注册请求侧字段名为 provider_ref）" },
                        "calibration_summary": { "allOf": [{ "$ref": "#/components/schemas/CalibrationReport" }], "nullable": true, "description": "晋升时刻的校准摘要快照（从未晋升过为 null）" }
                    },
                    "required": ["candidate_id", "model_id", "model_version", "source", "status", "created_at", "promoted_at", "promote_reason", "provider", "calibration_summary"]
                },
                "HealthResponse": {
                    "type": "object",
                    "description": "/health 响应（十期一路：build 为 additive 字段；§4.2 实例握手字段 additive）",
                    "properties": {
                        "healthy": { "type": "boolean" },
                        "version": { "type": "string" },
                        "api_version": { "type": "string", "description": "桌面壳与核心服务兼容性握手版本" },
                        "auto_approve": { "type": "boolean" },
                        "build": { "$ref": "#/components/schemas/BuildInfo", "nullable": true },
                        "instance_id": { "type": "string", "nullable": true, "description": "桌面壳注入的实例身份（开发模式不序列化）" },
                        "pid": { "type": "integer", "description": "服务进程 pid" },
                        "stage": { "type": "string", "description": "启动阶段（当前恒为 ready）" },
                        "build_id": { "type": "string", "description": "构建标识（git_commit，缺失 unknown）" }
                    },
                    "required": ["healthy", "version", "api_version", "auto_approve"]
                },
                "BuildInfo": {
                    "type": "object",
                    "description": "构建信息（§7.1 单一来源 owo-build-info：编译期烧录优先，OWO_BUILD_INFO 覆写文件兼容发布链）",
                    "properties": {
                        "commit": { "type": "string" },
                        "dirty": { "type": "boolean" },
                        "built_at": { "type": "string" }
                    },
                    "required": ["commit", "dirty", "built_at"]
                }
            },
            "securitySchemes": {
                "bearerAuth": { "type": "http", "scheme": "bearer" }
            }
        },
        "security": [{ "bearerAuth": [] }]
    }))
}

fn path_param(name: &str) -> Value {
    serde_json::json!({ "name": name, "in": "path", "required": true, "schema": { "type": "string" } })
}

/// §4.5.3 结构化权限配置的 OpenAPI 片段（`/permissions/spec` 与快照共用）。
///
/// 四组字面量在这里**只声明一次**，与 `owo_agent_core::permission_spec` 的
/// serde 表、`/permissions/overview` 的 `scope_literals` 以及前端 domain 层
/// 必须一致；改词表时三处一起改（`wire_literals_match_guide` 与
/// `route_contract_tests` 会把不一致判红）。
fn permission_spec_schema() -> Value {
    serde_json::json!({
        "type": "object",
        "properties": {
            "filesystem": { "type": "string", "enum": ["none", "workspace_read", "workspace_write", "custom"] },
            "command": { "type": "string", "enum": ["deny", "allowlisted", "unrestricted"] },
            "network": { "type": "string", "enum": ["deny", "allowlisted", "unrestricted"] },
            "persistence": { "type": "string", "enum": ["once", "task", "workspace"] },
            "scopes": { "type": "array", "items": { "type": "string" }, "description": "工作区相对字面量：path:… / host:… / command:…" }
        },
        "required": ["filesystem", "command", "network", "persistence"]
    })
}
