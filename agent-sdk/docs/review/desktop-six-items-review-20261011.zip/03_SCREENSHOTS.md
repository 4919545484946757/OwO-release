# Actual desktop screenshots

Current Electron source + current debug core, isolated profile. Local scripted-provider session facts; no cloud task submitted from GUI. Empty teams and absent diffs are real fixture states. App zoom 100%/125%/150%, not a full Windows DPI matrix. Raw JPEGs are unchanged.

- [Homepage / 100%](screenshots/01-home-100.jpg)
- [Recent sessions / 100%](screenshots/02-home-recent-100.jpg)
- [Cancelled session evidence / 100%](screenshots/03-evidence-cancelled-100.jpg)
- [Appearance / 125%](screenshots/04-settings-125.jpg)
- [Appearance / 150%](screenshots/05-settings-150.jpg)
- [Main recovery / 100%](screenshots/06-main-recovery-100.jpg)
- [Recovered task draft](screenshots/07-recovery-draft-100.jpg)
- [Main / dark](screenshots/08-main-dark-100.jpg)
- [Legacy team panel / dark](screenshots/09-team-dark-100.jpg)
- [Task wizard / dark](screenshots/10-task-dark-100.jpg)
- [Encrypted custom-model storage](screenshots/11-custom-model-security-dark.jpg)
- [Keyboard feature search](screenshots/12-keyboard-search-dark.jpg)
- [Homepage / dark 100%](screenshots/13-home-dark-100.jpg)
- [Homepage / dark 150%](screenshots/14-home-dark-150.jpg)
- [Homepage body scroll / dark 150%](screenshots/15-home-dark-150-scroll.jpg)
